import 'package:flutter/cupertino.dart';

import '../../model/api_models/user_model/user_model.dart';
import '../../services/api_services/user_services.dart';

class CurrentUserProvider extends ChangeNotifier {
  UserModel? user;

  updateUser(UserModel userData) {
    user = userData;
    notifyListeners();
  }

  getCurrentUser(BuildContext context) {
    UserServices().getCurrentUser(context);
  }

  uploadProfilePicture(String imagePath, BuildContext context) async {
    await UserServices().uploadProfileImage(imagePath, context);
  }
}

class OtherUserProvider extends ChangeNotifier {
  UserModel? user;
  updateUser(UserModel userData) {
    user = userData;
    notifyListeners();
  }

  getOtherUser(BuildContext context, userId) {
    print("Other user provider");

    UserServices().getOtherUser(context, userId);
  }
}
