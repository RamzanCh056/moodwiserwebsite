import 'package:flutter/cupertino.dart';
import '../../model/api_models/chat_model/chat_list_model.dart';
import '../../model/api_models/chat_model/conversation_model.dart';
import '../../model/api_models/store_chat_model/store_chat_model.dart';
import '../../model/api_models/store_chat_model/store_conversation_model.dart';

class ChatProvider extends ChangeNotifier{

  int startMessageId=0;
  List<ChatListModel> chatList=[];
  List<StoreChatModel> storeChatList=[];
  List<ConversationModel> conversationList=[];
  List<StoreConversationModel> storeConversationList=[];

  updateStoreConversationList(List<StoreConversationModel> storeConversation){
    storeConversationList=storeConversation;
    notifyListeners();
  }

  updateStoreChatList(List<StoreChatModel> storeChat){
    storeChatList=storeChat;
    notifyListeners();
  }

  updateStartMessageId(int id){
    startMessageId=id;
    notifyListeners();
  }

  updateConversation(List<ConversationModel> conversation){
    conversationList=conversation;
    notifyListeners();
  }

  updateChatList(List<ChatListModel> chat){
    chatList=chat;
    notifyListeners();
  }


}