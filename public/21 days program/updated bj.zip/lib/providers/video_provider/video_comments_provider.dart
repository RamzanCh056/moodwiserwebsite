import 'package:flutter/material.dart';

import '../../model/api_models/feed_models/feed_comments_model.dart';
import '../../model/api_models/video_models/single_video_comments_model.dart';

class VideoCommentsProvider extends ChangeNotifier{
  List<SingleVideoCommentModel> videoComments=[];

  update(List<SingleVideoCommentModel> comments){
    videoComments.clear();
    videoComments=comments;
    notifyListeners();
  }

}