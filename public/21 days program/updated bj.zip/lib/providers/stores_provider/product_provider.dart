
import 'package:flutter/cupertino.dart';

import '../../model/api_models/store_models/product_model.dart';
import '../../model/api_models/store_models/store_model.dart';

class ProductProvider extends ChangeNotifier{
  List<ProductModel> productList=[];

  updateProducts(List<ProductModel> products){
    productList=products;
    notifyListeners();
  }


}