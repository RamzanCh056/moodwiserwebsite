
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';

import '../../model/api_models/store_models/followed_stores_model.dart';
import '../../services/api_services/store_services/store_follow_services.dart';

class FollowedStoresProvider extends ChangeNotifier{

  List<FollowedStoresModel> followedStores=[];

  getFollowedStores(BuildContext context)async{
    await StoreFollowServices.getAllFollowedStores(context);
  }

  updateFollowedStores( List<FollowedStoresModel> followedStore){
    followedStores=followedStore;
    notifyListeners();
  }


}