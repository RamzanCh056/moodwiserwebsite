import 'package:flutter/cupertino.dart';

import '../../model/api_models/feed_models/current_user_feed_model.dart';

class StoreFeedsProvider extends ChangeNotifier{
  List<CurrentUserFeedsModel> storeFeeds=[];

  updateStoreFeeds(List<CurrentUserFeedsModel> feedsList){
    storeFeeds.clear();
    storeFeeds=feedsList;
    notifyListeners();
  }

}