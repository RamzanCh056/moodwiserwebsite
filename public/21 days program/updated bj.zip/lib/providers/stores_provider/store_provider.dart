
import 'package:flutter/cupertino.dart';

import '../../model/api_models/store_models/store_model.dart';
import '../../model/api_models/store_models/store_profile_model.dart';

class StoreProvider extends ChangeNotifier{
  List<StoreModel> storeList=[];
  StoreProfileModel? store;

  updateStoreProfile(StoreProfileModel newStore){
    store=newStore;
    notifyListeners();
  }

  updateStores(List<StoreModel> stores){
    storeList=stores;
    notifyListeners();
  }


}