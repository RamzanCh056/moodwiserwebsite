import 'package:flutter/material.dart';
import '../../model/api_models/artist_models/artist_model.dart';
import '../../services/api_services/artist_services/artist_services.dart';

class ArtistProvider extends ChangeNotifier{
  List<ArtistModel> artists=[];
  List<ArtistModel> myArtists=[];
  bool isLoading=true;

  updateArtists(List<ArtistModel> artistsList){
    artists=artistsList;
    isLoading=false;
    notifyListeners();
  }

  updateMyArtists(List<ArtistModel> myArtistsList){
    myArtists=myArtistsList;
    isLoading=false;
    notifyListeners();
  }

  getArtists(BuildContext context){
    ArtistServices().getAllArtists(context);
  }

  getMyArtists(BuildContext context){
    isLoading=true;
    ArtistServices().getMyArtists(context);
  }

}