
import 'package:flutter/material.dart';

import '../../model/api_models/artist_models/artist_model.dart';
import '../../model/api_models/artist_models/artist_song_model.dart';
import '../../services/api_services/artist_song_services/artist_song_services.dart';

class ArtistSongsProvider extends ChangeNotifier{
  List<ArtistSongModel> artistSongs=[];

  bool isLoading=true;

  updateArtistSongs(List<ArtistSongModel> artistSongsList){
    artistSongs=artistSongsList;
    isLoading=false;
    notifyListeners();
  }


  getArtistsSongs(BuildContext context,String artistId)async{

    isLoading=true;
    await ArtistSongsServices().getArtistAllSongs(context,artistId);
    isLoading=false;
    notifyListeners();
  }



}