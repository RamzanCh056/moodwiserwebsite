
import 'package:flutter/material.dart';

import '../../model/api_models/feed_models/single_feed_comments_model.dart';
import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../../notification_services/trigger_notification_services.dart';

class CommentsProvider extends ChangeNotifier{
  List<SingleFeedCommentModel> feedComments=[];

  update(List<SingleFeedCommentModel> comments){
    feedComments.clear();
    feedComments=comments;
    notifyListeners();
  }

}

class CommentProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  bool _isLoading = false;
  String? _errorMessage;
  List<Map<String, dynamic>> _comments = [];

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  List<Map<String, dynamic>> get comments => _comments;

  /// Load comments for a specific post
  Future<void> loadComments(String postId) async {
    _setLoading(true);
    try {
      final snapshot = await _firestore
          .collection('posts')
          .doc(postId)
          .collection('comments')
          .orderBy('timestamp', descending: false)
          .get();

      _comments = snapshot.docs.map((doc) {
        final data = doc.data();
        return {
          'id': doc.id,
          'text': data['text'] ?? '',
          'userName': data['userName'] ?? 'User',
          'userId': data['userId'] ?? '',
          'timestamp': data['timestamp'],
          'userImage': data['userImage'] ?? '',
        };
      }).toList();

      _setLoading(false);
    } catch (e) {
      log('Error loading comments: $e');
      _setError("Failed to load comments");
    }
  }

  /// Add a comment
  Future<void> addComment(String postId, String text) async {
    final user = _auth.currentUser;
    if (user == null || text.trim().isEmpty) return;

    _setLoading(true);

    try {
      // Fetch user data for name and image
      final userDoc =
          await _firestore.collection('usersData').doc(user.uid).get();
      final userData = userDoc.data() ?? {};

      final userProfileImage = userData['profileImage'] ?? user.photoURL ?? '';
      final commenterName = userData['firstName'] ?? user.displayName ?? 'User';

      // Create comment
      final commentData = {
        'text': text.trim(),
        'userId': user.uid,
        'userName': commenterName,
        'userImage': userProfileImage,
        'timestamp': FieldValue.serverTimestamp(),
      };

      await _firestore
          .collection('posts')
          .doc(postId)
          .collection('comments')
          .add(commentData);

      // Optimistically add new comment to local list
      _comments.add({
        'text': text,
        'userId': user.uid,
        'userName': commenterName,
        'userImage': userProfileImage,
        'timestamp': Timestamp.now(),
      });
      notifyListeners();

      // Send notification to post owner
      await _sendCommentNotification(commenterName, postId);

      _setLoading(false);
    } catch (e) {
      log('Error adding comment: $e');
      _setError("Failed to add comment");
    }
  }

  /// Send push notification to post owner
  Future<void> _sendCommentNotification(
      String commenterName, String postId) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) return;

      final postDoc = await _firestore.collection('posts').doc(postId).get();
      if (!postDoc.exists) return;

      final postOwnerId = postDoc.data()?['userId'];
      if (postOwnerId == null || postOwnerId == currentUser.uid) return;

      final ownerDoc =
          await _firestore.collection('usersData').doc(postOwnerId).get();
      final fcmToken = ownerDoc.data()?['fcmToken'];

      if (fcmToken != null && fcmToken.isNotEmpty) {
        await TriggerNotificationService().sendPushNotification(
          token: fcmToken,
          title: 'New Comment! 💬',
          body: '$commenterName commented on your post',
        );
      }

      // Save notification in Firestore
      await _firestore
          .collection('notifications')
          .doc(postOwnerId)
          .collection('userNotifications')
          .add({
        'type': 'comment',
        'fromUserId': currentUser.uid,
        'fromUserName': commenterName,
        'postId': postId,
        'timestamp': FieldValue.serverTimestamp(),
        'message': '$commenterName commented on your post',
        'isRead': false,
      });
    } catch (e) {
      log('Error sending comment notification: $e');
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _errorMessage = message;
    _isLoading = false;
    notifyListeners();
  }

  void clear() {
    _comments.clear();
    notifyListeners();
  }

}
