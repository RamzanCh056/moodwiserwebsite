import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../model/music_track_model.dart';
import 'package:flutter/cupertino.dart';
import '../../model/api_models/feed_models/feed_model.dart';

class FeedProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  List<Map<String, dynamic>> _posts = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<Map<String, dynamic>> get posts => _posts;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  FeedProvider() {
    fetchPosts();
  }

  void setIsLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void setErrorMessage(String? value) {
    _errorMessage = value;
    notifyListeners();
  }

  void fetchPosts() {
    setIsLoading(true);
    setErrorMessage(null);

    _firestore
        .collection('posts')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .listen(
          (snapshot) {
            try {
              _posts = snapshot.docs.map((doc) {
                final data = doc.data();
                return {
                  'id': doc.id,
                  'userId': data['userId'],
                  'fileUrl': data['fileUrl'] ?? '',
                  'likes': data['likes'] ?? 0,
                  'description': data['description'] ?? '',
                  'userImage': data['userImage'] ?? '',
                  'userFirstName': data['userFirstName'] ?? '',
                  'userSecondName': data['userSecondName'] ?? '',
                  'timestamp': data['timestamp'],
                  'type': data['type'] ?? 'image',
                  'music': data['music'],
                  'questionId': data['questionId'],
                  'location': data['location'],
                  'tags': data['tags'],
                };
              }).toList();

              setIsLoading(false);
            } catch (e) {
              log("Error parsing posts: $e");
              setErrorMessage(e.toString());
              setIsLoading(false);
            }
          },
          onError: (error) {
            setErrorMessage(error.toString());
            setIsLoading(false);
            notifyListeners();
          },
        );
  }

  PostWithMusic? safeMusicDataFromMap(Map<String, dynamic>? musicData) {
    try {
      if (musicData == null) return null;
      return PostWithMusic.fromMap(musicData);
    } catch (e) {
      log('Error parsing music data: $e');
      return null;
    }
  }
}

class FeedsProvider extends ChangeNotifier {
  List<FeedModel> feedsList = [];

  updateFeeds(List<FeedModel> feeds) {
    // Sort feeds by creation date, newest first
    feeds.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    feedsList = feeds;
    notifyListeners();
  }
}
