
import 'package:flutter/material.dart';

import '../../model/api_models/artist_models/artist_model.dart';
import '../../model/api_models/events_model/events_model.dart';
import '../../services/api_services/event_services/event_services.dart';

class EventsProvider extends ChangeNotifier{
  List<EventModel> events=[];
  List<EventModel> myEvents=[];
  bool isLoading=true;

  updateEvents(List<EventModel> eventList){
    events=eventList;
    isLoading=false;
    notifyListeners();
  }

  updateMyEvents(List<EventModel> myEventList){
    myEvents=myEventList;
    isLoading=false;
    notifyListeners();
  }

  getEvents(BuildContext context)async{
    await EventServices().getAllEvents(context);
  }

  getMyEvents(BuildContext context)async{
    isLoading=true;
    await EventServices().getMyEvents(context);
  }

}