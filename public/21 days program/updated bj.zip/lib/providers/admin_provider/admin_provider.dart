import 'package:flutter/cupertino.dart';

import '../../services/api_services/admin_services/get_admin_services.dart';

class AdminProvider extends ChangeNotifier{
  Map<String,dynamic> admin={};

  getAdmin(BuildContext context)async{
    List data=await AdminServices().getAdmin(context);
    admin=data.first;
    notifyListeners();
  }

}