import 'package:flutter/cupertino.dart';

import '../../model/api_models/all_categories/all_category_model.dart';
import '../../services/api_services/user_song_services/user_song_services.dart';

class UserSongsCategoriesProvider extends ChangeNotifier{
  List<AllCategoriesModel> allCategories=[];
  bool isLoading=true;

  updateAllCategories(List<AllCategoriesModel> list){
    allCategories=list;
    notifyListeners();
  }

  getCategories(BuildContext context){

    UserSongServices().getSongCategories(context);
  }

}