import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../model/music_track_model.dart';
import 'music_browser.dart';

class VideoEditorScreen extends StatefulWidget {
  final File videoFile;
  final Function(File videoFile, Map<String, dynamic> editData) onVideoEdited;

  const VideoEditorScreen({
    Key? key,
    required this.videoFile,
    required this.onVideoEdited,
  }) : super(key: key);

  @override
  State<VideoEditorScreen> createState() => _VideoEditorScreenState();
}

class _VideoEditorScreenState extends State<VideoEditorScreen> {
  late VideoPlayerController _controller;
  bool _isInitialized = false;
  
  // Edit properties
  MusicTrack? _selectedMusic;
  double _musicVolume = 0.5;
  double _videoVolume = 1.0;
  String _selectedFilter = 'None';
  String _captionText = '';
  Color _captionColor = Colors.white;
  double _captionSize = 16.0;
  
  // Available filters
  final List<String> _filters = [
    'None',
    'Vintage',
    'Black & White',
    'Sepia',
    'Cool',
    'Warm',
    'Bright',
    'Dark',
  ];

  // Available caption colors
  final List<Color> _captionColors = [
    Colors.white,
    Colors.black,
    Colors.red,
    Colors.blue,
    Colors.green,
    Colors.yellow,
    Colors.purple,
    Colors.orange,
  ];

  @override
  void initState() {
    super.initState();
    _initializeVideo();
  }

  Future<void> _initializeVideo() async {
    _controller = VideoPlayerController.file(widget.videoFile);
    await _controller.initialize();
    setState(() {
      _isInitialized = true;
    });
    _controller.setLooping(true);
    _controller.play();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _selectMusic() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MusicBrowserScreen(
          onMusicSelected: (track) {
            setState(() {
              _selectedMusic = track;
            });
          },
        ),
      ),
    );
  }

  void _removeMusic() {
    setState(() {
      _selectedMusic = null;
    });
  }

  void _showCaptionEditor() {
    final TextEditingController captionController = 
        TextEditingController(text: _captionText);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          return Container(
            padding: EdgeInsets.only(
              left: 20,
              right: 20,
              top: 20,
              bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Handle bar
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 20),
                
                // Title
                const Text(
                  'Add Caption',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),

                // Caption input
                TextField(
                  controller: captionController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Enter caption text...',
                    hintStyle: TextStyle(color: Colors.grey[400]),
                    filled: true,
                    fillColor: Colors.grey[800],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  maxLines: 3,
                  onChanged: (value) {
                    setModalState(() {
                      _captionText = value;
                    });
                    setState(() {
                      _captionText = value;
                    });
                  },
                ),
                const SizedBox(height: 20),

                // Caption size slider
                Row(
                  children: [
                    const Icon(Icons.text_fields, color: Colors.white),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Slider(
                        value: _captionSize,
                        min: 12.0,
                        max: 24.0,
                        divisions: 12,
                        activeColor: Colors.purple,
                        onChanged: (value) {
                          setModalState(() {
                            _captionSize = value;
                          });
                          setState(() {
                            _captionSize = value;
                          });
                        },
                      ),
                    ),
                    Text(
                      '${_captionSize.toInt()}',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Caption colors
                const Text(
                  'Caption Color',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  children: _captionColors.map((color) {
                    final isSelected = _captionColor == color;
                    return GestureDetector(
                      onTap: () {
                        setModalState(() {
                          _captionColor = color;
                        });
                        setState(() {
                          _captionColor = color;
                        });
                      },
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: color,
                          shape: BoxShape.circle,
                          border: isSelected
                              ? Border.all(color: Colors.purple, width: 3)
                              : Border.all(color: Colors.grey, width: 1),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 20),

                // Done button
                Container(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purple,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: const Text(
                      'Done',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _saveEditedVideo() {
    final editData = {
      'music': _selectedMusic?.toMap(),
      'musicVolume': _musicVolume,
      'videoVolume': _videoVolume,
      'filter': _selectedFilter,
      'caption': {
        'text': _captionText,
        'color': _captionColor.value,
        'size': _captionSize,
      },
    };

    widget.onVideoEdited(widget.videoFile, editData);
  }

  ColorFilter? _getFilterMatrix(String filterName) {
    switch (filterName) {
      case 'Black & White':
        return const ColorFilter.matrix(<double>[
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case 'Sepia':
        return const ColorFilter.matrix(<double>[
          0.393, 0.769, 0.189, 0, 0,
          0.349, 0.686, 0.168, 0, 0,
          0.272, 0.534, 0.131, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case 'Vintage':
        return const ColorFilter.matrix(<double>[
          1.2, 0, 0, 0, 0,
          0, 1.0, 0, 0, 0,
          0, 0, 0.8, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case 'Cool':
        return const ColorFilter.matrix(<double>[
          0.8, 0, 0, 0, 0,
          0, 0.9, 0, 0, 0,
          0, 0, 1.2, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case 'Warm':
        return const ColorFilter.matrix(<double>[
          1.2, 0, 0, 0, 0,
          0, 1.0, 0, 0, 0,
          0, 0, 0.8, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case 'Bright':
        return const ColorFilter.matrix(<double>[
          1.3, 0, 0, 0, 20,
          0, 1.3, 0, 0, 20,
          0, 0, 1.3, 0, 20,
          0, 0, 0, 1, 0,
        ]);
      case 'Dark':
        return const ColorFilter.matrix(<double>[
          0.7, 0, 0, 0, -20,
          0, 0.7, 0, 0, -20,
          0, 0, 0.7, 0, -20,
          0, 0, 0, 1, 0,
        ]);
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Edit Video',
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          TextButton(
            onPressed: _saveEditedVideo,
            child: const Text(
              'Save',
              style: TextStyle(
                color: Colors.purple,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: _isInitialized
          ? Column(
              children: [
                // Video preview
                Expanded(
                  flex: 3,
                  child: Container(
                    width: double.infinity,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        // Video player with filter
                        ColorFiltered(
                          colorFilter: _getFilterMatrix(_selectedFilter) ??
                              const ColorFilter.mode(
                                Colors.transparent,
                                BlendMode.multiply,
                              ),
                          child: AspectRatio(
                            aspectRatio: _controller.value.aspectRatio,
                            child: VideoPlayer(_controller),
                          ),
                        ),
                        // Caption overlay
                        if (_captionText.isNotEmpty)
                          Positioned(
                            bottom: 50,
                            left: 20,
                            right: 20,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 8,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                _captionText,
                                style: TextStyle(
                                  color: _captionColor,
                                  fontSize: _captionSize,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                        // Music indicator
                        if (_selectedMusic != null)
                          Positioned(
                            top: 20,
                            left: 20,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.music_note,
                                    color: Colors.white,
                                    size: 16,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    _selectedMusic!.title,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
                
                // Editing controls
                Expanded(
                  flex: 2,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[900],
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(20),
                      ),
                    ),
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Music section
                          _buildSectionTitle('Music'),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Expanded(
                                child: _selectedMusic != null
                                    ? Container(
                                        padding: const EdgeInsets.all(12),
                                        decoration: BoxDecoration(
                                          color: Colors.grey[800],
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Row(
                                          children: [
                                            const Icon(
                                              Icons.music_note,
                                              color: Colors.purple,
                                            ),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    _selectedMusic!.title,
                                                    style: const TextStyle(
                                                      color: Colors.white,
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                    maxLines: 1,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                  Text(
                                                    _selectedMusic!.artist,
                                                    style: TextStyle(
                                                      color: Colors.grey[400],
                                                      fontSize: 12,
                                                    ),
                                                    maxLines: 1,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            IconButton(
                                              onPressed: _removeMusic,
                                              icon: const Icon(
                                                Icons.close,
                                                color: Colors.red,
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    : ElevatedButton.icon(
                                        onPressed: _selectMusic,
                                        icon: const Icon(
                                          Icons.music_note,
                                          color: Colors.white,
                                        ),
                                        label: const Text(
                                          'Add Music',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.purple,
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(12),
                                          ),
                                        ),
                                      ),
                              ),
                            ],
                          ),
                          
                          // Volume controls
                          if (_selectedMusic != null) ...[
                            const SizedBox(height: 20),
                            _buildVolumeSlider('Music Volume', _musicVolume, (value) {
                              setState(() {
                                _musicVolume = value;
                              });
                            }),
                            const SizedBox(height: 10),
                            _buildVolumeSlider('Video Volume', _videoVolume, (value) {
                              setState(() {
                                _videoVolume = value;
                              });
                            }),
                          ],
                          
                          const SizedBox(height: 20),
                          
                          // Filters section
                          _buildSectionTitle('Filters'),
                          const SizedBox(height: 10),
                          Container(
                            height: 60,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: _filters.length,
                              itemBuilder: (context, index) {
                                final filter = _filters[index];
                                final isSelected = _selectedFilter == filter;
                                
                                return GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      _selectedFilter = filter;
                                    });
                                  },
                                  child: Container(
                                    margin: const EdgeInsets.only(right: 12),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 16,
                                      vertical: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      color: isSelected ? Colors.purple : Colors.grey[800],
                                      borderRadius: BorderRadius.circular(20),
                                      border: isSelected
                                          ? Border.all(color: Colors.purple)
                                          : null,
                                    ),
                                    child: Center(
                                      child: Text(
                                        filter,
                                        style: TextStyle(
                                          color: isSelected ? Colors.white : Colors.grey[400],
                                          fontWeight: isSelected
                                              ? FontWeight.bold
                                              : FontWeight.normal,
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          
                          const SizedBox(height: 20),
                          
                          // Caption section
                          _buildSectionTitle('Caption'),
                          const SizedBox(height: 10),
                          ElevatedButton.icon(
                            onPressed: _showCaptionEditor,
                            icon: const Icon(Icons.text_fields, color: Colors.white),
                            label: Text(
                              _captionText.isEmpty ? 'Add Caption' : 'Edit Caption',
                              style: const TextStyle(color: Colors.white),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.purple,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            )
          : const Center(
              child: CircularProgressIndicator(color: Colors.purple),
            ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.bold,
      ),
    );
  }

  Widget _buildVolumeSlider(String label, double value, ValueChanged<double> onChanged) {
    return Row(
      children: [
        SizedBox(
          width: 100,
          child: Text(
            label,
            style: const TextStyle(color: Colors.white),
          ),
        ),
        Expanded(
          child: Slider(
            value: value,
            min: 0.0,
            max: 1.0,
            activeColor: Colors.purple,
            onChanged: onChanged,
          ),
        ),
        SizedBox(
          width: 40,
          child: Text(
            '${(value * 100).toInt()}%',
            style: const TextStyle(color: Colors.white),
            textAlign: TextAlign.end,
          ),
        ),
      ],
    );
  }
}

