import 'package:flutter/material.dart';

const whiteColor = Color(0xFFFFFFFF);
const blackColor = Color(0xFF000000);
const lightBlackColor = Color(0xFF171717);
const greyColor = Colors.grey;
const indigoColor = Color(0xFFB717DB);
const recntsColor = Color(0xFFa82dff);
// const artistColor = Color(0xFFdd2968);
 Color artistSlowColor = Color(0xFFB717DB).withOpacity(0.4);


const backgroundColor = Color(0xFF1D1F3E);
const eventsColor = Color(0xFF168cff);
const peopleColor = Color(0xFFf9983b);
const storeColor = Color(0xFFf67199);

const pinkColor = Color(0xFFD127AE);
const redColor = Colors.red;
const greenColor = Colors.green;
const transparentColor = Colors.transparent;


Gradient buttonGradient = const LinearGradient(colors: [
  indigoColor,
  pinkColor,
],);