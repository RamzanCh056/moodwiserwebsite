import 'package:cloud_firestore/cloud_firestore.dart';

class ArtistModelFields {
  static const String id = "id";
  static const String userId = "userId";
  static const String artistName = "artistName";
  static const String bandName = "bandName";
  static const String about = "about";
  static const String picture = "picture";
  static const String updatedAt = "updatedAt";
  static const String createdAt = "createdAt";
}

class ArtistModel {
  final int id;
  final int userId;
  final String artistName;
  final String bandName;
  final String about;
  final String picture;
  final String updatedAt;
  final String createdAt;

  ArtistModel({
    required this.id,
      required this.userId,
      required this.artistName,
      required this.bandName,
      required this.about,
      required this.picture,
      required this.updatedAt,
      required this.createdAt});

  factory ArtistModel.fromJson(Map<String, dynamic> json) => ArtistModel(
    id: int.tryParse(json[ArtistModelFields.id].toString()) ?? 0,
    userId: int.tryParse(json[ArtistModelFields.userId].toString()) ?? 0,
    artistName: json[ArtistModelFields.artistName] ?? 'Unknown',
    bandName: json[ArtistModelFields.bandName] ?? '',
    about: json[ArtistModelFields.about] ?? '',
    picture: json[ArtistModelFields.picture] ?? '',
    updatedAt: json[ArtistModelFields.updatedAt] is Timestamp ? (json[ArtistModelFields.updatedAt] as Timestamp).toDate().toString() : json[ArtistModelFields.updatedAt] ?? '',
    createdAt: json[ArtistModelFields.createdAt] is Timestamp ? (json[ArtistModelFields.createdAt] as Timestamp).toDate().toString() : json[ArtistModelFields.createdAt] ?? '',
  );
}
