class ArtistSongModelFields {
  static const String id = 'id';
  static const String artistId = "artistId";
  static const String songName = "songName";
  static const String songPath = "songPath";
  static const String songCategoryId = "songCategoryId";
  static const String picturePath = "picturePath";
  static const String artistName = "artistName";
  static const String bandName = "bandName";
  static const String createdAt = "createdAt";
  static const String updatedAt = "updatedAt";
}

class ArtistSongModel {
  final int id;
  final int artistId;
  final String songName;
  final String songPath;
  final int songCategoryId;
  final String picturePath;
  final String artistName;
  final String bandName;
  final String createdAt;
  final String updatedAt;

  ArtistSongModel({
    required this.id,
    required this.artistId,
    required this.songName,
    required this.songPath,
    required this.songCategoryId,
    required this.picturePath,
    required this.artistName,
    required this.bandName,
    required this.createdAt,
    required this.updatedAt,
  });

  factory ArtistSongModel.fromJson(Map<String, dynamic> json)=>
      ArtistSongModel(
          id: json[ArtistSongModelFields.id],
          artistId: json[ArtistSongModelFields.artistId],
          songName: json[ArtistSongModelFields.songName],
          songPath: json[ArtistSongModelFields.songPath],
          songCategoryId: json[ArtistSongModelFields.songCategoryId],
          picturePath: json[ArtistSongModelFields.picturePath],
          artistName: json[ArtistSongModelFields.artistName],
          bandName: json[ArtistSongModelFields.bandName],
          createdAt: json[ArtistSongModelFields.createdAt],
          updatedAt: json[ArtistSongModelFields.updatedAt]
      );

}