

import 'package:beatjerky/model/api_models/store_chat_model/store_chat_model.dart';

class StoreConversationModelFields {
  static const String id = "id";
  static const String senderId = "senderId";
  static const String receiverId = "receiverId";
  static const String message = "message";
  static const String conversationId = "conversationId";
  static const String storeId = "storeId";
  static const String createdAt = "createdAt";
  static const String updatedAt = "updatedAt";
  static const String sender = "sender";
  static const String store = "store";
}

class SenderModelFields {
  static const String id = "id";
  static const String firstName = "firstName";
  static const String lastName = "lastName";
  static const String email = "email";
  static const String isAdmin = "isAdmin";
  static const String isOnline = "isOnline";
  static const String profileImg = "profileImg";
}

class StoreConversationModel {
  int id;
  int senderId;
  int receiverId;
  String message;
  int conversationId;
  int storeId;
  String createdAt;
  String updatedAt;
  SenderModel sender;
  StoreChatModel store;

  StoreConversationModel({required this.id,
    required this.senderId,
    required this.receiverId,
    required this.message,
    required this.conversationId,
    required this.storeId,
    required this.createdAt,
    required this.updatedAt,
    required this.sender,
    required this.store
  });

  factory StoreConversationModel.fromJson(Map<String, dynamic> json) =>
      StoreConversationModel(
          id: json[StoreConversationModelFields.id]??-1,
          senderId: json[StoreConversationModelFields.senderId]??-1,
          receiverId: json[StoreConversationModelFields.receiverId]??-1,
          message: json[StoreConversationModelFields.message]??"",
          conversationId: json[StoreConversationModelFields.conversationId]??-1,
          storeId: json[StoreConversationModelFields.storeId]??-1,
          createdAt: json[StoreConversationModelFields.createdAt]??"",
          updatedAt: json[StoreConversationModelFields.updatedAt]??"",
          sender: SenderModel.fromJson(json[StoreConversationModelFields.sender]),
        store: StoreChatModel.fromJson(json[StoreConversationModelFields.store])
      );
}

class SenderModel {
  int id;
  String firstName;
  String lastName;
  String email;
  bool isAdmin;
  bool isOnline;
  String profileImg;

  SenderModel({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.isAdmin,
    required this.isOnline,
    required this.profileImg});

  factory SenderModel.fromJson(Map<String, dynamic> json)=>
      SenderModel(
          id: json[SenderModelFields.id]??-1,
          firstName: json[SenderModelFields.firstName]??"",
          lastName: json[SenderModelFields.lastName]??"",
          email: json[SenderModelFields.email]??"",
          isAdmin: json[SenderModelFields.isAdmin]??false,
          isOnline: json[SenderModelFields.isOnline]??false,
          profileImg: json[SenderModelFields.profileImg]??""
      );
}
