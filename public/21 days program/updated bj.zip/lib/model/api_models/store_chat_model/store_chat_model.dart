class StoreChatModelFields {
  static const String id = "id";
  static const String storeName = "storeName";
  static const String storeImage = "storeImage";
}

class StoreChatModel {

  int id;
  String storeName;
  String storeImage;

  StoreChatModel({
    required this.id,
    required this.storeName,
    required this.storeImage
  });

  factory StoreChatModel.fromJson(Map<String, dynamic> json)=>
      StoreChatModel(
          id: json[StoreChatModelFields.id],
          storeName: json[StoreChatModelFields.storeName]??"",
          storeImage: json[StoreChatModelFields.storeImage]??"");

}