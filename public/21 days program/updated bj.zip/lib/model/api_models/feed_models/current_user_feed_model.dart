


class CurrentUserFeedsModelFields{
  static const String videoId='id';
  static const String userId='userId';
  static const String description='description';
  static const String imageUrl='imageUrl';
  static const String isDeleted='isDeleted';
  static const String createdAt='createdAt';
  static const String updatedAt='updatedAt';
  static const String feedLikes='feedLikes';
  static const String feedComments='feedComments';
}


class CurrentUserFeedsModel {
  int videoId;
  int userId;
  String description;
  String imageUrl;
  bool isDeleted;
  String createdAt;
  String updatedAt;
  List feedLikes=[];
  List feedComments=[];

  CurrentUserFeedsModel({
   required this.userId,
   required this.videoId,
   required this.description,
   required this.isDeleted,
   required this.imageUrl,
   required this.createdAt,
   required this.feedComments,
   required this.feedLikes,
   required this.updatedAt
});

  factory CurrentUserFeedsModel.fromJson(Map<String,dynamic> json)=>CurrentUserFeedsModel(
      userId: json[CurrentUserFeedsModelFields.userId],
      videoId: json[CurrentUserFeedsModelFields.videoId],
      description: json[CurrentUserFeedsModelFields.description],
      isDeleted: json[CurrentUserFeedsModelFields.isDeleted],
      imageUrl: json[CurrentUserFeedsModelFields.imageUrl],
      createdAt: json[CurrentUserFeedsModelFields.createdAt],
      feedComments: json[CurrentUserFeedsModelFields.feedComments]??[],
      feedLikes: json[CurrentUserFeedsModelFields.feedLikes]??[],
      updatedAt: json[CurrentUserFeedsModelFields.updatedAt]
  );
}