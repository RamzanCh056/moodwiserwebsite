



class StoreModelFields{
  static const String id="id";
  static const String storeName="storeName";
  static const String storeCategoryId="storeCategoryId";
  static const String storeDescription="storeDescription";
  static const String storeImage="storeImage";
  static const String createdAt="createdAt";
  static const String updatedAt="updatedAt";
}


class StoreModel{
  int id;
  String storeName;
  int storeCategoryId;
  String storeDescription;
  String storeImage;
  String createdAt;
  String updatedAt;

  StoreModel({
    required this.id,
    required this.storeName,
    required this.storeCategoryId,
    required this.storeDescription,
    required this.storeImage,
    required this.createdAt,
    required this.updatedAt
});

  factory StoreModel.fromJson(Map<String,dynamic> json)=>StoreModel(
      id: json[StoreModelFields.id],
      storeName: json[StoreModelFields.storeName],
      storeCategoryId: json[StoreModelFields.storeCategoryId],
      storeDescription: json[StoreModelFields.storeDescription],
      storeImage: json[StoreModelFields.storeImage],
      createdAt: json[StoreModelFields.createdAt],
      updatedAt: json[StoreModelFields.updatedAt]);

}