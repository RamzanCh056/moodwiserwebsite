class StoreProfileModelFields {
  static const String id = "id";
  static const String storeName = "storeName";
  static const String storeCategoryId = "storeCategoryId";
  static const String storeDescription = "storeDescription";
  static const String storeImage = "storeImage";
  static const String followerCount = "followerCount";
}

class StoreProfileModel {
  int id;
  String storeName;
  int storeCategoryId;
  String storeDescription;
  String storeImage;
  int followerCount;

  StoreProfileModel({
    required this.id,
    required this.storeName,
    required this.storeCategoryId,
    required this.storeImage,
    required this.followerCount,
    required this.storeDescription
  });

  factory StoreProfileModel.fromJson(Map<String, dynamic> json)=>
      StoreProfileModel(
          id: json[StoreProfileModelFields.id],
          storeName: json[StoreProfileModelFields.storeName],
          storeCategoryId: json[StoreProfileModelFields.storeCategoryId],
          storeImage: json[StoreProfileModelFields.storeImage],
          followerCount: json[StoreProfileModelFields.followerCount],
          storeDescription: json[StoreProfileModelFields.storeDescription]);
}