class FollowedStoresModelFields {
  static const String id = "id";
  static const String userId = "userId";
  static const String storeId = "storeId";
  static const String createdAt = "createdAt";
  static const String updatedAt = "updatedAt";
}

class FollowedStoresModel {
  int id;
  int userId;
  int storeId;
  String createdAt;
  String updatedAt;

  FollowedStoresModel({
    required this.id,
    required this.userId,
    required this.storeId,
    required this.createdAt,
    required this.updatedAt
  });

  factory FollowedStoresModel.fromJson(Map<String, dynamic> json)=>FollowedStoresModel(
      id: json[FollowedStoresModelFields.id],
      userId: json[FollowedStoresModelFields.userId],
      storeId: json[FollowedStoresModelFields.storeId],
      createdAt: json[FollowedStoresModelFields.createdAt],
      updatedAt: json[FollowedStoresModelFields.updatedAt]
  );
}
