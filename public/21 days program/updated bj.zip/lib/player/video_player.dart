import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../consolePrintWithColor.dart';
import '../controller/controller.dart';

import '../model/api_models/video_models/single_video_Likes_model.dart';
import '../model/api_models/video_models/single_video_comments_model.dart';
import '../model/api_models/video_models/video_model.dart';
import '../providers/users_provider/current_user_provider.dart';
import '../providers/video_provider/video_comments_provider.dart';
import '../providers/video_provider/video_likes_provider.dart';
import '../providers/video_provider/videos_provider.dart';
import '../repo/api_consts.dart';
import '../services/api_services/video_services/video_comment_services.dart' show VideoCommentServices;
import '../services/api_services/video_services/video_like_services.dart';
import '../services/api_services/video_services/video_services.dart';

import '../utils/app_sizes.dart';
import '../utils/color.dart';
import '../widget/reusable_text.dart';
import '../widget/reusable_textformfield.dart';

class Player extends StatefulWidget {
  final int i;
  Player({Key? key, required this.i}) : super(key: key);

  @override
  State<Player> createState() => _PlayerState();
}

class _PlayerState extends State<Player> {
  TextEditingController descriptionController = TextEditingController();
  TextEditingController commentController = TextEditingController();

  XFile? videoFile;
  final picker = ImagePicker();
  bool isVideo = true;
  bool isPic = false;

  bool isLoading = true;
  getAllVideos() async {
    await VideoServices().getAllVideos(context);

    setState(() {
      isLoading = false;
    });
  }

  updateAllVideos() async {
    await VideoServices().getAllVideos(context);
    setState(() {});
  }

  bool isLiked = false;
  getVideoCommentsAndLikes() async {
    // comments.clear();
    // likes.clear();
    VideoModel video = Provider.of<VideosProvider>(context, listen: false)
        .videosList[widget.i];
    
    await VideoCommentServices().getAllVideoComments(video.videoId, context);
    await VideoLikeServices().getAllVideoLikes(video.videoId, context);
    comments = Provider.of<VideoCommentsProvider>(context, listen: false)
        .videoComments;
    likes = Provider.of<VideoLikesProvider>(context, listen: false).videoLikes;
    printLog(
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Likes: ${likes.length}>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    // isLiked=likes.any((element) => element.userId==user!.userId);
    List<SingleVideoLikesModel> videoLikes =
        Provider.of<VideoLikesProvider>(context, listen: false).videoLikes;
    isLiked = videoLikes.any((element) =>
        element.userId ==
        Provider.of<CurrentUserProvider>(context, listen: false).user!.userId);

    printLog(">>>>>>>>>>>>>>>>>>>>>>>>>${isLiked}");
    setState(() {});
  }

  @override
  void initState() {
    // getVideoCommentsAndLikes();
    // TODO: implement initState
    super.initState();
  }

  final VideoController c = Get.find();

  /// This list only contains one item if and only if I have or current user
  /// has liked this video else it will be empty
  List<SingleVideoLikesModel> likes = [];
  List<SingleVideoCommentModel> comments = [];

  @override
  void dispose() {
    VideoController().disposeController(widget.i);
    // TODO: implement dispose
    super.dispose();
  }

  // Helper method to build profile image with proper validation
  ImageProvider<Object>? _buildProfileImage(String? profileImg) {
    if (profileImg == null || 
        profileImg.isEmpty || 
        !profileImg.startsWith('http') ||
        profileImg.contains('file:///')) {
      return null;
    }
    
    try {
      final cleanUrl = profileImg.replaceAll("public", ApiConstants.baseUrl);
      return CachedNetworkImageProvider(
        cleanUrl,
        maxWidth: 100,
        maxHeight: 100,
      );
    } catch (e) {
      printLog("Error loading profile image: $e");
      return null;
    }
  }

  // Cache of user paid status
  final Map<String, bool> _userPaidCache = {};
  Future<bool> _isUserPaid(String? userId) async {
    if (userId == null || userId.isEmpty) return false;
    if (_userPaidCache.containsKey(userId)) return _userPaidCache[userId]!;
    try {
      final doc = await FirebaseFirestore.instance.collection('usersData').doc(userId).get();
      final isPaid = doc.exists ? (doc.data()?['isPaid'] ?? false) : false;
      _userPaidCache[userId] = isPaid;
      return isPaid;
    } catch (_) {
      return false;
    }
  }

  // Helper method to determine if profile icon should be shown
  bool _shouldShowProfileIcon(String? profileImg) {
    return profileImg == null || 
           profileImg.isEmpty || 
           !profileImg.startsWith('http') ||
           profileImg.contains('file:///');
  }

  @override
  Widget build(BuildContext context) {
    VideoModel video = Provider.of<VideosProvider>(context, listen: false)
        .videosList[widget.i];
    // List<SingleVideoCommentModel> comments=Provider.of<VideoCommentsProvider>(context,listen: false).videoComments;
    // List<SingleVideoLikesModel> likes=Provider.of<VideoLikesProvider>(context,listen: false).videoLikes;
    printLog(
        "<<<<<<<<<<<<<<<<<<<<<<<<<<<I am inside build<<<<<<<<Likes: ${likes.length}>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

    return GetBuilder<VideoController>(
      initState: (x) async {
        //Need to change conditions according preaload page count
        //Don't load too many pages it will cause performance issue.
        // Below is for 1 page preaload.
        if (c.api > 1) {
          await c.disposeController(c.api - 2);
        }
        if (c.api < c.videoPlayerControllers.length - 2) {
          await c.disposeController(c.api + 2);
        }
        if (!c.initilizedIndexes.contains(widget.i)) {
          // getVideoCommentsAndLikes();
          await c.initializePlayer(widget.i, context);
        }
        if (c.api > 0) {
          if (c.videoPlayerControllers[c.api - 1] == null) {
            await c.initializeIndexedController(c.api - 1, context);
          }
        }
        if (c.api < c.videoPlayerControllers.length - 1) {
          if (c.videoPlayerControllers[c.api + 1] == null) {
            await c.initializeIndexedController(c.api + 1, context);
          }
        }
      },
      builder: (_) {
        if (c.videoPlayerControllers.isEmpty ||
            c.videoPlayerControllers[c.api] == null ||
            !c.videoPlayerControllers[c.api]!.value.isInitialized) {
           return Container(
             color: Colors.black,
             child: Center(
               child: Column(
                 mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Container(
                     width: 80,
                     height: 80,
                     decoration: BoxDecoration(
                       color: Colors.purple.withOpacity( 0.2),
                       shape: BoxShape.circle,
                     ),
                     child: const CircularProgressIndicator(
                       color: Colors.purple,
                       strokeWidth: 4,
                     ),
                   ),
                   const SizedBox(height: 24),
                   const Text(
                     'Loading video...',
                     style: TextStyle(
                       color: Colors.white,
                       fontSize: 18,
                       fontWeight: FontWeight.w600,
                     ),
                   ),
                   const SizedBox(height: 8),
                   Text(
                     'Please wait while we prepare your video',
                     style: TextStyle(
                       color: Colors.grey[400],
                       fontSize: 14,
                     ),
                   ),
                 ],
               ),
             ),
           );
        }

        if (widget.i == c.api) {
          //If Index equals Auto Play Index
          //Set AutoPlay True Here
          if (widget.i < c.videoPlayerControllers.length) {
            if (c.videoPlayerControllers[c.api]!.value.isInitialized) {
                             // Delay loading comments and likes to improve video performance
               Future.delayed(Duration(seconds: 1), () {
                getVideoCommentsAndLikes();
              });

               // Ensure smooth playback with optimized settings
              c.videoPlayerControllers[c.api]!.play();
               c.videoPlayerControllers[c.api]!.setPlaybackSpeed(1.0);
               
               // Set video quality for smooth playback
               c.videoPlayerControllers[c.api]!.setLooping(false);
            }
          }
          print('AutoPlaying ${c.api}');
        }
        return Stack(
          children: [
            c.videoPlayerControllers.isNotEmpty &&
                    c.videoPlayerControllers[c.api]!.value.isInitialized
                ? GestureDetector(
                    onDoubleTap: () {
                      if (c.videoPlayerControllers[c.api]!.value.isPlaying) {
                        print("paused");
                        c.videoPlayerControllers[c.api]!.pause();
                      } else {
                        c.videoPlayerControllers[c.api]!.play();
                        print("playing");
                      }
                    },
                    onTap: () {},
                    child: VideoPlayer(c.videoPlayerControllers[c.api]!),
                  )
                : Container(
                    color: Colors.black,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.purple.withOpacity( 0.2),
                              shape: BoxShape.circle,
                            ),
                            child: const CircularProgressIndicator(
                              color: Colors.purple,
                              strokeWidth: 3,
                            ),
                          ),
                          const SizedBox(height: 20),
                          const Text(
                            'Preparing video...',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Almost ready to play',
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
            c.videoPlayerControllers.isNotEmpty &&
                    c.videoPlayerControllers[c.api]!.value.isInitialized
                ? Padding(
                    padding:
                        const EdgeInsets.only(left: 20.0, right: 5, bottom: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.center,
                        //   children: [
                        //     const ReusableText(title: "Following",size: 18,weight: FontWeight.w700,color: whiteColor,),
                        //     const SizedBox(width: 10,),
                        //     Container(
                        //       height: 15,
                        //       width: 2,
                        //       color: whiteColor,
                        //     ),
                        //     const SizedBox(width: 10,),
                        //     const ReusableText(title: "For You",size: 18,weight: FontWeight.w700,color: whiteColor,),
                        //
                        //   ],
                        // ),
                        const Spacer(),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Column(
                            children: [
                              //like
                              InkWell(
                                onTap: () async {
                                  if (isLiked) {
                                    await VideoLikeServices().dislikeVideo(
                                        Provider.of<CurrentUserProvider>(
                                                context,
                                                listen: false)
                                            .user!
                                            .userId!,
                                        video.videoId,
                                        context);
                                    await VideoLikeServices().getAllVideoLikes(
                                        video.videoId, context);
                                    // getVideoCommentsAndLikes();
                                    setState(() {});
                                  } else {
                                    await VideoLikeServices().likeVideo(
                                        Provider.of<CurrentUserProvider>(
                                                context,
                                                listen: false)
                                            .user!
                                            .userId!,
                                        video.videoId,
                                        context);
                                    await VideoLikeServices().getAllVideoLikes(
                                        video.videoId, context);
                                    // await VideoServices().getAllVideos(context);
                                    // getVideoCommentsAndLikes();
                                    setState(() {});
                                  }
                                },
                                child: Container(
                                  height: 35,
                                  width: 35,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: blackColor.withOpacity( 0.3),
                                  ),
                                  child: !isLiked
                                      ? const Icon(
                                          Icons.favorite,
                                          color: whiteColor,
                                        )
                                      : const Icon(
                                          Icons.favorite,
                                          color: Colors.red,
                                        ),
                                ),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Consumer<VideoLikesProvider>(
                                builder: (context, likes, _) {
                                  return ReusableText(
                                    title: likes.videoLikes.length.toString(),
                                    color: whiteColor,
                                    weight: FontWeight.w700,
                                  );
                                },
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              //comment
                              InkWell(
                                onTap: () {
                                  _showComments(
                                      context: context,
                                      videoId: video.videoId,
                                      video: video);
                                },
                                child: Container(
                                  height: 35,
                                  width: 35,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: blackColor.withOpacity( 0.3),
                                  ),
                                  child: const Icon(
                                    Icons.messenger,
                                    color: whiteColor,
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              ReusableText(
                                title: comments.length.toString(),
                                color: whiteColor,
                                weight: FontWeight.w700,
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              //
                              PopupMenuButton<String>(
                                icon: const Icon(Icons.more_vert, color: Colors.white),
                                color: Colors.grey[800],
                                onSelected: (value) => _handleMenuSelection(value, context, video),
                                itemBuilder: (BuildContext context) {
                                  // Check if this is the current user's video
                                  final currentUserId = Provider.of<CurrentUserProvider>(context, listen: false).user?.userId;
                                  final isOwnVideo = currentUserId == video.userId;
                                  
                                  if (isOwnVideo) {
                                    // Show edit and delete options for own videos
                                    return [
                                      const PopupMenuItem<String>(
                                        value: 'edit',
                                        child: Row(
                                          children: [
                                            Icon(Icons.edit, color: Colors.white, size: 18),
                                            SizedBox(width: 8),
                                            Text(
                                              'Edit Video',
                                              style: TextStyle(color: Colors.white),
                                            ),
                                          ],
                                        ),
                                      ),
                                      const PopupMenuItem<String>(
                                        value: 'delete',
                                        child: Row(
                                          children: [
                                            Icon(Icons.delete, color: Colors.red, size: 18),
                                            SizedBox(width: 8),
                                            Text(
                                              'Delete Video',
                                              style: TextStyle(color: Colors.red),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ];
                                  } else {
                                    // Show report option for others' videos
                                    return [
                                      const PopupMenuItem<String>(
                                        value: 'report',
                                        child: Row(
                                          children: [
                                            Icon(Icons.report, color: Colors.white, size: 18),
                                            SizedBox(width: 8),
                                            Text(
                                              'Report',
                                              style: TextStyle(color: Colors.white),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ];
                                  }
                                },
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              InkWell(
                                onTap: () {
                                  _showPicker(context: context);
                                },
                                child: Container(
                                  height: 35,
                                  width: 35,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: blackColor.withOpacity( 0.3),
                                  ),
                                  child: const Icon(
                                    Icons.add_circle_outline_rounded,
                                    color: whiteColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),

                        Row(
                          children: [
                            CircleAvatar(
                              backgroundImage: _buildProfileImage(video.user?.profileImg),
                              backgroundColor: Colors.grey[700],
                              child: _shouldShowProfileIcon(video.user?.profileImg)
                                  ? const Icon(
                                      Icons.person,
                                      color: Colors.white,
                                      size: 20,
                                    )
                                  : null,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            FutureBuilder<bool>(
                              future: _isUserPaid(video.userId?.toString()),
                              builder: (context, snapshot) {
                                final paid = snapshot.data ?? false;
                                return Row(
                                  children: [
                                    ReusableText(
                                      title: video.user != null
                                          ? "@${"${video.user!.firstName} ${video.user!.lastName}"}"
                                          : "User${Random.secure().nextInt(9999999)}",
                                      size: 15,
                                      weight: FontWeight.w700,
                                      color: whiteColor,
                                    ),
                                    if (paid) const SizedBox(width: 6),
                                    if (paid)
                                      const Icon(
                                        Icons.check_circle,
                                        color: Colors.blue,
                                        size: 16,
                                      ),
                                  ],
                                );
                              },
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        ReusableText(
                          title: video.description,
                          size: 15,
                          weight: FontWeight.w500,
                          color: whiteColor,
                        ),
                      ],
                    ),
                  )
                : Container(
                    color: Colors.black,
                    child: const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 3,
                          ),
                          SizedBox(height: 16),
                          Text(
                            'Preparing video...',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
          ],
        );
      },
    );
  }

  // Handle menu selection (edit, delete, report)
  void _handleMenuSelection(String value, BuildContext context, VideoModel video) {
    switch (value) {
      case 'edit':
        _showEditVideoDialog(context, video);
        break;
      case 'delete':
        _showDeleteConfirmation(context, video);
        break;
      case 'report':
        _showReportOptions(context, video);
        break;
    }
  }

  // Show edit video dialog
  void _showEditVideoDialog(BuildContext context, VideoModel video) {
    final TextEditingController editController = TextEditingController(text: video.description);
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          title: Text(
            'Edit Video',
            style: TextStyle(color: Colors.white),
          ),
          content: TextField(
            controller: editController,
            maxLines: 3,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Edit your video description...',
              hintStyle: TextStyle(color: Colors.grey[400]),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey[600]!),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey[600]!),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.purple),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey[400])),
            ),
            ElevatedButton(
              onPressed: () async {
                await _updateVideo(video.videoId, editController.text.trim());
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text('Update'),
            ),
          ],
        );
      },
    );
  }

  // Show delete confirmation dialog
  void _showDeleteConfirmation(BuildContext context, VideoModel video) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          title: Text(
            'Delete Video',
            style: TextStyle(color: Colors.white),
          ),
          content: Text(
            'Are you sure you want to delete this video? This action cannot be undone.',
            style: TextStyle(color: Colors.grey[300]),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey[400])),
            ),
            ElevatedButton(
              onPressed: () async {
                await VideoServices().deleteVideo(video.videoId, context);
                await getAllVideos();
                Navigator.pop(context);
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  // Show report options
  void _showReportOptions(BuildContext context, VideoModel video) {
    final List<String> reportReasons = [
      'Sexual Content',
      'Hateful Speech',
      'Violence',
      'Harassment',
      'Spam',
      'False Information',
      'Other'
    ];
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String? selectedReason;
        
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setDialogState) {
            return AlertDialog(
              backgroundColor: Colors.grey[900],
              title: Text(
                'Report Video',
                style: TextStyle(color: Colors.white),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Please select a reason for reporting this video:',
                    style: TextStyle(color: Colors.grey[300]),
                  ),
                  SizedBox(height: 16),
                  ...reportReasons.map((reason) => RadioListTile<String>(
                    title: Text(reason, style: TextStyle(color: Colors.white)),
                    value: reason,
                    groupValue: selectedReason,
                    onChanged: (value) {
                      setDialogState(() {
                        selectedReason = value;
                      });
                    },
                    activeColor: Colors.purple,
                  )),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('Cancel', style: TextStyle(color: Colors.grey[400])),
                ),
                ElevatedButton(
                  onPressed: () async {
                    if (selectedReason != null) {
                      await _reportVideo(video.videoId, selectedReason!);
                      Navigator.pop(context);
                      _showReportConfirmation(context);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text('Report'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  // Show report confirmation
  void _showReportConfirmation(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Video reported successfully. We will review it soon and take appropriate action.',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  // Update video description
  Future<void> _updateVideo(int videoId, String newDescription) async {
    try {
      // TODO: Implement video update API call
      // await VideoServices().updateVideo(videoId, newDescription);
      
      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Video updated successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );
    } catch (e) {
      print('Error updating video: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to update video. Please try again.'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  // Report video
  Future<void> _reportVideo(int videoId, String reason) async {
    try {
      // TODO: Implement video report API call
      // await VideoServices().reportVideo(videoId, reason);
      
      print('Video reported successfully with reason: $reason');
    } catch (e) {
      print('Error reporting video: $e');
    }
  }

  double uploadProgress = 0.0;
  bool isUploading = false;

  void _showPicker({
    required BuildContext context,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.grey[900],
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
          padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
                top: 20,
                left: 20,
                right: 20,
          ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                  // Handle bar
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey[600],
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  // Title
                  const Text(
                    "Create New Video",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Description TextField
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[800],
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.grey[700]!),
                    ),
                    child: TextField(
                  controller: descriptionController,
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                      maxLines: 3,
                      decoration: const InputDecoration(
                        hintText: 'Write your video description here... (Optional)',
                        hintStyle: TextStyle(color: Colors.grey, fontSize: 14),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.all(16),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Video selection section
                  if (videoFile == null) ...[
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.grey[850],
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(
                          color: Colors.purple.withOpacity(0.3),
                          width: 2,
                        ),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            Icons.video_camera_back,
                            size: 50,
                            color: Colors.purple[300],
                          ),
                          const SizedBox(height: 10),
                          const Text(
                            "Select a video to upload",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 15),
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton.icon(
                                  onPressed: () => getVideo(ImageSource.gallery),
                                  icon: const Icon(Icons.photo_library, color: Colors.white),
                                  label: const Text("Gallery", style: TextStyle(color: Colors.white)),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.purple,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: ElevatedButton.icon(
                                  onPressed: () => getVideo(ImageSource.camera),
                                  icon: const Icon(Icons.videocam, color: Colors.white),
                                  label: const Text("Camera", style: TextStyle(color: Colors.white)),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.purple,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ] else ...[
                    // Video selected section
                    Container(
                      padding: const EdgeInsets.all(15),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity( 0.1),
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: Colors.green, width: 1),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.check_circle, color: Colors.green, size: 30),
                          const SizedBox(width: 15),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Video Selected",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                Text(
                                  videoFile!.name,
                                  style: TextStyle(
                                    color: Colors.grey[300],
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              setModalState(() {
                                videoFile = null;
                              });
                            },
                            icon: const Icon(Icons.close, color: Colors.red),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Upload button
                    Container(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: isUploading ? null : () async {
                          setModalState(() {
                            isUploading = true;
                            uploadProgress = 0.0;
                          });

                          // Simulate upload progress
                          for (int i = 0; i <= 100; i += 10) {
                            await Future.delayed(const Duration(milliseconds: 200));
                            setModalState(() {
                              uploadProgress = i / 100;
                            });
                          }

                        bool status = await VideoServices().uploadVideo(
                          videoFile!.path,
                            descriptionController.text.trim(),
                          context,
                        );

                          setModalState(() {
                            isUploading = false;
                            uploadProgress = 0.0;
                          });

                        if (status) {
                          Get.showSnackbar(
                            const GetSnackBar(
                                message: "Video posted successfully",
                              duration: Duration(seconds: 2),
                            ),
                          );
                            descriptionController.clear();
                            videoFile = null;
                          updateAllVideos();
                          Navigator.pop(context);
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isUploading ? Colors.grey : Colors.purple,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 15),
                        ),
                        child: isUploading
                            ? Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                          color: Colors.white,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  const Text(
                                    "Uploading...",
                          style: TextStyle(
                                      fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                                ],
                              )
                            : const Text(
                                "Upload Video",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                    ),

                    // Progress indicator
                    if (isUploading) ...[
                      const SizedBox(height: 15),
                      Container(
                        height: 8,
                        decoration: BoxDecoration(
                          color: Colors.grey[700],
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: uploadProgress,
                            backgroundColor: Colors.transparent,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.purple),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        "${(uploadProgress * 100).toInt()}% uploaded",
                        style: TextStyle(
                          color: Colors.grey[300],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ],
                  const SizedBox(height: 10),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future getVideo(
    ImageSource img,
  ) async {
    final pickedFile = await picker.pickVideo(
        source: img,
        preferredCameraDevice: CameraDevice.front,
        maxDuration: const Duration(minutes: 10));
    XFile? xfilePick = pickedFile;
    setState(
      () {
        if (xfilePick != null) {
          videoFile = xfilePick;
          // Close the modal when video is selected to refresh UI
          Navigator.pop(context);
          // Reopen with updated state
          _showPicker(context: context);
        } else {
          Get.showSnackbar(
            const GetSnackBar(
              message: 'No video selected',
              duration: Duration(seconds: 2),
            ),
          );
        }
      },
    );
  }

  void _showComments(
      {required BuildContext context,
      required int videoId,
      required VideoModel video}) {
    showModalBottomSheet(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
        topRight: Radius.circular(20),
        topLeft: Radius.circular(20),
      )),
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return SingleChildScrollView(
            reverse: true,
            child: Container(
                padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom),
                child: Consumer<VideoCommentsProvider>(
                  builder: (context, comments, _) {
                    return Container(
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: SizedBox(
                          height: responsiveHeight(Get.height * .62, context),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    const ReusableText(
                                      title: "Comments",
                                      size: 16,
                                    ),
                                    ReusableText(
                                      title:
                                          "${comments.videoComments.length} Comments",
                                      size: 14,
                                      color: Colors.grey,
                                    ),
                                  ],
                                ),
                              ),
                              const Divider(),
                              const SizedBox(
                                height: 10,
                              ),
                              SizedBox(
                                height:
                                    responsiveHeight(Get.height * .44, context),
                                child: ListView.builder(
                                    itemCount: comments.videoComments.length,
                                    itemBuilder: (context, commentIndex) {
                                      String? profileImg = comments
                                          .videoComments[commentIndex].user?.profileImg;
                                      return video.videoComments.isNotEmpty
                                          ? Padding(
                                              padding: const EdgeInsets.all(10),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Column(
                                                        children: [
                                                          SizedBox(
                                                            height: 20,
                                                          ),
                                                          CircleAvatar(
                                                            backgroundColor: Colors.grey[700],
                                                            backgroundImage: _buildProfileImage(profileImg),
                                                            radius: 25,
                                                            child: _shouldShowProfileIcon(profileImg)
                                                                ? const Icon(
                                                                    Icons.person,
                                                                    color: Colors.white,
                                                                    size: 24,
                                                                  )
                                                                : null,
                                                          ),
                                                        ],
                                                      ),
                                                      const SizedBox(
                                                        width: 10,
                                                      ),
                                                      Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          // SizedBox(height: 15,),
                                                          SizedBox(
                                                            // width: Get.width*.73,
                                                            width:
                                                                responsiveWidth(
                                                                    Get.width *
                                                                        .73,
                                                                    context),
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    SizedBox(
                                                                      height:
                                                                          20,
                                                                    ),
                                                                    ReusableText(
                                                                      title: comments.videoComments[commentIndex].user !=
                                                                              null
                                                                          ? "${comments.videoComments[commentIndex].user!.firstName} ${comments.videoComments[commentIndex].user!.lastName}"
                                                                          : "User${Random.secure().nextInt(9999999)}",
                                                                      size: 16,
                                                                      weight: FontWeight
                                                                          .w700,
                                                                      color:
                                                                          whiteColor,
                                                                    ),
                                                                    ReusableText(
                                                                      title: DateFormat(
                                                                              "dd-MMM-yyyy ")
                                                                          .add_jm()
                                                                          .format(DateTime.parse(comments
                                                                              .videoComments[commentIndex]
                                                                              .createdAt)),
                                                                      size: 10,
                                                                      color: Colors
                                                                          .grey,
                                                                    ),
                                                                  ],
                                                                ),
                                                                Spacer(),
                                                                PopupMenuButton(
                                                                    position: PopupMenuPosition
                                                                        .over,
                                                                    offset:
                                                                        const Offset(
                                                                            -20,
                                                                            30),
                                                                    padding:
                                                                        EdgeInsets
                                                                            .zero,
                                                                    icon:
                                                                        const Icon(
                                                                      Icons
                                                                          .more_horiz_rounded,
                                                                      size: 40,
                                                                      color:
                                                                          greyColor,
                                                                    ),
                                                                    itemBuilder:
                                                                        (context) =>
                                                                            [
                                                                              PopupMenuItem(
                                                                                  child: comments.videoComments[commentIndex].userId == Provider.of<CurrentUserProvider>(context, listen: false).user!.userId
                                                                                      ? TextButton(
                                                                                          onPressed: () async {
                                                                                            EasyLoading.show(status: 'Deleting');

                                                                                            bool isDeleted = await VideoCommentServices().deleteVideoComment(Provider.of<CurrentUserProvider>(context, listen: false).user!.userId!, videoId, comments.videoComments[commentIndex].commentId, context);
                                                                                            if (isDeleted) {
                                                                                              Get.showSnackbar(const GetSnackBar(
                                                                                                message: "Deleted successfully",
                                                                                                duration: Duration(seconds: 2),
                                                                                              ));
                                                                                            }
                                                                                            await updateAllVideos();
                                                                                            await VideoCommentServices().getAllVideoComments(videoId, context);
                                                                                            setState(() {});
                                                                                            Navigator.pop(context);
                                                                                            EasyLoading.dismiss();
                                                                                          },
                                                                                          child: const Text("Delete"),
                                                                                        )
                                                                                      : TextButton(
                                                                                          onPressed: () {
                                                                                            // VideoServices().deleteVideo(videoId, context);
                                                                                          },
                                                                                          child: const Text("About"),
                                                                                        ))
                                                                            ]),
                                                              ],
                                                            ),
                                                          ),
                                                          const SizedBox(
                                                            height: 5,
                                                          ),

                                                          const SizedBox(
                                                            height: 10,
                                                          ),
                                                          SizedBox(
                                                            width:
                                                                responsiveWidth(
                                                                    Get.width *
                                                                        .7,
                                                                    context),
                                                            // width: Get.width*.7,
                                                            child: ReusableText(
                                                              title: comments
                                                                  .videoComments[
                                                                      commentIndex]
                                                                  .comment,
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            )
                                          : const Center(
                                              child: ReusableText(
                                                title: "No comments available",
                                                color: Colors.white,
                                              ),
                                            );
                                    }),
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  SizedBox(
                                    height: 50,
                                    // width: Get.width*.78,
                                    width: responsiveWidth(
                                        Get.width * .87, context),

                                    child: ReusableTextForm(
                                      hintText: "Write comment here...",
                                      filledColor: Colors.white,
                                      textColor: Colors.black,
                                      controller: commentController,
                                      // maxLine: 3,
                                      borderRadius: 25,
                                    ),
                                  ),
                                  InkWell(
                                      onTap: () async {
                                        if (commentController.text.isEmpty) {
                                          Get.showSnackbar(
                                            const GetSnackBar(
                                              message:
                                                  "Can't post empty comment",
                                              duration: Duration(seconds: 2),
                                            ),
                                          );
                                        } else {
                                          EasyLoading.show(
                                              status: 'Posting...');
                                          await VideoCommentServices()
                                              .commentVideo(
                                                  Provider.of<CurrentUserProvider>(
                                                          context,
                                                          listen: false)
                                                      .user!
                                                      .userId!,
                                                  videoId,
                                                  commentController.text,
                                                  context);
                                          // await updateAllVideos();

                                          commentController.clear();
                                          await VideoCommentServices()
                                              .getAllVideoComments(
                                                  videoId, context);
                                          setState(() {});
                                          EasyLoading.dismiss();
                                        }
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                            color: whiteColor,
                                            borderRadius:
                                                BorderRadius.circular(50)),
                                        child: Transform.rotate(
                                            angle: -.78,
                                            child: const Icon(
                                              Icons.send,
                                              color: indigoColor,
                                              size: 30,
                                            )),
                                      ))
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),

                    );
                    
                  },
                )));
      },
    );
  }

  // void _showComments({required BuildContext context,required int videoId}) {
  //
  //   showModalBottomSheet(
  //     context: context,
  //     isScrollControlled: true,
  //     builder: (BuildContext context) {
  //       return SafeArea(
  //         child: Padding(
  //           padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
  //           child: Padding(
  //             padding: const EdgeInsets.all(8.0),
  //             child: SizedBox(
  //               height: Get.height*.48,
  //               child: Column(
  //                 mainAxisSize: MainAxisSize.min,
  //                 children: <Widget>[
  //                   SizedBox(
  //                     height: Get.height*.4,
  //                     child:ListView.builder(
  //                         itemCount: Provider.of<VideoCommentsProvider>(context).videoComments.length,
  //                         itemBuilder: (context,commentIndex){
  //                           List<SingleVideoCommentModel> videoComments=Provider.of<VideoCommentsProvider>(context).videoComments;
  //                           String imageUrl=videoComments[commentIndex].user!.profileImg.replaceAll('public', ApiConstants.baseUrl);
  //                           return Provider.of<VideoCommentsProvider>(context).videoComments.isNotEmpty?Container(
  //                             margin: const EdgeInsets.only(bottom: 10),
  //                             width: Get.width*.9,
  //                             decoration: BoxDecoration(
  //                                 borderRadius: BorderRadius.circular(10),
  //                                 border: Border.all(
  //                                     color: Colors.white
  //                                 )
  //                             ),
  //                             child: Column(
  //                               crossAxisAlignment: CrossAxisAlignment.start,
  //                               mainAxisSize: MainAxisSize.min,
  //                               children: [
  //                                 ListTile(
  //                                     leading: CircleAvatar(
  //                                       backgroundImage: NetworkImage(imageUrl),
  //                                     ),
  //
  //                                     title: ReusableText(
  //                                       title: "${videoComments[commentIndex].user!.firstName} ${videoComments[commentIndex].user!.lastName}",
  //                                       size: 16,
  //                                       weight: FontWeight.w700,
  //                                       color: whiteColor,
  //                                     ),
  //                                     trailing: PopupMenuButton(
  //                                         itemBuilder: (context)=>[
  //                                           PopupMenuItem(
  //                                               child: videoComments[commentIndex].userId==Provider.of<CurrentUserProvider>(context,listen: false).user!.userId?TextButton(
  //                                                 onPressed: () async{
  //                                                   EasyLoading.show(status: 'Deleting');
  //
  //                                                   bool isDeleted=await VideoCommentServices().deleteVideoComment(Provider.of<CurrentUserProvider>(context,listen: false).user!.userId!, videoId, videoComments[commentIndex].commentId, context);
  //                                                   if(isDeleted){
  //                                                     Get.showSnackbar(const GetSnackBar(message: "Deleted successfully",duration: Duration(seconds: 2),));
  //                                                   }
  //                                                   await updateAllVideos();
  //                                                   await VideoCommentServices().getAllVideoComments(videoId, context);
  //                                                   setState(() {
  //
  //                                                   });
  //                                                   Navigator.pop(context);
  //                                                   EasyLoading.dismiss();
  //                                                 },
  //                                                 child: const Text("Delete"),
  //                                               ):TextButton(
  //                                                 onPressed: () {
  //                                                   // VideoServices().deleteVideo(videoId, context);
  //                                                 },
  //                                                 child: const Text("About"),
  //                                               )
  //                                           )
  //                                         ])
  //                                 ),
  //                                 Divider(color: Colors.white,thickness: 1,indent: 30,endIndent: 30,),
  //                                 const SizedBox(
  //                                   height: 20,
  //                                 ),
  //                                 Padding(
  //
  //                                   padding: const EdgeInsets.all(15),
  //                                   child: ReusableText(title: videoComments[commentIndex].comment,),
  //                                 )
  //                               ],
  //                             ),
  //                           ):
  //                           const Center(child: ReusableText(title: "No comments available",color: Colors.white,),);
  //                         }),
  //                   ),
  //                   Row(
  //                     children: [
  //                       SizedBox(
  //                         height: 40,
  //                         width: Get.width*.6,
  //                         child: ReusableTextForm(
  //
  //                           hintText: "Write comment here...",
  //                           filledColor: Colors.white,
  //                           textColor: Colors.black,
  //                           controller: commentController,
  //                           maxLine: 3,
  //                         ),
  //                       ),
  //                       Center(
  //                         child: InkWell(
  //                             onTap: ()async{
  //                               if(commentController.text.isEmpty){
  //                                 Get.showSnackbar(const GetSnackBar(message: "Can't post empty comment",duration: Duration(seconds: 2),),);
  //                               }else{
  //                                 EasyLoading.show(status: 'Posting...');
  //                                 await VideoCommentServices().commentVideo(
  //                                     Provider.of<CurrentUserProvider>(context,listen: false).user!.userId!,
  //                                     videoId, commentController.text, context);
  //                                 await updateAllVideos();
  //                                 await VideoCommentServices().getAllVideoComments(videoId, context);
  //                                 setState(() {
  //
  //                                 });
  //                                 EasyLoading.dismiss();
  //                               }
  //                             },
  //                             child: Padding(
  //                               padding: const EdgeInsets.all(8.0),
  //                               child: Container(
  //                                   alignment: Alignment.center,
  //                                   width: MediaQuery.of(context).size.width*.3,
  //                                   height: 40,
  //                                   decoration: BoxDecoration(
  //                                       color: Colors.white,
  //                                       borderRadius: BorderRadius.circular(24)
  //                                   ),
  //                                   child: const Text("Comment",style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),)),
  //                             )),
  //                       )
  //                     ],
  //                   ),
  //
  //
  //
  //                 ],
  //               ),
  //             ),
  //           ),
  //         ),
  //       );
  //     },
  //   );
  // }
}
