import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart'as http;
import 'package:provider/provider.dart';
import '../../../consolePrintWithColor.dart';
import '../../../model/api_models/artist_models/artist_model.dart';
import '../../../model/api_models/events_model/events_model.dart';
import '../../../model/api_models/user_model/user_model.dart';
import '../../../providers/events_provider/events_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class EventServices{


  getAllEvents(BuildContext context)async{

    var header= {
      'Content-Type':'application/json',
    };

    String uri="${ApiConstants.baseUrl}${ApiConstants.getAllEvents}";

    print(uri);
    http.Response response=await ApiServices().getService(uri:uri,header: header);

    print(response.body);
    if(response.statusCode==200){
      var data= jsonDecode(response.body);
      List eventData=data['data'];
      print(response.body);
      print(eventData.length);

      // print(feedsMap);
      // imageUrl=imageUrl.replaceAll('public', ApiConstants.baseUrl);


      List<EventModel> eventList=[];
      for(int i=0; i<eventData.length;i++){

        eventList.add(EventModel.fromJson(eventData[i]));
      }

      Provider.of<EventsProvider>(context,listen: false).updateEvents(eventList);
      EasyLoading.dismiss();
      return true;
    }else{
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }


  }

  getMyEvents(BuildContext context)async{

    var header= {
      'Content-Type':'application/json',
    };

    String uri="${ApiConstants.baseUrl}${ApiConstants.getMyEvents}${Provider.of<CurrentUserProvider>(context,listen: false).user!.userId}";

    print(uri);
    http.Response response=await ApiServices().getService(uri:uri,header: header);

    print(response.body);
    if(response.statusCode==200){
      var data= jsonDecode(response.body);
      List eventData=data['data'];
      print(response.body);
      print(eventData.length);

      // print(feedsMap);
      // imageUrl=imageUrl.replaceAll('public', ApiConstants.baseUrl);


      List<EventModel> eventList=[];
      for(int i=0; i<eventData.length;i++){

        eventList.add(EventModel.fromJson(eventData[i]));
      }

      Provider.of<EventsProvider>(context,listen: false).updateMyEvents(eventList);
      EasyLoading.dismiss();
      return true;
    }else{
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }


  }


  createEvent(BuildContext context,{
    required String artistName,
    required String artistId,
    required String eventName,
    required String locationName,
    required String latitude,
    required String longitude,
    required String eventStartTime,
    required String eventEndTime,
    required String eventDate,
    required String imagePath
  })async{

    CurrentUserProvider user=Provider.of<CurrentUserProvider>(context,listen: false);

    var header= {
      'Content-Type':'application/json',
    };

    String uri="${ApiConstants.baseUrl}${ApiConstants.createEvent}";

    print(uri);
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'clientId': user.user!.userId.toString(),
      'artistName': artistName,
      'eventName': eventName,
      'eventPlace': locationName,
      'eventStartTime': eventStartTime,
      'eventEndTime': eventEndTime,
      'artistProfileId': "1",
      'longitude': "-92.037780",
      'latitude': "43.445110",

    });
    request.files.add(await http.MultipartFile.fromPath('eventImgStorage', imagePath));


    bool response=await ApiServices().postRequestWithFile(context,request);
    return response;
  }

  updateArtistProfile(BuildContext context,{
    required String artistName,
    required String bandName,
    required String about,
    required String imagePath,
    required String artistId
  })async{

    CurrentUserProvider user=Provider.of<CurrentUserProvider>(context,listen: false);

    var header= {
      'Content-Type':'application/json',
    };

    String uri="${ApiConstants.baseUrl}${ApiConstants.updateArtistProfile}$artistId";

    print(uri);
    var request = http.MultipartRequest('PUT', Uri.parse(uri));
    request.fields.addAll({
      'userId': user.user!.userId.toString(),
      'artistName': artistName,
      'bandName': bandName,
      'about': about
    });
    imagePath!=""?request.files.add(await http.MultipartFile.fromPath('artistProfileStorage', imagePath)):null;


    bool response=await ApiServices().postRequestWithFile(context,request);
    return response;
  }

  deleteEvent(BuildContext context,{

    required String eventId
  })async{

    CurrentUserProvider user=Provider.of<CurrentUserProvider>(context,listen: false);

    var header= {
      'Content-Type':'application/json',
    };

    String uri="${ApiConstants.baseUrl}${ApiConstants.deleteEvent}$eventId";

    printLog(uri);
    http.Response response=await ApiServices().deleteService(uri:uri);
    return response;
  }

}