import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart'as http;
import 'package:provider/provider.dart';
import '../../../consolePrintWithColor.dart';
import '../../../model/api_models/artist_models/artist_model.dart';
import '../../../model/api_models/user_model/user_model.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class AdminSongServices{



  addSong(
      BuildContext context,{
    required String songTitle,
    required String songDescription,
    required String year,
    required String singer,
    required String musicPath,
    required String categoryId,
  })async{

    CurrentUserProvider user=Provider.of<CurrentUserProvider>(context,listen: false);

    var header= {
      'Content-Type':'application/json',
    };

    String uri="${ApiConstants.baseUrl}${ApiConstants.addSong}";

    print(uri);
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'title': songTitle,
      'songCategoryId': categoryId,
      'singer': singer,
      'descriptionOfSong': songDescription,
      'Year': year,

    });
    request.files.add(await http.MultipartFile.fromPath('file', musicPath));


    bool response=await ApiServices().postRequestWithFile(context,request);
    return response;
  }

}