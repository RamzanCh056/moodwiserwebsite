import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../../../consolePrintWithColor.dart';
import '../../../model/api_models/artist_models/artist_model.dart';
import '../../../providers/artist_provider/artist_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class ArtistServices {
  getAllArtists(BuildContext context) async {
    var header = {
      'Content-Type': 'application/json',
    };

    String uri = "${ApiConstants.baseUrl}${ApiConstants.getAllArtists}";

    print(uri);
    http.Response response = await ApiServices().getService(uri: uri, header: header);

    print(response.body);
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      List artistData = data['data'];
      print(response.body);
      print(artistData.length);

      // print(feedsMap);
      // imageUrl=imageUrl.replaceAll('public', ApiConstants.baseUrl);

      List<ArtistModel> artistList = [];
      for (int i = 0; i < artistData.length; i++) {
        artistList.add(ArtistModel.fromJson(artistData[i]));
      }

      Provider.of<ArtistProvider>(context, listen: false).updateArtists(artistList);
      EasyLoading.dismiss();
      return true;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }

  getMyArtists(BuildContext context) async {
    CurrentUserProvider user = Provider.of<CurrentUserProvider>(context, listen: false);

    var header = {
      'Content-Type': 'application/json',
    };

    String uri = "${ApiConstants.baseUrl}${ApiConstants.getArtistByUserId}${user.user!.userId}";

    print(uri);
    http.Response response = await ApiServices().getService(uri: uri, header: header);

    print(response.body);
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      List artistData = data['data'];
      print(response.body);
      print(artistData.length);

      // print(feedsMap);
      // imageUrl=imageUrl.replaceAll('public', ApiConstants.baseUrl);

      List<ArtistModel> artistList = [];
      for (int i = 0; i < artistData.length; i++) {
        artistList.add(ArtistModel.fromJson(artistData[i]));
      }

      Provider.of<ArtistProvider>(context, listen: false).updateMyArtists(artistList);
      EasyLoading.dismiss();
      return true;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }

  createArtistProfile(BuildContext context,
      {required String artistName, required String bandName, required String about, required String imagePath}) async {
    CurrentUserProvider user = Provider.of<CurrentUserProvider>(context, listen: false);

    var header = {
      'Content-Type': 'application/json',
    };

    String uri = "${ApiConstants.baseUrl}${ApiConstants.getAllArtists}";

    print(uri);
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields
        .addAll({'userId': user.user!.userId.toString(), 'artistName': artistName, 'bandName': bandName, 'about': about});
    request.files.add(await http.MultipartFile.fromPath('artistProfileStorage', imagePath));

    bool response = await ApiServices().postRequestWithFile(context, request);
    return response;
  }

  updateArtistProfile(BuildContext context,
      {required String artistName,
      required String bandName,
      required String about,
      required String imagePath,
      required String artistId}) async {
    CurrentUserProvider user = Provider.of<CurrentUserProvider>(context, listen: false);

    var header = {
      'Content-Type': 'application/json',
    };

    String uri = "${ApiConstants.baseUrl}${ApiConstants.updateArtistProfile}$artistId";

    print(uri);
    var request = http.MultipartRequest('PUT', Uri.parse(uri));
    request.fields
        .addAll({'userId': user.user!.userId.toString(), 'artistName': artistName, 'bandName': bandName, 'about': about});
    imagePath != "" ? request.files.add(await http.MultipartFile.fromPath('artistProfileStorage', imagePath)) : null;

    bool response = await ApiServices().postRequestWithFile(context, request);
    return response;
  }

  deleteArtistProfile(BuildContext context, {required String artistId}) async {
    CurrentUserProvider user = Provider.of<CurrentUserProvider>(context, listen: false);

    var header = {
      'Content-Type': 'application/json',
    };

    String uri = "${ApiConstants.baseUrl}${ApiConstants.deleteArtistProfile}$artistId";

    printLog(uri);
    http.Response response = await ApiServices().deleteService(uri: uri);
    return response;
  }
}
