import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../model/api_models/feed_models/current_user_feed_model.dart';
import '../../../model/api_models/feed_models/feed_model.dart';
import '../../../model/api_models/user_model/user_model.dart';
import '../../../providers/feeds_provider/current_user_feeds_provider.dart';
import '../../../providers/feeds_provider/feeds_provider.dart';
import '../../../providers/stores_provider/store_feed_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class FeedServices {
  int? notificationId;
  Future<void> saveNotificationToApi(receiverId, postId, context) async {
    var provider = Provider.of<CurrentUserProvider>(context, listen: false);

    try {
      var url = Uri.parse('http://beatjerky.com/api/notification');
      var response = await http.post(
        url,
        body: jsonEncode({
          "message":
              "${provider.user?.firstName} ${provider.user?.lastName} commented on your post",
          "type": "Comment",
          "userId": provider.user?.userId,
          "receiverId": receiverId,
          "postId": postId,
          "followerId": provider.user?.userId,
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      print("Response status: ${response.statusCode}");
      print("Save noti Response body: ${response.body}");

      if (response.statusCode == 200) {
        var responseData = jsonDecode(response.body);
        // Extract the id field from the response
        notificationId = responseData['data']['id'];
        await fetchDeviceId(context, receiverId, notificationId);

        print("Notification saved successfully");
      } else {
        print("Failed to save notification");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  sendNotifications(context, notificationId, deviceId) async {
    var provider = Provider.of<CurrentUserProvider>(context, listen: false);

    try {
      var url = Uri.parse('https://fcm.googleapis.com/fcm/send');
      final body = {
        "to": deviceId,
        "notification": {
          "title": "Comment",
          "body":
              "${provider.user?.firstName} ${provider.user?.lastName} commented on your post",
        },
        "data": {
          "navigation": "/notification",
          "notificationId": notificationId.toString(),
        },
      };
      var response = await post(url,
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader:
                "key=AAAAzvnfWso:APA91bGq7Jb6rdm0AG4w9DwpOfi5vjUqR5V7L9nP8kF8CaDlvNTnDi6Ti4qH8kby1etFfPRqmand3ebDpbaehhxlLrsOahml-9h0XG3BEgb95W-a_8WKrH2-jxuXWSq-0-M-T0qWlJMN"
          },
          body: jsonEncode(body));

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');
      print("Sendiing Notification ");
      print("Send Notification successfully");
    } catch (e) {
      print("Notification-Error: ${e}");
    }
  }

  getCurrentUSerAllFeeds(BuildContext context) async {
    var header = {
      'Content-Type': 'application/json',
    };

    String uri =
        "${ApiConstants.baseUrl}${ApiConstants.getCurrentUserAllFeeds}${Provider.of<CurrentUserProvider>(context, listen: false).user!.userId}";

    print(uri);
    http.Response response =
        await ApiServices().getService(uri: uri, header: header);

    print(response.body);
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      List feedsMap = data['data'];
      print(response.body);
      print(feedsMap.length);
      // print(feedsMap);
      // imageUrl=imageUrl.replaceAll('public', ApiConstants.baseUrl);

      List<CurrentUserFeedsModel> feedList = [];
      for (int i = 0; i < feedsMap.length; i++) {
        feedList.add(CurrentUserFeedsModel.fromJson(feedsMap[i]));
      }
      print(feedList.length);
      Provider.of<CurrentUserFeedsProvider>(context, listen: false)
          .updateFeeds(feedList);
      EasyLoading.dismiss();
      return true;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }

  getStoreFeeds(BuildContext context, int storeId) async {
    var header = {
      'Content-Type': 'application/json',
    };

    String uri =
        "${ApiConstants.baseUrl}${ApiConstants.getCurrentUserAllFeeds}$storeId}";

    print(uri);
    http.Response response =
        await ApiServices().getService(uri: uri, header: header);

    print(response.body);
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      List feedsMap = data['data'];
      print(response.body);
      print(feedsMap.length);
      // print(feedsMap);
      // imageUrl=imageUrl.replaceAll('public', ApiConstants.baseUrl);

      List<CurrentUserFeedsModel> feedList = [];
      for (int i = 0; i < feedsMap.length; i++) {
        feedList.add(CurrentUserFeedsModel.fromJson(feedsMap[i]));
      }
      print(feedList.length);
      Provider.of<StoreFeedsProvider>(context, listen: false)
          .updateStoreFeeds(feedList);
      EasyLoading.dismiss();
      return true;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }

  fetchDeviceId(context, userId, notificationId) async {
    var header = {
      'Content-Type': 'application/json',
    };

    String uri = "${ApiConstants.baseUrl}${ApiConstants.userDeviceId}${userId}";

    http.Response response =
        await ApiServices().getService(uri: uri, header: header);

    if (response.statusCode == 200) {
      print("Device Id fetched successfully ${response.body}");
      var data = jsonDecode(response.body);
      var deviceId = data['data']['deviceId']; // Access deviceId from data
      await sendNotifications(context, notificationId, deviceId);
      return response.body;
    } else {
      throw Exception('Failed to fetch deviceId');
    }
  }

  getAllFeeds(BuildContext context) async {
    var header = {
      'Content-Type': 'application/json',
    };

    String uri = "${ApiConstants.baseUrl}${ApiConstants.getAllFeeds}?includeUser=true&populate=user";

    http.Response response =
        await ApiServices().getService(uri: uri, header: header);

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      List feedsMap = data['data'];
      print('API Response Body: ${response.body}');
      print('Feeds Count: ${feedsMap.length}');
      
              // Debug: Print first feed structure
        if (feedsMap.isNotEmpty) {
          print('First Feed Structure: ${feedsMap[0]}');
          print('All Keys in First Feed: ${feedsMap[0].keys.toList()}');
          if (feedsMap[0]['user'] != null) {
            print('User Data in First Feed: ${feedsMap[0]['user']}');
            print('Profile Image in User Data: ${feedsMap[0]['user']['profileImg']}');
            print('Profile Image (profileImage): ${feedsMap[0]['user']['profileImage']}');
            print('Profile Image (avatar): ${feedsMap[0]['user']['avatar']}');
            print('Profile Image (image): ${feedsMap[0]['user']['image']}');
            print('Profile Image (photo): ${feedsMap[0]['user']['photo']}');
            print('All User Fields: ${feedsMap[0]['user'].keys.toList()}');
            print('User Data Type: ${feedsMap[0]['user'].runtimeType}');
          } else {
            print('No user data found in feed!');
            print('Available fields: ${feedsMap[0].keys.toList()}');
          }
        }

      List<FeedModel> feedList = [];
      for (int i = 0; i < feedsMap.length; i++) {
        feedList.add(FeedModel.fromJson(feedsMap[i]));
      }
      print('Parsed Feed Models Count: ${feedList.length}');
      
      // Debug: Print first parsed feed model
      if (feedList.isNotEmpty) {
        print('First Parsed Feed User: ${feedList[0].user}');
        if (feedList[0].user != null) {
          print('First Parsed Feed User Profile Image: ${feedList[0].user!.profileImg}');
        }
      }
      
      Provider.of<FeedsProvider>(context, listen: false).updateFeeds(feedList);
      EasyLoading.dismiss();
      return true;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }

  Future<bool> deleteFeed(int feedId, BuildContext context) async {
    var user = Provider.of<CurrentUserProvider>(context, listen: false).user;
    var header = {
      'Content-Type': 'application/json',
    };

    String uri =
        "${ApiConstants.baseUrl}${ApiConstants.deleteFeed}?userId=${user!.userId}&feedId=$feedId";
    print(uri);
    Map<String, dynamic> body = {};
    http.Response response =
        await ApiServices().deleteService(uri: uri, body: body, header: header);

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      // var value=Provider.of<FeedsProvider>(context,listen: false).feedsList;
      // if(data["status"]=="success"){
      //   value[index].feedLikes.removeAt(likeIndex);
      // }

      EasyLoading.dismiss();
      return true;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }

  uploadFeed(String imagePath, String description, BuildContext context) async {
    var user = Provider.of<CurrentUserProvider>(context, listen: false).user;
    var request = http.MultipartRequest(
        'POST', Uri.parse('http://beatjerky.com/api/feed'));
    
    // Send only the required fields to the REST API
    request.fields.addAll({
      'userId': '${user!.userId}', 
      'description': description,
    });
    
    request.files.add(await http.MultipartFile.fromPath('feed', imagePath));

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      // After successful API upload, also save to Firebase with profile data
      try {
        await _savePostToFirebase(user, description, imagePath, context);
      } catch (e) {
        print('Error saving to Firebase: $e');
        // Don't fail the upload if Firebase save fails
      }
      return true;
    } else {
      return false;
    }
  }
  
  // Save post data to Firebase with profile information
  Future<void> _savePostToFirebase(user, String description, String imagePath, BuildContext context) async {
    try {
      // Get the current user's profile image from Firebase
      var userDoc = await FirebaseFirestore.instance
          .collection('usersData')
          .doc(user.userId.toString())
          .get();
      
      String? profileImageUrl = '';
      if (userDoc.exists && userDoc.data() != null) {
        var userData = userDoc.data()!;
        profileImageUrl = userData['profileImage'] ?? '';
      }
      
             // Create a post document in Firebase
       await FirebaseFirestore.instance.collection('posts').add({
         'userId': user.userId.toString(),
         'description': description,
         'userFirstName': user.firstName ?? '',
         'userLastName': user.lastName ?? '',
         'profileImage': profileImageUrl, // Use the same field name as usersData collection
         'timestamp': FieldValue.serverTimestamp(),
         'type': 'image',
         'likes': 0,
         'comments': 0,
         'dislikes': 0,
       });
      
      print('Post saved to Firebase with profile data');
    } catch (e) {
      print('Error saving post to Firebase: $e');
      rethrow;
    }
  }

  reportFeed(int feedId, BuildContext context) async {
    var user = Provider.of<CurrentUserProvider>(context, listen: false).user;
    var header = {
      'Content-Type': 'application/json',
    };

    String uri =
        "${ApiConstants.baseUrl}${ApiConstants.deleteFeed}?userId=${user!.userId}&feedId=$feedId";
    print(uri);
    Map<String, dynamic> body = {};
    http.Response response =
        await ApiServices().deleteService(uri: uri, body: body, header: header);

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      // var value=Provider.of<FeedsProvider>(context,listen: false).feedsList;
      // if(data["status"]=="success"){
      //   value[index].feedLikes.removeAt(likeIndex);
      // }

      EasyLoading.dismiss();
      return true;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }
}
