import 'dart:convert';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart'as http;
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../../../consolePrintWithColor.dart';
import '../../../model/api_models/store_models/product_model.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class Checkout{
  static checkOut(
      BuildContext context,
  String productName,
  int productId,
  String storeName,
  int storeId,
  int userId,
  String userName,
  int productPrice,
  int productDiscount,
  int OrderId,
  String orderStatus)async{

    try{
      var header= {
        'Content-Type':'application/json',
      };
      printLog("Getting Products");
      print(Provider.of<CurrentUserProvider>(context,listen: false).user!.userId);
      String uri="${ApiConstants.baseUrl}${ApiConstants.checkOut}";
      Map<String ,dynamic> body={
        "userId":Provider.of<CurrentUserProvider>(context,listen: false).user!.userId,
        'productName':productName,
            'productId':productId,
            'storeName':storeName,
            'storeId':storeId,
            'userName':userName,
            'productPrice':productPrice,
            'productDiscount':productDiscount,
            'OrderId': OrderId,
            'orderStatus': orderStatus
      };

      printLog(uri);
      // printLog(header);
      http.Response response=await ApiServices().postService(uri:uri,body:body,header: header);
      printLog(response.body);
      if(response.statusCode==200){
        EasyLoading.showSuccess("Checked out successfully");

        print(response.body);
        return true;
      }else{
        EasyLoading.showError(response.statusCode.toString());
        return false;
      }
    }catch(e){
      EasyLoading.showError(e.toString(),duration: const Duration(seconds: 3));
    }



  }
}