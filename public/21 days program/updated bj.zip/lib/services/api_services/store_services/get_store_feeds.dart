import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart'as http;
import 'package:provider/provider.dart';
import '../../../model/api_models/feed_models/current_user_feed_model.dart';
import '../../../model/api_models/user_model/user_model.dart';
import '../../../providers/stores_provider/store_feed_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class StoreFeedServices{


  getStoreFeeds(BuildContext context,int storeId)async{

    var header= {
      'Content-Type':'application/json',
    };

    String uri="${ApiConstants.baseUrl}${ApiConstants.getStoreFeeds}$storeId}";

    print(uri);
    http.Response response=await ApiServices().getService(uri:uri,header: header);

    print(response.body);
    if(response.statusCode==200){
      var data= jsonDecode(response.body);
      List feedsMap=data['data'];
      print(response.body);
      print(feedsMap.length);
      // print(feedsMap);
      // imageUrl=imageUrl.replaceAll('public', ApiConstants.baseUrl);


      List<CurrentUserFeedsModel> feedList=[];
      for(int i=0; i<feedsMap.length;i++){

        feedList.add(CurrentUserFeedsModel.fromJson(feedsMap[i]));
      }
      print(feedList.length);
      Provider.of<StoreFeedsProvider>(context,listen: false).updateStoreFeeds(feedList);
      EasyLoading.dismiss();
      return true;
    }else{
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }


  }




}