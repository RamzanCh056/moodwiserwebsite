import 'dart:convert';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart'as http;
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../../../consolePrintWithColor.dart';
import '../../../model/api_models/store_models/product_model.dart';
import '../../../providers/stores_provider/product_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class GetProducts{
  static getProducts(BuildContext context,int storeId)async{

    try{
      var header= {
        'Content-Type':'application/json',
      };
      printLog("Getting Products");
      print(Provider.of<CurrentUserProvider>(context,listen: false).user!.userId);
      String uri="${ApiConstants.baseUrl}${ApiConstants.getProducts}$storeId";
      Map<String ,dynamic> body={

      };

      printLog(uri);
      // printLog(header);
      http.Response response=await ApiServices().getService(uri:uri,header: header);
      printLog(response.body);
      if(response.statusCode==200){
        var data= jsonDecode(response.body);
        List usersMap=data['products'];

        List<ProductModel> allProductsList=[];
        for(int i=0;i<usersMap.length;i++){
          ProductModel user=ProductModel.fromJson(usersMap[i]);
          allProductsList.add(user);
        }

        Provider.of<ProductProvider>(context,listen: false).updateProducts(allProductsList);

        print(response.body);
        return true;
      }else{
        EasyLoading.showError(response.statusCode.toString());
        return false;
      }
    }catch(e){
      EasyLoading.showError(e.toString(),duration: const Duration(seconds: 3));
    }



  }
}