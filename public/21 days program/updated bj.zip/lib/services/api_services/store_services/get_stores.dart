import 'dart:convert';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../consolePrintWithColor.dart';
import '../../../model/api_models/store_models/store_model.dart';
import '../../../model/api_models/user_model/all_users_model.dart';
import '../../../providers/stores_provider/store_provider.dart' show StoreProvider;
import '../../../providers/users_provider/all_users_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class GetStores {
  static getAllStores(BuildContext context) async {
    try {
      var header = {
        'Content-Type': 'application/json',
      };
      printLog("Getting Stores");
      print(Provider.of<CurrentUserProvider>(context, listen: false).user!.userId);
      String uri = "${ApiConstants.baseUrl}${ApiConstants.getStores}";
      Map<String, dynamic> body = {};

      printLog(uri);
      // printLog(header);
      http.Response response = await ApiServices().getService(uri: uri, header: header);
      printLog(response.body);
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        List usersMap = data['stores'];

        List<StoreModel> allStoresList = [];
        for (int i = 0; i < usersMap.length; i++) {
          StoreModel user = StoreModel.fromJson(usersMap[i]);
          allStoresList.add(user);
        }

        Provider.of<StoreProvider>(context, listen: false).updateStores(allStoresList);

        print(response.body);
        return true;
      } else {
        EasyLoading.showError(response.statusCode.toString());
        return false;
      }
    } catch (e) {
      print("store error is here $e");
      EasyLoading.showError(e.toString(), duration: const Duration(seconds: 3));
    }
  }
}
