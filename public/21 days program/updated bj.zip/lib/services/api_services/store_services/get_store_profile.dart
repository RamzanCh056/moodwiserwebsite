import 'dart:convert';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../consolePrintWithColor.dart';
import '../../../model/api_models/store_models/store_profile_model.dart';
import '../../../model/api_models/user_model/all_users_model.dart';
import '../../../providers/stores_provider/store_provider.dart';
import '../../../providers/users_provider/all_users_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class GetStoreProfile{
  static getStoreProfile(BuildContext context,int storeId)async{

    try{
      var header= {
        'Content-Type':'application/json',
      };
      printLog("Getting Store profile");
      print(Provider.of<CurrentUserProvider>(context,listen: false).user!.userId);
      String uri="${ApiConstants.baseUrl}${ApiConstants.storeProfile}$storeId";
      Map<String ,dynamic> body={

      };

      printLog(uri);
      // printLog(header);
      http.Response response=await ApiServices().getService(uri:uri,header: header);
      printLog(response.body);
      if(response.statusCode==200){
        var data= jsonDecode(response.body);
        var storeProfileData=data['data'];
        StoreProfileModel storeProfile=StoreProfileModel.fromJson(storeProfileData);
        Provider.of<StoreProvider>(context,listen: false).updateStoreProfile(storeProfile);
        print(response.body);
        return true;
      }else{
        EasyLoading.showError(response.statusCode.toString());
        return false;
      }
    }catch(e){
      EasyLoading.showError(e.toString(),duration: const Duration(seconds: 3));
    }



  }

  static followStore(int storeId,BuildContext context)async{

    var header= {
      'Content-Type':'application/json',
    };
    print(Provider.of<CurrentUserProvider>(context,listen: false).user!.userId);
    String uri="${ApiConstants.baseUrl}${ApiConstants.followStore}";
    Map<String ,dynamic> body={
      "userId":Provider.of<CurrentUserProvider>(context,listen: false).user!.userId,
      "storeId":storeId
    };
    print(body);


    print(uri);
    print(header);
    http.Response response=await ApiServices().postService(uri:uri,body: body,header: header);
    print(response.body);
    if(response.statusCode==200){
      EasyLoading.showToast("Followed Successfully",duration: const Duration(seconds: 2),toastPosition: EasyLoadingToastPosition.bottom);
      await getStoreProfile( context,storeId);
      return true;
    }else if(response.statusCode==400){
      // await unFollowStore(storeId, context);
      // EasyLoading.showError("Already Followed");
      return false;
    }else{
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }


  }

  static unFollowStore(int storeId,BuildContext context)async{

    var header= {
      'Content-Type':'application/json',
    };
    int userId=Provider.of<CurrentUserProvider>(context,listen: false).user!.userId!;
    print(Provider.of<CurrentUserProvider>(context,listen: false).user!.userId);
    String uri="${ApiConstants.baseUrl}${ApiConstants.followStore}?storeId=$storeId&userId=$userId";

    // print(body);


    print(uri);
    print(header);
    http.Response response=await ApiServices().deleteService(uri:uri);
    print(response.body);
    if(response.statusCode==200){
      EasyLoading.showToast("UnFollowed Successfully",duration: const Duration(seconds: 2),toastPosition: EasyLoadingToastPosition.bottom);
      await getStoreProfile(context, storeId);
      return true;
    }else if(response.statusCode==400){
      /// Todo:15-9-2023
      return false;
    }else{
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }


  }

}