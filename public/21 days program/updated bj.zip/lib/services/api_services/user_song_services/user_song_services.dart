import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart'as http;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../model/api_models/all_categories/all_category_model.dart';
import '../../../model/api_models/all_categories/all_category_song_model.dart';
import '../../../providers/user_songs_categories_provider/user_songs_categories_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class UserSongServices{


  getSongCategories(BuildContext context)async{

    var header= {
      'Content-Type':'application/json',
    };

    String uri="${ApiConstants.baseUrl}${ApiConstants.getCategories}";
    Map<String ,dynamic> body={

    };

    print(uri);
    print(header);
    http.Response response=await ApiServices().getService(uri:uri,header: header);
    print(response.body);
    if(response.statusCode==200){
      var data= jsonDecode(response.body);
      List dataList=data['data'];
      List<AllCategoriesModel> categoriesList=[];
      for(int i=0;i<dataList.length;i++){
        categoriesList.add( AllCategoriesModel.fromJson(dataList[i]));
      }
      Provider.of<UserSongsCategoriesProvider>(context,listen: false).updateAllCategories(categoriesList);
      print(response.body);
      print(response.body);
      return true;
    }else{
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }


  }

  addSong(
      BuildContext context,{
        required String songTitle,
        required String songDescription,
        required String year,
        required String singer,
        required String musicPath,
        required String categoryId,
      })async{

    CurrentUserProvider user=Provider.of<CurrentUserProvider>(context,listen: false);

    var header= {
      'Content-Type':'application/json',
    };


    String uri="${ApiConstants.baseUrl}${ApiConstants.uploadSongByUser}";

    print("I am uploading song to ${uri}");
    print(uri);
    var request = http.MultipartRequest('POST', Uri.parse(uri));
    request.fields.addAll({
      'title': songTitle,
      'songCategoryID': categoryId,
      'singer': singer,
      'descriptionOfSong': songDescription,
      'Year': year,
      'userId':user.user!.userId.toString(),


    });
    request.files.add(await http.MultipartFile.fromPath('file', musicPath));




    bool response=await ApiServices().postRequestWithFile(context,request);
    return response;
  }

  


}

