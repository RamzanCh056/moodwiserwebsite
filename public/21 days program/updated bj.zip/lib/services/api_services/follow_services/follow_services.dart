import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:provider/provider.dart';

import '../../../providers/follower_provider/followers_and_following_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class FollowServices {
  int? followerId;
  Future<void> saveFollowerNotificationToApi(receiverId, context) async {
    var provider = Provider.of<CurrentUserProvider>(context, listen: false);

    try {
      var url = Uri.parse('http://beatjerky.com/api/notification');
      var response = await http.post(
        url,
        body: jsonEncode({
          "message":
              "${provider.user?.firstName} ${provider.user?.lastName} started following you",
          "type": "Follower",
          "userId": provider.user?.userId,
          "receiverId": receiverId,
          "postId": null,
          "followerId": provider.user?.userId,
        }),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      print("Response status: ${response.statusCode}");
      print("Save noti Response body: ${response.body}");

      if (response.statusCode == 200) {
        var responseData = jsonDecode(response.body);

        followerId = responseData['data']['id'];

        await fetchFollowerDeviceId(context, receiverId, followerId);

        print("Follower Notification saved successfully");
      } else {
        print("Failed to save notification");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  fetchFollowerDeviceId(context, receiverId, followerId) async {
    var header = {
      'Content-Type': 'application/json',
    };

    String uri =
        "${ApiConstants.baseUrl}${ApiConstants.userDeviceId}${receiverId}";

    http.Response response =
        await ApiServices().getService(uri: uri, header: header);

    if (response.statusCode == 200) {
      print("Device Id fetched successfully ${response.body}");
      var data = jsonDecode(response.body);
      var deviceId = data['data']['deviceId']; // Access deviceId from data
      await sendFollowerNotifications(context, followerId, deviceId);
      return response.body;
    } else {
      throw Exception('Failed to fetch deviceId');
    }
  }

  sendFollowerNotifications(context, notificationId, deviceId) async {
    var provider = Provider.of<CurrentUserProvider>(context, listen: false);

    try {
      var url = Uri.parse('https://fcm.googleapis.com/fcm/send');
      final body = {
        "to": deviceId,
        "notification": {
          "title": "Follower",
          "body":
              "${provider.user?.firstName} ${provider.user?.lastName} started following you",
        },
        "data": {
          "navigation": "/notification",
          "notificationId": notificationId.toString(),
        },
      };
      var response = await post(url,
          headers: {
            HttpHeaders.contentTypeHeader: 'application/json',
            HttpHeaders.authorizationHeader:
                "key=AAAAzvnfWso:APA91bGq7Jb6rdm0AG4w9DwpOfi5vjUqR5V7L9nP8kF8CaDlvNTnDi6Ti4qH8kby1etFfPRqmand3ebDpbaehhxlLrsOahml-9h0XG3BEgb95W-a_8WKrH2-jxuXWSq-0-M-T0qWlJMN"
          },
          body: jsonEncode(body));

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');
      print("Sendiing Notification ");
      print("Send Notification successfully");
    } catch (e) {
      print("Notification-Error: ${e}");
    }
  }

  followUser(int followerId, BuildContext context) async {
    var header = {
      'Content-Type': 'application/json',
    };
    print(
        Provider.of<CurrentUserProvider>(context, listen: false).user!.userId);
    String uri = "${ApiConstants.baseUrl}${ApiConstants.follow}";
    Map<String, dynamic> body = {
      "userId":
          Provider.of<CurrentUserProvider>(context, listen: false).user!.userId,
      "followerId": followerId
    };
    print(body);

    print(uri);
    print(header);
    http.Response response =
        await ApiServices().postService(uri: uri, body: body, header: header);
    print(response.body);
    if (response.statusCode == 200) {
      EasyLoading.showSuccess("Followed Successfully");

      await saveFollowerNotificationToApi(followerId, context);

      return true;
    } else if (response.statusCode == 400) {
      EasyLoading.showError("Already Followed");
      return false;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }

  getAllFollowersAndFollowing(BuildContext context) async {
    var header = {
      'Content-Type': 'application/json',
    };
    print(
        Provider.of<CurrentUserProvider>(context, listen: false).user!.userId);
    String uri =
        "${ApiConstants.baseUrl}${ApiConstants.getFollowersAndFollowing}${Provider.of<CurrentUserProvider>(context, listen: false).user!.userId}";
    Map<String, dynamic> body = {};

    print(uri);
    print(header);
    http.Response response =
        await ApiServices().getService(uri: uri, header: header);
    print(response.body);
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);

      Provider.of<FollowAndFollowingProvider>(context, listen: false)
          .updateFollowersAndFollowing(
              data['data']['follower'], data['data']['following']);

      print(response.body);
      return true;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }

  uploadProfileImage(String imagePath, BuildContext context) async {
    var headers = {
      'Cookie':
          'accessToken=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE0LCJmaXJzdE5hbWUiOiJTYWxpaCIsImxhc3ROYW1lIjoiSGF5YXQiLCJlbWFpbCI6InNhbGloQGdtYWlsLmNvbSIsImFkbWluIjpmYWxzZSwiaWF0IjoxNjg4OTY3NTE2LCJleHAiOjE2ODkwNTM5MTZ9.Jd9ITz9zj50w1B1GZyVATfE5yUGtpMA-_UZQL8loGeM'
    };

    String url = ApiConstants.baseUrl + ApiConstants.uploadProfileImage;

    var request = http.MultipartRequest('PUT', Uri.parse(url));
    request.fields.addAll({
      'userId': Provider.of<CurrentUserProvider>(context, listen: false)
          .user!
          .userId
          .toString()
    });
    request.files.add(await http.MultipartFile.fromPath('file', imagePath));
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send().whenComplete(() {
      EasyLoading.showToast("Uploaded successfully",
          duration: const Duration(seconds: 2),
          toastPosition: EasyLoadingToastPosition.bottom);
      EasyLoading.dismiss();
    });

    if (response.statusCode == 200) {
      print(await response.stream.bytesToString());
    } else {
      print(response.reasonPhrase);
    }
  }
}
