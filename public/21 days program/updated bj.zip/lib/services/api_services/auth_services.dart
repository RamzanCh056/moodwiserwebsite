import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../../consolePrintWithColor.dart';
import '../../model/api_models/user_model/user_model.dart';
import '../../providers/users_provider/current_user_provider.dart';
import '../../repo/api_consts.dart';
import '../../repo/api_services.dart';
import '../../screens/auth_screen/login_screen.dart';

class AuthServices {
  login(String email, String password, BuildContext context, deviceId) async {
    var header = {'Content-Type': 'application/json'};
    String uri = ApiConstants.baseUrl + ApiConstants.login;
    Map<String, dynamic> body = {
      'email': email,
      'password': password,
      'isAdmin': false,
      "deviceId": deviceId,
    };

    print(uri);
    print(body);
    http.Response response =
        await ApiServices().postService(uri: uri, body: body, header: header);
    print(response.body);
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);

      Provider.of<CurrentUserProvider>(context, listen: false)
          .updateUser(UserModel.fromJson(data['data']));

      print(response.body);
      print(response.body);
      return true;
    } else {
      return false;
    }
  }

  forgotPassword(String email, BuildContext context) async {
    var header = {'Content-Type': 'application/json'};
    String uri = ApiConstants.baseUrl + ApiConstants.forgotPassword;
    Map<String, dynamic> body = {
      'email': email,
    };

    http.Response response =
        await ApiServices().postService(uri: uri, body: body, header: header);
    print(response.body);
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      EasyLoading.showSuccess(
          "We have sent password reset link to provided email, please check email",
          duration: const Duration(seconds: 3));
      // print(response.body);
      return true;
    } else {
      return false;
    }
  }

  signUp(String firstName, String lastName, String email, String password,
      String deviceId) async {
    var header = {'Content-Type': 'application/json'};
    String uri = ApiConstants.baseUrl + ApiConstants.signup;
    Map<String, dynamic> body = {
      'firstName': firstName,
      'lastName': lastName,
      'email': email,
      'password': password,
      "deviceId": deviceId,
    };

    http.Response response =
        await ApiServices().postService(uri: uri, body: body, header: header);
    print(response.body);
    if (response.statusCode == 200) {
      print(response.body);
      print(response.body);
      return true;
    } else {
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }
  }

  deleteAccount(String userId, BuildContext context) async {
    var header = {'Content-Type': 'application/json'};
    String uri = ApiConstants.baseUrl + ApiConstants.deleteAccount + userId;
    printLog("${uri}");
    Map<String, dynamic> body = {};

    http.Response response =
        await ApiServices().deleteService(uri: uri, body: body, header: header);
    printLog(response.body);
    if (response.statusCode == 200) {
      EasyLoading.showToast("Successfully deleted");
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => LoginScreen()),
          (route) => false);
      return true;
    } else {
      return false;
    }
  }
}
