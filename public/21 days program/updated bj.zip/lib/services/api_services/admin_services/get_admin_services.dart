
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart'as http;
import 'package:provider/provider.dart';
import '../../../consolePrintWithColor.dart';
import '../../../model/api_models/user_model/user_model.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../repo/api_services.dart';

class AdminServices{


  getAdmin(BuildContext context)async{

    var header= {
      'Content-Type':'application/json',
    };

    String uri="${ApiConstants.baseUrl}${ApiConstants.getAdmin}";

    print(uri);
    http.Response response=await ApiServices().getService(uri:uri,header: header);

    print(response.body);
    if(response.statusCode==200){
      var data= jsonDecode(response.body);
      List admin=data['data'];
      printLog(response.body);
       // print(feedsMap);
      // imageUrl=imageUrl.replaceAll('public', ApiConstants.baseUrl);




      EasyLoading.dismiss();
      return admin;
    }else{
      EasyLoading.showError(response.statusCode.toString());
      return false;
    }


  }
}