import 'package:shared_preferences/shared_preferences.dart';

import '../../model/api_models/user_model/user_model.dart';

class AuthPreferences {
  setAuthPreferences(String email, String password, String deviceId) async {
    SharedPreferences instance = await SharedPreferences.getInstance();

    instance.setString(UserModelFields.email, email);

    /// here we are saving user password with key of userId
    instance.setString(UserModelFields.userId, password);
    instance.setString(UserModelFields.deviceId, deviceId);
  }

  getAuthPreferences() async {
    SharedPreferences instance = await SharedPreferences.getInstance();

    Map<String, dynamic> authMap = {
      UserModelFields.email: instance.getString(UserModelFields.email) ?? '',

      /// here we are saving user password with key of userId
      UserModelFields.userId: instance.getString(UserModelFields.userId) ?? '',
      UserModelFields.deviceId:
          instance.getString(UserModelFields.deviceId) ?? ''
    };
    return authMap;
  }
}
