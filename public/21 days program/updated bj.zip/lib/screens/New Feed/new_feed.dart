import 'dart:async';
import 'dart:developer';
import 'package:beatjerky/providers/feeds_provider/feed_comments_provider.dart';
import 'package:beatjerky/screens/New%20Feed/comment_screen.dart';
import 'package:provider/provider.dart';
import 'package:beatjerky/providers/feeds_provider/feeds_provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:video_player/video_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:just_audio/just_audio.dart';
import '../../widget/reusable_text.dart';
import '../../utils/name_utils.dart';
import '../auth_screen/login_screen.dart';
import '../../model/music_track_model.dart';
import '../../notification_services/trigger_notification_services.dart';
import '../../model/question_model.dart';
import 'create_post_screen.dart';

class NewFeedScreen extends StatelessWidget {
  const NewFeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final feedProvider = Provider.of<FeedProvider>(context);
    final userId = FirebaseAuth.instance.currentUser?.uid;

    if (userId == null) {
      Future.microtask(() {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const LoginScreen()),
        );
      });
      return const SizedBox();
    }

    return Scaffold(
      backgroundColor: const Color(0xFF1E1E1E),
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: const Color(0xFF1E1E1E),
        elevation: 0,
        title: const ReusableText(title: "BeatJerky Hub", color: Colors.white),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: Colors.white),
            onPressed: () async {
              final refreshed = await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CreatePostScreen()),
              );
              if (refreshed == true) {
                feedProvider.fetchPosts();
              }
            },
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: Builder(
        builder: (_) {
          if (feedProvider.isLoading && feedProvider.posts.isEmpty) {
            return const Center(
              child: CircularProgressIndicator(color: Colors.white),
            );
          }

          if (feedProvider.errorMessage != null) {
            return Center(
              child: Text(
                'Error: ${feedProvider.errorMessage}',
                style: const TextStyle(color: Colors.redAccent),
              ),
            );
          }

          if (feedProvider.posts.isEmpty) {
            return const Center(
              child: Text(
                'No posts available.',
                style: TextStyle(color: Colors.white),
              ),
            );
          }

          return ListView.builder(
            padding: EdgeInsets.only(top: 12.0, bottom: 12),
            itemCount: feedProvider.posts.length,
            itemBuilder: (context, index) {
              final post = feedProvider.posts[index];

              String timeAgo = "now";
              if (post['timestamp'] != null) {
                try {
                  timeAgo = timeago.format(
                    (post['timestamp'] as Timestamp).toDate(),
                    locale: 'en_short',
                  );
                } catch (_) {}
              }

              return HomeCard(
                userId: post['userId'],
                postId: post['id'],
                fileUrl: post['fileUrl'],
                likes: post['likes'],
                description: post['description'],
                userImage: post['userImage'],
                userName: NameUtils.getDisplayName(
                    post['userFirstName'], post['userSecondName']),
                time: timeAgo,
                type: post['type'],
                musicData:
                    feedProvider.safeMusicDataFromMap(post['music']),
                questionId: post['questionId'],
                location: post['location'],
                tags: post['tags'] != null
                    ? List<String>.from(post['tags'])
                    : null,
              );
            },
          );
        },
      ),
    );
  }
}


class HomeCard extends StatefulWidget {
  final String fileUrl;
  final String postId;
  final int likes;
  final String userId;
  final String description;
  final String userName;
  final String userImage;
  final String time;
  final String type;
  final PostWithMusic? musicData;
  final String? questionId;
  final String? location;
  final List<String>? tags;

  const HomeCard({
    super.key,
    required this.fileUrl,
    required this.postId,
    required this.userId,
    required this.description,
    required this.userName,
    required this.userImage,
    required this.time,
    required this.type,
    required this.likes,
    this.musicData,
    this.questionId,
    this.location,
    this.tags,
  });

  @override
  _HomeCardState createState() => _HomeCardState();
}

class _HomeCardState extends State<HomeCard> {
  int likes = 0;
  bool _isLiked = false;
  bool _isUpdating = false;
  int shareCount = 0;
  late VideoPlayerController _videoController;
  bool _isVideoPlaying = false;
  int commentCount = 0; // Add comment count variable
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  
  // Music playback
  AudioPlayer? _musicPlayer;
  bool _isMusicPlaying = false;
  bool _isMusicInitialized = false;
  StreamSubscription<Duration>? _musicPosSub;
  double _musicClipStart = 0;
  double? _musicClipDuration;
  
  // Stream subscriptions for proper disposal
  StreamSubscription<DocumentSnapshot>? _likeStatusSubscription;
  StreamSubscription<DocumentSnapshot>? _likeCountSubscription;
  StreamSubscription<DocumentSnapshot>? _questionSubscription;
  
  // Question state
  QuestionPost? _questionData;
  String? _selectedOptionId;
  bool _hasVoted = false;
  bool _isLoadingQuestion = false;
  bool get isLoadingQuestion => _isLoadingQuestion;

  @override
  void initState() {
    super.initState();
    likes = widget.likes;
    _checkUserLikeStatus();
    _listenToLikeStatus();
    _listenToLikeCount();
    _loadCommentCount();

    if (widget.type == 'video' && widget.fileUrl.isNotEmpty) {
      _videoController = VideoPlayerController.network(widget.fileUrl)
        ..initialize().then((_) {
          setState(() {});
        });
    }

    // Initialize music player if post has music
    if (widget.musicData != null && widget.musicData!.musicUrl != null) {
      _initializeMusicPlayer();
    }

    // Load question data if this is a question post
    if (widget.type == 'question' && widget.questionId != null) {
      _loadQuestionData();
      _questionSubscription = _firestore
          .collection('questions')
          .doc(widget.questionId!)
          .snapshots()
          .listen((doc) {
        if (!mounted) return;
        if (doc.exists) {
          try {
            final map = doc.data() as Map<String, dynamic>;
            _questionData = QuestionPost.fromMap(map);
            final currentUser = _auth.currentUser;
            if (currentUser != null) {
              bool voted = false;
              String? selected;
              for (final opt in _questionData!.options) {
                if (opt.voters.contains(currentUser.uid)) {
                  voted = true;
                  selected = opt.id;
                  break;
                }
              }
              _hasVoted = voted;
              _selectedOptionId = selected;
            }
            setState(() {});
          } catch (_) {}
        }
      });
    }
  }

  Future<void> _initializeMusicPlayer() async {
    try {
      _musicPlayer = AudioPlayer();
      await _musicPlayer!.setUrl(widget.musicData!.musicUrl!);
      await _musicPlayer!.setVolume(widget.musicData!.musicVolume ?? 0.5);

      _musicClipStart = (widget.musicData!.musicStartTime ?? 0).toDouble();
      _musicClipDuration = widget.musicData!.musicClipDuration?.toDouble();

      if (_musicClipStart > 0) {
        await _musicPlayer!.seek(Duration(seconds: _musicClipStart.toInt()));
      }

      _musicPosSub?.cancel();
      _musicPosSub = _musicPlayer!.positionStream.listen((pos) {
        if (_musicClipDuration != null) {
          final end = _musicClipStart + _musicClipDuration!;
          if (pos.inSeconds >= end.toInt()) {
            _musicPlayer?.pause();
            _musicPlayer?.seek(Duration(seconds: _musicClipStart.toInt()));
            if (mounted && _isMusicPlaying) {
              setState(() { _isMusicPlaying = false; });
            }
          }
        }
      });

      setState(() {
        _isMusicInitialized = true;
      });
    } catch (e) {
      print('Error initializing music player: $e');
    }
  }

  Future<void> _toggleMusicPlayback() async {
    if (!_isMusicInitialized || _musicPlayer == null) {
      await _initializeMusicPlayer();
      if (_musicPlayer == null) return;
    }
    
    try {
      if (_isMusicPlaying) {
        await _musicPlayer!.pause();
      } else {
        // Ensure we start inside clip
        final pos = _musicPlayer!.position;
        if (pos.inSeconds < _musicClipStart.toInt()) {
          await _musicPlayer!.seek(Duration(seconds: _musicClipStart.toInt()));
        }
        await _musicPlayer!.play();
      }
      
      setState(() {
        _isMusicPlaying = !_isMusicPlaying;
      });
    } catch (e) {
      print('Error toggling music playback: $e');
    }
  }

  Future<void> _loadCommentCount() async {
    try {
      final snapshot = await _firestore
          .collection('posts')
          .doc(widget.postId)
          .collection('comments')
          .get();
      
      setState(() {
        commentCount = snapshot.docs.length;
      });
    } catch (e) {
      print('Error loading comment count: $e');
    }
  }

  Future<void> _sendLikeNotification() async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) return;

      // Don't send notification if user is liking their own post
      if (currentUser.uid == widget.userId) return;

      log("postuserid ${widget.userId}");

      // Get post owner's FCM token using your approach
      final userSnapshot = await FirebaseFirestore.instance
          .collection('usersData')  // Correct collection name
          .doc(widget.userId)
          .get();
      
      final userData = userSnapshot.data();
      final targetToken = userData?['fcmToken'] as String?;

      // Get current user's name for the notification
      final currentUserDoc = await _firestore
            .collection('usersData')
            .doc(currentUser.uid)
            .get();
        
        final currentUserName = currentUserDoc['firstName'] ?? 'Someone';
      
      if (targetToken != null && targetToken.isNotEmpty) {
        
        // Send push notification
        final trigger = TriggerNotificationService();
        await trigger.sendPushNotification(
          token: targetToken,
          title: 'New Like! ❤️',
          body: '$currentUserName liked your post',
        );

        
      } else {
        log('No FCM token found for user ${widget.userId}');
      }
      // Save notification to Firestore
        final notificationData = {
          'type': 'like',
          'fromUserId': currentUser.uid,
          'fromUserName': currentUserName,
          'postId': widget.postId,
          'timestamp': FieldValue.serverTimestamp(),
          'message': '$currentUserName liked your post',
          'isRead': false,
        };
          await _firestore
  .collection('notifications')
  .doc(widget.userId)
  .collection('userNotifications')
  .add(notificationData);

        log('Like notification sent and saved for ${widget.userId}');
    } catch (e) {
      log('Error sending like notification: $e');
    }
  }

  @override
  void dispose() {
    // Cancel all stream subscriptions to prevent memory leaks
    _likeStatusSubscription?.cancel();
    _likeCountSubscription?.cancel();
    _questionSubscription?.cancel();
    
    if (widget.type == 'video') {
      _videoController.dispose();
    }
    _musicPosSub?.cancel();
    _musicPlayer?.dispose();
    super.dispose();
  }

  Future<void> _checkUserLikeStatus() async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) return;

      final likeDoc = await _firestore
          .collection('posts')
          .doc(widget.postId)
          .collection('likes')
          .doc(currentUser.uid)
          .get();

      if (mounted) {
        setState(() {
          _isLiked = likeDoc.exists;
        });
      }
    } catch (e) {
      print('Error checking user like status: $e');
    }
  }

  // Listen to real-time like status changes
  void _listenToLikeStatus() {
    final currentUser = _auth.currentUser;
    if (currentUser == null) return;

    _likeStatusSubscription = _firestore
        .collection('posts')
        .doc(widget.postId)
        .collection('likes')
        .doc(currentUser.uid)
        .snapshots()
        .listen((snapshot) {
      if (mounted) {
        setState(() {
          _isLiked = snapshot.exists;
        });
      }
    });
  }

  // Listen to real-time like count changes
  void _listenToLikeCount() {
    _likeCountSubscription = _firestore
        .collection('posts')
        .doc(widget.postId)
        .snapshots()
        .listen((snapshot) {
      if (mounted && snapshot.exists) {
        final data = snapshot.data() as Map<String, dynamic>;
        final newLikes = data['likes'] ?? 0;
        setState(() {
          likes = newLikes;
        });
      }
    });
  }

  Future<void> _toggleLike() async {
    if (_isUpdating) return; // Prevent multiple rapid taps
    
    final currentUser = _auth.currentUser;
    if (currentUser == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please log in to like posts'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    // Keep originals for rollback
    final bool originalIsLiked = _isLiked;
    final int originalLikes = likes;

    // Optimistic UI update
    setState(() {
      _isUpdating = true;
      _isLiked = !_isLiked;
      likes = _isLiked ? likes + 1 : (likes > 0 ? likes - 1 : 0);
    });

    bool isUnliking = false;

    try {
      final DocumentReference<Map<String, dynamic>> postRef = _firestore.collection('posts').doc(widget.postId);
      final DocumentReference<Map<String, dynamic>> likeRef = postRef.collection('likes').doc(currentUser.uid);

      await _firestore.runTransaction((transaction) async {
        final likeSnap = await transaction.get(likeRef);
        final postSnap = await transaction.get(postRef);
        final int serverLikes = (postSnap.data()?['likes'] ?? 0) is int
            ? (postSnap.data()?['likes'] ?? 0) as int
            : int.tryParse('${postSnap.data()?['likes'] ?? 0}') ?? 0;

        if (likeSnap.exists) {
          // Unlike: remove like doc and decrement count (min 0)
          transaction.delete(likeRef);
          transaction.update(postRef, {
            'likes': serverLikes > 0 ? serverLikes - 1 : 0,
          });

          isUnliking = true;
        } else {
          // Like: create like doc and increment count
          transaction.set(likeRef, {
            'userId': currentUser.uid,
            'timestamp': FieldValue.serverTimestamp(),
          });
          transaction.update(postRef, {
            'likes': serverLikes + 1,
          });
        }
      });

      // Send notification to post owner if someone liked their post
      if (!originalIsLiked && _isLiked) {
        await _sendLikeNotification();
      }

      if (isUnliking) {
      // Delete notification
      await _deleteLikeNotification(
        fromUserId: currentUser.uid,
        toUserId: widget.userId,
        postId: widget.postId,
      );
    }
    } catch (e) {
      // Roll back optimistic change on failure
      if (mounted) {
        setState(() {
          _isLiked = originalIsLiked;
          likes = originalLikes;
        });
      }
      print('Error toggling like in transaction: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not update like. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isUpdating = false;
        });
      }
    }
  }

  Future<void> _deleteLikeNotification({
  required String fromUserId,
  required String toUserId,
  required String postId,
}) async {
  try {
    final querySnapshot = await _firestore
        .collection('notifications')
        .doc(toUserId)
        .collection('userNotifications')
        .where('fromUserId', isEqualTo: fromUserId)
        .where('postId', isEqualTo: postId)
        .where('type', isEqualTo: 'like')
        .get();

    for (var doc in querySnapshot.docs) {
      await doc.reference.delete();
    }

    log('Deleted like notification from $fromUserId to $toUserId on post $postId');
  } catch (e) {
    log('Error deleting like notification: $e');
  }
}


  // Load question data
  Future<void> _loadQuestionData() async {
    if (widget.questionId == null) return;
    
    setState(() => _isLoadingQuestion = true);
    
    try {
      DocumentSnapshot doc = await _firestore
          .collection('questions')
          .doc(widget.questionId)
          .get();
      
      if (doc.exists && mounted) {
        _questionData = QuestionPost.fromMap(doc.data() as Map<String, dynamic>);
        
        // Check if current user has already voted
        final currentUser = _auth.currentUser;
        if (currentUser != null) {
          for (var option in _questionData!.options) {
            if (option.voters.contains(currentUser.uid)) {
              _hasVoted = true;
              _selectedOptionId = option.id;
              break;
            }
          }
        }
        
        setState(() {});
      }
    } catch (e) {
      print('Error loading question data: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoadingQuestion = false);
      }
    }
  }

  // Vote on question option
  Future<void> _voteOnOption(String optionId) async {
    if (_questionData == null || _hasVoted) return;
    
    final currentUser = _auth.currentUser;
    if (currentUser == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please log in to vote')),
      );
      return;
    }

    try {
      // Update the question document
      await _firestore.runTransaction((transaction) async {
        DocumentReference questionRef = _firestore
            .collection('questions')
            .doc(widget.questionId!);
        
        DocumentSnapshot questionDoc = await transaction.get(questionRef);
        if (!questionDoc.exists) return;
        
        Map<String, dynamic> data = questionDoc.data() as Map<String, dynamic>;
        List<dynamic> options = data['options'] ?? [];
        
        // Update the specific option
        for (int i = 0; i < options.length; i++) {
          if (options[i]['id'] == optionId) {
            List<String> voters = List<String>.from(options[i]['voters'] ?? []);
            if (!voters.contains(currentUser.uid)) {
              voters.add(currentUser.uid);
              options[i]['voters'] = voters;
              options[i]['votes'] = voters.length;
            }
            break;
          }
        }
        
        // Update total votes
        int totalVotes = 0;
        for (var option in options) {
          totalVotes += ((option['votes'] ?? 0) as num).toInt();
        }
        
        transaction.update(questionRef, {
          'options': options,
          'totalVotes': totalVotes,
        });
      });
      
      // Update local state
      if (mounted) {
        setState(() {
          _hasVoted = true;
          _selectedOptionId = optionId;
        });
      }
      
      // Reload question data to get updated vote counts
      await _loadQuestionData();
      
    } catch (e) {
      print('Error voting: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error voting. Please try again.')),
      );
    }
  }

  void _showComments(BuildContext context, String postId) {
    context.read<CommentProvider>().clear();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      builder: (context) { 
        return CommentScreen(
        postId: postId,
      );},
    ).then((_) {
      _loadCommentCount();
    });
  }

  // Handle menu selection (edit, delete, report)
  void _handleMenuSelection(String value, BuildContext context) {
    switch (value) {
      case 'edit':
        _showEditPostDialog(context);
        break;
      case 'delete':
        _showDeleteConfirmation(context);
        break;
      case 'report':
        _showReportOptions(context);
        break;
    }
  }

  // Show edit post dialog
  void _showEditPostDialog(BuildContext context) {
    final TextEditingController editController = TextEditingController(text: widget.description);
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          title: Text(
            'Edit Post',
            style: TextStyle(color: Colors.white),
          ),
          content: TextField(
            controller: editController,
            maxLines: 3,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Edit your post...',
              hintStyle: TextStyle(color: Colors.grey[400]),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey[600]!),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey[600]!),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.purple),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey[400])),
            ),
            ElevatedButton(
              onPressed: () async {
                await _updatePost(editController.text.trim());
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                foregroundColor: Colors.white, // Make button text white
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text('Update'),
            ),
          ],
        );
      },
    );
  }

  // Show delete confirmation dialog
  void _showDeleteConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          title: Text(
            'Delete Post',
            style: TextStyle(color: Colors.white),
          ),
          content: Text(
            'Are you sure you want to delete this post? This action cannot be undone.',
            style: TextStyle(color: Colors.grey[300]),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey[400])),
            ),
            ElevatedButton(
              onPressed: () async {
                await _deletePost();
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white, // Make button text white
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  // Show report options
  void _showReportOptions(BuildContext context) {
    final List<String> reportReasons = [
      'Sexual Content',
      'Hateful Speech',
      'Violence',
      'Harassment',
      'Spam',
      'False Information',
      'Other'
    ];
    
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String? selectedReason;
        
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setDialogState) {
            return AlertDialog(
              backgroundColor: Colors.grey[900],
              title: Text(
                'Report Post',
                style: TextStyle(color: Colors.white),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Please select a reason for reporting this post:',
                    style: TextStyle(color: Colors.grey[300]),
                  ),
                  SizedBox(height: 16),
                  ...reportReasons.map((reason) => RadioListTile<String>(
                    title: Text(reason, style: TextStyle(color: Colors.white)),
                    value: reason,
                    groupValue: selectedReason,
                    onChanged: (value) {
                      setDialogState(() {
                        selectedReason = value;
                      });
                    },
                    activeColor: Colors.purple,
                  )),
                            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey[400])),
            ),
            ElevatedButton(
              onPressed: () async {
                if (selectedReason != null) {
                  await _reportPost(selectedReason!);
                  Navigator.pop(context);
                  _showReportConfirmation(context);
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                foregroundColor: Colors.white, // Make button text white
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text('Report'),
            ),
          ],
        );
          },
        );
      },
    );
  }

  // Show report confirmation
  void _showReportConfirmation(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Post reported successfully. We will review it soon and take appropriate action.',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  // Update post description
  Future<void> _updatePost(String newDescription) async {
    try {
      await _firestore
          .collection('posts')
          .doc(widget.postId)
          .update({
        'description': newDescription,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      
      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Post updated successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );
    } catch (e) {
      print('Error updating post: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to update post. Please try again.'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  // Delete post
  Future<void> _deletePost() async {
    try {
      await _firestore
          .collection('posts')
          .doc(widget.postId)
          .delete();
      
      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Post deleted successfully!'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );
      
      // Note: The post will automatically disappear from the StreamBuilder
      // since it's listening to Firebase changes
    } catch (e) {
      print('Error deleting post: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to delete post. Please try again.'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  // Report post
  Future<void> _reportPost(String reason) async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) return;

      await _firestore
          .collection('reports')
          .add({
        'postId': widget.postId,
        'reporterId': currentUser.uid,
        'reportedUserId': widget.userId,
        'reason': reason,
        'timestamp': FieldValue.serverTimestamp(),
        'status': 'pending',
      });
      
      print('Post reported successfully with reason: $reason');
    } catch (e) {
      print('Error reporting post: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
       margin: const EdgeInsets.only(bottom: 20, left: 16, right: 16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(16),
         border: Border.all(
           color: Colors.grey[800]!,
           width: 1,
         ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with user info
          Container(
             padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top row with profile image, user info, and menu
                Row(
              children: [
                // User avatar
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                           color: Colors.purple.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                  child: CircleAvatar(
                         radius: 25,
                    backgroundImage: widget.userImage.isNotEmpty
                        ? NetworkImage(widget.userImage)
                        : null,
                    backgroundColor: Colors.grey[700],
                    child: widget.userImage.isNotEmpty
                        ? null
                        : const Icon(Icons.person, color: Colors.white, size: 24),
                  ),
                ),
                const SizedBox(width: 12),
                
                // User info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          FutureBuilder<DocumentSnapshot>(
                            future: _firestore.collection('usersData').doc(widget.userId).get(),
                            builder: (context, snap) {
                              final paid = (snap.data?.data() as Map<String, dynamic>?)?['isPaid'] ?? false;
                              return Row(
                    children: [
                      Text(
                        widget.userName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                                  ),
                                  const SizedBox(width: 6),
                                  if (paid)
                                    const Icon(
                                      Icons.check_circle,
                                      color: Colors.blue,
                                      size: 16,
                                    ),
                                ],
                              );
                            },
                      ),
                      const SizedBox(height: 4),
                      Text(
                        widget.time,
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                
                // More options menu
                PopupMenuButton<String>(
                  icon: Icon(Icons.more_vert, color: Colors.grey[400]),
                  color: Colors.grey[800],
                      onSelected: (value) => _handleMenuSelection(value, context),
                      itemBuilder: (BuildContext context) {
                        // Check if this is the current user's post
                        final currentUserId = FirebaseAuth.instance.currentUser?.uid;
                        final isOwnPost = currentUserId == widget.userId;
                        
                        // Debug prints
                        print('Current user ID: $currentUserId');
                        print('Post creator ID: ${widget.userId}');
                        print('Is own post: $isOwnPost');
                        
                        if (isOwnPost) {
                          // Show edit and delete options for own posts
                          return [
                    const PopupMenuItem<String>(
                              value: 'edit',
                              child: Row(
                                children: [
                                  Icon(Icons.edit, color: Colors.white, size: 18),
                                  SizedBox(width: 8),
                                  Text(
                                    'Edit Post',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                            const PopupMenuItem<String>(
                              value: 'delete',
                              child: Row(
                                children: [
                                  Icon(Icons.delete, color: Colors.red, size: 18),
                                  SizedBox(width: 8),
                                  Text(
                                    'Delete Post',
                                    style: TextStyle(color: Colors.red),
                ),
              ],
            ),
                            ),
                          ];
                        } else {
                          // Show report option for others' posts
                          return [
                    const PopupMenuItem<String>(
                      value: 'report',
                              child: Row(
                                children: [
                                  Icon(Icons.report, color: Colors.white, size: 18),
                                  SizedBox(width: 8),
                                  Text(
                                    'Report',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ],
                              ),
                            ),
                          ];
                        }
                      },
                ),
              ],
            ),
                
                // Description - SEPARATE ROW BELOW USER INFO
                if (widget.description.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                    child: Text(
                      widget.description,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        height: 1.4,
                      ),
                      textAlign: TextAlign.left,
                    ),
                  ),
                ],
                
                // Compact music row under username (like screenshot)
                if (widget.musicData != null && 
                    widget.musicData!.musicTitle != null && 
                    widget.musicData!.musicTitle!.isNotEmpty) ...[
                  Padding(
                    padding: const EdgeInsets.only(top: 4.0),
                    child: Row(
                      children: [
                        const Icon(Icons.music_note, color: Colors.white, size: 14),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            (widget.musicData!.musicArtist != null && widget.musicData!.musicArtist!.isNotEmpty)
                                ? '${widget.musicData!.musicTitle!} • ${widget.musicData!.musicArtist!}'
                                : widget.musicData!.musicTitle!,
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        GestureDetector(
                          onTap: _toggleMusicPlayback,
                          child: Icon(
                            _isMusicPlaying ? Icons.volume_up : Icons.volume_off,
                            color: Colors.white,
                            size: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                        ],
                      ),
                    ),
                    
                    // Poll content - always show a block for question posts
                    if (widget.type == 'question') ...[
                      const SizedBox(height: 12),
                      _questionData != null ? _buildQuestionContent() : _buildPollSkeleton(),
                    ],
                    
                                          // Media content - only show if there's an image or video
            if (widget.fileUrl.isNotEmpty) ...[
              const SizedBox(height: 2), // Small gap between header and media
          ClipRRect(
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(16),
              bottomRight: Radius.circular(16),
            ),
            child: widget.type == 'video'
                ? _buildVideoContent()
                : _buildImageContent(),
          ),
            ],
          
                     // Action buttons only - NO DESCRIPTION HERE
          Container(
             padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
            child: Row(
                  children: [
                    // Like button
                    InkWell(
                  onTap: _toggleLike,
                      child: Row(
                        children: [
                          Icon(
                        _isLiked ? Icons.favorite : Icons.favorite_border,
                        color: _isLiked ? Colors.red : Colors.grey[400],
                            size: 24,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            likes.toString(),
                            style: TextStyle(
                          color: _isLiked ? Colors.red : Colors.grey[400],
                              fontSize: 14,
                          fontWeight: _isLiked ? FontWeight.bold : FontWeight.normal,
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(width: 24),
                    
                                 // Comment button
                    InkWell(
                      onTap: () {
                     _showComments(context, widget.postId);
                      },
                      child: Row(
                        children: [
                          Icon(
                         Icons.comment_outlined,
                            color: Colors.grey[400],
                            size: 24,
                          ),
                          const SizedBox(width: 8),
                          Text(
                          commentCount.toString(),
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const Spacer(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoContent() {
    // Don't show video if no URL
    if (widget.fileUrl.isEmpty) {
      return const SizedBox.shrink();
    }
    
    return Container(
      height: 300,
      width: double.infinity,
      color: Colors.black,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (_videoController.value.isInitialized)
            AspectRatio(
              aspectRatio: _videoController.value.aspectRatio,
              child: VideoPlayer(_videoController),
            )
          else
            Container(
              color: Colors.grey[800],
              child: const Center(
                child: CircularProgressIndicator(color: Colors.white),
              ),
            ),
          
          // Play/Pause overlay
          Center(
            child: FloatingActionButton(
              backgroundColor: Colors.black54,
              onPressed: () {
                setState(() {
                  if (_videoController.value.isPlaying) {
                    _videoController.pause();
                  } else {
                    _videoController.play();
                  }
                  _isVideoPlaying = _videoController.value.isPlaying;
                });
              },
              child: Icon(
                _isVideoPlaying ? Icons.pause : Icons.play_arrow,
                color: Colors.white,
              ),
            ),
          ),
          
          // Video indicator
          Positioned(
            bottom: 8,
            left: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Icon(Icons.videocam, color: Colors.white, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  // Build question content
  Widget _buildQuestionContent() {
    if (_questionData == null) return const SizedBox.shrink();
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Location and tags
          if (widget.location != null || (widget.tags != null && widget.tags!.isNotEmpty)) ...[
            Row(
              children: [
                if (widget.location != null) ...[
                  Icon(Icons.location_on, color: Colors.grey[400], size: 14),
                  const SizedBox(width: 4),
                  Text(
                    widget.location!,
                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                  ),
                  if (widget.tags != null && widget.tags!.isNotEmpty) const SizedBox(width: 12),
                ],
                if (widget.tags != null && widget.tags!.isNotEmpty) ...[
                  ...widget.tags!.take(2).map((tag) => Container(
                    margin: const EdgeInsets.only(right: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: _getTagColor(tag).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _getTagColor(tag).withOpacity(0.5)),
                    ),
                    child: Text(
                      tag,
                      style: TextStyle(
                        color: _getTagColor(tag),
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  )),
                ],
              ],
            ),
            const SizedBox(height: 12),
          ],
          
          // Question options
          ..._questionData!.options.map((option) {
            final percentage = _questionData!.totalVotes > 0 
                ? (option.votes / _questionData!.totalVotes * 100).round()
                : 0;
            final isSelected = _selectedOptionId == option.id;
            final hasVoted = _hasVoted;
            
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              child: GestureDetector(
                onTap: hasVoted ? null : () => _voteOnOption(option.id),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isSelected 
                        ? Colors.purple.withOpacity(0.2)
                        : Colors.grey[850],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: isSelected 
                          ? Colors.purple
                          : Colors.grey[700]!,
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 20,
                            height: 20,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isSelected 
                                  ? Colors.purple
                                  : Colors.transparent,
                              border: Border.all(
                                color: isSelected 
                                    ? Colors.purple
                                    : Colors.grey[400]!,
                                width: 2,
                              ),
                            ),
                            child: isSelected
                                ? const Icon(
                                    Icons.check,
                                    color: Colors.white,
                                    size: 12,
                                  )
                                : null,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              option.text,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                              ),
                            ),
                          ),
                          Text(
                            '$percentage%',
                            style: TextStyle(
                              color: isSelected ? Colors.purple : Colors.grey[400],
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      if (hasVoted) ...[
                        const SizedBox(height: 8),
                        LinearProgressIndicator(
                          value: _questionData!.totalVotes > 0 
                              ? option.votes / _questionData!.totalVotes
                              : 0.0,
                          backgroundColor: Colors.grey[700],
                          valueColor: AlwaysStoppedAnimation<Color>(
                            isSelected ? Colors.purple : Colors.grey[500]!,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
          
          // Vote count
          if (_questionData!.totalVotes > 0) ...[
            const SizedBox(height: 8),
            Text(
              '${_questionData!.totalVotes} vote${_questionData!.totalVotes == 1 ? '' : 's'}',
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 12,
              ),
            ),
          ],
        ],
      ),
    );
  }

  // Skeleton shown while poll loads the first time
  Widget _buildPollSkeleton() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      child: Column(
        children: [
          _skeletonOption(),
          const SizedBox(height: 8),
          _skeletonOption(),
        ],
      ),
    );
  }

  Widget _skeletonOption() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[850],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[700]!),
      ),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.grey[600]!, width: 2),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Container(
              height: 12,
              decoration: BoxDecoration(
                color: Colors.grey[700],
                borderRadius: BorderRadius.circular(6),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            width: 28,
            height: 12,
            decoration: BoxDecoration(
              color: Colors.grey[700],
              borderRadius: BorderRadius.circular(6),
            ),
          ),
        ],
      ),
    );
  }

  // Get color for tag
  Color _getTagColor(String tag) {
    switch (tag.toLowerCase()) {
      case 'techjourney':
        return Colors.purple;
      case 'admissions':
        return Colors.orange;
      case 'education':
        return Colors.blue;
      case 'career':
        return Colors.green;
      case 'life':
        return Colors.pink;
      default:
        return Colors.grey;
    }
  }

  Widget _buildImageContent() {
    // Don't show image if no URL
    if (widget.fileUrl.isEmpty) {
      return const SizedBox.shrink();
    }
    
    return CachedNetworkImage(
      imageUrl: widget.fileUrl,
      width: double.infinity,
      fit: BoxFit.cover,
      placeholder: (context, url) => Container(
        height: 300,
        color: Colors.grey[800],
        child: const Center(
          child: CircularProgressIndicator(
            color: Colors.white,
            strokeWidth: 2,
          ),
        ),
      ),
      errorWidget: (context, url, error) => Container(
          height: 300,
          color: Colors.grey[800],
          child: const Center(
            child: Icon(Icons.error, color: Colors.white, size: 50),
          ),
      ),
      memCacheWidth: 800, // Optimize memory usage
      memCacheHeight: 600,
      maxWidthDiskCache: 800,
      maxHeightDiskCache: 600,
    );
  }
}
