import 'package:beatjerky/providers/feeds_provider/feed_comments_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:timeago/timeago.dart' as timeago;

class CommentScreen extends StatefulWidget {
  final String postId;

  const CommentScreen({super.key, required this.postId});

  @override
  State<CommentScreen> createState() => _CommentScreenState();
}

class _CommentScreenState extends State<CommentScreen> {
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      context.read<CommentProvider>().loadComments(widget.postId);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    context.read<CommentProvider>().clear();
    super.dispose();
  }

  // @override
  // Widget build(BuildContext context) {
  //   final commentProvider = context.watch<CommentProvider>();
  //   return Container(
  //     height: MediaQuery.of(context).size.height * 0.7,
  //     color: const Color(0xFF1E1E1E),
  //     child: Column(
  //       children: [
  //         const SizedBox(height: 8),
  //         Container(height: 4, width: 40, color: Colors.grey),
  //         const SizedBox(height: 12),
  //         const Text("Comments", style: TextStyle(color: Colors.white, fontSize: 18)),

  //         Expanded(
  //           child: commentProvider.isLoading && commentProvider.comments.isEmpty
  //               ? const Center(child: CircularProgressIndicator(color: Colors.purple))
  //               : commentProvider.comments.isEmpty
  //                   ? const Center(
  //                       child: Text('No comments yet',
  //                           style: TextStyle(color: Colors.grey)))
  //                   : ListView.builder(
  //                       padding: const EdgeInsets.all(16),
  //                       itemCount: commentProvider.comments.length,
  //                       itemBuilder: (context, index) {
  //                         final c = commentProvider.comments[index];
  //                         final timestamp = c['timestamp'];
  //                           String timeAgo = '';

  //                           if (timestamp != null) {
  //                             final dateTime = timestamp.toDate();
  //                             timeAgo = timeago.format(dateTime, locale: 'en_short');
  //                           }
  //                         return ListTile(
  //                           leading: CircleAvatar(
  //                             backgroundImage: (c['userImage'] ?? '').isNotEmpty
  //                                 ? NetworkImage(c['userImage'])
  //                                 : null,
  //                             backgroundColor: Colors.purple,
  //                             child: (c['userImage'] ?? '').isEmpty
  //                                 ? Text(c['userName'].isNotEmpty ? c['userName'][0].toUpperCase(): "",
  //                                     style: const TextStyle(color: Colors.white))
  //                                 : null,
  //                           ),
  //                           title: Text(
  //                             c['userName'],
  //                             style: const TextStyle(
  //                                 color: Colors.white,
  //                                 fontWeight: FontWeight.bold),
  //                           ),
  //                           subtitle: Text(
  //                             c['text'],
  //                             style: const TextStyle(color: Colors.white70),
  //                           ),
  //                           trailing: Row(
  //                             mainAxisSize: MainAxisSize.min,
  //                             children: [
  //                               Padding(
  //                                 padding: const EdgeInsets.only(top: 25.0),
  //                                 child: Text(
  //                                   timeAgo,
  //                                   style: const TextStyle(fontSize: 12, color: Colors.grey),
  //                                 ),
  //                               ),
  //                             ],
  //                           ),
  //                         );
  //                       },
  //                     ),
  //         ),

  //         // Input
  //         Container(
  //           padding: const EdgeInsets.all(12),
  //           color: Colors.grey[900],
  //           child: Row(
  //             children: [
  //               Expanded(
  //                 child: TextField(
  //                   controller: _controller,
  //                   style: const TextStyle(color: Colors.white),
  //                   decoration: const InputDecoration(
  //                     hintText: 'Write a comment...',
  //                     hintStyle: TextStyle(color: Colors.grey),
  //                     border: InputBorder.none,
  //                   ),
  //                 ),
  //               ),
  //               IconButton(
  //                 icon: const Icon(Icons.send, color: Colors.purple),
  //                 onPressed: () async {
  //                   if (_controller.text.trim().isNotEmpty) {
  //                     await commentProvider.addComment(
  //                       widget.postId,
  //                       _controller.text.trim(),
  //                     );
  //                     _controller.clear();
  //                   }
  //                 },
  //               )
  //             ],
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }

  @override
Widget build(BuildContext context) {
  final commentProvider = context.watch<CommentProvider>();

  return SafeArea(
    top: false,
    child: AnimatedPadding(
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut,
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.7,
        color: const Color(0xFF1E1E1E),
        child: Column(
          children: [
            const SizedBox(height: 8),
            Container(height: 4, width: 40, color: Colors.grey),
            const SizedBox(height: 12),
            const Text("Comments",
                style: TextStyle(color: Colors.white, fontSize: 18)),

            // Comments list
            Expanded(
              child: commentProvider.isLoading && commentProvider.comments.isEmpty
                  ? const Center(
                      child: CircularProgressIndicator(color: Colors.purple))
                  : commentProvider.comments.isEmpty
                      ? const Center(
                          child: Text(
                            'No comments yet',
                            style: TextStyle(color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: commentProvider.comments.length,
                          itemBuilder: (context, index) {
                            final c = commentProvider.comments[index];
                            final timestamp = c['timestamp'];
                            String timeAgo = '';
                            if (timestamp != null) {
                              final dateTime = timestamp.toDate();
                              timeAgo =
                                  timeago.format(dateTime, locale: 'en_short');
                            }

                            return ListTile(
                              leading: CircleAvatar(
                                backgroundImage:
                                    (c['userImage'] ?? '').isNotEmpty
                                        ? NetworkImage(c['userImage'])
                                        : null,
                                backgroundColor: Colors.purple,
                                child: (c['userImage'] ?? '').isEmpty
                                    ? Text(
                                        c['userName'].isNotEmpty
                                            ? c['userName'][0].toUpperCase()
                                            : "",
                                        style: const TextStyle(
                                            color: Colors.white),
                                      )
                                    : null,
                              ),
                              title: Text(
                                c['userName'],
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                c['text'],
                                style:
                                    const TextStyle(color: Colors.white70),
                              ),
                              trailing: Padding(
                                padding: const EdgeInsets.only(top: 25.0),
                                child: Text(
                                  timeAgo,
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.grey),
                                ),
                              ),
                            );
                          },
                        ),
            ),

            // Input field
            Container(
              padding: const EdgeInsets.all(12),
              color: Colors.grey[900],
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                        hintText: 'Write a comment...',
                        hintStyle: TextStyle(color: Colors.grey),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send, color: Colors.purple),
                    onPressed: () async {
                      if (_controller.text.trim().isNotEmpty) {
                        await commentProvider.addComment(
                          widget.postId,
                          _controller.text.trim(),
                        );
                        _controller.clear();
                      }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

}