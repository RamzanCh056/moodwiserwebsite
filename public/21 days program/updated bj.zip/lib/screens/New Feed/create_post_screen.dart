import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:beatjerky/notification_services/trigger_notification_services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:just_audio/just_audio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../utils/color.dart';
import '../../model/music_track_model.dart';
import '../../model/question_model.dart';
import '../../widget/music_browser.dart';

class CreatePostScreen extends StatefulWidget {
  @override
  _CreatePostScreenState createState() => _CreatePostScreenState();
}

class _CreatePostScreenState extends State<CreatePostScreen> with TickerProviderStateMixin {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  File? _selectedImage;
  bool _isUploading = false;
  TextEditingController descriptionController = TextEditingController();
  MusicTrack? _selectedMusic;
  
  // Tab controller for different post types
  late TabController _tabController;
  
  // Question creation state
  final TextEditingController _questionController = TextEditingController();
  final List<TextEditingController> _optionControllers = [
    TextEditingController(),
    TextEditingController(),
  ];
  String _selectedLocation = '';
  final List<String> _selectedTags = [];
  bool _isQuestionActive = true;
  DateTime? _expirationDate;
  
  // Music preview controls
  final AudioPlayer _previewPlayer = AudioPlayer();
  bool _isPreviewPlaying = false;
  double _musicVolume = 0.5;
  // Trim selection (in seconds)
  double _trackDurationSeconds = 0;
  double _clipStartSeconds = 0;
  double _clipEndSeconds = 15;
  StreamSubscription<Duration>? _positionSub;
  double _currentPosSeconds = 0;
  
  // AI generation state
  bool _isAIGenerating = false;
  
  // Reuse BJAI API configuration
  static const String _aiApiKey = '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';
  static const String _aiBaseUrl = 'https://api.openai.com/v1/chat/completions';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  Future<void> _selectMusic() async {
    // Simple MP3 picker only (no extra fields)
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3'],
    );
    if (res == null || res.files.single.path == null) return;

    final pickedPath = res.files.single.path!;
    final track = MusicTrack(
      id: 'local',
      title: 'My Music',
      artist: '',
      audioUrl: pickedPath,
      coverImageUrl: '',
      duration: 0,
      genre: '',
      uploadedAt: DateTime.now(),
      uploadedBy: _auth.currentUser?.uid ?? '',
    );
    setState(() {
      _selectedMusic = track;
    });
    await _setupPreview(track);
  }

  Future<void> _setupPreview(MusicTrack track) async {
    try {
      // Local mp3 vs remote url
      if (await File(track.audioUrl).exists()) {
        await _previewPlayer.setFilePath(track.audioUrl);
      } else {
        await _previewPlayer.setUrl(track.audioUrl);
      }
      await _previewPlayer.setVolume(_musicVolume);
      final dur = await _previewPlayer.durationStream.firstWhere((d) => d != null);
      _trackDurationSeconds = (dur ?? Duration.zero).inSeconds.toDouble();
      if (_trackDurationSeconds <= 0) {
        _trackDurationSeconds = 30; // fallback UI range
      }
      // Default 15s clip or full length if shorter
      _clipStartSeconds = 0;
      _clipEndSeconds = _trackDurationSeconds >= 15 ? 15 : _trackDurationSeconds;
      _positionSub?.cancel();
      _positionSub = _previewPlayer.positionStream.listen((pos) {
        final secs = pos.inSeconds.toDouble();
        if (mounted) {
          setState(() {
            _currentPosSeconds = secs;
          });
        }
        if (_isPreviewPlaying && secs >= _clipEndSeconds) {
          _previewPlayer.pause();
          _previewPlayer.seek(Duration(seconds: _clipStartSeconds.floor()));
          if (mounted) {
            setState(() { _isPreviewPlaying = false; });
          }
        }
      });
      setState(() {});
    } catch (e) {
      print('Error setting up preview: $e');
    }
  }

  Future<void> _togglePreview() async {
    try {
      if (_isPreviewPlaying) {
        await _previewPlayer.pause();
      } else {
        // Start from selected start point
        final withinClip = _currentPosSeconds >= _clipStartSeconds && _currentPosSeconds <= _clipEndSeconds;
        if (!withinClip) {
          await _previewPlayer.seek(Duration(seconds: _clipStartSeconds.floor()));
        }
        await _previewPlayer.play();
      }
      if (mounted) {
        setState(() {
          _isPreviewPlaying = !_isPreviewPlaying;
        });
      }
    } catch (e) {
      print('Error toggling preview: $e');
    }
  }

  Future<void> _uploadPost(String description) async {
    // Allow posts with either text or image (or both)
    if (_selectedImage == null && description.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please add either text or image before posting!")),
      );
      return;
    }

    setState(() => _isUploading = true);

    try {
      User? user = _auth.currentUser;
      if (user == null) return;

      DocumentSnapshot userDoc = await _firestore.collection('usersData').doc(user.uid).get();
      if (!userDoc.exists) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("User data not found!")));
        return;
      }

      String userFirstName = userDoc['firstName'] ?? "Anonymous";
      String userSecondName = userDoc['secondName'] ?? "";
      String userImage = userDoc['profileImage'] ?? "";

      String? fileUrl;
      String postType = 'text'; // Default to text post

      // Upload image if selected
      if (_selectedImage != null) {
      String fileName = DateTime.now().millisecondsSinceEpoch.toString();
      String fileType = 'posts';
      Reference storageRef = FirebaseStorage.instance.ref().child('$fileType/${user.uid}/$fileName');

      UploadTask uploadTask = storageRef.putFile(_selectedImage!);
      TaskSnapshot snapshot = await uploadTask;
        fileUrl = await snapshot.ref.getDownloadURL();
        postType = 'image';
      }

      // Create post data
      Map<String, dynamic> postData = {
        'userId': user.uid,
        'userFirstName': userFirstName,
        'userSecondName': userSecondName,
        'userImage': userImage,
        'description': description,
        'timestamp': FieldValue.serverTimestamp(),
        'likes': 0,
        'dislikes': 0,
        'comments': 0,
        'type': postType,
      };
      
      // Add fileUrl only if image was uploaded
      if (fileUrl != null) {
        postData['fileUrl'] = fileUrl;
      }

      // Add music data if selected
      if (_selectedMusic != null) {
        // If local file, upload to storage first to get a stable URL
        String finalMusicUrl = _selectedMusic!.audioUrl;
        try {
          if (await File(_selectedMusic!.audioUrl).exists()) {
            final String fileName = 'music_${DateTime.now().millisecondsSinceEpoch}.mp3';
            final ref = FirebaseStorage.instance.ref().child('post_music/${user.uid}/$fileName');
            final snap = await ref.putFile(File(_selectedMusic!.audioUrl));
            finalMusicUrl = await snap.ref.getDownloadURL();
          }
        } catch (e) {
          print('Error uploading music: $e');
        }

        postData['music'] = {
          'musicId': _selectedMusic!.id,
          'musicTitle': _selectedMusic!.title,
          'musicArtist': _selectedMusic!.artist,
          'musicUrl': finalMusicUrl,
          'musicStartTime': _clipStartSeconds.floor(),
          'musicClipDuration': (_clipEndSeconds - _clipStartSeconds).floor(),
          'musicVolume': _musicVolume,
        };
      }

      await _firestore.collection('posts').add(postData);

      // 🔔 Trigger notifications
      await _sendNewPostNotificationToAllUsers();

      setState(() {
        _selectedImage = null;
        _selectedMusic = null;
        descriptionController.clear();
        _isPreviewPlaying = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Post uploaded successfully!")));
      
      // Navigate back to feed screen
      // Pop back and signal feed to refresh
      Navigator.pop(context, true);
    } catch (e) {
      print("Error uploading post: $e");
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error uploading post. Try again.")));
    }

    setState(() => _isUploading = false);
  }

  Future<void> _sendNewPostNotificationToAllUsers() async {
  try {
    final currentUser = _auth.currentUser;
    if (currentUser == null) return;

    final currentUserDoc = await _firestore
        .collection('usersData')
        .doc(currentUser.uid)
        .get();

    final currentUserName = currentUserDoc['firstName'] ?? 'Someone';

    final usersSnapshot = await _firestore
        .collection('usersData')
        .get();

    final trigger = TriggerNotificationService();
    int notificationCount = 0;

    for (var userDoc in usersSnapshot.docs) {
      final userId = userDoc.id;
      if (userId == currentUser.uid) continue;

      final userData = userDoc.data();
      final fcmToken = userData['fcmToken'] as String?;

      if (fcmToken != null && fcmToken.isNotEmpty) {
        try {
          await trigger.sendPushNotification(
            token: fcmToken,
            title: 'New Post Alert! 📝',
            body: '$currentUserName just shared a new post',
          );
        } catch (e) {
          log('Error sending notification to user $userId: $e');
        }
      }

      final notificationData = {
        'type': 'new_post',
        'fromUserId': currentUser.uid,
        'fromUserName': currentUserName,
        'timestamp': FieldValue.serverTimestamp(),
        'message': '$currentUserName just shared a new post',
        'isRead': false,
      };

      await _firestore
          .collection('notifications')
          .doc(userId)
          .collection('userNotifications')
          .add(notificationData);

      notificationCount++;
    }

    log('New post notification sent to $notificationCount users');
  } catch (e) {
    log('Error sending new post notifications: $e');
  }
}


  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Handle back button press
        Navigator.pop(context);
        return false; // Prevent default back behavior
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xFF1E1E1E),
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              print('Back button pressed'); // Debug print
              Navigator.pop(context);
            },
          ),
          title: Text(
            "Create Post",
            style: TextStyle(
              fontSize: 18,
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
          centerTitle: true,
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: Colors.purple,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.grey[400],
            tabs: [
              Tab(text: "Post", icon: Icon(Icons.post_add)),
              Tab(text: "Poll", icon: Icon(Icons.quiz)),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            // Regular Post Tab
            Container(
              color: Color(0xFF1E1E1E),
              width: double.infinity,
              height: double.infinity,
              child: Padding(
        padding: const EdgeInsets.all(18.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Upload Area
              InkWell(
                onTap: _pickImage,
                child: Container(
                  width: double.infinity,
                  height: 200,
                  decoration: BoxDecoration(
                        color: Colors.grey[850],
                        border: Border.all(color: Colors.grey[600]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: _selectedImage != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.file(_selectedImage!, fit: BoxFit.cover),
                        )
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset("images/image.svg"),
                            SizedBox(height: 11),
                            Text(
                               "Upload Picture (Optional)",
                               style: TextStyle(fontSize: 16, color: Colors.grey[400]),
                            ),
                          ],
                        ),
                ),
              ),

              SizedBox(height: 16),

              // Description field
              TextField(
                controller: descriptionController,
                maxLines: 5,
                    style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                      hintText: "Write here... (Optional)",
                      hintStyle: TextStyle(color: Colors.grey[400]),
                      filled: true,
                      fillColor: Colors.grey[850],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey[600]!),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey[600]!),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.purple),
                      ),
                ),
              ),

              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: () {
                    if (_selectedImage == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Please add an image first for AI to analyze.')),
                      );
                      return;
                    }
                    _showAIGenerateSheet();
                  },
                  icon: Icon(Icons.auto_awesome, color: Colors.purpleAccent),
                  label: Text(
                    _isAIGenerating ? 'Generating…' : 'AI caption/hashtags',
                    style: TextStyle(color: Colors.purpleAccent),
                  ),
                ),
              ),

              SizedBox(height: 16),

                  // Music selection button
                  Container(
                    width: double.infinity,
                    margin: EdgeInsets.only(bottom: 16),
                    child: OutlinedButton.icon(
                      onPressed: _selectMusic,
                      icon: Icon(
                        _selectedMusic != null ? Icons.music_note : Icons.music_note_outlined,
                        color: _selectedMusic != null ? Colors.purple : Colors.grey,
                      ),
                      label: Text(
                        _selectedMusic != null 
                            ? '${_selectedMusic!.title} - ${_selectedMusic!.artist}'
                            : 'Add Background Music',
                        style: TextStyle(
                          color: _selectedMusic != null ? Colors.purple : Colors.grey,
                          fontWeight: FontWeight.w500,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      style: OutlinedButton.styleFrom(
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        side: BorderSide(
                          color: _selectedMusic != null ? Colors.purple : Colors.grey[600]!,
                          width: 1.5,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),

                  // Music preview controls
                  if (_selectedMusic != null) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.grey[850],
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey[600]!),
                      ),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: _togglePreview,
                            child: Container(
                              width: 36,
                              height: 36,
                              decoration: const BoxDecoration(
                                color: Colors.purple,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                _isPreviewPlaying ? Icons.pause : Icons.play_arrow,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _selectedMusic!.title,
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                if (_selectedMusic!.artist.isNotEmpty)
                                  Text(
                                    _selectedMusic!.artist,
                                    style: TextStyle(color: Colors.grey[400], fontSize: 12),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Trim selector
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Select clip', style: TextStyle(color: Colors.white70, fontSize: 12)),
                            Text(
                              '${_formatSeconds(_clipStartSeconds)} - ${_formatSeconds(_clipEndSeconds)}',
                              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500, fontSize: 12),
                            ),
                          ],
                        ),
                        RangeSlider(
                          values: RangeValues(_clipStartSeconds.clamp(0, _trackDurationSeconds), _clipEndSeconds.clamp(0, _trackDurationSeconds)),
                          min: 0,
                          max: _trackDurationSeconds > 0 ? _trackDurationSeconds : 30,
                          divisions: (_trackDurationSeconds > 0 ? _trackDurationSeconds.toInt() : 30),
                          activeColor: Colors.purple,
                          onChanged: (rng) {
                            setState(() {
                              // Keep at least 2s clip
                              _clipStartSeconds = rng.start;
                              _clipEndSeconds = rng.end;
                              if ((_clipEndSeconds - _clipStartSeconds) < 2) {
                                _clipEndSeconds = _clipStartSeconds + 2;
                              }
                            });
                            // If playing and cursor outside, seek into the clip start
                            if (_isPreviewPlaying && (_currentPosSeconds < _clipStartSeconds || _currentPosSeconds > _clipEndSeconds)) {
                              _previewPlayer.seek(Duration(seconds: _clipStartSeconds.floor()));
                            }
                          },
                          onChangeEnd: (rng) async {
                            // Snap to start when user finishes adjusting
                            if (_isPreviewPlaying) {
                              await _previewPlayer.seek(Duration(seconds: _clipStartSeconds.floor()));
                            }
                          },
                        ),
                        // Current time vs total duration for the selected clip
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_formatSeconds(_currentPosSeconds), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                            Text(_formatSeconds(_clipEndSeconds), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                          ],
                        ),
                        // Current playhead inside selected clip
                        Slider(
                          value: _currentPosSeconds.clamp(_clipStartSeconds, _clipEndSeconds),
                          min: _clipStartSeconds,
                          max: _clipEndSeconds,
                          activeColor: Colors.purpleAccent,
                          inactiveColor: Colors.white12,
                          onChanged: (v) async {
                            // Allow scrubbing within the clip
                            setState(() { _currentPosSeconds = v; });
                            await _previewPlayer.seek(Duration(seconds: v.floor()));
                          },
                          onChangeStart: (_) {
                            // Pause while scrubbing
                            if (_isPreviewPlaying) {
                              _previewPlayer.pause();
                            }
                          },
                          onChangeEnd: (_) async {
                            if (_isPreviewPlaying) {
                              await _previewPlayer.play();
                            }
                          },
                        ),
                      ],
                    ),
                    // Volume slider
                    Row(
                      children: [
                        const Icon(Icons.volume_down, color: Colors.white70, size: 18),
                        Expanded(
                          child: Slider(
                            value: _musicVolume,
                            min: 0,
                            max: 1,
                            divisions: 10,
                            activeColor: Colors.purple,
                            onChanged: (v) async {
                              setState(() => _musicVolume = v);
                              try { await _previewPlayer.setVolume(v); } catch (_) {}
                            },
                          ),
                        ),
                        const Icon(Icons.volume_up, color: Colors.white70, size: 18),
                      ],
                    ),
                    const SizedBox(height: 8),
                  ],

                  // Remove music button (if music is selected)
                  if (_selectedMusic != null)
                    Container(
                      width: double.infinity,
                      margin: EdgeInsets.only(bottom: 16),
                      child: TextButton.icon(
                        onPressed: () {
                          setState(() {
                            _selectedMusic = null;
                          });
                        },
                        icon: Icon(Icons.clear, color: Colors.red, size: 20),
                        label: Text(
                          'Remove Music',
                          style: TextStyle(color: Colors.red),
                        ),
                      ),
                    ),

              // Post button
              MaterialButton(
                onPressed: () {
                      // Allow posts with either text or image (or both)
                      if (_selectedImage == null && descriptionController.text.trim().isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please add either text or image before posting!")));
                  } else {
                    _uploadPost(descriptionController.text.trim());
                  }
                },
                height: 50,
                minWidth: double.infinity,
                    color: Colors.purple,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: _isUploading
                        ? CircularProgressIndicator(color: Colors.white)
                        : Text("Post", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
          ),
            ),
            // Question Tab
            _buildQuestionTab(),
          ],
        ),
      ),
    );
  }

  // Build Question Tab
  Widget _buildQuestionTab() {
    return Container(
      color: Color(0xFF1E1E1E),
      width: double.infinity,
      height: double.infinity,
      child: Padding(
        padding: const EdgeInsets.all(18.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Question Input
              Text(
                "What's your question?",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 12),
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[850],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey[600]!),
                ),
                child: TextField(
                  controller: _questionController,
                  maxLines: 3,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: "Ask your question here...",
                    hintStyle: TextStyle(color: Colors.grey[400]),
                    border: InputBorder.none,
                  ),
                ),
              ),
              SizedBox(height: 20),

              // Options Section
              Text(
                "Options (2-6 choices)",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 12),
              
              // Options List
              ...List.generate(_optionControllers.length, (index) {
                return Container(
                  margin: EdgeInsets.only(bottom: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 24,
                        height: 24,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.grey[400]!, width: 2),
                        ),
                        child: Center(
                          child: Text(
                            '${index + 1}',
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.grey[850],
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.grey[600]!),
                          ),
                          child: TextField(
                            controller: _optionControllers[index],
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              hintText: "Option ${index + 1}",
                              hintStyle: TextStyle(color: Colors.grey[400]),
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ),
                      if (_optionControllers.length > 2)
                        IconButton(
                          onPressed: () => _removeOption(index),
                          icon: Icon(Icons.remove_circle, color: Colors.red[400]),
                        ),
                    ],
                  ),
                );
              }),

              // Add Option Button
              if (_optionControllers.length < 6)
                GestureDetector(
                  onTap: _addOption,
                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.purple.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.purple.withOpacity(0.3)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add, color: Colors.purple),
                        SizedBox(width: 8),
                        Text(
                          "Add Option",
                          style: TextStyle(
                            color: Colors.purple,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              SizedBox(height: 20),

              // Location removed per request

              // Tags Section
              Text(
                "Tags (Optional)",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _buildTagChip("TechJourney", Colors.purple),
                  _buildTagChip("Admissions", Colors.orange),
                  _buildTagChip("Education", Colors.blue),
                  _buildTagChip("Career", Colors.green),
                  _buildTagChip("Life", Colors.pink),
                ],
              ),
              SizedBox(height: 30),

              // Post Question Button
              MaterialButton(
                onPressed: _createQuestionPost,
                height: 50,
                minWidth: double.infinity,
                color: Colors.purple,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: _isUploading
                    ? CircularProgressIndicator(color: Colors.white)
                    : Text("Post Question", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Build Video Tab
  Widget _buildVideoTab() {
    return Container(
      color: Color(0xFF1E1E1E),
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.videocam,
              size: 64,
              color: Colors.grey[400],
            ),
            SizedBox(height: 16),
            Text(
              "Video Creation",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              "Coming Soon!",
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/create_video');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
              child: Text(
                "Go to Video Creator",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Build Tag Chip
  Widget _buildTagChip(String tag, Color color) {
    bool isSelected = _selectedTags.contains(tag);
    return GestureDetector(
      onTap: () {
        setState(() {
          if (isSelected) {
            _selectedTags.remove(tag);
          } else {
            _selectedTags.add(tag);
          }
        });
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? color : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color, width: 1),
        ),
        child: Text(
          tag,
          style: TextStyle(
            color: isSelected ? Colors.white : color,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  // Add option to question
  void _addOption() {
    if (_optionControllers.length < 6) {
      setState(() {
        _optionControllers.add(TextEditingController());
      });
    }
  }

  // Remove option from question
  void _removeOption(int index) {
    if (_optionControllers.length > 2) {
      setState(() {
        _optionControllers[index].dispose();
        _optionControllers.removeAt(index);
      });
    }
  }

  // Create question post
  Future<void> _createQuestionPost() async {
    if (_questionController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please enter a question!")),
      );
      return;
    }

    List<String> validOptions = _optionControllers
        .map((controller) => controller.text.trim())
        .where((text) => text.isNotEmpty)
        .toList();

    if (validOptions.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please add at least 2 options!")),
      );
      return;
    }

    setState(() => _isUploading = true);

    try {
      User? user = _auth.currentUser;
      if (user == null) return;

      DocumentSnapshot userDoc = await _firestore.collection('usersData').doc(user.uid).get();
      if (!userDoc.exists) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("User data not found!")));
        return;
      }

      String userFirstName = userDoc['firstName'] ?? "Anonymous";
      String userSecondName = userDoc['secondName'] ?? "";
      String userImage = userDoc['profileImage'] ?? "";

      // Create question options
      List<QuestionOption> options = validOptions.asMap().entries.map((entry) {
        return QuestionOption(
          id: DateTime.now().millisecondsSinceEpoch.toString() + entry.key.toString(),
          text: entry.value,
          votes: 0,
          voters: [],
        );
      }).toList();

      // Create question post
      QuestionPost questionPost = QuestionPost(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        userId: user.uid,
        userFirstName: userFirstName,
        userSecondName: userSecondName,
        userImage: userImage,
        question: _questionController.text.trim(),
        location: null,
        options: options,
        timestamp: DateTime.now(),
        tags: _selectedTags,
        isActive: _isQuestionActive,
        expiresAt: _expirationDate,
      );

      // Save to Firestore
      await _firestore.collection('questions').doc(questionPost.id).set(questionPost.toMap());

      // Also save as a regular post for feed display
      Map<String, dynamic> postData = {
        'userId': user.uid,
        'userFirstName': userFirstName,
        'userSecondName': userSecondName,
        'userImage': userImage,
        'description': _questionController.text.trim(),
        'timestamp': FieldValue.serverTimestamp(),
        'likes': 0,
        'dislikes': 0,
        'comments': 0,
        'type': 'question',
        'questionId': questionPost.id,
        'location': null,
        'tags': _selectedTags,
      };

      await _firestore.collection('posts').doc(questionPost.id).set(postData);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Question posted successfully!")),
      );

      // Clear form
      _questionController.clear();
      for (var controller in _optionControllers) {
        controller.clear();
      }
      _selectedLocation = '';
      _selectedTags.clear();
      _isQuestionActive = true;
      _expirationDate = null;

      Navigator.pop(context);
    } catch (e) {
      print("Error creating question: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error creating question: $e")),
      );
    } finally {
      setState(() => _isUploading = false);
    }
  }

  // ========== AI helpers ==========
  Future<void> _showAIGenerateSheet() async {
    if (_isAIGenerating) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E1E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: const [
                    Icon(Icons.auto_awesome, color: Colors.purpleAccent),
                    SizedBox(width: 8),
                    Text('Let AI help', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  ],
                ),
                const SizedBox(height: 12),
                ListTile(
                  leading: const Icon(Icons.text_fields, color: Colors.white70),
                  title: const Text('Generate caption', style: TextStyle(color: Colors.white)),
                  onTap: () async {
                    Navigator.pop(context);
                    await _generateCaption();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.tag, color: Colors.white70),
                  title: const Text('Generate hashtags', style: TextStyle(color: Colors.white)),
                  onTap: () async {
                    Navigator.pop(context);
                    await _generateHashtags();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _generateCaption() async {
    final prompt = 'Analyze the attached image and write a short, catchy, emoji-friendly social media caption (max 140 chars). Keep it relevant to the image content.';
    await _runAIVision(prompt, insertMode: _InsertMode.caption);
  }

  Future<void> _generateHashtags() async {
    final prompt = 'Analyze the attached image and generate 8-12 relevant, trending hashtags. Output as a single line of space-separated hashtags only, no explanations.';
    await _runAIVision(prompt, insertMode: _InsertMode.hashtags);
  }

  Future<void> _runAI(String prompt, {required _InsertMode insertMode}) async {
    setState(() { _isAIGenerating = true; });
    try {
      final response = await http.post(
        Uri.parse(_aiBaseUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_aiApiKey',
        },
        body: jsonEncode({
          'model': 'gpt-3.5-turbo',
          'messages': [
            {'role': 'system', 'content': 'You are BJAI (BeatJerky AI). Generate concise social captions and hashtags.'},
            {'role': 'user', 'content': prompt},
          ],
          'max_tokens': 120,
          'temperature': 0.8,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final text = (data['choices'][0]['message']['content'] as String).trim();
        setState(() {
          if (insertMode == _InsertMode.caption) {
            if (descriptionController.text.trim().isEmpty) {
              descriptionController.text = text;
            } else {
              descriptionController.text = descriptionController.text.trim() + '\n' + text;
            }
          } else {
            final withSpace = descriptionController.text.trim().isEmpty ? '' : '\n';
            descriptionController.text = descriptionController.text.trim() + withSpace + text;
          }
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('AI error: ${response.statusCode}')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('AI error: $e')),
      );
    } finally {
      if (mounted) setState(() { _isAIGenerating = false; });
    }
  }

  Future<void> _runAIVision(String prompt, {required _InsertMode insertMode}) async {
    if (_selectedImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please add an image first.')),
      );
      return;
    }
    setState(() { _isAIGenerating = true; });
    try {
      final bytes = await _selectedImage!.readAsBytes();
      final b64 = base64Encode(bytes);
      final response = await http.post(
        Uri.parse(_aiBaseUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_aiApiKey',
        },
        body: jsonEncode({
          'model': 'gpt-4o-mini',
          'messages': [
            {
              'role': 'user',
              'content': [
                {'type': 'text', 'text': prompt},
                {
                  'type': 'image_url',
                  'image_url': {'url': 'data:image/jpeg;base64,' + b64}
                }
              ]
            }
          ],
          'max_tokens': 120,
          'temperature': 0.7,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final text = (data['choices'][0]['message']['content'] as String).trim();
        setState(() {
          if (insertMode == _InsertMode.caption) {
            if (descriptionController.text.trim().isEmpty) {
              descriptionController.text = text;
            } else {
              descriptionController.text = descriptionController.text.trim() + '\n' + text;
            }
          } else {
            final withSpace = descriptionController.text.trim().isEmpty ? '' : '\n';
            descriptionController.text = descriptionController.text.trim() + withSpace + text;
          }
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('AI error: ${response.statusCode}')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('AI error: $e')),
      );
    } finally {
      if (mounted) setState(() { _isAIGenerating = false; });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _questionController.dispose();
    for (var controller in _optionControllers) {
      controller.dispose();
    }
    _positionSub?.cancel();
    _previewPlayer.dispose();
    super.dispose();
  }
}

String _formatSeconds(double secs) {
  final d = Duration(seconds: secs.floor());
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return '$m:$s';
}

enum _InsertMode { caption, hashtags }
