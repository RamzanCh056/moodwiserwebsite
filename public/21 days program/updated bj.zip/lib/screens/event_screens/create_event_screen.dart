import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_stripe/flutter_stripe.dart' as StripePkg;
import '../../stripe_payment/stripe_payment.dart';

import 'event_model.dart';
import 'event_service.dart';
import 'map_location_picker.dart';

class CreateEventScreen extends StatefulWidget {
  final Event1Model? event;

  const CreateEventScreen({Key? key, this.event}) : super(key: key);

  @override
  State<CreateEventScreen> createState() => _CreateEventScreenState();
}

class _CreateEventScreenState extends State<CreateEventScreen> {
  File? _image;
  final _picker = ImagePicker();
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _artistController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _placeController = TextEditingController();
  String? _startTime;
  String? _endTime;
  DateTime? _selectedDate;
  bool _loading = false;

  // Map location variables
  double? _selectedLatitude;
  double? _selectedLongitude;
  String _selectedAddress = '';
  bool _isLocationSelected = false;
  bool _isPaidUser = false;
  bool _hasShownPaymentPopup = false;
  bool get isPaidUser => _isPaidUser;
  bool get hasShownPaymentPopup => _hasShownPaymentPopup;

  @override
  void initState() {
    super.initState();
    if (widget.event != null) {
      _artistController.text = widget.event!.artistName;
      _nameController.text = widget.event!.eventName;
      _placeController.text = widget.event!.place;
      _startTime = widget.event!.startTime;
      _endTime = widget.event!.endTime;
      _selectedDate = DateTime.parse(widget.event!.date);
      _selectedLatitude = widget.event!.latitude;
      _selectedLongitude = widget.event!.longitude;
      _selectedAddress = widget.event!.place;
      _isLocationSelected =
          widget.event!.latitude != null && widget.event!.longitude != null;
    }
  }

  Future<void> _pickImage() async {
    final XFile? picked = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (picked != null) {
      setState(() => _image = File(picked.path));
    }
  }

  // Get current location
  Future<void> _getCurrentLocation() async {
    try {
      // Check permissions
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Location permission denied')),
          );
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Location permissions are permanently denied'),
          ),
        );
        return;
      }

      // Get current position
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      // Get address from coordinates
      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty) {
        Placemark place = placemarks[0];
        String address =
            '${place.street}, ${place.locality}, ${place.administrativeArea}';

        setState(() {
          _selectedLatitude = position.latitude;
          _selectedLongitude = position.longitude;
          _selectedAddress = address;
          _placeController.text = address;
          _isLocationSelected = true;
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error getting location: $e')));
    }
  }

  // Open map picker
  Future<void> _openMapPicker() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MapLocationPicker(
          initialLatitude: _selectedLatitude ?? 30.3753,
          initialLongitude: _selectedLongitude ?? 69.3451,
        ),
      ),
    );

    if (result != null) {
      setState(() {
        _selectedLatitude = result['latitude'];
        _selectedLongitude = result['longitude'];
        _selectedAddress = result['address'];
        _placeController.text = result['address'];
        _isLocationSelected = true;
      });
    }
  }

  Future<void> _pickTime({required bool isStart}) async {
    // Check if selected date is today to prevent past times
    bool isToday =
        _selectedDate != null &&
        _selectedDate!.year == DateTime.now().year &&
        _selectedDate!.month == DateTime.now().month &&
        _selectedDate!.day == DateTime.now().day;

    TimeOfDay initialTime = TimeOfDay.now();
    if (isStart && isToday) {
      // For start time on today, add 1 hour to current time
      final now = DateTime.now();
      initialTime = TimeOfDay(hour: now.hour + 1, minute: now.minute);
    }

    final TimeOfDay? t = await showTimePicker(
      context: context,
      initialTime: initialTime,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            timePickerTheme: TimePickerThemeData(
              backgroundColor: const Color(0xFF1F1F1F),
              hourMinuteColor: MaterialStateColor.resolveWith(
                (states) => const Color(0xFF2A2A2A),
              ),
              hourMinuteTextColor: MaterialStateColor.resolveWith(
                (states) => Colors.white,
              ),
              dialHandColor: const Color(0xFFBB86FC),
              dialBackgroundColor: const Color(0xFF2A2A2A),
              entryModeIconColor: Colors.white,
            ),
            colorScheme: ColorScheme.dark(primary: const Color(0xFFBB86FC)),
          ),
          child: child!,
        );
      },
    );
    if (t != null) {
      setState(() {
        final formatted = t.format(context);
        if (isStart)
          _startTime = formatted;
        else
          _endTime = formatted;
      });
    }
  }

  Future<void> _pickDate() async {
    final DateTime? d = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime.now(), // Only allow dates from today onwards
      lastDate: DateTime(2100),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.dark(
              primary: const Color(0xFFBB86FC),
              onPrimary: Colors.white,
              surface: const Color(0xFF1F1F1F),
              onSurface: Colors.white,
            ),
            dialogBackgroundColor: const Color(0xFF121212),
          ),
          child: child!,
        );
      },
    );
    if (d != null) setState(() => _selectedDate = d);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate() ||
        _startTime == null ||
        _endTime == null ||
        _selectedDate == null ||
        !_isLocationSelected ||
        (widget.event == null && _image == null)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please fill all fields, select location, and select image',
          ),
        ),
      );
      return;
    }

    // Check payment status before allowing event creation
    await _checkUserPaymentStatus();
    if (!_isPaidUser) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Premium subscription required to create events. Please upgrade to continue.',
          ),
          backgroundColor: Colors.orange,
          duration: Duration(seconds: 3),
        ),
      );
      _showPaymentPopup();
      return;
    }

    // Validate that event date and time are not in the past
    final now = DateTime.now();
    final eventDateTime = DateTime(
      _selectedDate!.year,
      _selectedDate!.month,
      _selectedDate!.day,
      int.parse(_startTime!.split(':')[0]),
      int.parse(_startTime!.split(':')[1].split(' ')[0]),
    );

    if (eventDateTime.isBefore(now)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Event cannot be scheduled in the past. Please select a future date and time.',
          ),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    setState(() => _loading = true);
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';

    try {
      if (widget.event == null) {
        // Create new event
        await EventService().createEvent(
          artistName: _artistController.text.trim(),
          eventName: _nameController.text.trim(),
          place: _placeController.text.trim(),
          startTime: _startTime!,
          endTime: _endTime!,
          date:
              '${_selectedDate!.year}-${_selectedDate!.month.toString().padLeft(2, '0')}-${_selectedDate!.day.toString().padLeft(2, '0')}',
          imageFile: _image!,
          ownerId: uid,
          latitude: _selectedLatitude,
          longitude: _selectedLongitude,
          address: _selectedAddress,
        );
      } else {
        // Update existing event
        await EventService().updateEvent(
          eventId: widget.event!.id,
          artistName: _artistController.text.trim(),
          eventName: _nameController.text.trim(),
          place: _placeController.text.trim(),
          startTime: _startTime!,
          endTime: _endTime!,
          date:
              '${_selectedDate!.year}-${_selectedDate!.month.toString().padLeft(2, '0')}-${_selectedDate!.day.toString().padLeft(2, '0')}',
          newImageFile: _image,
          latitude: _selectedLatitude,
          longitude: _selectedLongitude,
          address: _selectedAddress,
        );
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Event saved successfully!')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _checkUserPaymentStatus() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final doc = await FirebaseFirestore.instance
          .collection('usersData')
          .doc(user.uid)
          .get();
      if (doc.exists) {
        final data = doc.data()!;
        final isPaid = data['isPaid'] ?? false;

        setState(() {
          _isPaidUser = isPaid;
        });
      }
    } catch (e) {
      print('Error checking user status: $e');
    }
  }

  // Show blue tick popup
  void _showPaymentPopup() {
    if (_hasShownPaymentPopup) return;

    setState(() {
      _hasShownPaymentPopup = true;
    });

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1F1F1F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.verified,
                      color: Colors.blue,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'Premium Required for Events!',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white70),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'To create events, you need BeatJerky Premium:',
                style: TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 8),
              _buildBenefitItem(
                Icons.event,
                'Create and manage unlimited events',
              ),
              _buildBenefitItem(
                Icons.location_on,
                'Add custom locations and venues',
              ),
              _buildBenefitItem(
                Icons.schedule,
                'Schedule events with custom timing',
              ),
              _buildBenefitItem(
                Icons.people,
                'Invite and manage event attendees',
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purple,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: () async {
                        Navigator.pop(ctx);
                        await _startStripeFlow(
                          priceCents: 999,
                          plan: 'monthly',
                        );
                      },
                      child: const Text(
                        'Monthly - \$9.99',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.purple),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: () async {
                        Navigator.pop(ctx);
                        await _startStripeFlow(
                          priceCents: 9999,
                          plan: 'yearly',
                        );
                      },
                      child: const Text(
                        'Yearly - \$99.99',
                        style: TextStyle(
                          color: Colors.purple,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Center(
                child: Text(
                  'You can cancel anytime from Settings.',
                  style: TextStyle(color: Colors.white30, fontSize: 12),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBenefitItem(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFBB86FC), size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: Colors.white70, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  // Start Stripe payment flow
  Future<void> _startStripeFlow({
    required int priceCents,
    required String plan,
  }) async {
    final stripeServices = StripeServices();
    try {
      // Create a minimal payment sheet
      final pi = await stripeServices.createPaymentIntent(
        priceCents.toString(),
      );
      await StripePkg.Stripe.instance.initPaymentSheet(
        paymentSheetParameters: StripePkg.SetupPaymentSheetParameters(
          paymentIntentClientSecret: pi['client_secret'],
          customFlow: true,
          merchantDisplayName: 'BeatJerky',
        ),
      );
      await StripePkg.Stripe.instance.presentPaymentSheet();

      // Mark user paid
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid != null) {
        await FirebaseFirestore.instance
            .collection('usersData')
            .doc(uid)
            .update({
              'isPaid': true,
              'paidPlan': plan,
              'paidAt': FieldValue.serverTimestamp(),
            });

        setState(() {
          _isPaidUser = true;
        });
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Payment successful! You can now create events.'),
            backgroundColor: Colors.green,
          ),
        );
        // Automatically retry event creation after successful payment
        _submit();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Payment failed: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  InputDecoration _inputDecoration(String label, {Widget? suffix}) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
      filled: true,
      fillColor: const Color(0xFF2A2A2A),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide.none,
      ),
      suffixIcon: suffix,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
        ),
        backgroundColor: const Color(0xFF1F1F1F),
        elevation: 0,
        centerTitle: true,
        title: Text(
          widget.event == null ? 'Add Event' : 'Edit Event',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 180,
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2A2A),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: _image != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.file(_image!, fit: BoxFit.cover),
                        )
                      : widget.event != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.network(
                            widget.event!.imageUrl,
                            fit: BoxFit.cover,
                            loadingBuilder: (context, child, progress) {
                              if (progress == null) return child;
                              return const Center(
                                child: CircularProgressIndicator(
                                  color: Color(0xFFBB86FC),
                                ),
                              );
                            },
                            errorBuilder: (_, __, ___) => const Center(
                              child: Text(
                                'Click to Change Event Photo',
                                style: TextStyle(color: Colors.white54),
                              ),
                            ),
                          ),
                        )
                      : const Center(
                          child: Text(
                            'Click to Add Event Photo',
                            style: TextStyle(color: Colors.white54),
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _artistController,
                style: const TextStyle(color: Colors.white),
                decoration: _inputDecoration('Enter artist name'),
                validator: (v) => v!.isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _nameController,
                style: const TextStyle(color: Colors.white),
                decoration: _inputDecoration('Enter event name'),
                validator: (v) => v!.isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              // Location selection section
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.shade700),
                ),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.location_on, color: Color(0xFFBB86FC)),
                        const SizedBox(width: 8),
                        const Text(
                          'Event Location',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Location input field
                    TextFormField(
                      controller: _placeController,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'Select event location',
                        hintStyle: TextStyle(color: Colors.grey.shade400),
                        filled: true,
                        fillColor: Colors.grey.shade800,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide.none,
                        ),
                        suffixIcon: Icon(
                          _isLocationSelected
                              ? Icons.check_circle
                              : Icons.location_on,
                          color: _isLocationSelected
                              ? Colors.green
                              : Colors.grey.shade400,
                        ),
                      ),
                      readOnly: true,
                      onTap: _openMapPicker,
                      validator: (v) =>
                          v!.isEmpty ? 'Please select a location' : null,
                    ),

                    const SizedBox(height: 12),

                    // Location action buttons
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _openMapPicker,
                            icon: const Icon(
                              Icons.map,
                              color: Color(0xFFBB86FC),
                            ),
                            label: const Text(
                              'Pick on Map',
                              style: TextStyle(color: Color(0xFFBB86FC)),
                            ),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Color(0xFFBB86FC)),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _getCurrentLocation,
                            icon: const Icon(
                              Icons.my_location,
                              color: Color(0xFFBB86FC),
                            ),
                            label: const Text(
                              'Current Location',
                              style: TextStyle(color: Color(0xFFBB86FC)),
                            ),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Color(0xFFBB86FC)),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                      ],
                    ),

                    // Show selected coordinates if available
                    if (_isLocationSelected) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.green.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: Colors.green.withOpacity(0.3),
                          ),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.check_circle,
                              color: Colors.green,
                              size: 16,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Location: ${_selectedLatitude?.toStringAsFixed(6)}, ${_selectedLongitude?.toStringAsFixed(6)}',
                                style: const TextStyle(
                                  color: Colors.green,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      readOnly: true,
                      style: const TextStyle(color: Colors.white),
                      decoration: _inputDecoration(
                        'Select Start time',
                        suffix: const Icon(
                          Icons.access_time,
                          color: Colors.white70,
                        ),
                      ),
                      onTap: () => _pickTime(isStart: true),
                      controller: TextEditingController(text: _startTime),
                      validator: (v) => v!.isEmpty ? 'Required' : null,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextFormField(
                      readOnly: true,
                      style: const TextStyle(color: Colors.white),
                      decoration: _inputDecoration(
                        'Select end time',
                        suffix: const Icon(
                          Icons.access_time,
                          color: Colors.white70,
                        ),
                      ),
                      onTap: () => _pickTime(isStart: false),
                      controller: TextEditingController(text: _endTime),
                      validator: (v) => v!.isEmpty ? 'Required' : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextFormField(
                readOnly: true,
                style: const TextStyle(color: Colors.white),
                decoration: _inputDecoration(
                  'Select date',
                  suffix: const Icon(
                    Icons.calendar_today,
                    color: Colors.white70,
                  ),
                ),
                onTap: _pickDate,
                controller: TextEditingController(
                  text: _selectedDate == null
                      ? ''
                      : '${_selectedDate!.year}-${_selectedDate!.month.toString().padLeft(2, '0')}-${_selectedDate!.day.toString().padLeft(2, '0')}',
                ),
                validator: (v) => v!.isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _loading ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFBB86FC),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: _loading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Text(
                        widget.event == null ? 'Create Event' : 'Update Event',
                        style: const TextStyle(color: Colors.white),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
