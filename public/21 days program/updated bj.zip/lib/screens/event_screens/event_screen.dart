
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'create_event_screen.dart';
import 'event_model.dart';
import 'event_service.dart';
import '../events/event_map_screen.dart';

class EventsScreen extends StatefulWidget {
  const EventsScreen({Key? key}) : super(key: key);

  @override
  State<EventsScreen> createState() => _EventsScreenState();
}

class _EventsScreenState extends State<EventsScreen> with SingleTickerProviderStateMixin {
  int _currentTab = 0;
  final TextEditingController _searchController = TextEditingController();
  final EventService _eventService = EventService();
  late TabController _tabController;

  String get _uid => FirebaseAuth.instance.currentUser?.uid ?? '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        setState(() {
          _currentTab = _tabController.index;
          _searchController.clear();
        });
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF121212),
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.white,
          ),
        ),
        backgroundColor: const Color(0xFF1F1F1F),
        elevation: 0,
        title: const Text('Events', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFFBB86FC),
          labelColor: const Color(0xFFBB86FC),
          unselectedLabelColor: Colors.white60,
          tabs: const [Tab(text: 'All Events'), Tab(text: 'My Events')],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search, color: Colors.white70),
                hintText: 'Search event',
                hintStyle: const TextStyle(color: Colors.white54),
                filled: true,
                fillColor: const Color(0xFF2A2A2A),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _buildList(_eventService.getAllEvents()),
                _buildList(_eventService.getMyEvents(_uid), showEmpty: true),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: _currentTab == 1
          ? FloatingActionButton(
              backgroundColor: const Color(0xFFBB86FC),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CreateEventScreen()),
                );
              },
              child: const Icon(Icons.add, color: Colors.white),
            )
          : null,
    );
  }

  Widget _buildList(Stream<List<Event1Model>> stream, {bool showEmpty = false}) {
    return StreamBuilder<List<Event1Model>>(
      stream: stream,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Color(0xFFBB86FC)));
        }
        final events = snapshot.data ?? [];
        final filtered = events.where((e) => e.eventName.toLowerCase().contains(_searchController.text.toLowerCase())).toList();

        if (filtered.isEmpty) {
          return Center(
            child: Text(
              showEmpty ? 'No Events Available' : 'No matching events',
              style: const TextStyle(color: Colors.white70),
            ),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: filtered.length,
          itemBuilder: (context, index) => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: EventCard(
              event: filtered[index],
              currentUserId: _uid,
              onDelete: (eventId) async {
                try {
                  await _eventService.deleteEvent(eventId);
                  Fluttertoast.showToast(msg: "Event deleted successfully");
                } catch (e) {
                  Fluttertoast.showToast(msg: "Failed to delete event: $e");
                }
              },
              onEdit: (event) async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CreateEventScreen(event: event),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}

class EventCard extends StatelessWidget {
  final Event1Model event;
  final String currentUserId;
  final Function(String) onDelete;
  final Function(Event1Model) onEdit;

  const EventCard({
    Key? key,
    required this.event,
    required this.currentUserId,
    required this.onDelete,
    required this.onEdit,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isOwner = event.ownerId == currentUserId;

    return Card(
      color: const Color(0xFF1F1F1F),
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: const Color(0xFFBB86FC).withOpacity(0.2),
          width: 1,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          // Navigate to map screen if coordinates are available
          if (event.latitude != null && event.longitude != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => EventMapScreen(
                  latitude: event.latitude!,
                  longitude: event.longitude!,
                  eventName: event.eventName,
                  eventAddress: event.address,
                ),
              ),
            );
          } else {
            // Show message if no coordinates available
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Location coordinates not available for this event'),
                backgroundColor: Colors.orange,
              ),
            );
          }
        },
        splashColor: const Color(0xFFBB86FC).withOpacity(0.3),
        highlightColor: const Color(0xFFBB86FC).withOpacity(0.1),
        child: Stack(
          children: [
            // Map icon indicator
            Positioned(
              top: 8,
              right: 8,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: event.latitude != null && event.longitude != null
                      ? const Color(0xFFBB86FC).withOpacity(0.9)
                      : Colors.grey.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Icon(
                  event.latitude != null && event.longitude != null ? Icons.map : Icons.location_off,
                  size: 16,
                  color: Colors.white,
                ),
              ),
            ),
            // Main content
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Image.network(
                  event.imageUrl,
                  width: 120,
                  height: 120,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, progress) {
                    if (progress == null) return child;
                    return Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        color: const Color(0xFF2A2A2A),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: CircularProgressIndicator(
                          color: const Color(0xFFBB86FC),
                        ),
                      ),
                    );
                  },
                  errorBuilder: (_, __, ___) => Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      color: const Color(0xFF2A2A2A),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.image,
                      color: Color(0xFFBB86FC),
                      size: 50,
                    ),
                  ),
                ),
              ),
            ),
                              const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                event.eventName,
                                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ),
                            if (isOwner)
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.edit, color: Colors.blue, size: 20),
                                    onPressed: () => onEdit(event),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red, size: 20),
                                    onPressed: () {
                                      showDialog(
                                        context: context,
                                        builder: (context) => AlertDialog(
                                          backgroundColor: const Color(0xFF1F1F1F),
                                          title: const Text(
                                            'Delete Event',
                                            style: TextStyle(color: Colors.white),
                                          ),
                                          content: const Text(
                                            'Are you sure you want to delete this event?',
                                            style: TextStyle(color: Colors.white70),
                                          ),
                                          actions: [
                                            TextButton(
                                              onPressed: () => Navigator.pop(context),
                                              child: const Text('Cancel'),
                                            ),
                                            TextButton(
                                              onPressed: () {
                                                Navigator.pop(context);
                                                onDelete(event.id);
                                              },
                                              child: const Text(
                                                'Delete',
                                                style: TextStyle(color: Colors.red),
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ],
                              ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        _infoText('Artist', event.artistName),
                        _infoText('Place', event.place),
                        _infoText('Time', '${event.startTime} – ${event.endTime}'),
                        _infoText('Date', event.date),
                        const SizedBox(height: 8),
                        // Add map hint
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFBB86FC).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: const Color(0xFFBB86FC).withOpacity(0.3),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.map,
                                size: 12,
                                color: Color(0xFFBB86FC),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                event.latitude != null && event.longitude != null 
                                    ? 'Tap to view location' 
                                    : 'Location not set',
                                style: TextStyle(
                                  color: const Color(0xFFBB86FC).withOpacity(0.8),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoText(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Text(
        '$label: $value',
        style: const TextStyle(color: Colors.white60, fontSize: 13),
      ),
    );
  }
}
