// lib/services/event_service.dart

import 'dart:io';
import 'package:beatjerky/notification_services/trigger_notification_services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';  
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';
import 'event_model.dart';
import 'dart:developer';

class EventService {
  final CollectionReference _eventsRef =
  FirebaseFirestore.instance.collection('events');
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final Uuid _uuid = const Uuid();

  /// Stream all events
  Stream<List<Event1Model>> getAllEvents() {
    return _eventsRef.snapshots().map((snap) =>
        snap.docs
            .map((doc) => Event1Model.fromMap(doc.id, doc.data() as Map<String, dynamic>))
            .toList()
    );
  }

  /// Stream only the current user's events
  Stream<List<Event1Model>> getMyEvents(String uid) {
    return _eventsRef
        .where('ownerId', isEqualTo: uid)
        .snapshots()
        .map((snap) =>
        snap.docs
            .map((doc) => Event1Model.fromMap(doc.id, doc.data() as Map<String, dynamic>))
            .toList()
    );
  }

  /// Create a new event (uploads image then writes Firestore doc)
  Future<void> createEvent({
    required String artistName,
    required String eventName,
    required String place,
    required String startTime,
    required String endTime,
    required String date,
    required File imageFile,
    required String ownerId,
    double? latitude,
    double? longitude,
    String? address,
  }) async {
    // 1) upload image
    final String imageId = _uuid.v4();
    final ref = _storage.ref().child('event_images/$imageId.jpg');
    await ref.putFile(imageFile);
    final imageUrl = await ref.getDownloadURL();

    // 2) assemble model & push to Firestore
    final event = Event1Model(
      id: '',
      imageUrl: imageUrl,
      artistName: artistName,
      eventName: eventName,
      place: place,
      startTime: startTime,
      endTime: endTime,
      date: date,
      ownerId: ownerId,
      latitude: latitude,
      longitude: longitude,
      address: address,
    );
    await _eventsRef.add(event.toMap());

    // 🔔 Send notifications
      await _sendEventNotificationToAllUsers(
        type: 'new_event',
        title: '🎤 New Event Added!',
        body: '$eventName by $artistName at $place',
        message: 'A new event "$eventName" by $artistName has been added.',
      );
  }

  /// Delete an event and its associated image
  Future<void> deleteEvent(String eventId) async {
    try {
      // Get the event document to get the image URL
      final doc = await _eventsRef.doc(eventId).get();
      if (!doc.exists) {
        throw Exception('Event not found');
      }

      final data = doc.data() as Map<String, dynamic>;
      final imageUrl = data['imageUrl'] as String;

      // Delete the image from storage
      if (imageUrl.isNotEmpty) {
        try {
          final ref = _storage.refFromURL(imageUrl);
          await ref.delete();
        } catch (e) {
          print('Error deleting image: $e');
          // Continue with event deletion even if image deletion fails
        }
      }

      // Delete the event document
      await _eventsRef.doc(eventId).delete();

      // 🔔 Notify users
      await _sendEventNotificationToAllUsers(
        type: 'event_deleted',
        title: '🚫 Event Cancelled',
        body: 'An event has been removed — check the latest schedule.',
        message: 'An event was deleted or cancelled by the organizer.',
      );
    } catch (e) {
      throw Exception('Failed to delete event: $e');
    }
  }

  /// Update an existing event
  Future<void> updateEvent({
    required String eventId,
    required String artistName,
    required String eventName,
    required String place,
    required String startTime,
    required String endTime,
    required String date,
    File? newImageFile,
    double? latitude,
    double? longitude,
    String? address,
  }) async {
    try {
      final Map<String, dynamic> updateData = {
        'artistName': artistName,
        'eventName': eventName,
        'place': place,
        'startTime': startTime,
        'endTime': endTime,
        'date': date,
        'latitude': latitude,
        'longitude': longitude,
        'address': address,
      };

      // If a new image is provided, upload it and update the URL
      if (newImageFile != null) {
        final String imageId = _uuid.v4();
        final ref = _storage.ref().child('event_images/$imageId.jpg');
        await ref.putFile(newImageFile);
        final imageUrl = await ref.getDownloadURL();
        updateData['imageUrl'] = imageUrl;

        // Delete the old image
        final doc = await _eventsRef.doc(eventId).get();
        if (doc.exists) {
          final data = doc.data() as Map<String, dynamic>;
          final oldImageUrl = data['imageUrl'] as String;
          if (oldImageUrl.isNotEmpty) {
            try {
              final oldRef = _storage.refFromURL(oldImageUrl);
              await oldRef.delete();
            } catch (e) {
              print('Error deleting old image: $e');
            }
          }
        }
      }

      await _eventsRef.doc(eventId).update(updateData);

      // 🔔 Notify users
      await _sendEventNotificationToAllUsers(
        type: 'event_update',
        title: '📅 Event Updated',
        body: '$eventName has been updated — check out new details!',
        message: 'The event "$eventName" has been updated by $artistName.',
      );
    } catch (e) {
      throw Exception('Failed to update event: $e');
    }
  }

  // 🔔 Reusable private method for sending + saving notifications
  Future<void> _sendEventNotificationToAllUsers({
    required String type,
    required String title,
    required String body,
    required String message,
  }) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) return;

      final currentUserDoc = await FirebaseFirestore.instance
          .collection('usersData')
          .doc(currentUser.uid)
          .get();

      final currentUserName = currentUserDoc['firstName'] ?? 'Someone';

      final usersSnapshot =
          await FirebaseFirestore.instance.collection('usersData').get();

      final trigger = TriggerNotificationService();
      int count = 0;

      for (var userDoc in usersSnapshot.docs) {
        final userId = userDoc.id;
        if (userId == currentUser.uid) continue;

        final userData = userDoc.data();
        final fcmToken = userData['fcmToken'] as String?;

        // Send FCM push
        if (fcmToken != null && fcmToken.isNotEmpty) {
          try {
            await trigger.sendPushNotification(
              token: fcmToken,
              title: title,
              body: body,
            );
          } catch (e) {
            log('Error sending push to $userId: $e');
          }
        }

        // Save notification in Firestore
        await FirebaseFirestore.instance
            .collection('notifications')
            .doc(userId)
            .collection('userNotifications')
            .add({
          'type': type,
          'fromUserId': currentUser.uid,
          'fromUserName': currentUserName,
          'timestamp': FieldValue.serverTimestamp(),
          'message': message,
          'isRead': false,
        });

        count++;
      }

      log('Event notification "$type" sent to $count users');
    } catch (e) {
      log('Error sending event notification: $e');
    }
  }
}
