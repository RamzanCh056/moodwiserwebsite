// lib/screens/store/store_product/store_product.dart
import 'dart:io';

import 'package:beatjerky/screens/order_screen/models/order_model.dart';
import 'package:beatjerky/screens/order_screen/services/order_services.dart';
import 'package:beatjerky/screens/store/store_product/product_checkout.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import '../../../model/api_models/store_models/product_model.dart';
import 'package:flutter_stripe/flutter_stripe.dart' hide Card;
import 'package:cached_network_image/cached_network_image.dart';

import '../../../stripe_payment/stripe_payment.dart';

class ProductScreen extends StatefulWidget {
  final String storeId;
  const ProductScreen({required this.storeId, Key? key}) : super(key: key);

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  final _firestore = FirebaseFirestore.instance;
  final _storage = FirebaseStorage.instance;
  final _picker = ImagePicker();

  void _openAddProductSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return SingleChildScrollView(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 24,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(top: 8, bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey[700],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                _AddProductForm(
                  firestore: _firestore,
                  storage: _storage,
                  picker: _picker,
                  storeId: widget.storeId,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Products', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
        centerTitle: true,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back, color: Colors.white),
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestore
            .collection('products')
            .where('storeId', isEqualTo: widget.storeId)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error: ${snapshot.error}',
                style: const TextStyle(color: Colors.white70),
              ),
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(
              child: Text(
                'No products yet',
                style: TextStyle(color: Colors.white70),
              ),
            );
          }

          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 0.7, // Adjusted back to prevent width issues
            ),
            itemCount: docs.length,
            itemBuilder: (ctx, i) {
              final data = docs[i].data()! as Map<String, dynamic>;
              return _ProductCard(
                name: data['name'] ?? '',
                imageUrl: data['imageUrl'] ?? '',
                price: data['price'] ?? 0,
                productId: docs[i].id,
                firestore: _firestore,
                storeId: widget.storeId,
              );
            },
          );
        },
      ),
      floatingActionButton: FutureBuilder<DocumentSnapshot>(
        future: _firestore.collection('stores').doc(widget.storeId).get(),
        builder: (context, storeSnapshot) {
          if (storeSnapshot.hasData && storeSnapshot.data != null) {
            final currentUserId = FirebaseAuth.instance.currentUser?.uid;
            final storeData =
                storeSnapshot.data!.data() as Map<String, dynamic>?;
            final isStoreOwner =
                storeSnapshot.hasData &&
                storeSnapshot.data != null &&
                storeData != null &&
                storeData['userId'] == currentUserId;

            return isStoreOwner
                ? FloatingActionButton(
                    onPressed: _openAddProductSheet,
                    child: const Icon(Icons.add),
                  )
                : const SizedBox.shrink(); // Hide FAB for non-owners
          }
          return const SizedBox.shrink(); // Hide FAB while loading
        },
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final String name, imageUrl;
  final dynamic price;
  final String productId;
  final FirebaseFirestore firestore;
  final String storeId;
  _ProductCard({
    required this.name,
    required this.imageUrl,
    required this.price,
    required this.productId,
    required this.firestore,
    required this.storeId,
  });

  // Stripe payment service
  StripeServices get _stripeServices => StripeServices();

  // Handle purchase with Stripe
  Future<void> _handlePurchase(BuildContext context) async {
    print('Purchase button tapped for product: $name');

    // Check if user is trying to purchase their own product
    final currentUserId = FirebaseAuth.instance.currentUser?.uid;
    final storeDoc = await firestore.collection('stores').doc(storeId).get();
    final storeData = storeDoc.data();
    final isStoreOwner = storeData?['userId'] == currentUserId;

    if (isStoreOwner) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You cannot purchase your own products!'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    // Show confirmation dialog first
    bool? confirmPurchase = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          title: const Text(
            'Confirm Purchase',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Product: $name',
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 8),
              Text(
                'Price: \$$price',
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 16),
              const Text(
                'Are you sure you want to purchase this product?',
                style: TextStyle(color: Colors.white),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
              child: const Text('Confirm Purchase'),
            ),
          ],
        );
      },
    );

    if (confirmPurchase != true) return;

    try {
      EasyLoading.show(status: 'Processing payment...');

      // Convert price to cents (Stripe expects amount in cents)
      double priceValue = double.tryParse(price) ?? 0.0;
      String priceInCents = (priceValue * 100).round().toString();

      // Create a mock product model for Stripe service
      final mockProduct = MockProductModel(
        id: int.tryParse(productId) ?? 0,
        productName: name,
        productPrice: priceValue.round(),
        productDiscount: 0,
        storeId: storeId,
      );

      // Create payment intent
      var paymentIntent = await _stripeServices.createPaymentIntent(
        priceInCents,
      );

      if (paymentIntent['error'] != null) {
        EasyLoading.dismiss();
        EasyLoading.showError(
          'Payment failed: ${paymentIntent['error']['message']}',
        );
        return;
      }

      // Initialize payment sheet first
      try {
        var gpay = const PaymentSheetGooglePay(
          merchantCountryCode: "US",
          currencyCode: "US",
          testEnv: false,
        );

        await Stripe.instance.initPaymentSheet(
          paymentSheetParameters: SetupPaymentSheetParameters(
            paymentIntentClientSecret: paymentIntent['client_secret'],
            customerId: null,
            customFlow: true,
            style: ThemeMode.dark,
            merchantDisplayName: "BeatJerky",
            googlePay: gpay,
            allowsDelayedPaymentMethods: true,
          ),
        );

        // Now display the payment sheet and handle the result
        final paymentResult = await _stripeServices.displayPaymentSheet(
          context,
          priceInCents,
          mockProduct,
          'Store', // Store name placeholder
          paymentIntent['id'],
        );

        // Only show success if payment was actually completed
        if (paymentResult == true) {
          // Create order in Firebase
          await _createOrder(mockProduct, priceValue);

          EasyLoading.dismiss();
          EasyLoading.showSuccess(
            'Payment completed successfully! Order created.',
          );
        } else {
          EasyLoading.dismiss();
          EasyLoading.showInfo('Payment was cancelled or failed.');
        }
      } catch (stripeError) {
        EasyLoading.dismiss();
        EasyLoading.showError('Stripe initialization error: $stripeError');
        print('Stripe initialization error: $stripeError');
      }
    } catch (e) {
      EasyLoading.dismiss();
      EasyLoading.showError('Payment error: $e');
      print('Purchase error: $e');
    }
  }

  // Create order after successful payment
  Future<void> _createOrder(MockProductModel product, double price) async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      final orderService = OrderService();
      if (currentUser == null) return;

      // Get store information
      final storeDoc = await firestore.collection('stores').doc(storeId).get();
      final storeData = storeDoc.data();
      final storeName = storeData?['name'] ?? 'Unknown Store';
      final storeOwnerId = storeData?['userId'] ?? '';

      // // Create order document
      // await firestore.collection('orders').add({
      //   'userId': currentUser.uid,
      //   'productId': product.id.toString(),
      //   'productName': product.productName,
      //   'productPrice': price,
      //   'storeId': storeId,
      //   'storeName': storeName,
      //   'orderStatus': 'Pending',
      //   'orderDate': FieldValue.serverTimestamp(),
      //   'paymentStatus': 'Completed',
      //   'paymentMethod': 'Stripe',
      // });

      final newOrder = OrderModel(
        orderId: '',
        productId: product.id.toString(),
        productName: product.productName,
        productImage: product.productImg1,
        quantity: 1,
        price: price.toInt(),
        buyerId: currentUser.uid,
        buyerName: currentUser.displayName ?? "",
        sellerId: storeOwnerId,
        sellerName: storeName,
        status: 'pending',
        createdAt: Timestamp.now(),
        dispatchedAt: null,
        deliveredAt: null,
        paymentStatus: 'Completed',
        paymentMethod: 'Stripe',
        orderStatus: 'Pending',
        storeId: storeId,
        storeName: storeName

      );

      await orderService.createOrder(order: newOrder);
   

      print('Order created successfully for product: ${product.productName}');
    } catch (e) {
      print('Error creating order: $e');
    }
  }

  Future<void> _deleteProduct(BuildContext context) async {
    // Security check - verify the store belongs to current user
    try {
      final storeDoc = await firestore.collection('stores').doc(storeId).get();
      final currentUserId = FirebaseAuth.instance.currentUser?.uid;

      if (!storeDoc.exists || storeDoc.data()?['userId'] != currentUserId) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('You don\'t have permission to delete this product'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error verifying permissions: $e'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'Delete Product',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Are you sure you want to delete this product?',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.white70),
            ),
          ),
          TextButton(
            onPressed: () async {
              try {
                // Delete the product image from storage if it exists
                if (imageUrl.isNotEmpty) {
                  final ref = FirebaseStorage.instance.refFromURL(imageUrl);
                  await ref.delete();
                }
                // Delete the product document
                await firestore.collection('products').doc(productId).delete();
                if (context.mounted) {
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Product deleted successfully'),
                    ),
                  );
                }
              } catch (e) {
                if (context.mounted) {
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error deleting product: $e')),
                  );
                }
              }
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _editProduct(BuildContext context) async {
    // Security check - verify the store belongs to current user
    try {
      final storeDoc = await firestore.collection('stores').doc(storeId).get();
      final currentUserId = FirebaseAuth.instance.currentUser?.uid;

      if (!storeDoc.exists || storeDoc.data()?['userId'] != currentUserId) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('You don\'t have permission to edit this product'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error verifying permissions: $e'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return SingleChildScrollView(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 24,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(top: 8, bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey[700],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                _EditProductForm(
                  firestore: FirebaseFirestore.instance,
                  storage: FirebaseStorage.instance,
                  picker: ImagePicker(),
                  productId: productId,
                  initialName: name,
                  initialPrice: price,
                  initialImageUrl: imageUrl,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    print('Debug: Building ProductCard for $name'); // Debug print
    return FutureBuilder<DocumentSnapshot>(
      future: firestore.collection('stores').doc(storeId).get(),
      builder: (context, storeSnapshot) {
        final currentUserId = FirebaseAuth.instance.currentUser?.uid;
        final storeData = storeSnapshot.data?.data() as Map<String, dynamic>?;
        final isStoreOwner =
            storeSnapshot.hasData &&
            storeSnapshot.data != null &&
            storeData != null &&
            storeData['userId'] == currentUserId;

        // Debug prints
        print('Debug: currentUserId = $currentUserId');
        print('Debug: storeData = $storeData');
        print('Debug: storeData[userId] = ${storeData?['userId']}');
        print('Debug: isStoreOwner = $isStoreOwner');
        print('Debug: About to build Purchase button'); // Debug print
        print(
          'Debug: Purchase button will be shown for everyone now',
        ); // Debug print

        return Card(
          elevation: 8, // Add elevation for depth
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16), // More rounded corners
          ),
          clipBehavior: Clip.antiAlias, // Prevent overflow
          child: GestureDetector(
            onTap: isStoreOwner ? null : (){
              Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ProductCheckoutScreen(productId: productId, productImg: imageUrl, storeId: storeId, productPrice: price, productName: name,),
                    ),
                  );
            },
            child: Container(
              constraints: const BoxConstraints(
                maxWidth: double.infinity,
              ), // Ensure proper width
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Colors.grey[900]!, Colors.grey[850]!],
                ),
              ),
              child: Stack(
                fit: StackFit.expand, // Ensure proper sizing
                children: [
                  Positioned.fill(
                    // top: 36,
                    // bottom: 120, // Increased bottom space for Purchase button
                    child: ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(8),
                        topRight: Radius.circular(8),
                      ),
                      child: imageUrl.isNotEmpty
                          ? CachedNetworkImage(
                              imageUrl: imageUrl,
                              fit: BoxFit.cover,
                              width: double.infinity,
                              height: double.infinity,
                              placeholder: (context, url) => Container(
                                color: Colors.grey[800],
                                child: const Center(
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              errorWidget: (context, url, error) => const Icon(
                                Icons.inventory,
                                size: 48,
                                color: Colors.white24,
                              ),
                            )
                          : const Icon(
                              Icons.inventory,
                              size: 48,
                              color: Colors.white24,
                            ),
                    ),
                  ),
                  Positioned(
                    top: 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.green,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.green.withOpacity(0.3),
                            blurRadius: 6,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Text(
                        '\$${price.toString()}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.grey[800],
                        borderRadius: const BorderRadius.vertical(
                          bottom: Radius.circular(12),
                        ),
                      ),
                      constraints: const BoxConstraints(
                        maxHeight: 200,
                      ), // Prevent overflow
                      child: Column(
                        mainAxisSize: MainAxisSize.min, // Prevent overflow
                        crossAxisAlignment:
                            CrossAxisAlignment.center, // Center content
                        children: [
                          // Product name and options row
                          Row(
                            children: [
                              Expanded(
                                child: Center(
                                  child: Text(
                                    name,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.5,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ),
                              // Only show edit/delete options if user owns the store
                              if (isStoreOwner)
                                PopupMenuButton<String>(
                                  icon: const Icon(
                                    Icons.more_vert,
                                    color: Colors.white,
                                  ),
                                  color: Colors.grey[900],
                                  itemBuilder: (context) => [
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Row(
                                        children: [
                                          Icon(Icons.edit, color: Colors.white70),
                                          SizedBox(width: 8),
                                          Text(
                                            'Edit',
                                            style: TextStyle(
                                              color: Colors.white70,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const PopupMenuItem(
                                      value: 'delete',
                                      child: Row(
                                        children: [
                                          Icon(Icons.delete, color: Colors.red),
                                          SizedBox(width: 8),
                                          Text(
                                            'Delete',
                                            style: TextStyle(color: Colors.red),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                  onSelected: (value) {
                                    if (value == 'edit') {
                                      _editProduct(context);
                                    } else if (value == 'delete') {
                                      _deleteProduct(context);
                                    }
                                  },
                                ),
                            ],
                          ),
                          // const SizedBox(height: 8),
                          // // Purchase button row - Always show for testing
                          // InkWell(
                          //   onTap: () => _handlePurchase(context),
                          //   child: Container(
                          //     width: double.infinity,
                          //     height:
                          //         50, // Increased height for better visibility
                          //     margin: const EdgeInsets.symmetric(
                          //       horizontal: 4,
                          //     ), // Minimal margin
                          //     padding: const EdgeInsets.symmetric(
                          //       horizontal: 8,
                          //       vertical: 8,
                          //     ), // Minimal padding
                          //     decoration: BoxDecoration(
                          //       borderRadius: BorderRadius.circular(
                          //         12,
                          //       ), // More rounded corners
                          //       color: const Color(0xFFB717DB), // Purple color
                          //       boxShadow: [
                          //         BoxShadow(
                          //           color: const Color(
                          //             0xFFB717DB,
                          //           ).withOpacity(0.3),
                          //           blurRadius: 8,
                          //           offset: const Offset(0, 4),
                          //         ),
                          //       ],
                          //     ),
                          //     child: const Center(
                          //       child: Row(
                          //         mainAxisAlignment: MainAxisAlignment.center,
                          //         mainAxisSize:
                          //             MainAxisSize.min, // Prevent overflow
                          //         children: [
                          //           Icon(
                          //             Icons.payment,
                          //             color: Colors.white,
                          //             size: 18, // Slightly larger icon
                          //           ),
                          //           SizedBox(width: 8), // Better spacing
                          //           Text(
                          //             'Purchase Now', // Normal text
                          //             style: TextStyle(
                          //               color: Colors.white,
                          //               fontSize:
                          //                   14, // Larger, more readable font
                          //               fontWeight: FontWeight
                          //                   .w600, // Medium weight for elegance
                          //               letterSpacing:
                          //                   0.5, // Better letter spacing
                          //             ),
                          //             textAlign: TextAlign.center,
                          //           ),
                          //         ],
                          //       ),
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _AddProductForm extends StatefulWidget {
  final FirebaseFirestore firestore;
  final FirebaseStorage storage;
  final ImagePicker picker;
  final String storeId;

  const _AddProductForm({
    required this.firestore,
    required this.storage,
    required this.picker,
    required this.storeId,
    Key? key,
  }) : super(key: key);

  @override
  State<_AddProductForm> createState() => _AddProductFormState();
}

class _AddProductFormState extends State<_AddProductForm> {
  final _formKey = GlobalKey<FormState>();
  String _name = '';
  String _price = '';
  XFile? _pickedImage;
  bool _loading = false;

  Future<void> _pickImage() async {
    final img = await widget.picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 75,
    );
    if (img != null) {
      setState(() => _pickedImage = img);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    setState(() => _loading = true);
    String imageUrl = '';

    // 1) upload image if any
    if (_pickedImage != null) {
      final ref = widget.storage.ref().child(
        'product_images/${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      await ref.putFile(File(_pickedImage!.path));
      imageUrl = await ref.getDownloadURL();
    }

    // 2) write product doc
    await widget.firestore.collection('products').add({
      'storeId': widget.storeId,
      'name': _name,
      'price': double.parse(_price),
      'imageUrl': imageUrl,
      'created_at': Timestamp.now(),
    });

    setState(() => _loading = false);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      // ensure the form isn't hidden by keyboard
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Product Name
            TextFormField(
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Product Name',
                filled: true,
                fillColor: Colors.white10,
                labelStyle: TextStyle(color: Colors.white70),
              ),
              onSaved: (v) => _name = v!.trim(),
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Enter a name' : null,
            ),
            const SizedBox(height: 12),

            // Price
            TextFormField(
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Price',
                filled: true,
                fillColor: Colors.white10,
                labelStyle: TextStyle(color: Colors.white70),
              ),
              keyboardType: TextInputType.number,
              onSaved: (v) => _price = v!.trim(),
              validator: (v) =>
                  double.tryParse(v ?? '') == null ? 'Enter valid price' : null,
            ),
            const SizedBox(height: 12),

            // Image picker
            OutlinedButton.icon(
              onPressed: _pickImage,
              icon: const Icon(Icons.image, color: Colors.white),
              label: Text(
                _pickedImage == null
                    ? 'Pick Image (optional)'
                    : 'Image Selected',
                style: const TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),

            // Submit
            _loading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Add Product',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}

class _EditProductForm extends StatefulWidget {
  final FirebaseFirestore firestore;
  final FirebaseStorage storage;
  final ImagePicker picker;
  final String productId;
  final String initialName;
  final String initialPrice;
  final String initialImageUrl;

  const _EditProductForm({
    required this.firestore,
    required this.storage,
    required this.picker,
    required this.productId,
    required this.initialName,
    required this.initialPrice,
    required this.initialImageUrl,
    Key? key,
  }) : super(key: key);

  @override
  State<_EditProductForm> createState() => _EditProductFormState();
}

class _EditProductFormState extends State<_EditProductForm> {
  final _formKey = GlobalKey<FormState>();
  late String _name;
  late String _price;
  XFile? _pickedImage;
  String? _imageUrl;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _name = widget.initialName;
    _price = widget.initialPrice;
    _imageUrl = widget.initialImageUrl;
  }

  Future<void> _pickImage() async {
    final img = await widget.picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 75,
    );
    if (img != null) {
      setState(() => _pickedImage = img);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    setState(() => _loading = true);

    try {
      String finalImageUrl = _imageUrl ?? '';

      // Upload new image if picked
      if (_pickedImage != null) {
        // Delete old image if exists
        if (_imageUrl?.isNotEmpty ?? false) {
          try {
            final oldRef = widget.storage.refFromURL(_imageUrl!);
            await oldRef.delete();
          } catch (e) {
            print('Error deleting old image: $e');
          }
        }

        // Upload new image
        final ref = widget.storage.ref().child(
          'product_images/${DateTime.now().millisecondsSinceEpoch}.jpg',
        );
        await ref.putFile(File(_pickedImage!.path));
        finalImageUrl = await ref.getDownloadURL();
      }

      // Update product document
      await widget.firestore
          .collection('products')
          .doc(widget.productId)
          .update({
            'name': _name,
            'price': double.parse(_price),
            'imageUrl': finalImageUrl,
            'updated_at': Timestamp.now(),
          });

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Product updated successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error updating product: $e')));
      }
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(
              initialValue: _name,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Product Name',
                filled: true,
                fillColor: Colors.white10,
                labelStyle: TextStyle(color: Colors.white70),
              ),
              onSaved: (v) => _name = v!.trim(),
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Enter a name' : null,
            ),
            const SizedBox(height: 12),

            TextFormField(
              initialValue: _price,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Price',
                filled: true,
                fillColor: Colors.white10,
                labelStyle: TextStyle(color: Colors.white70),
              ),
              keyboardType: TextInputType.number,
              onSaved: (v) => _price = v!.trim(),
              validator: (v) =>
                  double.tryParse(v ?? '') == null ? 'Enter valid price' : null,
            ),
            const SizedBox(height: 12),

            if (_imageUrl?.isNotEmpty ?? false)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: CachedNetworkImage(
                    imageUrl: _imageUrl!,
                    height: 100,
                    fit: BoxFit.cover,
                    placeholder: (context, url) => Container(
                      height: 100,
                      color: Colors.grey[800],
                      child: const Center(
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            Colors.white,
                          ),
                        ),
                      ),
                    ),
                    errorWidget: (context, url, error) => Container(
                      height: 100,
                      color: Colors.grey[800],
                      child: const Icon(Icons.error, color: Colors.white24),
                    ),
                  ),
                ),
              ),

            OutlinedButton.icon(
              onPressed: _pickImage,
              icon: const Icon(Icons.image, color: Colors.white),
              label: Text(
                _pickedImage == null
                    ? 'Change Image (optional)'
                    : 'New Image Selected',
                style: const TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),

            _loading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Update Product',
                      style: TextStyle(color: Colors.black),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}

// Mock product model for Stripe integration
class MockProductModel extends ProductModel {
  MockProductModel({
    required int id,
    required String productName,
    required int productPrice,
    required int productDiscount,
    required String storeId,
    String productDescription = '',
    String productImg1 = '',
    String productImg2 = '',
    String productImg3 = '',
    String productImg4 = '',
    String createdAt = '',
    String updatedAt = '',
  }) : super(
         id: id,
         productName: productName,
         productDescription: productDescription,
         productPrice: productPrice,
         productDiscount: productDiscount,
         storeId: storeId,
         productImg1: productImg1,
         productImg2: productImg2,
         productImg3: productImg3,
         productImg4: productImg4,
         createdAt: createdAt,
         updatedAt: updatedAt,
       );
}
