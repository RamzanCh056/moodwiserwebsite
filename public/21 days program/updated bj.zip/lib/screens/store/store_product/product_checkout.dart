import 'dart:developer';

import 'package:beatjerky/notification_services/trigger_notification_services.dart';
import 'package:beatjerky/notification_services/email_service.dart';
import 'package:beatjerky/screens/order_screen/models/order_model.dart';
import 'package:beatjerky/screens/order_screen/services/order_services.dart';
import 'package:beatjerky/screens/store/store_product/product_screen.dart';
import 'package:beatjerky/stripe_payment/stripe_payment.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_stripe/flutter_stripe.dart';

class ProductCheckoutScreen extends StatefulWidget {
  final String productId;
  final String productImg;
  final String storeId;
  final dynamic productPrice;
  final String productName;

  const ProductCheckoutScreen({
    Key? key,
    required this.productId,
    required this.productImg,
    required this.storeId,
    this.productPrice,
    required this.productName,
  }) : super(key: key);

  @override
  State<ProductCheckoutScreen> createState() => _ProductCheckoutScreenState();
}

class _ProductCheckoutScreenState extends State<ProductCheckoutScreen> {
  final TextEditingController _addressController = TextEditingController();
  final ValueNotifier<int> _quantityNotifier = ValueNotifier<int>(1);

  @override
  void dispose() {
    _addressController.dispose();
    _quantityNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final productPrice = widget.productPrice;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Checkout', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
        centerTitle: true,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back, color: Colors.white),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            // Product Image
            AspectRatio(
              aspectRatio: 1,
              child: ClipRRect(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(8),
                  topRight: Radius.circular(8),
                ),
                child: widget.productImg.isNotEmpty
                    ? CachedNetworkImage(
                        imageUrl: widget.productImg,
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                        placeholder: (context, url) => Container(
                          color: Colors.grey[800],
                          child: const Center(
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                Colors.white,
                              ),
                            ),
                          ),
                        ),
                        errorWidget: (context, url, error) => const Icon(
                          Icons.inventory,
                          size: 48,
                          color: Colors.white24,
                        ),
                      )
                    : const Icon(
                        Icons.inventory,
                        size: 48,
                        color: Colors.white24,
                      ),
              ),
            ),
            const SizedBox(height: 16),

            // Product Name & Price
            Text(
              widget.productName,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.white70,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '\$${productPrice.toStringAsFixed(2)}',
              style: const TextStyle(
                fontSize: 18,
                color: Colors.green,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 24),

            // Quantity Selector (reactive)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Quantity:',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.white70,
                  ),
                ),
                ValueListenableBuilder<int>(
                  valueListenable: _quantityNotifier,
                  builder: (context, quantity, _) {
                    return Row(
                      children: [
                        IconButton(
                          icon: const Icon(
                            Icons.remove_circle_outline,
                            color: Colors.white70,
                          ),
                          onPressed: quantity > 1
                              ? () => _quantityNotifier.value--
                              : null,
                        ),
                        Text(
                          '$quantity',
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.white70,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.add_circle_outline,
                            color: Colors.white70,
                          ),
                          onPressed: () => _quantityNotifier.value++,
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Address Input
            const Text(
              'Delivery Address:',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.white70,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _addressController,
              maxLines: 3,
              style: const TextStyle(color: Colors.white70),
              decoration: InputDecoration(
                hintText: 'Enter your delivery address',
                hintStyle: const TextStyle(color: Colors.white38),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Total Price (reactive)
            ValueListenableBuilder<int>(
              valueListenable: _quantityNotifier,
              builder: (context, quantity, _) {
                final totalPrice = productPrice * quantity;
                return Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Total:',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white70,
                      ),
                    ),
                    Text(
                      '\$${totalPrice.toStringAsFixed(2)}',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                  ],
                );
              },
            ),

            const SizedBox(height: 24),

            // Pay Now Button
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                backgroundColor: Colors.blueAccent,
              ),
              onPressed: () async {
                final address = _addressController.text.trim();
                if (address.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please enter a delivery address'),
                    ),
                  );
                  return;
                }

                final quantity = _quantityNotifier.value;
                final totalPrice = productPrice * quantity;

                await _handlePurchase(
                  context: context,
                  totalprice: totalPrice,
                  quantity: quantity,
                );
              },
              child: const Text(
                'Pay Now',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  StripeServices get _stripeServices => StripeServices();

  final _firestore = FirebaseFirestore.instance;

  Future<void> _handlePurchase({
    required BuildContext context,
    required dynamic totalprice,
    required int quantity,
  }) async {
    // Show confirmation dialog first
    bool? confirmPurchase = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[900],
          title: const Text(
            'Confirm Purchase',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Product: ${widget.productName}',
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 8),
              Text(
                'Price: \$$totalprice',
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(height: 16),
              const Text(
                'Are you sure you want to purchase this product?',
                style: TextStyle(color: Colors.white),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
              child: const Text('Confirm Purchase'),
            ),
          ],
        );
      },
    );

    if (confirmPurchase != true) return;

    try {
      EasyLoading.show(status: 'Processing payment...');

      // Convert price to cents (Stripe expects amount in cents)
      String priceInCents = (totalprice * 100).round().toString();


      // Create a mock product model for Stripe service
      final mockProduct = MockProductModel(
        id: int.tryParse(widget.productId) ?? 0,
        productName: widget.productName,
        productPrice: totalprice.round(),
        productDiscount: 0,
        storeId: widget.storeId,
      );

      // Create payment intent
      var paymentIntent = await _stripeServices.createPaymentIntent(
        priceInCents,
      );

      // Initialize payment sheet first
      try {
        var gpay = const PaymentSheetGooglePay(
          merchantCountryCode: "US",
          currencyCode: "US",
          testEnv: false,
        );

        await Stripe.instance.initPaymentSheet(
          paymentSheetParameters: SetupPaymentSheetParameters(
            paymentIntentClientSecret: paymentIntent['client_secret'],
            customerId: null,
            customFlow: true,
            style: ThemeMode.dark,
            merchantDisplayName: "BeatJerky",
            googlePay: gpay,
            allowsDelayedPaymentMethods: true,
          ),
        );

        // Now display the payment sheet and handle the result
        final paymentResult = await _stripeServices.displayPaymentSheet(
          context,
          priceInCents,
          mockProduct,
          widget.storeId, // Store name placeholder
          paymentIntent['id'],
        );

        print("payment result: ${paymentResult}");

        // Only show success if payment was actually completed
        if (paymentResult == true) {
          // Create order in Firebase
          await _createOrder(mockProduct, totalprice);

          EasyLoading.dismiss();
          EasyLoading.showSuccess(
            'Payment completed successfully! Order created.',
          );
          Navigator.pop(context);
        } else {
          EasyLoading.dismiss();
          EasyLoading.showInfo('Payment was cancelled or failed.');
        }
      } catch (stripeError) {
        EasyLoading.dismiss();
        EasyLoading.showError('Stripe initialization error: $stripeError');
        print('Stripe initialization error: $stripeError');
      }
    } catch (e) {
      EasyLoading.dismiss();
      EasyLoading.showError('Payment error: $e');
      print('Purchase error: $e');
    }
  }

  // // Create order after successful payment
  Future<void> _createOrder(MockProductModel product, double price) async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      final orderService = OrderService();
      if (currentUser == null) return;

      // Get store information
      final storeDoc = await _firestore
          .collection('stores')
          .doc(widget.storeId)
          .get();
      final storeData = storeDoc.data();
      final storeName = storeData?['name'] ?? 'Unknown Store';
      final storeOwnerId = storeData?['userId'] ?? '';
      final quantity = _quantityNotifier.value;
      final userDoc = await _firestore
          .collection("usersData")
          .doc(currentUser.uid)
          .get();
      final buyerData = userDoc.data();
      final sellerDoc = await _firestore
          .collection("usersData")
          .doc(storeOwnerId)
          .get();
      final sellerData = sellerDoc.data();

      final newOrder = OrderModel(
        orderId: '',
        productId: widget.productId,
        productName: widget.productName,
        productImage: widget.productImg,
        quantity: quantity,
        price: price.toInt(),
        buyerId: currentUser.uid,
        buyerName: buyerData?['firstName'] ?? "",
        sellerId: storeOwnerId,
        sellerName: sellerData?['firstName'] ?? "",
        status: 'pending',
        createdAt: Timestamp.now(),
        dispatchedAt: null,
        deliveredAt: null,
        paymentStatus: 'Completed',
        paymentMethod: 'Stripe',
        orderStatus: 'Pending',
        storeId: widget.storeId,
        storeName: storeName,
      );

      await orderService.createOrder(order: newOrder);
      _sendsoldNotification(buyerName: buyerData?['firstName'], buyerid: currentUser.uid, price: price, productName: widget.productName, quentity: quantity, sellersid: storeOwnerId, sellersfcmToken: sellerData?['fcmToken']);
    } catch (e) {
      print('Error creating order: $e');
    }
  }

  Future<void> _sendsoldNotification({
    required String sellersfcmToken,
    required String buyerName,
    required String buyerid,
    required String productName,
    required int quentity,
    required double price,
    required String sellersid,
  }) async {
    try {
      final title = "🎉 You've Made a Sale!";
      final body =
          "$buyerName just purchased $quentity × $productName for \$${price.toStringAsFixed(2)}.";

      if (sellersfcmToken.isNotEmpty) {
        // Send push notification
        final trigger = TriggerNotificationService();
        await trigger.sendPushNotification(
          token: sellersfcmToken,
          title: title,
          body: body,
        );
      }
      // Save notification to Firestore
      final notificationData = {
        'type': 'sold',
        'fromUserId': buyerid,
        'fromUserName': buyerName,
        'timestamp': FieldValue.serverTimestamp(),
        'message': body,
        'isRead': false,
      };
      await _firestore
          .collection('notifications')
          .doc(sellersid)
          .collection('userNotifications')
          .add(notificationData);


      final sellerDoc = await _firestore.collection("usersData").doc(sellersid).get();
      final sellerData = sellerDoc.data();
      final sellerEmail = sellerData?['email'];

      if (sellerEmail != null && sellerEmail.isNotEmpty) {
        final emailService = EmailService();

        final emailBody = '''
          <h2>Congratulations ${sellerData?['firstName']}!</h2>
          <p>You’ve made a new sale 🎉</p>
          <p><b>Buyer:</b> $buyerName</p>
          <p><b>Product:</b> $productName</p>
          <p><b>Quantity:</b> $quentity</p>
          <p><b>Total:</b> \$${price.toStringAsFixed(2)}</p>
          <br>
          <p>Keep up the great work! 💼</p>
          <p><i>— The BeatJerky Team</i></p>
        ''';

        await emailService.sendEmail(
          to: sellerEmail,
          subject: "🎉 New Sale: $productName Sold!",
          body: emailBody,
        );
      }


    } catch (e) {
      log('Error sending notification: $e');
    }
  }
}
