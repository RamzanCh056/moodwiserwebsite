import 'dart:io';
import 'package:beatjerky/screens/order_screen/presentation/order_screen.dart';
import 'package:beatjerky/screens/store/store_product/product_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:beatjerky/notification_services/email_service.dart';
import 'dart:developer';

class StoreScreen extends StatefulWidget {
  const StoreScreen({Key? key}) : super(key: key);
  @override
  State<StoreScreen> createState() => _StoreScreenState();
}

class _StoreScreenState extends State<StoreScreen> {
  final _firestore = FirebaseFirestore.instance;
  final _storage = FirebaseStorage.instance;
  final _picker = ImagePicker();

  void _openAddSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return SingleChildScrollView(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 24,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // draggable handle
                Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(top: 8, bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey[700],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                _AddStoreItemForm(
                  firestore: _firestore,
                  storage: _storage,
                  picker: _picker,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _openEditSheet(String storeId, Map<String, dynamic> data) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return SingleChildScrollView(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 24,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(top: 8, bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey[700],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                _EditStoreItemForm(
                  firestore: _firestore,
                  storage: _storage,
                  picker: _picker,
                  storeId: storeId,
                  initialData: data,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text(
          'Beat Jerky Store',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.inventory, color: Colors.white),
            onPressed: ()async {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) =>
                      const OrderScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestore
            .collection('stores')
            .orderBy('created_at', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error: ${snapshot.error}',
                style: const TextStyle(color: Colors.white70),
              ),
            );
          }
          if (!snapshot.hasData) {
            // still loading first batch
            return const Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(
              child: Text(
                'No stores yet',
                style: TextStyle(color: Colors.white70),
              ),
            );
          }

          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 0.8,
            ),
            itemCount: docs.length,
            itemBuilder: (ctx, i) {
              final doc = docs[i];
              final data = doc.data()! as Map<String, dynamic>;
              final storeId = doc.id;
              final currentUserId = FirebaseAuth.instance.currentUser?.uid;
              final isOwner = data['userId'] == currentUserId;

              return InkWell(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => ProductScreen(storeId: storeId),
                    ),
                  );
                },
                child: Stack(
                  children: [
                    _StoreCard(
                      name: data['name'] ?? '',
                      imageUrl: data['imageUrl'] ?? '',
                      discount: data['discount']?.toString() ?? '',
                    ),
                    if (isOwner)
                      Positioned(
                        top: 0,
                        right: 0,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.blue),
                              onPressed: () async {
                                // Security check - verify the store belongs to current user
                                final storeDoc = await _firestore
                                    .collection('stores')
                                    .doc(storeId)
                                    .get();
                                if (!storeDoc.exists ||
                                    storeDoc.data()?['userId'] !=
                                        currentUserId) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        'You don\'t have permission to edit this store',
                                      ),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                  return;
                                }

                                _openEditSheet(storeId, data);
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () async {
                                final shouldDelete = await showDialog<bool>(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    backgroundColor: Colors.grey[900],
                                    title: const Text(
                                      'Delete Store',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                    content: const Text(
                                      'Are you sure you want to delete this store?',
                                      style: TextStyle(color: Colors.white70),
                                    ),
                                    actions: [
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(context, false),
                                        child: const Text('Cancel'),
                                      ),
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(context, true),
                                        child: const Text(
                                          'Delete',
                                          style: TextStyle(color: Colors.red),
                                        ),
                                      ),
                                    ],
                                  ),
                                );

                                if (shouldDelete == true) {
                                  try {
                                    final storeDoc = await _firestore
                                        .collection('stores')
                                        .doc(storeId)
                                        .get();
                                    if (!storeDoc.exists ||
                                        storeDoc.data()?['userId'] !=
                                            currentUserId) {
                                      ScaffoldMessenger.of(
                                        context,
                                      ).showSnackBar(
                                        const SnackBar(
                                          content: Text(
                                            'You don\'t have permission to delete this store',
                                          ),
                                          backgroundColor: Colors.red,
                                        ),
                                      );
                                      return;
                                    }

                                    await _firestore
                                        .collection('stores')
                                        .doc(storeId)
                                        .delete();
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                          'Store deleted successfully',
                                        ),
                                        backgroundColor: Colors.green,
                                      ),
                                    );
                                  } catch (e) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          'Error deleting store: $e',
                                        ),
                                        backgroundColor: Colors.red,
                                      ),
                                    );
                                  }
                                }
                              },
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _openAddSheet,
        child: const Icon(Icons.add),
      ),
    );
  }
}

class _StoreCard extends StatelessWidget {
  final String name, imageUrl, discount;
  const _StoreCard({
    required this.name,
    required this.imageUrl,
    required this.discount,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.grey[900],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Stack(
        children: [
          if (discount.isNotEmpty)
            Positioned(
              top: 8,
              left: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '$discount% off',
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
            ),
          Positioned.fill(
            top: 36,
            bottom: 36,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: imageUrl.isNotEmpty
                    ? Image.network(imageUrl, fit: BoxFit.cover)
                    : const Icon(Icons.store, size: 48, color: Colors.white24),
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: Colors.grey[800],
                borderRadius: const BorderRadius.vertical(
                  bottom: Radius.circular(12),
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                name,
                style: const TextStyle(color: Colors.white),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AddStoreItemForm extends StatefulWidget {
  final FirebaseFirestore firestore;
  final FirebaseStorage storage;
  final ImagePicker picker;

  const _AddStoreItemForm({
    required this.firestore,
    required this.storage,
    required this.picker,
  });

  @override
  State<_AddStoreItemForm> createState() => _AddStoreItemFormState();
}

class _AddStoreItemFormState extends State<_AddStoreItemForm> {
  final _formKey = GlobalKey<FormState>();
  String _name = '', _discount = '';
  XFile? _picked;
  bool _loading = false;

  Future<void> _pickImage() async {
    final img = await widget.picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 75,
    );
    if (img != null) setState(() => _picked = img);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();
    setState(() => _loading = true);

    String imageUrl = '';
    if (_picked != null) {
      final ref = widget.storage.ref().child(
        'store_images/${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      await ref.putFile(File(_picked!.path));
      imageUrl = await ref.getDownloadURL();
    }

    await widget.firestore.collection('stores').add({
      'name': _name,
      'discount': int.parse(_discount),
      'imageUrl': imageUrl,
      'created_at': Timestamp.now(),
      'userId': FirebaseAuth.instance.currentUser!.uid,
    });

    setState(() => _loading = false);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextFormField(
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              labelText: 'Name',
              filled: true,
              fillColor: Colors.white10,
              labelStyle: TextStyle(color: Colors.white70),
            ),
            onSaved: (v) => _name = v!.trim(),
            validator: (v) =>
                v == null || v.trim().isEmpty ? 'Enter name' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              labelText: 'Discount (%)',
              filled: true,
              fillColor: Colors.white10,
              labelStyle: TextStyle(color: Colors.white70),
            ),
            keyboardType: TextInputType.number,
            onSaved: (v) => _discount = v!.trim(),
            validator: (v) =>
                int.tryParse(v ?? '') == null ? 'Enter valid %' : null,
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickImage,
            icon: const Icon(Icons.image, color: Colors.white),
            label: Text(
              _picked == null ? 'Pick Image (optional)' : 'Image Selected',
              style: const TextStyle(color: Colors.white),
            ),
          ),
          const SizedBox(height: 16),
          _loading
              ? const CircularProgressIndicator()
              : ElevatedButton(
                  onPressed: _submit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Create',
                    style: TextStyle(color: Colors.black),
                  ),
                ),
        ],
      ),
    );
  }
}

class _EditStoreItemForm extends StatefulWidget {
  final FirebaseFirestore firestore;
  final FirebaseStorage storage;
  final ImagePicker picker;
  final String storeId;
  final Map<String, dynamic> initialData;

  const _EditStoreItemForm({
    required this.firestore,
    required this.storage,
    required this.picker,
    required this.storeId,
    required this.initialData,
  });

  @override
  State<_EditStoreItemForm> createState() => _EditStoreItemFormState();
}

class _EditStoreItemFormState extends State<_EditStoreItemForm> {
  final _formKey = GlobalKey<FormState>();
  late String _name, _discount;
  XFile? _picked;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _name = widget.initialData['name'] ?? '';
    _discount = widget.initialData['discount']?.toString() ?? '';
  }

  Future<void> _pickImage() async {
    final img = await widget.picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 75,
    );
    if (img != null) setState(() => _picked = img);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();
    setState(() => _loading = true);

    String imageUrl = widget.initialData['imageUrl'] ?? '';
    if (_picked != null) {
      final ref = widget.storage.ref().child(
        'store_images/${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      await ref.putFile(File(_picked!.path));
      imageUrl = await ref.getDownloadURL();
    }

    await widget.firestore.collection('stores').doc(widget.storeId).update({
      'name': _name,
      'discount': int.parse(_discount),
      'imageUrl': imageUrl,
    });

    setState(() => _loading = false);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextFormField(
            initialValue: _name,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              labelText: 'Name',
              filled: true,
              fillColor: Colors.white10,
              labelStyle: TextStyle(color: Colors.white70),
            ),
            onSaved: (v) => _name = v!.trim(),
            validator: (v) =>
                v == null || v.trim().isEmpty ? 'Enter name' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            initialValue: _discount,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
              labelText: 'Discount (%)',
              filled: true,
              fillColor: Colors.white10,
              labelStyle: TextStyle(color: Colors.white70),
            ),
            keyboardType: TextInputType.number,
            onSaved: (v) => _discount = v!.trim(),
            validator: (v) =>
                int.tryParse(v ?? '') == null ? 'Enter valid %' : null,
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickImage,
            icon: const Icon(Icons.image, color: Colors.white),
            label: Text(
              _picked == null ? 'Pick Image (optional)' : 'Image Selected',
              style: const TextStyle(color: Colors.white),
            ),
          ),
          const SizedBox(height: 16),
          _loading
              ? const CircularProgressIndicator()
              : ElevatedButton(
                  onPressed: _submit,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Update',
                    style: TextStyle(color: Colors.black),
                  ),
                ),
        ],
      ),
    );
  }
}
