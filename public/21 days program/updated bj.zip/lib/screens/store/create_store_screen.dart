import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../providers/music_store_provider/music_store_provider.dart';
import '../../utils/color.dart';
import '../music_store/music_store_model.dart';

class CreateStoreScreen extends StatefulWidget {
  /// If true, builds a music‐store form; otherwise a generic store form.
  final bool isMusicStore;
  final MusicStoreModel? store;

  const CreateStoreScreen({
    Key? key,
    this.isMusicStore = false,
    this.store,
  }) : super(key: key);

  @override
  State<CreateStoreScreen> createState() => _CreateStoreScreenState();
}

class _CreateStoreScreenState extends State<CreateStoreScreen> {
  final _formKey = GlobalKey<FormState>();
  final ImagePicker _picker = ImagePicker();

  File? _pickedImage;
  String _name = '';
  String _discount = '';
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.store != null) {
      _name = widget.store!.name;
      _discount = widget.store!.discount.toString();
    }
  }

  Future<void> _pickImage() async {
    final XFile? img = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (img != null) setState(() => _pickedImage = File(img.path));
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    setState(() => _isLoading = true);

    try {
      if (widget.store != null) {
        await Provider.of<MusicStoreProvider>(context, listen: false).updateStore(
          storeId: widget.store!.id,
          name: _name,
          discount: int.parse(_discount),
          imageFile: _pickedImage,
        );
      } else if (widget.isMusicStore) {
        await Provider.of<MusicStoreProvider>(context, listen: false).createMusicStore(
          name: _name,
          imageFile: _pickedImage,
        );
      } else {
        await Provider.of<MusicStoreProvider>(context, listen: false).addStore(
          name: _name,
          discount: int.parse(_discount),
          imageFile: _pickedImage,
        );
      }
      Navigator.of(context).pop();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error ${widget.store != null ? 'updating' : 'creating'} store: $e')),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E1E1E),
        elevation: 0,
        title: Text(widget.store != null ? 'Edit Store' : 'Create Store'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: SingleChildScrollView(
          padding: EdgeInsets.only(
            top: 24,
            bottom: MediaQuery.of(context).viewInsets.bottom + 24,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                GestureDetector(
                  onTap: _isLoading ? null : _pickImage,
                  child: _pickedImage != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.file(
                            _pickedImage!,
                            height: 180,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                        )
                      : widget.store?.imageUrl.isNotEmpty == true
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.network(
                                widget.store!.imageUrl,
                                height: 180,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              ),
                            )
                          : const DottedBorderPlaceholder(),
                ),
                const SizedBox(height: 8),
                TextButton.icon(
                  onPressed: _isLoading ? null : _pickImage,
                  icon: const Icon(Icons.image, color: indigoColor),
                  label: const Text(
                    'Pick Image',
                    style: TextStyle(color: indigoColor),
                  ),
                ),
                const SizedBox(height: 16),
                _darkField(
                  label: 'Store Name',
                  initialValue: _name,
                  onSaved: (v) => _name = v!.trim(),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter a name' : null,
                ),
                const SizedBox(height: 12),
                if (!widget.isMusicStore) ...[
                  _darkField(
                    label: 'Discount (%)',
                    initialValue: _discount,
                    keyboardType: TextInputType.number,
                    onSaved: (v) => _discount = v!.trim(),
                    validator: (v) {
                      final n = int.tryParse(v ?? '');
                      return n == null ? 'Enter a valid number' : null;
                    },
                  ),
                  const SizedBox(height: 24),
                ],
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: indigoColor,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onPressed: _isLoading ? null : _submit,
                    child: _isLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : Text(
                            widget.store != null ? 'Update Store' : 'Create Store',
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                            ),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _darkField({
    required String label,
    String? initialValue,
    TextInputType keyboardType = TextInputType.text,
    required FormFieldSetter<String> onSaved,
    required FormFieldValidator<String> validator,
  }) {
    return TextFormField(
      initialValue: initialValue,
      style: const TextStyle(color: Colors.white),
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70),
        filled: true,
        fillColor: const Color(0xFF1E1E1E),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
      onSaved: onSaved,
      validator: validator,
    );
  }
}

class DottedBorderPlaceholder extends StatelessWidget {
  const DottedBorderPlaceholder({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 180,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white38,
          width: 2,
          style: BorderStyle.solid,
        ),
      ),
      child: const Center(
        child: Icon(
          Icons.add_photo_alternate,
          size: 48,
          color: Colors.white38,
        ),
      ),
    );
  }
}
