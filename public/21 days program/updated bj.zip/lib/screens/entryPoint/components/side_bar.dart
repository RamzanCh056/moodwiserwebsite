
import 'package:flutter/material.dart';

import '../../../model/menu.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../utils/rive_utils.dart';
import '../../all_users_screen.dart';
import '../../chat_screens/store_profile_screen.dart';
import '../../settings_screen.dart';
import '../../shop/stores_screen.dart';
import 'info_card.dart';
import 'side_menu.dart';
import 'package:provider/provider.dart';

class SideBar extends StatefulWidget {
  const SideBar({super.key});

  @override
  State<SideBar> createState() => _SideBarState();
}

class _SideBarState extends State<SideBar> {
  Menu selectedSideMenu = sidebarMenus.first;
  @override
  Widget build(BuildContext context) {
    return Container(
        width: 288,
        height: double.infinity,
        decoration: const BoxDecoration(
          // color: Color(0xFF17203A),
          borderRadius: BorderRadius.all(
            Radius.circular(30),
          ),
        ),
        child: DefaultTextStyle(
          style: const TextStyle(color: Colors.white),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InfoCard(
                name:
                    "${Provider.of<CurrentUserProvider>(context).user!.firstName} ${Provider.of<CurrentUserProvider>(context).user!.lastName}",
                bio: "",
              ),
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  // Important: Remove any padding from the ListView.

                  children: <Widget>[
                    ListTile(
                      leading: const Icon(Icons.people),
                      title: const Text("People"),
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (cotex)=>const AllUsersScreen()));
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.settings),
                      title: const Text("Feed Shop"),
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>const StoresScreen() ));
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.settings),
                      title: const Text("Setting"),
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>const SettingsScreen() ));
                      },
                    ),
                  ],
                ),
              ),
              // Padding(
              //   padding: const EdgeInsets.only(left: 24, top: 32, bottom: 16),
              //   child: Text(
              //     "Browse".toUpperCase(),
              //     style: Theme.of(context)
              //         .textTheme
              //         .titleMedium!
              //         .copyWith(color: Colors.white70),
              //   ),
              // ),
              // ...sidebarMenus
              //     .map((menu) => SideMenu(
              //           menu: menu,
              //           selectedMenu: selectedSideMenu,
              //           press: () {
              //             RiveUtils.chnageSMIBoolState(menu.rive.status!);
              //             setState(() {
              //               selectedSideMenu = menu;
              //             });
              //           },
              //           riveOnInit: (artboard) {
              //             menu.rive.status = RiveUtils.getRiveInput(artboard,
              //                 stateMachineName: menu.rive.stateMachineName);
              //           },
              //         ))
              //     .toList(),
              // Padding(
              //   padding: const EdgeInsets.only(left: 24, top: 40, bottom: 16),
              //   child: Text(
              //     "History".toUpperCase(),
              //     style: Theme.of(context)
              //         .textTheme
              //         .titleMedium!
              //         .copyWith(color: Colors.white70),
              //   ),
              // ),
              // ...sidebarMenus2
              //     .map((menu) => SideMenu(
              //           menu: menu,
              //           selectedMenu: selectedSideMenu,
              //           press: () {
              //             RiveUtils.chnageSMIBoolState(menu.rive.status!);
              //             setState(() {
              //               selectedSideMenu = menu;
              //             });
              //           },
              //           riveOnInit: (artboard) {
              //             menu.rive.status = RiveUtils.getRiveInput(artboard,
              //                 stateMachineName: menu.rive.stateMachineName);
              //           },
              //         ))
              //     .toList(),
            ],
          ),
        ),
      );
  }
}
