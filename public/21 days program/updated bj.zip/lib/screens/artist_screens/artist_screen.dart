import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uuid/uuid.dart';
import 'add_artist_dialog.dart';
import 'my_artist_screen.dart';
import 'artist_upload_song_screen.dart';
import '../home1/song_player_screen.dart';

class AllArtistsScreen extends StatefulWidget {
  const AllArtistsScreen({super.key});

  @override
  State<AllArtistsScreen> createState() => _AllArtistsScreenState();
}

class _AllArtistsScreenState extends State<AllArtistsScreen> {
  final _firestore = FirebaseFirestore.instance;
  late Stream<QuerySnapshot> _artistsStream;
  String? _selectedArtistId;
  String? _selectedArtistName;

  @override
  void initState() {
    super.initState();
    _artistsStream = _firestore.collection('artists').orderBy('createdAt', descending: true).snapshots();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // No more audio management needed
  }

  void _selectArtist(String artistId, String artistName) {
    print('DEBUG: Selecting artist - ID: $artistId, Name: $artistName');
    
    setState(() {
      if (_selectedArtistId == artistId) {
        _selectedArtistId = null;
        _selectedArtistName = null;
      } else {
        _selectedArtistId = artistId;
        _selectedArtistName = artistName;
      }
    });
    print('DEBUG: Selected artist ID is now: $_selectedArtistId');
  }

  Future<void> _editArtist(String artistId, String currentName, String currentBandName, String currentAbout, String currentImageUrl) async {
    final TextEditingController nameController = TextEditingController(text: currentName);
    final TextEditingController bandController = TextEditingController(text: currentBandName);
    final TextEditingController aboutController = TextEditingController(text: currentAbout);
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text(
          'Edit Artist',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Artist Name',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70)),
                  focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFBB86FC))),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: bandController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Band Name (Optional)',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70)),
                  focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFBB86FC))),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: aboutController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'About',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70)),
                  focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFBB86FC))),
                ),
                maxLines: 3,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Artist name is required')),
                );
                return;
              }
              
              try {
                await FirebaseFirestore.instance.collection('artists').doc(artistId).update({
                  'name': nameController.text.trim(),
                  'bandName': bandController.text.trim(),
                  'about': aboutController.text.trim(),
                  'updatedAt': FieldValue.serverTimestamp(),
                });
                
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Artist updated successfully')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Error updating artist: $e')),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFBB86FC),
            ),
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteArtist(String artistId, String artistName) async {
    // Check if artist has songs
    final songsSnapshot = await FirebaseFirestore.instance
        .collection('artistSongs')
        .where('artistId', isEqualTo: artistId)
        .get();
    
    if (songsSnapshot.docs.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Cannot delete artist with existing songs. Please delete all songs first.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text(
          'Delete Artist',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Are you sure you want to delete "$artistName"? This action cannot be undone.',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                // Delete artist image from storage if exists
                final artistDoc = await FirebaseFirestore.instance.collection('artists').doc(artistId).get();
                if (artistDoc.exists) {
                  final data = artistDoc.data()!;
                  final imageUrl = data['imageUrl'] as String? ?? '';
                  if (imageUrl.isNotEmpty && imageUrl.startsWith('https://firebasestorage.googleapis.com')) {
                    try {
                      final ref = FirebaseStorage.instance.refFromURL(imageUrl);
                      await ref.delete();
                    } catch (e) {
                      print('Error deleting artist image: $e');
                    }
                  }
                }
                
                // Delete artist document
                await FirebaseFirestore.instance.collection('artists').doc(artistId).delete();
                
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Artist deleted successfully')),
                );
                
                // Clear selection if deleted artist was selected
                if (_selectedArtistId == artistId) {
                  setState(() {
                    _selectedArtistId = null;
                    _selectedArtistName = null;
                  });
                }
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Error deleting artist: $e')),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _autoSelectFirstArtist(List<QueryDocumentSnapshot> docs) {
    if (_selectedArtistId == null && docs.isNotEmpty) {
      final firstArtist = docs.first;
      final artistId = firstArtist.id;
      final artistName = firstArtist['name'] as String? ?? 'Unknown';
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _selectArtist(artistId, artistName);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFFBB86FC);
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Artists', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.white70),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // Toggle buttons
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accent,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    ),
                    onPressed: () {},
                    child: const Text('All Artist', style: TextStyle(color: Colors.white)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: accent),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const MyArtistsScreen()),
                      );
                    },
                    child: const Text('My Artist', style: TextStyle(color: Color(0xFFBB86FC))),
                  ),
                ),
              ],
            ),
          ),
          
          // Artists heading
          const Padding(
            padding: EdgeInsets.only(left: 16, bottom: 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'All Artists',
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
              ),
            ),
          ),
          
          // Artists grid with inline songs
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _artistsStream,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator(color: accent));
                }
                final docs = snap.data?.docs ?? [];
                if (docs.isEmpty) {
                  return const Center(child: Text('No artists yet', style: TextStyle(color: Colors.white70)));
                }
                
                // Auto-select first artist if none selected
                _autoSelectFirstArtist(docs);
                
                return Column(
                  children: [
                    // Artists grid (original 5-column design)
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 5,
                        mainAxisSpacing: 8,
                        crossAxisSpacing: 8,
                        childAspectRatio: 0.6,
                  ),
                  itemCount: docs.length,
                  itemBuilder: (ctx, i) {
                    final data = docs[i].data()! as Map<String, dynamic>;
                    final name = data['name'] as String? ?? 'Unknown';
                    final imageUrl = data['imageUrl'] as String? ?? '';
                        final artistId = docs[i].id;
                        final isSelected = _selectedArtistId == artistId;
                        
                    return GestureDetector(
                          onTap: () => _selectArtist(artistId, name),
                          child: Column(
                              children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(50),
                                child: imageUrl.isNotEmpty
                                    ? Image.network(
                                        imageUrl,
                                        width: 60,
                                        height: 60,
                                        fit: BoxFit.cover,
                                      )
                                    : Container(width: 60, height: 60, color: Colors.grey[800]),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: isSelected ? accent : Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 10,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                    
                    // Songs section (centered, inline)
                    if (_selectedArtistId != null) ...[
                      const SizedBox(height: 20),
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 16),
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                        color: const Color(0xFF1F1F1F),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: accent, width: 1),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Header
                            Row(
                          children: [
                            Expanded(
                                  child: Text(
                                    '${_selectedArtistName}\'s Songs',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                GestureDetector(
                                    onTap: () => _selectArtist(_selectedArtistId!, _selectedArtistName!),
                                      child: const Icon(Icons.close, color: Colors.white70, size: 24)),
                              ],
                            ),
                            const SizedBox(height: 16),
                            
                            // Songs list
                            StreamBuilder<QuerySnapshot>(
                              stream: _firestore
                                  .collection('artistSongs')
                                  .where('artistId', isEqualTo: _selectedArtistId)
                                  .snapshots(),
                              builder: (context, snap) {
                                if (snap.connectionState == ConnectionState.waiting) {
                                  return const Center(child: CircularProgressIndicator(color: accent));
                                }
                                if (snap.hasError) {
                                  return Center(
                                    child: Text('Error: ${snap.error}', style: const TextStyle(color: Colors.red)),
                                  );
                                }
                                final songDocs = snap.data?.docs ?? [];
                                if (songDocs.isEmpty) {
                                  return const Center(
                                    child: Padding(
                                      padding: EdgeInsets.all(20),
                                      child: Text(
                                        'No songs yet',
                                        style: TextStyle(color: Colors.white70, fontSize: 16),
                                      ),
                                    ),
                                  );
                                }
                                return Column(
                                  children: songDocs.map((doc) {
                                    final songData = doc.data()! as Map<String, dynamic>;
                                    final title = songData['title'] as String? ?? 'Unknown';
                                    final year = songData['year']?.toString() ?? '';
                                    final audioUrl = songData['audioUrl'] as String? ?? '';
                                    final coverImage = songData['coverUrl'] as String? ?? '';
                                    
                                    return Container(
                                      margin: const EdgeInsets.only(bottom: 12),
                                      padding: const EdgeInsets.all(16),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF2A2A2A),
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                      child: Row(
                                        children: [
                                          // Album art placeholder
                            Container(
                                            width: 50,
                                            height: 50,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.circular(12),
                                            ),
                                            child: const Icon(
                                              Icons.music_note,
                                              color: Colors.black,
                                              size: 28,
                                            ),
                                          ),
                                          const SizedBox(width: 16),
                                          // Song info
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  title,
                                                  style: const TextStyle(
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 16,
                                                  ),
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                                if (year.isNotEmpty) ...[
                                                  const SizedBox(height: 4),
                                                  Text(
                                                    year,
                                                    style: const TextStyle(
                                                      color: Colors.white60,
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                ],
                                              ],
                                            ),
                                          ),
                                          // Play button
                                          GestureDetector(
                                            onTap: () {
                                              if (audioUrl.isNotEmpty) {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (_) => SongPlayerScreen(
                                                      title: title,
                                                      fileUrl: audioUrl,
                                                      coverImage: coverImage, description: '',
                                                    ),
                                                  ),
                                                );
                                              } else {
                                                ScaffoldMessenger.of(context).showSnackBar(
                                                  const SnackBar(content: Text('No audio file available')),
                                                );
                                              }
                                            },
                                            child: Container(
                                              width: 50,
                                              height: 50,
                                              decoration: BoxDecoration(
                              color: accent,
                                                shape: BoxShape.circle,
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: accent.withOpacity(0.3),
                                                    blurRadius: 8,
                                                    spreadRadius: 2,
                                                  ),
                                                ],
                                              ),
                                              child: const Icon(
                                                Icons.play_arrow,
                                                color: Colors.white,
                                                size: 24,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
