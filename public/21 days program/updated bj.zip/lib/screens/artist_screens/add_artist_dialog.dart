// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:uuid/uuid.dart';
//
// class AddArtistDialog extends StatefulWidget {
//   const AddArtistDialog({Key? key}) : super(key: key);
//
//   @override
//   State<AddArtistDialog> createState() => _AddArtistDialogState();
// }
//
// class _AddArtistDialogState extends State<AddArtistDialog> {
//   final _picker = ImagePicker();
//   File? _image;
//   final _nameCtrl = TextEditingController();
//   final _bandCtrl = TextEditingController();
//   final _aboutCtrl = TextEditingController();
//   bool _submitting = false;
//
//   Future<void> _pickImage() async {
//     final xfile = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 75);
//     if (xfile != null) {
//       setState(() => _image = File(xfile.path));
//     }
//   }
//
//   Future<void> _submit() async {
//     // ❌ removed `return` before showSnackBar
//     if (_nameCtrl.text.isEmpty || _bandCtrl.text.isEmpty || _aboutCtrl.text.isEmpty || _image == null) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('All fields and a picture are required')),
//       );
//       return;
//     }
//
//     setState(() => _submitting = true);
//     try {
//       final uid = FirebaseAuth.instance.currentUser!.uid;
//       final id = const Uuid().v4();
//       final ref = FirebaseStorage.instance.ref().child('artists/$id.jpg');
//       await ref.putFile(_image!);
//       final url = await ref.getDownloadURL();
//
//       await FirebaseFirestore.instance.collection('artists').doc(id).set({
//         'name': _nameCtrl.text.trim(),
//         'bandName': _bandCtrl.text.trim(),
//         'about': _aboutCtrl.text.trim(),
//         'imageUrl': url,
//         'userId': uid,
//         'createdAt': FieldValue.serverTimestamp(),
//       });
//
//       Navigator.of(context).pop();
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Error: $e')),
//       );
//     } finally {
//       setState(() => _submitting = false);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     const purple = Color(0xFF9C27B0);
//
//     return Dialog(
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//       insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
//       child: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.all(16),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               // Close button
//               Align(
//                 alignment: Alignment.topRight,
//                 child: GestureDetector(
//                   onTap: () => Navigator.of(context).pop(),
//                   child: const CircleAvatar(
//                     radius: 12,
//                     backgroundColor: Colors.red,
//                     child: Icon(Icons.close, size: 16, color: Colors.white),
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 8),
//
//               // Image picker
//               GestureDetector(
//                 onTap: _pickImage,
//                 child: Container(
//                   height: 150,
//                   decoration: BoxDecoration(
//                     color: purple,
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: Center(
//                     child: _image == null
//                         ? const Text(
//                             'Click to Add Artist Picture',
//                             style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
//                           )
//                         : ClipRRect(
//                             borderRadius: BorderRadius.circular(12),
//                             child: Image.file(_image!, fit: BoxFit.cover, width: double.infinity),
//                           ),
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 16),
//
//               // Text fields
//               TextField(
//                 controller: _nameCtrl,
//                 decoration: const InputDecoration(hintText: 'Enter artist name'),
//               ),
//               const SizedBox(height: 12),
//               TextField(
//                 controller: _bandCtrl,
//                 decoration: const InputDecoration(hintText: 'Enter band name'),
//               ),
//               const SizedBox(height: 12),
//               TextField(
//                 controller: _aboutCtrl,
//                 decoration: const InputDecoration(hintText: 'About artist'),
//                 maxLines: 3,
//               ),
//               const SizedBox(height: 20),
//
//               // Submit
//               SizedBox(
//                 width: double.infinity,
//                 child: ElevatedButton(
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: purple,
//                     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
//                   ),
//                   onPressed: _submitting ? null : _submit,
//                   child: _submitting
//                       ? const SizedBox(
//                           height: 16,
//                           width: 16,
//                           child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
//                         )
//                       : const Text('Profile Upload'),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uuid/uuid.dart';

class AddArtistDialog extends StatefulWidget {
  const AddArtistDialog({Key? key}) : super(key: key);

  @override
  State<AddArtistDialog> createState() => _AddArtistDialogState();
}

class _AddArtistDialogState extends State<AddArtistDialog> {
  final _picker = ImagePicker();
  File? _image;
  final _nameCtrl = TextEditingController();
  final _bandCtrl = TextEditingController();
  final _aboutCtrl = TextEditingController();
  bool _submitting = false;

  Future<void> _pickImage() async {
    final xfile = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 75,
    );
    if (xfile != null) {
      setState(() => _image = File(xfile.path));
    }
  }

  Future<void> _submit() async {
    if (_nameCtrl.text.isEmpty || _bandCtrl.text.isEmpty || _aboutCtrl.text.isEmpty || _image == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('All fields and a picture are required'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() => _submitting = true);
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final id = const Uuid().v4();
      final ref = FirebaseStorage.instance.ref().child('artists/$id.jpg');
      await ref.putFile(_image!);
      final url = await ref.getDownloadURL();

      await FirebaseFirestore.instance.collection('artists').doc(id).set({
        'name': _nameCtrl.text.trim(),
        'bandName': _bandCtrl.text.trim(),
        'about': _aboutCtrl.text.trim(),
        'imageUrl': url,
        'userId': uid,
        'createdAt': FieldValue.serverTimestamp(),
      });

      Navigator.of(context).pop();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: \$e'),
          backgroundColor: Colors.redAccent,
        ),
      );
    } finally {
      setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final accent = const Color(0xFFBB86FC);
    return Dialog(
      backgroundColor: const Color(0xFF121212),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Close button
              Align(
                alignment: Alignment.topRight,
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: const CircleAvatar(
                    radius: 12,
                    backgroundColor: Colors.red,
                    child: Icon(Icons.close, size: 16, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 8),

              // Image picker
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 150,
                  decoration: BoxDecoration(
                    color: const Color(0xFF2A2A2A),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: _image == null
                        ? Text(
                            'Click to Add Artist Picture',
                            style: TextStyle(color: accent, fontWeight: FontWeight.w600),
                          )
                        : ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.file(
                              _image!,
                              fit: BoxFit.cover,
                              width: double.infinity,
                            ),
                          ),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Text fields
              _buildDarkTextField(_nameCtrl, 'Enter artist name'),
              const SizedBox(height: 12),
              _buildDarkTextField(_bandCtrl, 'Enter band name'),
              const SizedBox(height: 12),
              _buildDarkTextField(_aboutCtrl, 'About artist', maxLines: 3),
              const SizedBox(height: 20),

              // Submit
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accent,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: _submitting ? null : _submit,
                  child: _submitting
                      ? const SizedBox(
                          height: 16,
                          width: 16,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('Profile Upload', style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDarkTextField(TextEditingController controller, String hint, {int maxLines = 1}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white54),
        filled: true,
        fillColor: const Color(0xFF2A2A2A),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      ),
    );
  }
}
