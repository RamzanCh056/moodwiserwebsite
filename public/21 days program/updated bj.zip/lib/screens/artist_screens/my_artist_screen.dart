import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/widgets.dart';
import 'artist_upload_song_screen.dart';
import 'add_artist_dialog.dart';

class MyArtistsScreen extends StatefulWidget {
  const MyArtistsScreen({Key? key}) : super(key: key);

  @override
  State<MyArtistsScreen> createState() => _MyArtistsScreenState();
}

class _MyArtistsScreenState extends State<MyArtistsScreen> {
  final _firestore = FirebaseFirestore.instance;
  final _searchController = TextEditingController();
  List<QueryDocumentSnapshot> _allMyArtists = [];
  List<QueryDocumentSnapshot> _filtered = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetchMyArtists();
    _searchController.addListener(_onSearch);
  }

  Future<void> _fetchMyArtists() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    final snap = await _firestore.collection('artists').where('userId', isEqualTo: uid).get();
    _allMyArtists = snap.docs;
    _filtered = List.from(_allMyArtists);
    setState(() => _loading = false);
  }

  void _onSearch() {
    final term = _searchController.text.toLowerCase();
    if (term.isEmpty) {
      setState(() => _filtered = List.from(_allMyArtists));
    } else {
      setState(() {
        _filtered = _allMyArtists.where((d) => (d['name'] as String).toLowerCase().contains(term)).toList();
      });
    }
  }

  Future<void> _openAddDialog() async {
    await showDialog(
      context: context,
      builder: (_) => const AddArtistDialog(),
    );
    await _fetchMyArtists();
  }

  Future<void> _editArtist(String artistId, String currentName, String currentBandName, String currentAbout, String currentImageUrl) async {
    final TextEditingController nameController = TextEditingController(text: currentName);
    final TextEditingController bandController = TextEditingController(text: currentBandName);
    final TextEditingController aboutController = TextEditingController(text: currentAbout);
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text(
          'Edit Artist',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Artist Name',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70)),
                  focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFBB86FC))),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: bandController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Band Name (Optional)',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70)),
                  focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFBB86FC))),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: aboutController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'About',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70)),
                  focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFFBB86FC))),
                ),
                maxLines: 3,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Artist name is required')),
                );
                return;
              }
              
              try {
                await FirebaseFirestore.instance.collection('artists').doc(artistId).update({
                  'name': nameController.text.trim(),
                  'bandName': bandController.text.trim(),
                  'about': aboutController.text.trim(),
                  'updatedAt': FieldValue.serverTimestamp(),
                });
                
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Artist updated successfully')),
                );
                await _fetchMyArtists(); // Refresh the list
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Error updating artist: $e')),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFBB86FC),
            ),
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteArtist(String artistId, String artistName) async {
    // Check if artist has songs
    final songsSnapshot = await FirebaseFirestore.instance
        .collection('artistSongs')
        .where('artistId', isEqualTo: artistId)
        .get();
    
    final hasSongs = songsSnapshot.docs.isNotEmpty;
    final songCount = songsSnapshot.docs.length;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text(
          'Delete Artist',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Are you sure you want to delete "$artistName"?',
              style: const TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 16),
            if (hasSongs) ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.red.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.warning, color: Colors.red, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'This artist has $songCount song${songCount == 1 ? '' : 's'} that will also be deleted permanently.',
                        style: const TextStyle(color: Colors.red, fontSize: 14),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
            ],
            const Text(
              'This action cannot be undone!',
              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                Navigator.pop(context);
                
                // Show loading indicator
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => const AlertDialog(
                    backgroundColor: Color(0xFF1F1F1F),
                    content: Row(
                      children: [
                        CircularProgressIndicator(color: Color(0xFFBB86FC)),
                        SizedBox(width: 16),
                        Text(
                          'Deleting artist and songs...',
                          style: TextStyle(color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                );
                
                // Delete all songs first
                if (hasSongs) {
                  for (final songDoc in songsSnapshot.docs) {
                    final songData = songDoc.data() as Map<String, dynamic>;
                    
                    // Delete audio file from storage
                    final audioUrl = songData['audioUrl'] as String? ?? '';
                    if (audioUrl.isNotEmpty && audioUrl.startsWith('https://firebasestorage.googleapis.com')) {
                      try {
                        final audioRef = FirebaseStorage.instance.refFromURL(audioUrl);
                        await audioRef.delete();
                      } catch (e) {
                        print('Error deleting audio file: $e');
                      }
                    }
                    
                    // Delete cover image from storage
                    final coverUrl = songData['coverUrl'] as String? ?? '';
                    if (coverUrl.isNotEmpty && coverUrl.startsWith('https://firebasestorage.googleapis.com')) {
                      try {
                        final coverRef = FirebaseStorage.instance.refFromURL(coverUrl);
                        await coverRef.delete();
                      } catch (e) {
                        print('Error deleting cover image: $e');
                      }
                    }
                    
                    // Delete song document
                    await FirebaseFirestore.instance.collection('artistSongs').doc(songDoc.id).delete();
                  }
                }
                
                // Delete artist image from storage if exists
                final artistDoc = await FirebaseFirestore.instance.collection('artists').doc(artistId).get();
                if (artistDoc.exists) {
                  final data = artistDoc.data()!;
                  final imageUrl = data['imageUrl'] as String? ?? '';
                  if (imageUrl.isNotEmpty && imageUrl.startsWith('https://firebasestorage.googleapis.com')) {
                    try {
                      final ref = FirebaseStorage.instance.refFromURL(imageUrl);
                      await ref.delete();
                    } catch (e) {
                      print('Error deleting artist image: $e');
                    }
                  }
                }
                
                // Delete artist document
                await FirebaseFirestore.instance.collection('artists').doc(artistId).delete();
                
                // Close loading dialog
                if (context.mounted) {
                  Navigator.pop(context);
                }
                
                // Show success message
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        hasSongs 
                          ? 'Artist and $songCount song${songCount == 1 ? '' : 's'} deleted successfully'
                          : 'Artist deleted successfully',
                      ),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
                
                // Refresh the list
                await _fetchMyArtists();
              } catch (e) {
                // Close loading dialog
                if (context.mounted) {
                  Navigator.pop(context);
                }
                
                // Show error message
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error deleting artist: $e'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFFBB86FC);
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white70),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'Artists',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            // Toggle Row
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: accent),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: const Text(
                        'All Artist',
                        style: TextStyle(color: accent),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accent,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      ),
                      onPressed: () {},
                      child: const Text('My Artist', style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
            // Search + Add
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search, color: Colors.white70),
                      hintText: 'Search artist name',
                      hintStyle: const TextStyle(color: Colors.white54),
                      filled: true,
                      fillColor: const Color(0xFF2A2A2A),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                FloatingActionButton(
                  backgroundColor: accent,
                  onPressed: _openAddDialog,
                  child: const Icon(Icons.add, color: Colors.white),
                ),
              ],
            ),
            // Heading
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'My Artists',
                style: Theme.of(context).textTheme.titleMedium!.copyWith(color: Colors.white, fontWeight: FontWeight.w600),
              ),
            ),
            // Content
            Expanded(
              child: _loading
                  ? const Center(
                      child: CircularProgressIndicator(color: accent),
                    )
                  : _filtered.isEmpty
                      ? const Center(
                          child: Text('No Artist Found', style: TextStyle(color: Colors.white70)),
                        )
                      : ListView.builder(
                          itemCount: _filtered.length,
                          padding: EdgeInsets.zero,
                          itemBuilder: (ctx, i) {
                            final doc = _filtered[i];
                            final data = doc.data()! as Map<String, dynamic>;
                            return Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              padding: const EdgeInsets.symmetric(horizontal: 14,vertical: 10),
                              decoration: BoxDecoration(
                                color: const Color(0xFF2A2A2A),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Row(
                                children: [
                                  // Artist image
                                  ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: data['imageUrl'] != null
                                    ? Image.network(
                                        data['imageUrl'],
                                            width: 70,
                                            height: 70,
                                        fit: BoxFit.cover,
                                          )
                                        : Container(color: Colors.grey[800], width: 50, height: 50),
                                  ),
                                  const SizedBox(width: 16),
                                  // Artist info
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          data['name'] as String? ?? '',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                        if ((data['bandName'] as String? ?? '').isNotEmpty) ...[
                                          const SizedBox(height: 4),
                                          Text(
                                            data['bandName'] as String? ?? '',
                                            style: const TextStyle(
                                              color: Colors.white60,
                                              fontSize: 14,
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                  // Action buttons
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [

Row(
  crossAxisAlignment: CrossAxisAlignment.end,
  mainAxisAlignment: MainAxisAlignment.end,
  children: [
    // Edit button
    GestureDetector(
      onTap: () => _editArtist(
        doc.id,
        data['name'] ?? '',
        data['bandName'] ?? '',
        data['about'] ?? '',
        data['imageUrl'] ?? '',
      ),
      child: Icon(
        Icons.edit,
        color: Colors.blue,
        size: 20,
      ),
    ),

    SizedBox(width: 10,),
    // Delete button
    GestureDetector(
      onTap:() => _deleteArtist(
        doc.id,
        data['name'] ?? '',
      ),
      child:  Icon(
        Icons.delete,
        color: Colors.red,
        size: 20,
      ),
    ),
  ],
),
                                      // Upload Song button
                                      Container(
                                        margin: const EdgeInsets.only(left: 8),
                                        child: ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: const Color(0xFF2A2A2A),
                                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                          ),
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (_) => ArtistUploadSongScreen(
                                                  artistId: doc.id,
                                                  artistName: data['name'] as String? ?? '',
                                                ),
                                            ),
                                          );
                                        },
                                          child: const Text(
                                            'Upload Song',
                                            style: TextStyle(color: Colors.white, fontSize: 12),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}
