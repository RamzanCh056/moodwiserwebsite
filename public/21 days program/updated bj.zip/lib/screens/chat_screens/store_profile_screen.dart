import 'package:beatjerky/screens/chat_screens/store_chat_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';

import '../../consolePrintWithColor.dart';
import '../../providers/stores_provider/followed_stores_provider.dart';
import '../../providers/stores_provider/store_provider.dart';
import '../../repo/api_consts.dart' show ApiConstants;
import '../../services/api_services/store_services/get_products.dart';
import '../../services/api_services/store_services/get_store_feeds.dart';
import '../../services/api_services/store_services/get_store_profile.dart';
import '../../services/api_services/store_services/store_follow_services.dart';
import '../../shimmer_effect/profile_screen_skeleton.dart';
import '../../utils/color.dart';
import '../../widget/reusable_text.dart';
import '../drawer/shop_profile_screen/shop_tab.dart';
import '../drawer/shop_profile_screen/timline_tab.dart' show TimelineTab;


class StoreProfileScreen extends StatefulWidget {
  const StoreProfileScreen({
    required this.storeId,
    required this.storeImage,
    Key? key}) : super(key: key);
  final int storeId;
  final String storeImage;
  @override
  State<StoreProfileScreen> createState() => _StoreProfileScreenState();
}

class _StoreProfileScreenState extends State<StoreProfileScreen> {

  bool isLoading=true;

  initializeScreen()async{
    await GetStoreProfile.getStoreProfile(context, widget.storeId);
    await GetProducts.getProducts(context, widget.storeId);
    await StoreFeedServices().getStoreFeeds(context, widget.storeId);
    setState(() {
      isLoading=false;
    });
  }


  @override
  void initState() {
    initializeScreen();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    var followed=Provider.of<FollowedStoresProvider>(context,listen: false).followedStores;
    return SafeArea(
      child: DefaultTabController(
        length: 2,
        child: Scaffold(

          backgroundColor: const Color(0xff000000),
          body: !isLoading?Stack(
            children: [
              ListView(
                children: [

                  Consumer<StoreProvider>(
                    builder: (BuildContext context, store, Widget? child) {
                      return Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          children: [
                            Center(
                              child:  CircleAvatar(
                                radius: 60,
                                backgroundImage:
                                NetworkImage(store.store!.storeImage.replaceAll("public", ApiConstants.baseUrl)),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                ReusableText(
                                  title: store.store!.storeName,
                                  color: Color(0xffFFFFFF),
                                  size: 16,
                                  weight: FontWeight.w700,
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(
                                  width: 5,
                                ),
                                const Image(image: AssetImage("assets/shop_feed/icons/Subtract.png"))
                              ],
                            ),
                            // const SizedBox(
                            //   height: 5,
                            // ),
                            // const ReusableText(
                            //   title: '@mark_h01',
                            //   color: Color(0xffFFFFFF),
                            //   size: 12,
                            //   weight: FontWeight.w400,
                            //   textAlign: TextAlign.center,
                            // ),
                            const SizedBox(
                              height: 20,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  height: 54,
                                  width: 109,
                                  decoration: BoxDecoration(
                                      color: const Color(0xf30FFFFFF),
                                      border:
                                      Border.all(color: const Color(0xf30E0E6F3)),
                                      borderRadius: BorderRadius.circular(8)),
                                  child: Padding(
                                    padding: const EdgeInsets.all(6.0),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        ReusableText(
                                          title: store.store!.followerCount.toString(),
                                          color: const Color(0xffFFFFFF),
                                          size: 14,
                                          weight: FontWeight.w600,
                                        ),
                                        const SizedBox(
                                          height: 8,
                                        ),
                                        const ReusableText(
                                          title: 'Followers',
                                          color: Color(0xffFFFFFF),
                                          size: 12,
                                          weight: FontWeight.w500,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                InkWell(
                                  onTap: ()async{
                                    var result=followed.where((element) => element.storeId==widget.storeId);
                                    printLog(">>>>>>>>>>>>>>>>>>>>${result.length}");
                                    if(result.isNotEmpty){

                                      await GetStoreProfile.unFollowStore(store.store!.id, context);
                                      await StoreFollowServices.getAllFollowedStores(context);
                                      setState(() {

                                      });
                                    }else{
                                      await GetStoreProfile.followStore(store.store!.id, context);
                                      await StoreFollowServices.getAllFollowedStores(context);
                                      setState(() {

                                      });
                                    }

                                  },
                                  child: Container(
                                    height: 54,
                                    width: 109,
                                    decoration: BoxDecoration(
                                        color: const Color(0xf30FFFFFF),
                                        border:
                                        Border.all(color: const Color(0xf30E0E6F3)),
                                        borderRadius: BorderRadius.circular(8)),
                                    child: Padding(
                                      padding: const EdgeInsets.all(6.0),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [

                                          const SizedBox(
                                            height: 8,
                                          ),
                                          ReusableText(
                                            title: followed.any((element)=>
                                              element.storeId==widget.storeId
                                            )?'Followed':"Follow",
                                            color: Color(0xffFFFFFF),
                                            size: 12,
                                            weight: FontWeight.w500,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                // Container(
                                //   height: 54,
                                //   width: 109,
                                //   decoration: BoxDecoration(
                                //       color: const Color(0xf30FFFFFF),
                                //       border:
                                //       Border.all(color: const Color(0xf30E0E6F3)),
                                //       borderRadius: BorderRadius.circular(8)),
                                //   child: Padding(
                                //     padding: const EdgeInsets.all(6.0),
                                //     child: Column(
                                //       mainAxisAlignment: MainAxisAlignment.center,
                                //       children: const [
                                //         ReusableText(
                                //           title: '3.2 M',
                                //           color: Color(0xffFFFFFF),
                                //           size: 14,
                                //           weight: FontWeight.w600,
                                //         ),
                                //         SizedBox(
                                //           height: 8,
                                //         ),
                                //         ReusableText(
                                //           title: 'Reactions',
                                //           color: Color(0xffFFFFFF),
                                //           size: 12,
                                //           weight: FontWeight.w500,
                                //         ),
                                //       ],
                                //     ),
                                //   ),
                                // ),
                                // Container(
                                //   height: 54,
                                //   width: 109,
                                //   decoration: BoxDecoration(
                                //       color: const Color(0xf30FFFFFF),
                                //       border:
                                //       Border.all(color: const Color(0xf30E0E6F3)),
                                //       borderRadius: BorderRadius.circular(8)),
                                //   child: Padding(
                                //     padding: const EdgeInsets.all(6.0),
                                //     child: Column(
                                //       mainAxisAlignment: MainAxisAlignment.center,
                                //       children: const [
                                //         ReusableText(
                                //           title: '230',
                                //           color: Color(0xffFFFFFF),
                                //           size: 14,
                                //           weight: FontWeight.w600,
                                //         ),
                                //         SizedBox(
                                //           height: 8,
                                //         ),
                                //         ReusableText(
                                //           title: 'Posts',
                                //           color: Color(0xffFFFFFF),
                                //           size: 12,
                                //           weight: FontWeight.w500,
                                //         ),
                                //       ],
                                //     ),
                                //   ),
                                // ),
                              ],
                            ),
                            const SizedBox(
                              height: 13,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  height: 40,
                                  width: 152,
                                  decoration: BoxDecoration(
                                      color: const Color(0xf30FFFFFF),
                                      borderRadius: BorderRadius.circular(8)),
                                  child: const Center(
                                      child: ReusableText(
                                        title: 'Like',
                                        color: Color(0xffFFFFFF),
                                        size: 16,
                                        weight: FontWeight.w700,
                                        textAlign: TextAlign.center,
                                      )),
                                ),
                                InkWell(
                                  onTap: (){
                                    Get.to(()=>StoreChatScreen(storeId: widget.storeId,storeImage: widget.storeImage,));
                                  },
                                  child: Container(
                                    height: 40,
                                    width: 152,
                                    decoration: BoxDecoration(
                                        color: const Color(0xf30FFFFFF),
                                        border:
                                        Border.all(color: const Color(0xf30FFFFFF)),
                                        borderRadius: BorderRadius.circular(8)),
                                    child: const Center(
                                        child: ReusableText(
                                          title: 'Message',
                                          color: Color(0xffFFFFFF),
                                          size: 16,
                                          weight: FontWeight.w700,
                                          textAlign: TextAlign.center,
                                        )),
                                  ),
                                ),
                                Container(
                                  height: 40,
                                  width: 27,
                                  decoration: BoxDecoration(
                                      color: const Color(0xf30FFFFFF),
                                      borderRadius: BorderRadius.circular(8)),
                                  child: const Center(
                                      child: Icon(
                                        Icons.more_vert,
                                        color: Color(0xffFFFFFF),
                                      )),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },

                  ),
                  const TabBar(

                      indicatorColor: indigoColor,
                      unselectedLabelColor: Color(0xf70FFFFFF),
                      labelColor: Color(0xffFFFFFF),
                      labelStyle:
                          TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                      tabs: [
                        Tab(
                          text: 'Timeline',
                        ),
                        Tab(
                          text: 'Shop',
                        ),
                      ]),
                  Container(
                    color: const Color(0xf30FFFFFF),
                    child: SizedBox(
                      height: MediaQuery.of(context).size.height * 0.5,
                      child: TabBarView(children: [
                        TimelineTab(storeId: widget.storeId,),
                        ShopTab(storeName: Provider.of<StoreProvider>(context,listen: false).store!.storeName,),
                      ]),
                    ),
                  )
                ],
              ),
              Container(
                margin: EdgeInsets.all(5),
                // padding: EdgeInsets.all(3),
                decoration: BoxDecoration(
              color: Color(0x50ffffff),
              borderRadius: BorderRadius.circular(50)
                ),
                child: IconButton(
              onPressed: ()=>Navigator.pop(context),
              icon: Icon(Icons.arrow_back,color: Colors.white,),
                ),
              )
            ],
          ):
          const ProfileScreenSkeleton(),
        ),
      ),
    );
  }
}
