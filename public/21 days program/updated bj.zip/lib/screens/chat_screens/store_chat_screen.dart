import 'dart:async';


import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../consolePrintWithColor.dart';
import '../../providers/admin_provider/admin_provider.dart' show AdminProvider;
import '../../providers/chat_provider/chat_provider.dart' show ChatProvider;
import '../../providers/users_provider/current_user_provider.dart';
import '../../repo/api_consts.dart';
import '../../services/api_services/chat_services/chat_services.dart';
import '../../shimmer_effect/message_screen_skeleton.dart';
import '../../utils/color.dart';
import '../../widget/build_message.dart';


class StoreChatScreen extends StatefulWidget {
  final int storeId;
  final String storeImage;
  const StoreChatScreen({Key? key,
    required this.storeId,
  required this.storeImage}) : super(key: key);

  @override
  State<StoreChatScreen> createState() => _StoreChatScreenState();
}

class _StoreChatScreenState extends State<StoreChatScreen> {

  TextEditingController messageController=TextEditingController();

  bool isLoading=true;
  getStoreConversation()async{
    await ChatServices().getStoreConversation(widget.storeId, context);
    setState(() {
      setState(() {
        isLoading=false;
      });
    });
  }


  @override
  void initState() {

    getStoreConversation();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: ()=>getStoreConversation(),
      child: Scaffold(
          appBar: AppBar(
            backgroundColor: blackColor,
            title: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                backgroundImage: NetworkImage(widget.storeImage.replaceAll('public', ApiConstants.baseUrl)),


              ),
              // title: ReusableText(title: widget.name,color: whiteColor,),
              // subtitle: ReusableText(title: widget.status ? "online" : "offline",color: greyColor,),
            ),
            actions: const [
              Icon(Icons.more_vert,color: whiteColor,),
              SizedBox(width: 10,),
            ],
          ),
          body:  Column(
            children: [
              Expanded(
                child: isLoading?const MessageScreenSkeleton():Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Provider.of<ChatProvider>(context,listen: false).storeConversationList.isNotEmpty?
                  ListView.builder(
                    itemCount: Provider.of<ChatProvider>(context,listen: false).storeConversationList.length,
                    itemBuilder: (context,index){


                      return Consumer<ChatProvider>(
                          builder: (context,chat,_){

                            bool sameDate=false;

                            if(index<chat.storeConversationList.length-1){
                              DateTime.parse(chat.storeConversationList[index].createdAt).day==
                                  DateTime.parse(chat.storeConversationList[index+1].createdAt).day?
                              sameDate=true:
                              sameDate=false;

                            }
                            return BuildMessage(message: chat.storeConversationList[index].message,
                              indexZero: index==0?true:false,
                              isMe: chat.storeConversationList[index].senderId==Provider.of<CurrentUserProvider>(context).user!.userId,
                              dateTime: chat.storeConversationList[index].createdAt,
                              // dateTime: sameDate?DateFormat("").add_jm().format(DateTime.parse(chat.storeConversationList[index].createdAt)):
                              // DateFormat("dd-MMM-yyyy").add_jm().format(DateTime.parse(chat.storeConversationList[index].createdAt)),
                              isSameDate: sameDate,
                            );

                          }
                          );
                    },
                  ):
                  const Center(child: Text("No Chat found")),
                ),
              ),
              Container(
                height: 60,
                width: double.infinity,
                color: backgroundColor,
                child: TextField(
                  controller: messageController,
                  style: const TextStyle(color: whiteColor),
                  decoration: InputDecoration(
                      hintText: "write your message",
                      hintStyle: const TextStyle(color: whiteColor),
                      suffixIcon: InkWell(
                          onTap: ()async{
                            if(messageController.text.isNotEmpty) {
                              var chatList=Provider.of<ChatProvider>(context,listen: false).storeConversationList;

                              printLog(">>>>>>>>>Admin id>>>>>>${Provider.of<AdminProvider>(context,listen: false).admin["id"]}");
                              await ChatServices().sendMessageToStore(
                                  chatList.isEmpty?Provider.of<AdminProvider>(context,listen: false).admin["id"]:
                                  chatList[0].senderId==
                                  Provider.of<CurrentUserProvider>(context,listen: false).user!.userId?
                                  Provider.of<ChatProvider>(context,listen: false).storeConversationList[0].receiverId:
                                  Provider.of<ChatProvider>(context,listen: false).storeConversationList[0].senderId,
                                  widget.storeId,
                                  messageController.text,
                                  context);
                              messageController.clear();
                              SystemChannels.textInput.invokeMethod('TextInput.hide');
                              await getStoreConversation();
                              setState(() {

                              });
                            }
                          },
                          child: messageController.text.isEmpty?const Icon(Icons.send,color: greyColor,):
                          const Icon(Icons.send,color: whiteColor,)
                      ),
                      border: const OutlineInputBorder(
                        borderSide: BorderSide.none,
                      )
                  ),
                ),
              )
            ],
          )
      ),
    );
  }
}



