
import 'package:beatjerky/screens/chat_screens/store_chat_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../model/api_models/chat_model/chat_list_model.dart';
import '../../model/api_models/user_model/all_users_model.dart';
import '../../model/message_model.dart';
import '../../providers/chat_provider/chat_provider.dart';
import '../../providers/users_provider/all_users_provider.dart';
import '../../repo/api_consts.dart';
import '../../services/api_services/chat_services/chat_services.dart';
import '../../services/api_services/user_services.dart';
import '../../shimmer_effect/message_screen_skeleton.dart';
import '../../utils/color.dart';
import '../../widget/reusable_text.dart';
import '../../widget/reusable_textformfield.dart';
import 'chat_screen.dart';

class StoreMessageScreen extends StatefulWidget {
  const StoreMessageScreen({Key? key}) : super(key: key);

  @override
  State<StoreMessageScreen> createState() => _StoreMessageScreenState();
}

class _StoreMessageScreenState extends State<StoreMessageScreen> {

  TextEditingController searchController=TextEditingController();
  TextEditingController messageController=TextEditingController();




  AllUserModel? user;
  List<AllUserModel> allUsers=[];
  List<ChatListModel> chatList=[];
  bool selectRecipient=false;
   bool isLoading=true;

   getStoresChat()async{
     await ChatServices().getStoresChatList(context);
     setState(() {
       isLoading=false;
     });
   }


  @override
  void initState() {
     getStoresChat();
    // TODO: implement initState
    super.initState();
  }

  bool usersChat=true;

  @override
  Widget build(BuildContext context) {
    return isLoading?const MessageScreenSkeleton():
    Column(
      mainAxisSize: MainAxisSize.min,
      children: [

        SizedBox(
            height: Get.height*.8,
            child: ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: Provider.of<ChatProvider>(context,listen: false).storeChatList.length,
              itemBuilder: (BuildContext context, int index) {

                return  Consumer<ChatProvider>(
                  builder: (context,chat,_){
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: ListTile(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) {
                            return StoreChatScreen(storeId: chat.storeChatList[index].id,storeImage: chat.storeChatList[index].storeImage,);
                          }),);
                        },
                        contentPadding: EdgeInsets.zero,
                        leading: chat.storeChatList[index].storeImage.isNotEmpty?CircleAvatar(
                          radius: 30,
                          backgroundImage: NetworkImage(chat.storeChatList[index].storeImage.replaceAll('public', ApiConstants.baseUrl)),
                        ):const CircleAvatar(
                          radius: 30,
                          backgroundImage: AssetImage('assets/images/logo.png'),
                        ),
                        title: Row(
                          children: [
                            ReusableText(title: chat.storeChatList[index].storeName,size: 18,color: whiteColor,weight: FontWeight.w700,),
                            const SizedBox(width: 10,),
                          ],
                        ),
                      ),
                    );
                  },

                );
              }, separatorBuilder: (BuildContext context, int index) {
                return Divider(color: Color(0x70ffffff),);
            },
            )
        ),
      ],
    );
  }

  void _showMessageBox({required BuildContext context,}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return StatefulBuilder(

          builder: (context, StateSetter setState) {
            return SafeArea(
              child: Padding(
                padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      selectRecipient==false?Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          user!=null?Container(
                            padding: const EdgeInsets.all(5),
                            // height: 30,
                            // width: 120,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(24),
                                color: Colors.white70
                            ),
                            child: ReusableText(title: "${user!.firstName} ${user!.lastName}",color: Colors.black,),
                          ):SizedBox(),
                          InkWell(
                            onTap: ()async{
                              setState(() {
                                selectRecipient=true;
                              });
                            },
                            child: Container(
                              alignment: Alignment.center,
                              padding: EdgeInsets.all(4),
                              height: 30,
                              // width: 120,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(24),
                                  color: Colors.white70
                              ),
                              child: const ReusableText(title: "Select Recipient",color: Colors.black,),
                            ),
                          ),
                        ],
                      ):
                      const SizedBox(),
                      const SizedBox(height: 5,),
                      Visibility(
                        visible: selectRecipient,
                        child: SizedBox(
                          height: Get.height*.4,
                          width: Get.width,
                          child: ListView.builder(
                            itemCount: allUsers.length,
                              itemBuilder: (context,index){
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 10),
                                  child: Column(
                                    children: [
                                      ListTile(
                                          leading: CircleAvatar(
                                            backgroundColor: Colors.white,
                                            backgroundImage: NetworkImage(allUsers[index].profileImg!=null?allUsers[index].profileImg!.replaceAll('public', ApiConstants.baseUrl):'https://firebasestorage.googleapis.com/v0/b/nail-technician-app.appspot.com/o/profile%20(2).png?alt=media&token=2bcdde88-6c54-443b-9f43-0354fa168698'),
                                          ),
                                          title: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              ReusableText(
                                                title: "${allUsers[index].firstName} ${allUsers[index].lastName}",
                                                size: 16,
                                                weight: FontWeight.w700,
                                                color: whiteColor,
                                              ),
                                              ReusableText(
                                                title: allUsers[index].isOnline?'Online':'Offline',
                                                size: 14,
                                                // weight: FontWeight.w700,
                                                color: Colors.grey,
                                              ),
                                            ],
                                          ),
                                          trailing: Container(
                                            height: 30,
                                            width: 60,
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(24),
                                                color: Colors.white70
                                            ),
                                            child: TextButton(
                                              onPressed: ()async{
                                                user=allUsers[index];
                                                Get.showSnackbar(GetSnackBar(message: '${allUsers[index].firstName} ${allUsers[index].lastName} Selected',duration: const Duration(seconds: 2),));
                                                setState(() {
                                                  selectRecipient=false;
                                                });
                                              },
                                              child: const ReusableText(title: "Select",color: Colors.black,),
                                            ),
                                          )
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      // NetworkImage(imageUrl),
                                      // Image.network(imageUrl),
                                      // FadeInImage(
                                      //     placeholder: const AssetImage('assets/images/beet.jpg'),
                                      //     image: NetworkImage(imageUrl)),

                                      const SizedBox(
                                        height: 20,
                                      ),
                                    ],
                                  ),
                                );
                              }),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            );
          }
        );
      },
    );
  }
}
