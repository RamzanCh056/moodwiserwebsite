import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../model/gamification_models.dart';
import '../services/achievement_service.dart';
import '../widget/confetti_widget.dart';
import 'settings_screen.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({Key? key}) : super(key: key);

  @override
  _LeaderboardScreenState createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> 
    with TickerProviderStateMixin {
  
  // Gamification variables
  int _dailyStreak = 0;
  int _totalPoints = 0;
  int _level = 1;
  List<Achievement> _achievements = [];
  List<LeaderboardEntry> _leaderboard = [];
  bool _isLoading = true;
  
  // User profile variables
  String _userName = '';
  String _userEmail = '';
  String? _profileImage;
  bool _isPaid = false;
  String? _currentBadge;
  


  // Animation controllers
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _scaleController;
  late AnimationController _streakController;

  @override
  void initState() {
    super.initState();
    
    // Initialize animation controllers
    _fadeController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    
    _slideController = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );
    
    _scaleController = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );
    
    _streakController = AnimationController(
      duration: Duration(milliseconds: 1500),
      vsync: this,
    );

    _loadGamificationData();
    
    // Start animations
    _startAnimations();
  }

  void _startAnimations() async {
    await Future.delayed(Duration(milliseconds: 300));
    _fadeController.forward();
    
    await Future.delayed(Duration(milliseconds: 200));
    _slideController.forward();
    
    await Future.delayed(Duration(milliseconds: 200));
    _scaleController.forward();
    
    await Future.delayed(Duration(milliseconds: 300));
    _streakController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _scaleController.dispose();
    _streakController.dispose();
    super.dispose();
  }

  /// Load gamification data
  Future<void> _loadGamificationData() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      // Load user's gamification data
      final doc = await FirebaseFirestore.instance
          .collection('userRewards')
          .doc(user.uid)
          .get();

      if (doc.exists) {
        final data = doc.data()!;
        setState(() {
          _dailyStreak = data['dailyStreak'] ?? 0;
          _totalPoints = data['totalPoints'] ?? 0;
          _level = data['level'] ?? 1;
        });
      }
      


      // Load user profile data
      final userDoc = await FirebaseFirestore.instance
          .collection('usersData')
          .doc(user.uid)
          .get();
          
      if (userDoc.exists) {
        final userData = userDoc.data()!;
        setState(() {
          _isPaid = userData['isPaid'] ?? false;
          _profileImage = userData['profileImage'];
          
          // Try multiple possible name fields
          if (userData['firstName'] != null && userData['lastName'] != null) {
            _userName = '${userData['firstName']} ${userData['lastName']}';
          } else if (userData['firstName'] != null && userData['secondName'] != null) {
            _userName = '${userData['firstName']} ${userData['secondName']}';
          } else if (userData['firstName'] != null) {
            _userName = userData['firstName'];
          } else if (userData['lastName'] != null) {
            _userName = userData['lastName'];
          } else if (userData['secondName'] != null) {
            _userName = userData['secondName'];
          } else if (userData['name'] != null) {
            _userName = userData['name'];
          } else if (userData['userFirstName'] != null && userData['userSecondName'] != null) {
            _userName = '${userData['userFirstName']} ${userData['userSecondName']}';
          } else if (userData['userFirstName'] != null) {
            _userName = userData['userFirstName'];
          } else if (userData['userSecondName'] != null) {
            _userName = userData['userSecondName'];
          } else {
            _userName = 'User ${user.uid.substring(0, 6)}';
          }
          
          _userEmail = userData['email'] ?? user.email ?? '';
        });
      }
      
      // Load achievements
      await _loadAchievements();
      
      // Get current achievement badge
      _getCurrentBadge();
      
      // Load leaderboard
      await _loadLeaderboard();
      
      // Check daily login
      await _checkDailyLogin();
      
      // Check and unlock achievements
      await AchievementService.checkAndUnlockAchievements(user.uid);
      
      // Check for newly unlocked achievements and show notifications
      await _checkForNewAchievements();
      
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Error loading gamification data: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  /// Load user achievements
  Future<void> _loadAchievements() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      // Initialize achievements if they don't exist
      await AchievementService.initializeUserAchievements(user.uid);
      
      // Load achievements using the service
      final achievements = await AchievementService.getUserAchievements(user.uid);
      
      setState(() {
        _achievements = achievements;
      });
    } catch (e) {
      debugPrint('Error loading achievements: $e');
    }
  }

  /// Get current achievement badge
  void _getCurrentBadge() {
    if (_achievements.isNotEmpty) {
      // Get the most recent unlocked achievement
      final unlockedAchievements = _achievements.where((a) => a.isUnlocked).toList();
      if (unlockedAchievements.isNotEmpty) {
        // Sort by points to get the highest achievement
        unlockedAchievements.sort((a, b) => b.points.compareTo(a.points));
        setState(() {
          _currentBadge = unlockedAchievements.first.title;
        });
      }
    }
  }

  /// Load leaderboard
  Future<void> _loadLeaderboard() async {
    try {
      // First, update the current user's leaderboard entry with correct name
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await AchievementService.updateLeaderboard(user.uid);
      }
      
      // Load leaderboard using the service
      final leaderboard = await AchievementService.getLeaderboard();
      
      setState(() {
        _leaderboard = leaderboard;
      });
    } catch (e) {
      debugPrint('Error loading leaderboard: $e');
    }
  }

  /// Check daily login and update streak
  Future<void> _checkDailyLogin() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      
      final doc = await FirebaseFirestore.instance
          .collection('userRewards')
          .doc(user.uid)
          .get();

      if (doc.exists) {
        final data = doc.data()!;
        final lastLogin = data['lastLogin'];
        
        if (lastLogin != null) {
          final lastLoginDate = (lastLogin as Timestamp).toDate();
          final lastLoginDay = DateTime(lastLoginDate.year, lastLoginDate.month, lastLoginDate.day);
          
          if (today.difference(lastLoginDay).inDays == 1) {
            // Consecutive day
            final newStreak = (data['dailyStreak'] ?? 0) + 1;
            final newPoints = (data['totalPoints'] ?? 0) + 10;
            
            await FirebaseFirestore.instance
                .collection('userRewards')
                .doc(user.uid)
                .update({
              'dailyStreak': newStreak,
              'totalPoints': newPoints,
              'lastLogin': Timestamp.now(),
            });
            
            setState(() {
              _dailyStreak = newStreak;
              _totalPoints = newPoints;
            });
            
            _showStreakReward(newStreak);
          } else if (today.difference(lastLoginDay).inDays > 1) {
            // Streak broken
            await FirebaseFirestore.instance
                .collection('userRewards')
                .doc(user.uid)
                .update({
              'dailyStreak': 1,
              'totalPoints': (data['totalPoints'] ?? 0) + 10,
              'lastLogin': Timestamp.now(),
            });
            
            setState(() {
              _dailyStreak = 1;
              _totalPoints = (data['totalPoints'] ?? 0) + 10;
            });
          }
        } else {
          // First time login
          await FirebaseFirestore.instance
              .collection('userRewards')
              .doc(user.uid)
              .set({
            'dailyStreak': 1,
            'totalPoints': 10,
            'lastLogin': Timestamp.now(),
            'level': 1,
          });
          
          setState(() {
            _dailyStreak = 1;
            _totalPoints = 10;
          });
        }
      } else {
        // Create new user rewards document
        await FirebaseFirestore.instance
            .collection('userRewards')
            .doc(user.uid)
            .set({
          'dailyStreak': 1,
          'totalPoints': 10,
          'lastLogin': Timestamp.now(),
          'level': 1,
        });
        
        setState(() {
          _dailyStreak = 1;
          _totalPoints = 10;
        });
      }
    } catch (e) {
      debugPrint('Error checking daily login: $e');
    }
  }

  /// Check for newly unlocked achievements and show notifications
  Future<void> _checkForNewAchievements() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      // Get current achievements
      final currentAchievements = await AchievementService.getUserAchievements(user.uid);
      
      // Find newly unlocked achievements
      for (final achievement in currentAchievements) {
        if (achievement.isUnlocked && 
            achievement.unlockedAt != null &&
            achievement.unlockedAt!.toDate().isAfter(DateTime.now().subtract(Duration(minutes: 5)))) {
          // Show notification for recently unlocked achievement
          _showAchievementUnlocked(achievement);
        }
      }
      
      // Update local achievements
      setState(() {
        _achievements = currentAchievements;
      });
    } catch (e) {
      debugPrint('Error checking for new achievements: $e');
    }
  }

  /// Show streak reward
  void _showStreakReward(int streak) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.local_fire_department, color: Colors.orange, size: 30),
            SizedBox(width: 10),
            Text(
              'Daily Streak!',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Text(
          'Amazing! You\'ve logged in for $streak consecutive days!\n\n+10 points earned! 🔥',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Awesome!',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  /// Show achievement unlocked notification
  void _showAchievementUnlocked(Achievement achievement) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Stack(
        children: [
          // Confetti background
          ConfettiWidget(isActive: true),
          
          // Achievement dialog
          Center(
            child: Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                padding: EdgeInsets.all(30),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.amber.shade600, Colors.orange.shade600],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.amber.withOpacity(0.5),
                      blurRadius: 30,
                      offset: const Offset(0, 15),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Celebration animation
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 800),
                      builder: (context, value, child) {
                        return Transform.scale(
                          scale: value,
                          child: Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              achievement.icon,
                              color: Colors.amber.shade800,
                              size: 80,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 25),
                    
                    // Achievement title with animation
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 600),
                      builder: (context, value, child) {
                        return Transform.translate(
                          offset: Offset(0, 20 * (1 - value)),
                          child: Opacity(
                            opacity: value,
                            child: Text(
                              'Achievement Unlocked!',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 15),
                    
                    // Achievement name
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 800),
                      builder: (context, value, child) {
                        return Transform.translate(
                          offset: Offset(0, 20 * (1 - value)),
                          child: Opacity(
                            opacity: value,
                            child: Text(
                              achievement.title,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 10),
                    
                    // Achievement description
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 1000),
                      builder: (context, value, child) {
                        return Transform.translate(
                          offset: Offset(0, 20 * (1 - value)),
                          child: Opacity(
                            opacity: value,
                            child: Text(
                              achievement.description,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 25),
                    
                    // Points earned with animation
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 1200),
                      builder: (context, value, child) {
                        return Transform.scale(
                          scale: value,
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(25),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 10,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.star, color: Colors.amber.shade800, size: 24),
                                SizedBox(width: 10),
                                Text(
                                  '+${achievement.points} Points!',
                                  style: TextStyle(
                                    color: Colors.amber.shade800,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
    
         // Auto-close after 3 seconds
     Future.delayed(Duration(seconds: 3), () {
       if (Navigator.canPop(context)) {
         Navigator.pop(context);
       }
     });
   }

   /// Show all badges dialog with beautiful achievement previews
   void _showAllBadges() {
     showModalBottomSheet(
       context: context,
       backgroundColor: Colors.transparent,
       isScrollControlled: true,
       builder: (context) => Container(
         height: MediaQuery.of(context).size.height * 0.85,
         decoration: BoxDecoration(
           gradient: LinearGradient(
             colors: [Colors.grey.shade900, Colors.black],
             begin: Alignment.topCenter,
             end: Alignment.bottomCenter,
           ),
           borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
           boxShadow: [
             BoxShadow(
               color: Colors.black.withOpacity(0.5),
               blurRadius: 30,
               offset: const Offset(0, -10),
             ),
           ],
         ),
         child: Column(
           children: [
             // Beautiful handle bar with close button
             Container(
               margin: EdgeInsets.only(top: 12),
               child: Row(
                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
                 children: [
                   // Handle bar
                   Container(
                     width: 50,
                     height: 5,
                     decoration: BoxDecoration(
                       color: Colors.grey.shade600,
                       borderRadius: BorderRadius.circular(3),
                     ),
                   ),
                   // Close button
                   IconButton(
                     onPressed: () => Navigator.pop(context),
                     icon: Icon(Icons.close, color: Colors.white, size: 24),
                     style: IconButton.styleFrom(
                       backgroundColor: Colors.grey.shade800,
                       shape: CircleBorder(),
                     ),
                   ),
                 ],
               ),
             ),
             
             // Title with animation
             Padding(
               padding: EdgeInsets.all(20),
               child: Row(
                 mainAxisAlignment: MainAxisAlignment.center,
                 children: [
                   Icon(Icons.emoji_events, color: Colors.amber, size: 28),
                   SizedBox(width: 12),
                   Text(
                     'All Badges & Achievements',
                     style: TextStyle(
                       color: Colors.white,
                       fontSize: 22,
                       fontWeight: FontWeight.bold,
                     ),
                   ),
                 ],
               ),
             ),
             
             // Badges grid with beautiful previews
             Expanded(
               child: GridView.builder(
                 padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                 gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                   crossAxisCount: 2,
                   crossAxisSpacing: 20,
                   mainAxisSpacing: 20,
                   childAspectRatio: 0.85,
                 ),
                 itemCount: _achievements.length,
                 itemBuilder: (context, index) {
                   final achievement = _achievements[index];
                   return Container(
                     decoration: BoxDecoration(
                       gradient: achievement.isUnlocked
                           ? LinearGradient(
                               colors: [Colors.amber.shade600, Colors.orange.shade600],
                               begin: Alignment.topLeft,
                               end: Alignment.bottomRight,
                             )
                           : LinearGradient(
                               colors: [Colors.grey.shade700, Colors.grey.shade800],
                               begin: Alignment.topLeft,
                               end: Alignment.bottomRight,
                             ),
                       borderRadius: BorderRadius.circular(25),
                       border: Border.all(
                         color: achievement.isUnlocked ? Colors.amber.shade400 : Colors.grey.shade600,
                         width: 3,
                       ),
                       boxShadow: [
                         BoxShadow(
                           color: achievement.isUnlocked 
                               ? Colors.amber.withOpacity(0.4)
                               : Colors.black.withOpacity(0.3),
                           blurRadius: 15,
                           offset: const Offset(0, 8),
                         ),
                       ],
                     ),
                     child: Column(
                       mainAxisAlignment: MainAxisAlignment.center,
                       children: [
                         // Achievement icon with glow effect
                         Container(
                           padding: EdgeInsets.all(12),
                           decoration: BoxDecoration(
                             color: achievement.isUnlocked 
                                 ? Colors.white.withOpacity(0.2)
                                 : Colors.grey.withOpacity(0.1),
                             shape: BoxShape.circle,
                           ),
                           child: Icon(
                             achievement.icon,
                             color: achievement.isUnlocked ? Colors.white : Colors.grey.shade500,
                             size: 35,
                           ),
                         ),
                         SizedBox(height: 12),
                         
                         // Achievement title
                         Text(
                           achievement.title,
                           style: TextStyle(
                             color: achievement.isUnlocked ? Colors.white : Colors.grey.shade400,
                             fontSize: 14,
                             fontWeight: FontWeight.bold,
                           ),
                           textAlign: TextAlign.center,
                           maxLines: 2,
                           overflow: TextOverflow.ellipsis,
                         ),
                         SizedBox(height: 6),
                         
                         // Points with beautiful styling
                         Container(
                           padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                           decoration: BoxDecoration(
                             color: achievement.isUnlocked 
                                 ? Colors.white.withOpacity(0.2)
                                 : Colors.grey.withOpacity(0.1),
                             borderRadius: BorderRadius.circular(12),
                           ),
                           child: Text(
                             '+${achievement.points} pts',
                             style: TextStyle(
                               color: achievement.isUnlocked ? Colors.white : Colors.grey.shade400,
                               fontSize: 12,
                               fontWeight: FontWeight.bold,
                             ),
                           ),
                         ),
                         
                         // Achievement status
                         if (achievement.isUnlocked) ...[
                           SizedBox(height: 6),
                           Container(
                             padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                             decoration: BoxDecoration(
                               color: Colors.green.shade600,
                               borderRadius: BorderRadius.circular(10),
                             ),
                             child: Text(
                               'Unlocked!',
                               style: TextStyle(
                                 color: Colors.white,
                                 fontSize: 10,
                                 fontWeight: FontWeight.bold,
                               ),
                             ),
                           ),
                         ] else ...[
                           SizedBox(height: 6),
                           Container(
                             padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                             decoration: BoxDecoration(
                               color: Colors.grey.shade600,
                               borderRadius: BorderRadius.circular(10),
                             ),
                             child: Text(
                               'Locked',
                               style: TextStyle(
                                 color: Colors.grey.shade300,
                                 fontSize: 10,
                                 fontWeight: FontWeight.bold,
                               ),
                             ),
                           ),
                         ],
                       ],
                     ),
                   );
                 },
               ),
             ),
             
             SizedBox(height: 20),
           ],
         ),
       ),
     );
   }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
        //    Icon(Icons.emoji_events, color: Colors.amber, size: 28),
            SizedBox(width: 10),
            Text(
              "Leaderboard",
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          // All Badges button in app bar
          IconButton(
            icon: Icon(Icons.emoji_events, color: Colors.amber),
            onPressed: _showAllBadges,
            tooltip: 'All Badges',
          ),
          IconButton(
            icon: Icon(Icons.settings, color: Colors.white),
            onPressed: () {
              // Navigate to settings screen
              Navigator.push(context, MaterialPageRoute(builder: (context) => const SettingsScreen()));
            },
          ),
        ],
      ),
      body: _isLoading
          ? Center(
              child: CircularProgressIndicator(color: Colors.white),
            )
          : FadeTransition(
              opacity: _fadeController,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 16),
                                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Beautiful Profile Section at Top Left
                    FadeTransition(
                      opacity: _fadeController,
                      child: Container(
                        margin: EdgeInsets.only(top: 20, left: 16, right: 16),
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.grey.shade800, Colors.grey.shade900],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.grey.shade700, width: 1),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 10,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            // Profile Picture with Badges
                            Stack(
                              children: [
                                CircleAvatar(
                                  radius: 30,
                                  backgroundColor: Colors.grey.shade700,
                                  backgroundImage: _profileImage != null && _profileImage!.isNotEmpty
                                      ? NetworkImage(_profileImage!)
                                      : null,
                                  child: _profileImage == null || _profileImage!.isEmpty
                                      ? Icon(Icons.person, color: Colors.white, size: 30)
                                      : null,
                                ),
                                // Blue Tick Badge
                                if (_isPaid)
                                  Positioned(
                                    bottom: 2,
                                    right: 2,
                                    child: Container(
                                      padding: EdgeInsets.all(3),
                                      decoration: BoxDecoration(
                                        color: Colors.blue,
                                        shape: BoxShape.circle,
                                        border: Border.all(color: Colors.white, width: 2),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.blue.withOpacity(0.5),
                                            blurRadius: 4,
                                            offset: const Offset(0, 2),
                                          ),
                                        ],
                                      ),
                                      child: Icon(Icons.verified, color: Colors.white, size: 10),
                                    ),
                                  ),
                                                                 // Achievement Badge - positioned to not hide picture
                                 if (_currentBadge != null)
                                   Positioned(
                                     top: -2,
                                     right: -2,
                                     child: Container(
                                       padding: EdgeInsets.all(4),
                                       decoration: BoxDecoration(
                                         gradient: LinearGradient(
                                           colors: [Colors.amber.shade600, Colors.orange.shade600],
                                           begin: Alignment.topLeft,
                                           end: Alignment.bottomRight,
                                         ),
                                         shape: BoxShape.circle,
                                         border: Border.all(color: Colors.white, width: 2),
                                         boxShadow: [
                                           BoxShadow(
                                             color: Colors.amber.withOpacity(0.5),
                                             blurRadius: 6,
                                             offset: const Offset(0, 2),
                                           ),
                                         ],
                                       ),
                                       child: Icon(Icons.emoji_events, color: Colors.white, size: 12),
                                     ),
                                   ),
                              ],
                            ),
                            SizedBox(width: 16),
                            // User Info
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _userName.isNotEmpty ? _userName : 'User',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  if (_userEmail.isNotEmpty)
                                    Text(
                                      '@${_userEmail.split('@').first}',
                                      style: TextStyle(
                                        color: Colors.grey.shade400,
                                        fontSize: 14,
                                      ),
                                    ),
                                  if (_currentBadge != null) ...[
                                    SizedBox(height: 6),
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [Colors.amber.shade600, Colors.orange.shade600],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.emoji_events, color: Colors.white, size: 12),
                                          SizedBox(width: 4),
                                          Text(
                                            _currentBadge!,
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 11,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                  // Add Verified User text for paid users
                                  if (_isPaid) ...[
                                    SizedBox(height: 6),
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [Colors.blue.shade600, Colors.blue.shade800],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.verified, color: Colors.white, size: 10),
                                          SizedBox(width: 4),
                                          Text(
                                            'Verified User',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 10,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    SizedBox(height: 20),
                    
                    // Daily Streak Card with Animation
                    SlideTransition(
                      position: Tween<Offset>(
                        begin: Offset(0, -0.5),
                        end: Offset.zero,
                      ).animate(CurvedAnimation(
                        parent: _slideController,
                        curve: Curves.easeOutBack,
                      )),
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(20),
                        margin: EdgeInsets.only(top: 20),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.orange.shade600, Colors.red.shade600],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.orange.withOpacity(0.3),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.local_fire_department,
                                  color: Colors.white,
                                  size: 30,
                                ),
                                SizedBox(width: 10),
                                Text(
                                  'Daily Streak',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 15),
                            TweenAnimationBuilder<double>(
                              tween: Tween(begin: 0.0, end: _dailyStreak.toDouble()),
                              duration: Duration(milliseconds: 1500),
                              builder: (context, value, child) {
                                return Text(
                                  '${value.toInt()}',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 48,
                                    fontWeight: FontWeight.bold,
                                  ),
                                );
                              },
                            ),
                            Text(
                              'days in a row! 🔥',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    SizedBox(height: 20),
                    
                    // Points and Level Card with Animation
                    ScaleTransition(
                      scale: Tween<double>(
                        begin: 0.8,
                        end: 1.0,
                      ).animate(CurvedAnimation(
                        parent: _scaleController,
                        curve: Curves.elasticOut,
                      )),
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.purple.shade600, Colors.blue.shade600],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.purple.withOpacity(0.3),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Total Points',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 16,
                                      ),
                                    ),
                                    TweenAnimationBuilder<double>(
                                      tween: Tween(begin: 0.0, end: _totalPoints.toDouble()),
                                      duration: Duration(milliseconds: 1500),
                                      builder: (context, value, child) {
                                        return Text(
                                          '${value.toInt()}',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 32,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        );
                                      },
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      'Level',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 16,
                                      ),
                                    ),
                                    TweenAnimationBuilder<double>(
                                      tween: Tween(begin: 0.0, end: _level.toDouble()),
                                      duration: Duration(milliseconds: 1000),
                                      builder: (context, value, child) {
                                        return Text(
                                          '${value.toInt()}',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 32,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        );
                                      },
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(height: 15),
                            TweenAnimationBuilder<double>(
                              tween: Tween(begin: 0.0, end: (_totalPoints % 100) / 100),
                              duration: Duration(milliseconds: 2000),
                              builder: (context, value, child) {
                                return LinearProgressIndicator(
                                  value: value,
                                  backgroundColor: Colors.white.withOpacity(0.3),
                                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                );
                              },
                            ),
                            SizedBox(height: 8),
                            Text(
                              '${_totalPoints % 100}/100 to next level',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    SizedBox(height: 20),
                    
                    // Achievements Section with Animation
                    FadeTransition(
                      opacity: _fadeController,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Achievements',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 15),
                          
                          GridView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              crossAxisSpacing: 15,
                              mainAxisSpacing: 15,
                              childAspectRatio: 1.2,
                            ),
                            itemCount: _achievements.length,
                            itemBuilder: (context, index) {
                              final achievement = _achievements[index];
                              return AnimatedBuilder(
                                animation: _scaleController,
                                builder: (context, child) {
                                  final delay = index * 0.1;
                                  final animation = Tween<double>(
                                    begin: 0.0,
                                    end: 1.0,
                                  ).animate(CurvedAnimation(
                                    parent: _scaleController,
                                    curve: Interval(delay, delay + 0.3, curve: Curves.elasticOut),
                                  ));
                                  
                                  return Transform.scale(
                                    scale: animation.value,
                                    child: Container(
                                      padding: EdgeInsets.all(15),
                                      decoration: BoxDecoration(
                                        color: achievement.isUnlocked ? Colors.green.shade800 : Colors.grey.shade800,
                                        borderRadius: BorderRadius.circular(15),
                                        border: Border.all(
                                          color: achievement.isUnlocked ? Colors.green.shade400 : Colors.grey.shade600,
                                          width: 2,
                                        ),
                                      ),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            achievement.icon,
                                            color: achievement.isUnlocked ? Colors.white : Colors.grey.shade400,
                                            size: 40,
                                          ),
                                          SizedBox(height: 10),
                                          Text(
                                            achievement.title,
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            textAlign: TextAlign.center,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          SizedBox(height: 5),
                                          Text(
                                            '${achievement.points} pts',
                                            style: TextStyle(
                                              color: achievement.isUnlocked ? Colors.green.shade300 : Colors.grey.shade400,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                    
                    SizedBox(height: 20),
                    
                    // Leaderboard Section with Animation
                    FadeTransition(
                      opacity: _fadeController,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Top Performers',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 15),
                          
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.grey.shade900,
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount: _leaderboard.length,
                              itemBuilder: (context, index) {
                                final entry = _leaderboard[index];
                                return AnimatedBuilder(
                                  animation: _slideController,
                                  builder: (context, child) {
                                    final delay = index * 0.1;
                                    final animation = Tween<Offset>(
                                      begin: Offset(1.0, 0.0),
                                      end: Offset.zero,
                                    ).animate(CurvedAnimation(
                                      parent: _slideController,
                                      curve: Interval(delay, delay + 0.3, curve: Curves.easeOutBack),
                                    ));
                                    
                                    return SlideTransition(
                                      position: animation,
                                      child: Container(
                                        margin: EdgeInsets.only(bottom: 10),
                                        padding: EdgeInsets.all(15),
                                        decoration: BoxDecoration(
                                          color: index < 3 ? Colors.amber.shade900 : Colors.grey.shade800,
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 40,
                                              height: 40,
                                              decoration: BoxDecoration(
                                                color: index < 3 ? Colors.amber.shade600 : Colors.grey.shade600,
                                                shape: BoxShape.circle,
                                              ),
                                              child: Center(
                                                child: Text(
                                                  '${entry.rank}',
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(width: 15),
                                            CircleAvatar(
                                              radius: 20,
                                              backgroundImage: entry.profileImage != null
                                                  ? NetworkImage(entry.profileImage!)
                                                  : null,
                                              backgroundColor: Colors.grey.shade700,
                                              child: entry.profileImage == null
                                                  ? Icon(Icons.person, color: Colors.white)
                                                  : null,
                                            ),
                                            SizedBox(width: 15),
                                                                                         Expanded(
                                               child: Column(
                                                 crossAxisAlignment: CrossAxisAlignment.start,
                                                 children: [
                                                   Text(
                                                     entry.userId == FirebaseAuth.instance.currentUser?.uid 
                                                         ? (_userName.isNotEmpty ? _userName : entry.name)
                                                         : entry.name,
                                                     style: TextStyle(
                                                       color: Colors.white,
                                                       fontSize: 16,
                                                       fontWeight: FontWeight.bold,
                                                     ),
                                                     maxLines: 1,
                                                     overflow: TextOverflow.ellipsis,
                                                   ),
                                                   Wrap(
                                                     spacing: 8,
                                                     runSpacing: 4,
                                                     children: [
                                                       Text(
                                                         '${entry.points} points',
                                                         style: TextStyle(
                                                           color: Colors.grey.shade300,
                                                           fontSize: 14,
                                                         ),
                                                       ),
                                                       // Show streak for all users
                                                       Container(
                                                         padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                         decoration: BoxDecoration(
                                                           gradient: LinearGradient(
                                                             colors: [Colors.orange.shade600, Colors.red.shade600],
                                                             begin: Alignment.topLeft,
                                                             end: Alignment.bottomRight,
                                                           ),
                                                           borderRadius: BorderRadius.circular(8),
                                                         ),
                                                         child: Row(
                                                           mainAxisSize: MainAxisSize.min,
                                                           children: [
                                                             Icon(Icons.local_fire_department, color: Colors.white, size: 10),
                                                             SizedBox(width: 2),
                                                             Text(
                                                               '${entry.dailyStreak}',
                                                               style: TextStyle(
                                                                 color: Colors.white,
                                                                 fontSize: 10,
                                                                 fontWeight: FontWeight.bold,
                                                               ),
                                                             ),
                                                           ],
                                                         ),
                                                       ),

                                                       // Show current badge if available
                                                       if (entry.currentBadgeTitle != null && entry.currentBadgeTitle!.isNotEmpty)
                                                         Container(
                                                           padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                                           decoration: BoxDecoration(
                                                             gradient: LinearGradient(
                                                               colors: [Colors.amber.shade600, Colors.orange.shade600],
                                                               begin: Alignment.topLeft,
                                                               end: Alignment.bottomRight,
                                                             ),
                                                             borderRadius: BorderRadius.circular(10),
                                                             boxShadow: [
                                                               BoxShadow(
                                                                 color: Colors.amber.withOpacity(0.3),
                                                                 blurRadius: 4,
                                                                 offset: const Offset(0, 2),
                                                               ),
                                                             ],
                                                           ),
                                                           child: Row(
                                                             mainAxisSize: MainAxisSize.min,
                                                             children: [
                                                               Icon(Icons.emoji_events, color: Colors.white, size: 10),
                                                               SizedBox(width: 3),
                                                               Text(
                                                                 entry.currentBadgeTitle!,
                                                                 style: TextStyle(
                                                                   color: Colors.white,
                                                                   fontSize: 10,
                                                                   fontWeight: FontWeight.bold,
                                                                 ),
                                                               ),
                                                             ],
                                                           ),
                                                         ),
                                                     ],
                                                   ),
                                                 ],
                                               ),
                                             ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                                         SizedBox(height: 20),
                   ],
                 ),
               ),
             ),
      );
    }
  }
