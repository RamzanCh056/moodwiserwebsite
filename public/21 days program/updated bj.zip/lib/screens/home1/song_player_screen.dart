// import 'package:flutter/material.dart';
// import 'package:just_audio/just_audio.dart';
// import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
//
// class SongPlayerScreen extends StatefulWidget {
//   final String title;
//   final String description;
//   final String fileUrl;
//   final String? coverImage;
//
//   const SongPlayerScreen({
//     super.key,
//     required this.title,
//     required this.description,
//     required this.fileUrl,
//     this.coverImage,
//   });
//
//   @override
//   State<SongPlayerScreen> createState() => _SongPlayerScreenState();
// }
//
// class _SongPlayerScreenState extends State<SongPlayerScreen> {
//   final AudioPlayer _audioPlayer = AudioPlayer();
//   Duration _duration = Duration.zero;
//   Duration _position = Duration.zero;
//   Duration _buffered = Duration.zero;
//
//   bool isPlaying = false;
//
//   @override
//   void initState() {
//     super.initState();
//     _initializePlayer();
//   }
//
//   Future<void> _initializePlayer() async {
//     try {
//       await _audioPlayer.setUrl(widget.fileUrl);
//
//       _audioPlayer.durationStream.listen((d) {
//         if (d != null) setState(() => _duration = d);
//       });
//
//       _audioPlayer.positionStream.listen((p) {
//         setState(() => _position = p);
//       });
//
//       _audioPlayer.bufferedPositionStream.listen((b) {
//         setState(() => _buffered = b);
//       });
//
//       _audioPlayer.playerStateStream.listen((state) {
//         setState(() {
//           isPlaying = state.playing;
//         });
//       });
//     } catch (e) {
//       debugPrint("Error loading audio: $e");
//     }
//   }
//
//   @override
//   void dispose() {
//     _audioPlayer.dispose();
//     super.dispose();
//   }
//
//   void _playPause() {
//     if (isPlaying) {
//       _audioPlayer.pause();
//     } else {
//       _audioPlayer.play();
//     }
//   }
//
//   void _seek(Duration position) {
//     _audioPlayer.seek(position);
//   }
//
//   void _rewind10() {
//     final newPosition = _position - const Duration(seconds: 10);
//     _audioPlayer.seek(newPosition > Duration.zero ? newPosition : Duration.zero);
//   }
//
//   void _forward10() {
//     final newPosition = _position + const Duration(seconds: 10);
//     _audioPlayer.seek(newPosition < _duration ? newPosition : _duration);
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         title: const Text("Podcast Details", style: TextStyle(color: Colors.black)),
//         centerTitle: true,
//         iconTheme: const IconThemeData(color: Colors.black),
//         elevation: 0,
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(20),
//         child: Column(
//           children: [
//             Align(
//               alignment: Alignment.topLeft,
//               child: Container(
//                 padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                 decoration: BoxDecoration(
//                   color: Colors.purple,
//                   borderRadius: BorderRadius.circular(6),
//                 ),
//                 child: const Text("NEW", style: TextStyle(color: Colors.white, fontSize: 12)),
//               ),
//             ),
//             const SizedBox(height: 20),
//             Container(
//               height: 200,
//               width: 200,
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(20),
//                 color: Colors.grey.shade200,
//               ),
//               child: widget.coverImage != null && widget.coverImage!.isNotEmpty
//                   ? ClipRRect(
//                 borderRadius: BorderRadius.circular(20),
//                 child: Image.network(widget.coverImage!, fit: BoxFit.cover),
//               )
//                   : const Center(
//                 child: Icon(Icons.music_note, size: 100, color: Colors.black54),
//               ),
//             ),
//             const SizedBox(height: 20),
//             Text(widget.title,
//                 style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//             const SizedBox(height: 6),
//             Text(widget.description, style: const TextStyle(color: Colors.grey)),
//             const SizedBox(height: 30),
//
//             /// Progress Bar
//             ProgressBar(
//               progress: _position,
//               buffered: _buffered,
//               total: _duration,
//               onSeek: _seek,
//               timeLabelTextStyle: const TextStyle(color: Colors.black),
//               progressBarColor: Colors.purple,
//               bufferedBarColor: Colors.purple.shade100,
//               baseBarColor: Colors.grey.shade300,
//               thumbColor: Colors.blue,
//             ),
//             const SizedBox(height: 30),
//
//             /// Controls
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: [
//                 const Icon(Icons.skip_previous, size: 30),
//                 IconButton(
//                   onPressed: _rewind10,
//                   icon: const Icon(Icons.replay_10, size: 30),
//                 ),
//                 Container(
//                   height: 60,
//                   width: 60,
//                   decoration: const BoxDecoration(
//                     shape: BoxShape.circle,
//                     color: Colors.purple,
//                   ),
//                   child: IconButton(
//                     icon: Icon(
//                       isPlaying ? Icons.pause : Icons.play_arrow,
//                       size: 34,
//                       color: Colors.white,
//                     ),
//                     onPressed: _playPause,
//                   ),
//                 ),
//                 IconButton(
//                   onPressed: _forward10,
//                   icon: const Icon(Icons.forward_10, size: 30),
//                 ),
//                 const Icon(Icons.skip_next, size: 30),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';

class SongPlayerScreen extends StatefulWidget {
  final String title;
  final String description;
  final String fileUrl;
  final String? coverImage;

  const SongPlayerScreen({
    super.key,
    required this.title,
    required this.description,
    required this.fileUrl,
    this.coverImage,
  });

  @override
  State<SongPlayerScreen> createState() => _SongPlayerScreenState();
}

class _SongPlayerScreenState extends State<SongPlayerScreen> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;
  Duration _buffered = Duration.zero;
  bool isPlaying = false;

  @override
  void initState() {
    super.initState();
    _initializePlayer();
  }

  Future<void> _initializePlayer() async {
    try {
      await _audioPlayer.setUrl(widget.fileUrl);
      _audioPlayer.durationStream.listen((d) {
        if (d != null) setState(() => _duration = d);
      });
      _audioPlayer.positionStream.listen((p) {
        setState(() => _position = p);
      });
      _audioPlayer.bufferedPositionStream.listen((b) {
        setState(() => _buffered = b);
      });
      _audioPlayer.playerStateStream.listen((state) {
        setState(() {
          isPlaying = state.playing;
        });
      });
    } catch (e) {
      debugPrint('Error loading audio: $e');
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  void _playPause() {
    if (isPlaying)
      _audioPlayer.pause();
    else
      _audioPlayer.play();
  }

  void _seek(Duration position) => _audioPlayer.seek(position);

  void _rewind10() {
    final newPosition = _position - const Duration(seconds: 10);
    _audioPlayer.seek(newPosition > Duration.zero ? newPosition : Duration.zero);
  }

  void _forward10() {
    final newPosition = _position + const Duration(seconds: 10);
    _audioPlayer.seek(newPosition < _duration ? newPosition : _duration);
  }

  @override
  Widget build(BuildContext context) {
    const bgColor = Color(0xFF121212);
    const cardColor = Color(0xFF1F1F1F);
    const accent = Color(0xFFBB86FC);
    const textWhite = Colors.white;
    const textGrey = Colors.white70;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: cardColor,
        elevation: 0,
        title:  Text(
          '${widget.title}',
          style: TextStyle(color: textWhite),
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(color: textWhite),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Align(
              alignment: Alignment.topLeft,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: accent,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'NEW',
                  style: TextStyle(color: textWhite, fontSize: 12),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              height: 200,
              width: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: cardColor,
              ),
              child: widget.coverImage != null && widget.coverImage!.isNotEmpty
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.network(
                        widget.coverImage!,
                        fit: BoxFit.cover,
                      ),
                    )
                  : const Center(
                      child: Icon(
                        Icons.music_note,
                        size: 100,
                        color: Colors.white24,
                      ),
                    ),
            ),
            const SizedBox(height: 20),
            Text(
              widget.title,
              style: const TextStyle(
                color: textWhite,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              widget.description,
              style: const TextStyle(color: textGrey),
            ),
            const SizedBox(height: 30),

            // Progress Bar
            ProgressBar(
              progress: _position,
              buffered: _buffered,
              total: _duration,
              onSeek: _seek,
              timeLabelTextStyle: const TextStyle(color: textWhite),
              progressBarColor: accent,
              bufferedBarColor: accent.withOpacity(0.5),
              baseBarColor: Colors.white24,
              thumbColor: accent,
            ),
            const SizedBox(height: 30),

            // Controls
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.skip_previous, color: textWhite, size: 30),
                ),
                IconButton(
                  onPressed: _rewind10,
                  icon: const Icon(Icons.replay_10, color: textWhite, size: 30),
                ),
                Container(
                  height: 60,
                  width: 60,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: accent,
                  ),
                  child: IconButton(
                    icon: Icon(
                      isPlaying ? Icons.pause : Icons.play_arrow,
                      size: 34,
                      color: textWhite,
                    ),
                    onPressed: _playPause,
                  ),
                ),
                IconButton(
                  onPressed: _forward10,
                  icon: const Icon(Icons.forward_10, color: textWhite, size: 30),
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.skip_next, color: textWhite, size: 30),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
