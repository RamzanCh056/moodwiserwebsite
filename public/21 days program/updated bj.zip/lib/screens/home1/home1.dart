import 'dart:io';
import 'dart:async';
import 'package:beatjerky/notification_services/trigger_notification_services.dart';
import 'package:beatjerky/screens/home1/song_player_screen.dart';
import 'package:beatjerky/screens/notification/notification.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path/path.dart' as path;
import 'package:file_picker/file_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_stripe/flutter_stripe.dart' as StripePkg;
import '../../stripe_payment/stripe_payment.dart';
import '../artist_screens/artist_screen.dart';
import '../event_screens/event_screen.dart';
import '../music_store/music_store_list_screen.dart';
import '../peoples_screen/people.dart';
import '../messages_screen.dart';

class Home1 extends StatefulWidget {
  const Home1({super.key});

  @override
  State<Home1> createState() => _Home1State();
}

class _Home1State extends State<Home1> {
  List<Map<String, dynamic>> songs = [];
  List<Map<String, dynamic>> filteredSongs = [];
  final TextEditingController searchController = TextEditingController();

  // Stories data - Dynamic (empty by default)
  List<StoryModel> _stories = [];

  // Cache for resolved display names to reduce reads
  final Map<String, String> _displayNameCache = {};

  // Blue tick popup state
  bool _hasShownBlueTickPopup = false;
  bool _isPaidUser = false;

  // Resolve a user's display name from Firestore, trying multiple collections/fields
  Future<String> _resolveDisplayName(String userId) async {
    if (userId.isEmpty) return 'Unknown User';
    if (_displayNameCache.containsKey(userId))
      return _displayNameCache[userId]!;

    // Collections to try in order
    final List<String> collections = [
      'usersData',
      'users',
      'stores',
      'userdata',
    ];

    for (final collection in collections) {
      try {
        final doc = await FirebaseFirestore.instance
            .collection(collection)
            .doc(userId)
            .get();
        if (doc.exists) {
          final data = doc.data() as Map<String, dynamic>;
          String name = '';
          if ((data['name'] ?? '').toString().trim().isNotEmpty) {
            name = data['name'].toString().trim();
          } else if ((data['userFirstName'] ?? '')
              .toString()
              .trim()
              .isNotEmpty ||
              (data['userSecondName'] ?? '').toString().trim().isNotEmpty) {
            name =
                '${(data['userFirstName'] ?? '').toString().trim()} ${(data['userSecondName'] ?? '').toString().trim()}'
                    .trim();
          } else if ((data['firstName'] ?? '').toString().trim().isNotEmpty ||
              (data['lastName'] ?? '').toString().trim().isNotEmpty) {
            name =
                '${(data['firstName'] ?? '').toString().trim()} ${(data['lastName'] ?? '').toString().trim()}'
                    .trim();
          }

          if (name.isNotEmpty) {
            _displayNameCache[userId] = name;
            return name;
          }
        }
      } catch (_) {
        // continue trying next collection
      }
    }

    _displayNameCache[userId] = 'Unknown User';
    return 'Unknown User';
  }

  // Fetch stories from Firebase
  Future<void> fetchStories() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('stories')
          .where('expiryTime',
          isGreaterThan: Timestamp.fromDate(DateTime.now()))
          .orderBy('expiryTime', descending: true)
          .get();

      setState(() {
        _stories = snapshot.docs
            .map((doc) => StoryModel.fromFirestore(doc.data(), doc.id))
            .toList();
      });
    } catch (e) {
      print('Error fetching stories: $e');
    }
  }

  // Cleanup expired stories
  Future<void> _cleanupExpiredStories() async {
    try {
      final now = DateTime.now();
      final expiredStories =
      _stories.where((story) => story.expiryTime.isBefore(now)).toList();

      for (final story in expiredStories) {
        // Delete from Firestore
        await FirebaseFirestore.instance
            .collection('stories')
            .doc(story.id)
            .delete();

        // Delete image from Storage if it's an image story
        if (story.isImage &&
            story.content
                .startsWith('https://firebasestorage.googleapis.com')) {
          try {
            final ref = FirebaseStorage.instance.refFromURL(story.content);
            await ref.delete();
          } catch (e) {
            print('Error deleting story image: $e');
          }
        }
      }

      // Refresh stories list
      await fetchStories();
    } catch (e) {
      print('Error cleaning up expired stories: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    fetchSongs();
    fetchStories();
    // Start story cleanup timer
    _startStoryCleanupTimer();
    // Check user status and show blue tick popup only on app start
    _checkUserStatusAndShowPopup();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Remove the automatic popup reset - only show on app start
  }

  // Remove the reset method since we don't want popup on every tab switch
  // void _resetBlueTickPopupState() {
  //   if (!_isPaidUser) {
  //     setState(() {
  //       _hasShownBlueTickPopup = false;
  //     });
  //     // Show popup after a short delay
  //     Future.delayed(const Duration(seconds: 1), () {
  //       if (mounted && !_isPaidUser && !_hasShownBlueTickPopup) {
  //         _showBlueTickPopup();
  //       }
  //     });
  //   }
  // }

  // Check user payment status and show blue tick popup if needed
  Future<void> _checkUserStatusAndShowPopup() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final doc = await FirebaseFirestore.instance
          .collection('usersData')
          .doc(user.uid)
          .get();
      if (doc.exists) {
        final data = doc.data()!;
        final isPaid = data['isPaid'] ?? false;

        setState(() {
          _isPaidUser = isPaid;
        });

        // Only show popup if user is NOT paid and hasn't seen it yet
        if (!isPaid && !_hasShownBlueTickPopup) {
          // Delay to ensure the screen is fully loaded
          await Future.delayed(const Duration(seconds: 2));
          if (mounted) {
            _showBlueTickPopup();
          }
        }
      }
    } catch (e) {
      print('Error checking user status: $e');
    }
  }

  // Show blue tick popup
  void _showBlueTickPopup() {
    if (_hasShownBlueTickPopup) return;

    setState(() {
      _hasShownBlueTickPopup = true;
    });

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1F1F1F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.verified,
                        color: Colors.blue, size: 24),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'Unlock BeatJerky Blue!',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white70),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'Get exclusive benefits:',
                style: TextStyle(
                    color: Colors.white70, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              _buildBenefitItem(
                  Icons.check_circle, 'Verified Blue Tick on your profile'),
              _buildBenefitItem(Icons.flash_on, 'Unlimited access to BJAI'),
              _buildBenefitItem(
                  Icons.support_agent, 'Priority customer support'),
              _buildBenefitItem(
                  Icons.star, 'Exclusive features and early access'),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purple,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: () async {
                        Navigator.pop(ctx);
                        await _startStripeFlow(
                            priceCents: 999, plan: 'monthly');
                      },
                      child: const Text(
                        'Monthly - \$9.99',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.purple),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: () async {
                        Navigator.pop(ctx);
                        await _startStripeFlow(
                            priceCents: 9999, plan: 'yearly');
                      },
                      child: const Text(
                        'Yearly - \$99.99',
                        style: TextStyle(
                            color: Colors.purple, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Center(
                child: Text(
                  'You can cancel anytime from Settings.',
                  style: TextStyle(color: Colors.white30, fontSize: 12),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  // Build benefit item widget
  Widget _buildBenefitItem(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFBB86FC), size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: Colors.white70, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  // Start Stripe payment flow
  Future<void> _startStripeFlow(
      {required int priceCents, required String plan}) async {
    final stripeServices = StripeServices();
    try {
      // Create a minimal payment sheet
      final pi =
      await stripeServices.createPaymentIntent(priceCents.toString());
      await StripePkg.Stripe.instance.initPaymentSheet(
        paymentSheetParameters: StripePkg.SetupPaymentSheetParameters(
          paymentIntentClientSecret: pi['client_secret'],
          customFlow: true,
          merchantDisplayName: 'BeatJerky',
        ),
      );
      await StripePkg.Stripe.instance.presentPaymentSheet();

      // Mark user paid
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid != null) {
        await FirebaseFirestore.instance
            .collection('usersData')
            .doc(uid)
            .update({
          'isPaid': true,
          'paidPlan': plan,
          'paidAt': FieldValue.serverTimestamp(),
        });

        setState(() {
          _isPaidUser = true;
        });
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Blue tick purchased successfully!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Payment failed: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  // Timer for cleaning up expired stories
  Timer? _storyCleanupTimer;

  void _startStoryCleanupTimer() {
    _storyCleanupTimer = Timer.periodic(const Duration(hours: 1), (timer) {
      _cleanupExpiredStories();
    });
  }

  @override
  void dispose() {
    _storyCleanupTimer?.cancel();
    searchController.dispose();
    super.dispose();
  }

  void filterSongs(String query) {
    setState(() {
      filteredSongs = songs.where((song) {
        final title = song['title']?.toString().toLowerCase() ?? '';
        final singer = song['singer']?.toString().toLowerCase() ?? '';
        final year = song['year']?.toString().toLowerCase() ?? '';
        final description = song['description']?.toString().toLowerCase() ?? '';

        final searchLower = query.toLowerCase();
        return title.contains(searchLower) ||
            singer.contains(searchLower) ||
            year.contains(searchLower) ||
            description.contains(searchLower);
      }).toList();
    });
  }

  Future<void> fetchSongs() async {
    try {
      final currentUserId = FirebaseAuth.instance.currentUser?.uid;

      if (currentUserId == null) {
        Fluttertoast.showToast(msg: "User not logged in");
        return;
      }

      final snapshot = await FirebaseFirestore.instance
          .collection('songs')
          .orderBy('timestamp', descending: true)
          .get();

      setState(() {
        songs = snapshot.docs
            .map((doc) => {
          ...doc.data(),
          'id': doc.id,
        })
            .toList();
        filteredSongs = songs; // Initialize filtered songs with all songs
      });
    } catch (e) {
      Fluttertoast.showToast(msg: "Failed to load songs: $e");
    }
  }

  Future<void> deleteSong(String songId, String songUrl) async {
    try {
      final currentUserId = FirebaseAuth.instance.currentUser?.uid;

      // Get the song document to check ownership
      final songDoc = await FirebaseFirestore.instance
          .collection('songs')
          .doc(songId)
          .get();

      if (!songDoc.exists) {
        Fluttertoast.showToast(msg: "Song not found");
        return;
      }

      final songData = songDoc.data();
      if (songData == null || songData['userId'] != currentUserId) {
        Fluttertoast.showToast(msg: "You can only delete your own songs");
        return;
      }

      // Delete the audio file from Firebase Storage
      if (songUrl.isNotEmpty) {
        final ref = FirebaseStorage.instance.refFromURL(songUrl);
        await ref.delete();
      }

      // Delete the song document from Firestore
      await FirebaseFirestore.instance.collection('songs').doc(songId).delete();

      // Update the local state
      setState(() {
        songs.removeWhere((song) => song['id'] == songId);
        filteredSongs.removeWhere((song) => song['id'] == songId);
      });

      Fluttertoast.showToast(msg: "Song deleted successfully");
    } catch (e) {
      Fluttertoast.showToast(msg: "Failed to delete song: $e");
    }
  }

  //tabs data above the search field
  final List<TabsModel> tabsData = [
    TabsModel(
      requiredIcon: Icons.mic,
      label: "Artists",
      labelColor: Colors.white,
      bgColor: Colors.purple,
    ),
    TabsModel(
      requiredIcon: Icons.event,
      label: "Events",
      labelColor: Colors.white,
      bgColor: Colors.green,
    ),
    TabsModel(
      requiredIcon: Icons.message,
      label: "Message",
      labelColor: Colors.white,
      bgColor: Colors.indigo,
    ),
    TabsModel(
      requiredIcon: Icons.person,
      label: "People",
      labelColor: Colors.white,
      bgColor: Colors.blue,
    ),
    TabsModel(
      requiredIcon: Icons.library_music,
      label: "Add Song",
      labelColor: Colors.white,
      bgColor: Colors.orange,
    ),
    TabsModel(
      requiredIcon: Icons.music_note,
      label: "Music Style",
      labelColor: Colors.white,
      bgColor: Colors.teal,
    ),
  ];

  int currentIndex = 0;

  Future<void> showAddSongBottomSheet(BuildContext context) async {
    String selectedYear = '2024';
    File? pickedFile;
    String? fileName;
    bool isUploading = false;

    final TextEditingController singerController = TextEditingController();
    final TextEditingController titleController = TextEditingController();
    final TextEditingController descriptionController = TextEditingController();

    final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;
  final trigger = TriggerNotificationService();

  // -------------------------------
  // 🔔 Internal Notification Sender
  // -------------------------------
  Future<void> _sendSongNotificationToAllUsers({
    required String type,
    required String title,
    required String body,
    required String message,
  }) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) return;

      // Get current user name
      final currentUserDoc = await _firestore
          .collection('usersData')
          .doc(currentUser.uid)
          .get();

      final currentUserName = currentUserDoc['firstName'] ?? 'Someone';

      // Get all users
      final usersSnapshot = await _firestore.collection('usersData').get();
      int count = 0;

      for (var userDoc in usersSnapshot.docs) {
        final userId = userDoc.id;
        if (userId == currentUser.uid) continue;

        final userData = userDoc.data();
        final fcmToken = userData['fcmToken'] as String?;

        // 🔹 Send FCM push
        if (fcmToken != null && fcmToken.isNotEmpty) {
          try {
            await trigger.sendPushNotification(
              token: fcmToken,
              title: title,
              body: body,
            );
          } catch (e) {
            debugPrint('Error sending push to $userId: $e');
          }
        }

        // 🔹 Save notification in Firestore
        await _firestore
            .collection('notifications')
            .doc(userId)
            .collection('userNotifications')
            .add({
          'type': type,
          'fromUserId': currentUser.uid,
          'fromUserName': currentUserName,
          'timestamp': FieldValue.serverTimestamp(),
          'message': message,
          'isRead': false,
        });

        count++;
      }

      debugPrint('Song notification "$type" sent to $count users');
    } catch (e) {
      debugPrint('Error sending song notification: $e');
    }
  }

    Future<void> _pickMusic() async {
      // 1️⃣  Check & request permission
      final status = await Permission.audio.request(); // iOS
      // For Android 13+, audio covers READ_MEDIA_AUDIO; for Android <13 we add storage.
      final storageStatus = await Permission.storage.request();

      if (!status.isGranted && !storageStatus.isGranted) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('Permission denied – can\'t pick music.')),
          );
        }
        return;
      }

      // 2️⃣  Pick audio file
      final result = await FilePicker.platform.pickFiles(type: FileType.audio);
      if (result == null || result.files.isEmpty) return;

      setState(() {
        pickedFile = File(result.files.single.path!);
        fileName = path.basename(pickedFile!.path);
      });
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      backgroundColor: Colors.grey[900],
      builder: (context) {
        return Padding(
          padding: MediaQuery.of(context).viewInsets,
          child: StatefulBuilder(
            builder: (context, setState) {
              return Padding(
                padding: const EdgeInsets.all(16),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: const CircleAvatar(
                            backgroundColor: Colors.red,
                            child: Icon(Icons.close, color: Colors.white),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: () => _pickMusic(),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.purple,
                          minimumSize: const Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text(
                          fileName ?? "Choose MP3 Song",
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: singerController,
                        style: const TextStyle(color: Colors.white),
                        decoration: input("Enter Singer name"),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: titleController,
                        style: const TextStyle(color: Colors.white),
                        decoration: input("Enter Song Title"),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: descriptionController,
                        style: const TextStyle(color: Colors.white),
                        decoration: input("Enter Song Description"),
                        maxLines: 3,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          const Text(
                            'Year Of Song:',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: Colors.white),
                          ),
                          const SizedBox(width: 10),
                          DropdownButton<String>(
                            dropdownColor: Colors.grey[800],
                            value: selectedYear,
                            underline: Container(),
                            onChanged: (String? newValue) {
                              setState(() => selectedYear = newValue!);
                            },
                            items: ['2023', '2024', '2025']
                                .map(
                                  (val) => DropdownMenuItem(
                                value: val,
                                child: Text(val,
                                    style: const TextStyle(
                                        color: Colors.white)),
                              ),
                            )
                                .toList(),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: isUploading
                            ? null
                            : () async {
                          if (pickedFile == null ||
                              singerController.text.isEmpty ||
                              titleController.text.isEmpty) {
                            Fluttertoast.showToast(
                                msg:
                                "Please complete all required fields.");
                            return;
                          }

                          try {
                            setState(() => isUploading = true);

                            final ref = FirebaseStorage.instance.ref().child(
                                'songs/${DateTime.now().millisecondsSinceEpoch}_${path.basename(pickedFile!.path)}');

                            final uploadTask =
                            await ref.putFile(pickedFile!);
                            final url = await ref.getDownloadURL();

                            await FirebaseFirestore.instance
                                .collection('songs')
                                .add({
                              'singer': singerController.text,
                              'title': titleController.text,
                              'description': descriptionController.text,
                              'year': selectedYear,
                              'url': url,
                              'timestamp': FieldValue.serverTimestamp(),
                              'userId':
                              FirebaseAuth.instance.currentUser!.uid,
                            });

                            // ✅ Trigger and save notification
                                await _sendSongNotificationToAllUsers(
                                  type: 'new_song',
                                  title: '🎵 New Song Uploaded!',
                                  body:
                                      '${singerController.text} just uploaded a new song "${titleController.text}"',
                                  message:
                                      'A new song "${titleController.text}" by ${singerController.text} is now available.',
                                );

                            Fluttertoast.showToast(
                                msg: "Song uploaded successfully");
                            Navigator.pop(context);
                            fetchSongs();
                          } catch (e) {
                            Fluttertoast.showToast(
                                msg: "Error uploading: $e");
                          } finally {
                            setState(() => isUploading = false);
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.purple,
                          minimumSize: const Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25)),
                        ),
                        child: isUploading
                            ? const CircularProgressIndicator(
                            color: Colors.white)
                            : const Text(
                          "Upload Song",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Future<void> showEditSongBottomSheet(
      BuildContext context, Map<String, dynamic> song) async {
    final currentUserId = FirebaseAuth.instance.currentUser?.uid;

    // Server-side ownership verification
    if (song['userId'] != currentUserId) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You can only edit your own songs'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    String selectedYear = song['year'] ?? '2024';
    File? pickedFile;
    String? fileName;
    bool isUploading = false;

    final TextEditingController singerController =
    TextEditingController(text: song['singer']);
    final TextEditingController titleController =
    TextEditingController(text: song['title']);
    final TextEditingController descriptionController =
    TextEditingController(text: song['description']);

    Future<void> _pickMusic() async {
      final status = await Permission.audio.request();
      final storageStatus = await Permission.storage.request();

      if (!status.isGranted && !storageStatus.isGranted) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('Permission denied – can\'t pick music.')),
          );
        }
        return;
      }

      final result = await FilePicker.platform.pickFiles(type: FileType.audio);
      if (result == null || result.files.isEmpty) return;

      setState(() {
        pickedFile = File(result.files.single.path!);
        fileName = path.basename(pickedFile!.path);
      });
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      backgroundColor: Colors.grey[900],
      builder: (context) {
        return Padding(
          padding: MediaQuery.of(context).viewInsets,
          child: StatefulBuilder(
            builder: (context, setState) {
              return Padding(
                padding: const EdgeInsets.all(16),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: const CircleAvatar(
                            backgroundColor: Colors.red,
                            child: Icon(Icons.close, color: Colors.white),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: () => _pickMusic(),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.purple,
                          minimumSize: const Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text(
                          fileName ?? "Choose New MP3 Song (Optional)",
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: singerController,
                        style: const TextStyle(color: Colors.white),
                        decoration: input("Enter Singer name"),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: titleController,
                        style: const TextStyle(color: Colors.white),
                        decoration: input("Enter Song Title"),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: descriptionController,
                        style: const TextStyle(color: Colors.white),
                        decoration: input("Enter Song Description"),
                        maxLines: 3,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          const Text(
                            'Year Of Song:',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: Colors.white),
                          ),
                          const SizedBox(width: 10),
                          DropdownButton<String>(
                            dropdownColor: Colors.grey[800],
                            value: selectedYear,
                            underline: Container(),
                            onChanged: (String? newValue) {
                              setState(() => selectedYear = newValue!);
                            },
                            items: ['2023', '2024', '2025']
                                .map(
                                  (val) => DropdownMenuItem(
                                value: val,
                                child: Text(val,
                                    style: const TextStyle(
                                        color: Colors.white)),
                              ),
                            )
                                .toList(),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: isUploading
                            ? null
                            : () async {
                          if (singerController.text.isEmpty ||
                              titleController.text.isEmpty) {
                            Fluttertoast.showToast(
                                msg:
                                "Please complete all required fields.");
                            return;
                          }

                          try {
                            setState(() => isUploading = true);

                            String url = song['url'];
                            if (pickedFile != null) {
                              // Delete old file if exists
                              if (song['url'].isNotEmpty) {
                                final oldRef = FirebaseStorage.instance
                                    .refFromURL(song['url']);
                                await oldRef.delete();
                              }

                              // Upload new file
                              final ref = FirebaseStorage.instance
                                  .ref()
                                  .child(
                                  'songs/${DateTime.now().millisecondsSinceEpoch}_${path.basename(pickedFile!.path)}');
                              final uploadTask =
                              await ref.putFile(pickedFile!);
                              url = await ref.getDownloadURL();
                            }

                            await FirebaseFirestore.instance
                                .collection('songs')
                                .doc(song['id'])
                                .update({
                              'singer': singerController.text,
                              'title': titleController.text,
                              'description': descriptionController.text,
                              'year': selectedYear,
                              'url': url,
                              'timestamp': FieldValue.serverTimestamp(),
                            });

                            Fluttertoast.showToast(
                                msg: "Song updated successfully");
                            Navigator.pop(context);
                            fetchSongs();
                          } catch (e) {
                            Fluttertoast.showToast(
                                msg: "Error updating: $e");
                          } finally {
                            setState(() => isUploading = false);
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.purple,
                          minimumSize: const Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25)),
                        ),
                        child: isUploading
                            ? const CircularProgressIndicator(
                            color: Colors.white)
                            : const Text(
                          "Update Song",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  InputDecoration input(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.white70),
      filled: true,
      fillColor: Colors.grey[800],
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide.none,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentUserId = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 40,
            ),
            // Stories Section - Moved to top
            _buildStoriesSection(),

            const SizedBox(height: 10),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: GridView.builder(
                itemCount: tabsData.length,
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                padding: EdgeInsets.zero,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 1.2),
                itemBuilder: (BuildContext context, int index) {
                  return _buildTabs(
                      tabsData[index].requiredIcon,
                      tabsData[index].label,
                      tabsData[index].labelColor,
                      tabsData[index].bgColor, () {
                    setState(() {
                      currentIndex = index;
                    });
                    currentIndex == 0
                        ? Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => AllArtistsScreen()),
                    )
                        : currentIndex == 1
                        ? Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => EventsScreen()),
                    )
                        : currentIndex == 2
                        ? Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => MessagesScreen()),
                    )
                        : currentIndex == 3
                        ? Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              PeopleScreen()),
                    )
                        : currentIndex == 4
                        ? showAddSongBottomSheet(context)
                        : Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              StoreListScreen()),
                    );
                  });
                },
              ),
            ),

            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.grey[850],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TextField(
                  controller: searchController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    icon: const Icon(Icons.search, color: Colors.white),
                    hintText: 'Search Songs',
                    hintStyle: const TextStyle(color: Colors.white70),
                    border: InputBorder.none,
                    suffixIcon: searchController.text.isNotEmpty
                        ? IconButton(
                      icon:
                      const Icon(Icons.clear, color: Colors.white70),
                      onPressed: () {
                        searchController.clear();
                        filterSongs('');
                      },
                    )
                        : null,
                  ),
                  onChanged: filterSongs,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: filteredSongs.isEmpty
                  ? Center(
                child: Text(
                  searchController.text.isEmpty
                      ? "No songs uploaded"
                      : "No songs found",
                  style: const TextStyle(color: Colors.white),
                ),
              )
                  : ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: filteredSongs.length,
                itemBuilder: (context, index) {
                  final song = filteredSongs[index];
                  final isOwner = song['userId'] == currentUserId;

                  return Card(
                    color: Colors.grey[900],
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      leading: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8)),
                        child: const Center(child: Text('🎵')),
                      ),
                      title: Text(
                        song['title'] ?? '',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            song['singer'] ?? '',
                            style: const TextStyle(color: Colors.white70),
                          ),
                          Text(
                            song['year'] ?? '',
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Only show edit and delete buttons if user owns the song
                          if (isOwner) ...[
                            IconButton(
                              icon: const Icon(Icons.edit,
                                  color: Colors.blue),
                              onPressed: () =>
                                  showEditSongBottomSheet(context, song),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete,
                                  color: Colors.red),
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    backgroundColor: Colors.grey[900],
                                    title: const Text(
                                      'Delete Song',
                                      style:
                                      TextStyle(color: Colors.white),
                                    ),
                                    content: const Text(
                                      'Are you sure you want to delete this song? This action cannot be undone.',
                                      style: TextStyle(
                                          color: Colors.white70),
                                    ),
                                    actions: [
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.pop(context),
                                        child: const Text('Cancel',
                                            style: TextStyle(
                                                color: Colors.blue)),
                                      ),
                                      TextButton(
                                        onPressed: () {
                                          Navigator.pop(context);
                                          deleteSong(
                                              song['id'], song['url']);
                                        },
                                        child: const Text(
                                          'Delete',
                                          style: TextStyle(
                                              color: Colors.red),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ],
                          const Icon(
                            Icons.play_circle_fill,
                            color: Colors.purple,
                            size: 36,
                          ),
                        ],
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SongPlayerScreen(
                              title: song['title'],
                              description: song['description'],
                              fileUrl: song['url'],
                              coverImage: song['coverImage'],
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotificationIcon() {
  final currentUser = FirebaseAuth.instance.currentUser;
  if (currentUser == null) return const SizedBox();

  return StreamBuilder<QuerySnapshot>(
    stream: FirebaseFirestore.instance
        .collection('notifications')
        .doc(currentUser.uid)
        .collection('userNotifications')
        .where('isRead', isEqualTo: false)
        .snapshots(),
    builder: (context, snapshot) {
      int unreadCount = snapshot.data?.docs.length ?? 0;

      return Stack(
        children: [
          Badge(
          label: Text(
                  unreadCount > 99 ? '99+' : unreadCount.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
          offset: const Offset(-8, 5),
          isLabelVisible: unreadCount > 0,
          backgroundColor: const Color(0xffED2024),
          child:  IconButton(
            onPressed: () {
              // Navigate to notifications page
              Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => NotificationScreen()),
                    );
            },
            icon: const Icon(Icons.notifications, color: Colors.white),
          ),
        ),
        ],
      );
    },
  );
}


  // Stories Section Widget
  Widget _buildStoriesSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Stories',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              _buildNotificationIcon(),
            ],
          ),
          const SizedBox(height: 15),
          SizedBox(
            height: 100,
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('stories')
                  .where('expiryTime',
                  isGreaterThan: Timestamp.fromDate(DateTime.now()))
                  .orderBy('expiryTime', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                      child: CircularProgressIndicator(color: Colors.white));
                }
                final docs = snapshot.data?.docs ?? [];
                final stories = docs
                    .map((doc) => StoryModel.fromFirestore(
                    doc.data() as Map<String, dynamic>, doc.id))
                    .toList();
                return ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: stories.length + 1, // +1 for "Your Story"
                  itemBuilder: (context, index) {
                    if (index == 0) {
                      return _buildCreateStoryItem();
                    } else {
                      return _buildStoryItem(stories[index - 1]);
                    }
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabs(IconData requiredIcon, String label, Color labelColor,
      Color bgColor, VoidCallback onTap) {
    return TopIcon(
      icon: requiredIcon,
      label: label,
      color: bgColor,
      labelColor: labelColor,
      onTap: onTap,
    );
  }

  // Create Story Item
  Widget _buildCreateStoryItem() {
    return Container(
      margin: const EdgeInsets.only(right: 12),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              _showCreateStoryDialog();
            },
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [Color(0xFFBB86FC), Color(0xFF6200EE)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: Colors.white,
                  width: 2,
                ),
              ),
              child: const Center(
                child: Icon(
                  Icons.add,
                  color: Colors.white,
                  size: 25,
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Your Story',
            style: TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // Story Item
  Widget _buildStoryItem(StoryModel story) {
    return Container(
      margin: const EdgeInsets.only(right: 12),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              _showStoryViewer(story);
            },
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: story.isLive
                      ? const Color(0xFFE91E63)
                      : const LinearGradient(
                    colors: [Color(0xFFBB86FC), Color(0xFF6200EE)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ).colors.first,
                  width: 3,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: story.isImage
                    ? Image.network(
                  story.content,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      color: const Color(0xFF2A2A2A),
                      child: const Icon(
                        Icons.image,
                        color: Color(0xFFBB86FC),
                      ),
                    );
                  },
                )
                    : Container(
                  color: const Color(0xFF2A2A2A),
                  child: Center(
                    child: Text(
                      story.content,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
          // Owner name display
          Text(
            story.ownerName,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          // View count indicator for own stories
          if (story.ownerId == FirebaseAuth.instance.currentUser?.uid)
            GestureDetector(
              onTap: () => _showStoryViews(story),
              child: Container(
                margin: const EdgeInsets.only(top: 1),
                padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
                decoration: BoxDecoration(
                  color: const Color(0xFFBB86FC).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.visibility,
                      size: 10,
                      color: Color(0xFFBB86FC),
                    ),
                    const SizedBox(width: 3),
                    Text(
                      '${story.viewers.length}',
                      style: const TextStyle(
                        color: Color(0xFFBB86FC),
                        fontSize: 9,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // Show Create Story Dialog
  void _showCreateStoryDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text(
          'Create Story',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.image, color: Color(0xFFBB86FC)),
              title: const Text(
                'Image Story',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.pop(context);
                _pickImageForStory();
              },
            ),
            ListTile(
              leading: const Icon(Icons.text_fields, color: Color(0xFFBB86FC)),
              title: const Text(
                'Text Story',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.pop(context);
                _showTextStoryDialog();
              },
            ),
          ],
        ),
      ),
    );
  }

  // Show Text Story Dialog
  void _showTextStoryDialog() {
    final TextEditingController textController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text(
          'Create Text Story',
          style: TextStyle(color: Colors.white),
        ),
        content: TextField(
          controller: textController,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
            hintText: 'Enter your story text...',
            hintStyle: TextStyle(color: Colors.white54),
            border: OutlineInputBorder(),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Color(0xFFBB86FC)),
            ),
          ),
          maxLines: 3,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (textController.text.isNotEmpty) {
                _createTextStory(textController.text);
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFBB86FC),
            ),
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  // Pick Image for Story
  void _pickImageForStory() async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1080,
        maxHeight: 1080,
        imageQuality: 85,
      );

      if (image != null) {
        // Ask user if they want to add text to the image
        final TextEditingController textController = TextEditingController();
        final bool? addText = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            backgroundColor: const Color(0xFF1F1F1F),
            title: const Text(
              'Add Text to Image?',
              style: TextStyle(color: Colors.white),
            ),
            content: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Would you like to add text to your image story?',
                    style: TextStyle(color: Colors.white70),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: textController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      hintText: 'Enter text (optional)...',
                      hintStyle: TextStyle(color: Colors.white54),
                      border: OutlineInputBorder(),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Color(0xFFBB86FC)),
                      ),
                    ),
                    maxLines: 2,
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('No Text'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(context, true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFBB86FC),
                ),
                child: const Text('Add Text'),
              ),
            ],
          ),
        );

        if (addText != null) {
          // Show loading
          Fluttertoast.showToast(msg: "Uploading story...");

          // Upload image to Firebase Storage
          final ref = FirebaseStorage.instance.ref().child(
              'stories/${DateTime.now().millisecondsSinceEpoch}_${path.basename(image.path)}');

          final uploadTask = await ref.putFile(File(image.path));
          final imageUrl = await ref.getDownloadURL();

          // Create story in Firestore
          final currentUser = FirebaseAuth.instance.currentUser;
          if (currentUser != null) {
            // Resolve actual display name for the current user
            final ownerName = await _resolveDisplayName(currentUser.uid);

            final storyData = {
              'username': ownerName,
              'content': imageUrl,
              'textContent':
              textController.text.isNotEmpty ? textController.text : null,
              'isImage': true,
              'isLive': false,
              'timestamp': Timestamp.fromDate(DateTime.now()),
              'ownerId': currentUser.uid,
              'ownerName': ownerName,
              'viewers': <String>[],
              'expiryTime': Timestamp.fromDate(
                  DateTime.now().add(const Duration(hours: 24))),
            };

            await FirebaseFirestore.instance
                .collection('stories')
                .add(storyData);

            // Refresh stories
            await fetchStories();

            Fluttertoast.showToast(msg: "Image story uploaded successfully!");
          }
        }
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error uploading image story: $e");
    }
  }

  // Create Text Story
  Future<void> _createTextStory(String text) async {
    try {
      // Show loading
      Fluttertoast.showToast(msg: "Creating text story...");

      // Create story in Firestore
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser != null) {
        // Resolve actual display name for the current user
        final ownerName = await _resolveDisplayName(currentUser.uid);

        final storyData = {
          'username': ownerName,
          'content': text,
          'textContent': text,
          'isImage': false,
          'isLive': false,
          'timestamp': Timestamp.fromDate(DateTime.now()),
          'ownerId': currentUser.uid,
          'ownerName': ownerName,
          'viewers': <String>[],
          'expiryTime':
          Timestamp.fromDate(DateTime.now().add(const Duration(hours: 24))),
        };

        await FirebaseFirestore.instance.collection('stories').add(storyData);

        // Refresh stories
        await fetchStories();

        Fluttertoast.showToast(msg: "Text story created successfully!");
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error creating text story: $e");
    }
  }

  // Show Story Views
  void _showStoryViews(StoryModel story) async {
    // Fetch user names for viewers
    List<String> viewerNames = [];
    for (String userId in story.viewers) {
      final name = await _resolveDisplayName(userId);
      viewerNames.add(name);
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text(
          'Story Views',
          style: TextStyle(color: Colors.white),
        ),
        content: SizedBox(
          width: double.maxFinite,
          height: 300,
          child: story.viewers.isEmpty
              ? const Center(
            child: Text(
              'No views yet',
              style: TextStyle(color: Colors.white70),
            ),
          )
              : ListView.builder(
            itemCount: story.viewers.length,
            itemBuilder: (context, index) {
              return ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFFBB86FC),
                  child: Icon(Icons.person, color: Colors.white),
                ),
                title: Text(
                  viewerNames[index],
                  style: const TextStyle(color: Colors.white),
                ),
                subtitle: Text(
                  'Viewed ${_getTimeAgo(story.timestamp)}',
                  style: TextStyle(color: Colors.white70),
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Close',
              style: TextStyle(color: Color(0xFFBB86FC)),
            ),
          ),
        ],
      ),
    );
  }

  // Helper method for time ago
  String _getTimeAgo(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }

  // Show Story Viewer
  void _showStoryViewer(StoryModel story) async {
    // Track view if not the owner
    if (story.ownerId != FirebaseAuth.instance.currentUser?.uid) {
      try {
        await FirebaseFirestore.instance
            .collection('stories')
            .doc(story.id)
            .update({
          'viewers': FieldValue.arrayUnion(
              [FirebaseAuth.instance.currentUser?.uid ?? 'anonymous']),
        });

        // Refresh stories to update view count
        await fetchStories();
      } catch (e) {
        print('Error tracking story view: $e');
      }
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              story.username,
              style: const TextStyle(color: Colors.white),
            ),
            if (story.ownerId == FirebaseAuth.instance.currentUser?.uid)
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert, color: Colors.white),
                color: const Color(0xFF1F1F1F),
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'delete',
                    child: Text(
                      'Delete Story',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
                onSelected: (value) {
                  if (value == 'delete') {
                    Navigator.pop(context);
                    _deleteStory(story.id);
                  }
                },
              ),
          ],
        ),
        content: Container(
          width: double.maxFinite,
          height: 300,
          child: Column(
            children: [
              // Image or Text Content
              Expanded(
                child: story.isImage
                    ? Stack(
                  children: [
                    Image.network(
                      story.content,
                      width: double.maxFinite,
                      height: double.maxFinite,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return const Center(
                          child: Icon(
                            Icons.image,
                            color: Color(0xFFBB86FC),
                            size: 50,
                          ),
                        );
                      },
                    ),
                    // Text overlay on image (if there's text content)
                    if (story.textContent != null &&
                        story.textContent!.isNotEmpty)
                      Positioned(
                        bottom: 20,
                        left: 20,
                        right: 20,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            story.textContent!,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                  ],
                )
                    : Container(
                  color: const Color(0xFF2A2A2A),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Text(
                        story.content,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
              ),
              // Time and additional info
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      story.timeAgo,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                    if (story.ownerId == FirebaseAuth.instance.currentUser?.uid)
                      Text(
                        '${story.viewers.length} views',
                        style: const TextStyle(
                          color: Color(0xFFBB86FC),
                          fontSize: 12,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Close',
              style: TextStyle(color: Color(0xFFBB86FC)),
            ),
          ),
        ],
      ),
    );
  }

  // Delete Story
  Future<void> _deleteStory(String storyId) async {
    try {
      // Find the story to get its content
      final story = _stories.firstWhere((s) => s.id == storyId);

      // Delete from Firestore
      await FirebaseFirestore.instance
          .collection('stories')
          .doc(storyId)
          .delete();

      // If it's an image story, also delete from Firebase Storage
      if (story.isImage && story.content.isNotEmpty) {
        try {
          final ref = FirebaseStorage.instance.refFromURL(story.content);
          await ref.delete();
        } catch (e) {
          print('Error deleting image from storage: $e');
        }
      }

      // Remove from local list
      setState(() {
        _stories.removeWhere((s) => s.id == storyId);
      });

      Fluttertoast.showToast(msg: "Story deleted successfully!");
    } catch (e) {
      Fluttertoast.showToast(msg: "Error deleting story: $e");
    }
  }
}

class TopIcon extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final Color labelColor;
  final VoidCallback? onTap;

  const TopIcon({
    super.key,
    required this.icon,
    required this.label,
    required this.color,
    this.labelColor = Colors.black,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          CircleAvatar(
              backgroundColor: color, child: Icon(icon, color: Colors.white)),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: labelColor)),
        ],
      ),
    );
  }
}

// Story Model Class
class StoryModel {
  final String id;
  final String username;
  final String content;
  final String? textContent; // For text overlay on images
  final bool isImage;
  final bool isLive;
  final DateTime timestamp;
  final String ownerId;
  final String ownerName;
  final List<String> viewers;
  final DateTime expiryTime;

  StoryModel({
    required this.id,
    required this.username,
    required this.content,
    this.textContent,
    required this.isImage,
    required this.isLive,
    required this.timestamp,
    required this.ownerId,
    required this.ownerName,
    required this.viewers,
    required this.expiryTime,
  });

  // Create from Firestore document
  factory StoryModel.fromFirestore(Map<String, dynamic> data, String id) {
    return StoryModel(
      id: id,
      username: data['username'] ?? '',
      content: data['content'] ?? '',
      textContent: data['textContent'],
      isImage: data['isImage'] ?? false,
      isLive: data['isLive'] ?? false,
      timestamp: (data['timestamp'] as Timestamp).toDate(),
      ownerId: data['ownerId'] ?? '',
      ownerName: data['ownerName'] ?? '',
      viewers: List<String>.from(data['viewers'] ?? []),
      expiryTime: (data['expiryTime'] as Timestamp).toDate(),
    );
  }

  // Convert to Firestore document
  Map<String, dynamic> toFirestore() {
    return {
      'username': username,
      'content': content,
      'textContent': textContent,
      'isImage': isImage,
      'isLive': isLive,
      'timestamp': Timestamp.fromDate(timestamp),
      'ownerId': ownerId,
      'ownerName': ownerName,
      'viewers': viewers,
      'expiryTime': Timestamp.fromDate(expiryTime),
    };
  }

  String get timeAgo {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }
}

class TabsModel {
  final IconData requiredIcon;
  final String label;
  final Color labelColor;
  final Color bgColor;

  TabsModel({
    required this.requiredIcon,
    required this.label,
    required this.labelColor,
    required this.bgColor,
  });
}
