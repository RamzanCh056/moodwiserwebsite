
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/snackbar/snackbar.dart';

import '../../eula.dart';
import '../../services/shared_preferences_Services/auth_preferences.dart';
import '../../widget/backward_button.dart';
import '../../widget/reusable_text.dart';
import '../../widget/reusable_textformfield.dart';
import '../../widget/round_button.dart';
import '../bottom_nav_bar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'login_screen.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  bool _isLoading = false;
  final _formKey = GlobalKey<FormState>();

  bool eulaAcceptance = false;
  FirebaseMessaging messaging = FirebaseMessaging.instance;
  String? deviceId;

  @override
  void initState() {
    generateAndSaveToken();
    super.initState();
  }

  void generateAndSaveToken() async {
    await messaging.requestPermission();
    deviceId = await messaging.getToken();
    print('FCM Token: $deviceId');
  }

  bool pass = true;
  Future<void> _signUpUser() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        // Step 1: Sign up user with FirebaseAuth
        UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emailController.text.trim(),
          password: passwordController.text.trim(),
        );

        await FirebaseFirestore.instance.collection('usersData').doc(userCredential.user!.uid).set({
          'docId': userCredential.user!.uid,
          'firstName': firstNameController.text.trim(),
          'secondName': firstNameController.text.trim(),
          'email': emailController.text.trim(),
          'password': passwordController.text.trim(),
          'createdAt': Timestamp.now(),
          'following': <String>[],
        });
        EasyLoading.dismiss();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Sign Up Successfully'),
        ));

        // Navigate to the login screen
        Get.to(LoginScreen());
      } on FirebaseAuthException catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('${e.message}'),
        ));
        EasyLoading.dismiss();
        print('${e.message}');
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    BackwardButton(),
                    SizedBox(
                      width: 20,
                    ),
                    ReusableText(
                      title: "Sign Up",
                      size: 24,
                      weight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ],
                ),
                Center(
                  child: SizedBox(
                    height: 150,
                    width: 150,
                    child: Image.asset(
                      "assets/images/logo.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                const ReusableText(
                  title: "First Name",
                  size: 16,
                  color: Colors.white,
                ),
                const SizedBox(
                  height: 5,
                ),
                ReusableTextForm(
                  controller: firstNameController,
                  capitalize: TextCapitalization.words,
                  hintText: "First Name",
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This field is required';
                    } else {
                      return null;
                    }
                  },
                ),
                const SizedBox(
                  height: 20,
                ),
                const ReusableText(
                  title: "Last Name",
                  size: 16,
                  color: Colors.white,
                ),
                const SizedBox(
                  height: 5,
                ),
                ReusableTextForm(
                  controller: lastNameController,
                  capitalize: TextCapitalization.words,
                  hintText: "Last Name",
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This field is required';
                    } else {
                      return null;
                    }
                  },
                ),
                const SizedBox(
                  height: 20,
                ),
                const ReusableText(
                  title: "Email",
                  size: 16,
                  color: Colors.white,
                ),
                const SizedBox(
                  height: 5,
                ),
                ReusableTextForm(
                  controller: emailController,
                  hintText: "Email",
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This field is required';
                    } else if (!value.contains('@') && !value.contains('.com')) {
                      return 'Invalid email';
                    } else {
                      return null;
                    }
                  },
                ),
                const SizedBox(
                  height: 20,
                ),
                const ReusableText(
                  title: "Password",
                  size: 16,
                  color: Colors.white,
                ),
                const SizedBox(
                  height: 5,
                ),
                ReusableTextForm(
                  controller: passwordController,
                  hintText: "Password",
                  obscureText: pass,
                  suffixIcon: InkWell(
                    onTap: () {
                      setState(() {
                        pass = !pass;
                      });
                    },
                    child: Icon(
                      pass ? Icons.visibility : Icons.visibility_off,
                      color: Colors.white,
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This field is required';
                    } else {
                      return null;
                    }
                  },
                ),
                const SizedBox(
                  height: 20,
                ),
                Row(
                  children: [
                    Checkbox(
                        value: eulaAcceptance,
                        onChanged: (value) {
                          setState(() {
                            eulaAcceptance = !eulaAcceptance;
                          });
                        }),
                    Text("By Checking you agree with our ", style: TextStyle(color: Colors.white)),
                    InkWell(
                        onTap: () {
                          showDialog(
                              context: context,
                              builder: (context) {
                                return AlertDialog(
                                  content: ListView(
                                    children: [Text(eula)],
                                  ),
                                );
                              });
                        },
                        child: Text(
                          "EULA",
                          style: TextStyle(color: Colors.blue),
                        ))
                  ],
                ),
                const SizedBox(
                  height: 10,
                ),
                eulaAcceptance
                    ? RoundButton(
                        title: "Sign Up",
                        onTap: () async {
                          if (_formKey.currentState!.validate()) {
                            EasyLoading.show(status: "Signing up...");
                            emailController.text.replaceAll(" ", "");
                            _signUpUser();
                          }
                        },
                      )
                    : SizedBox.shrink(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const ReusableText(
                      title: "Already have an account?",
                      size: 16,
                      color: Colors.white,
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const ReusableText(
                        title: "Log in",
                        size: 16,
                        color: Colors.white,
                        weight: FontWeight.bold,
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
