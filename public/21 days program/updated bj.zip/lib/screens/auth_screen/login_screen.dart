import 'dart:async';
import 'dart:developer';
import 'package:beatjerky/notification_services/notification_services.dart';
import 'package:beatjerky/screens/auth_screen/signup_screen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../model/api_models/user_model/user_model.dart';
import '../../utils/color.dart';
import '../../widget/reusable_text.dart';
import '../../widget/reusable_textformfield.dart';
import '../../widget/round_button.dart';
import '../bottom_nav_bar.dart';
import 'forgot_password.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool _isLoading = false, _obscure = true;

  @override
  void initState() {
    super.initState();
  }

  Future<void> _logIn() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    try {
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      final fcmtoken = await NotificationService.getToken();
      log("device fcm token is : $fcmtoken");

      final user = cred.user!;

      log("user is : ${user.uid}");

      // Update FCM token in Firestore usersData collection
      try {
        await FirebaseFirestore.instance
            .collection('usersData')
            .doc(user.uid)
            .set({
          'fcmToken': fcmtoken,
        }, SetOptions(
          merge: true
        ));
        log("FCM token updated successfully for user: ${user.uid}");
      } catch (e) {
        log("Error updating FCM token: $e");
        // Continue with login even if FCM token update fails
      }

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(UserModelFields.email, user.email!);
      await prefs.setString(UserModelFields.userId, user.uid);
      if (fcmtoken != null) {
        await prefs.setString(UserModelFields.deviceId, fcmtoken!);
      }

      EasyLoading.dismiss();
      Get.offAll(() => const BottomNavBar());
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Login Successful')),
      );
    } on FirebaseAuthException catch (e) {
      EasyLoading.dismiss();
      String msg = 'Login failed. Please try again.';
      if (e.code == 'user-not-found') msg = 'No user found for that email.';
      if (e.code == 'wrong-password') msg = 'Wrong password provided.';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg)),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: blackColor,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: IconThemeData(color: whiteColor),
          titleTextStyle: TextStyle(color: whiteColor, fontSize: 24, fontWeight: FontWeight.bold),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF1E1E1E),
          hintStyle: const TextStyle(color: Colors.grey),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colors.grey),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colors.grey),
          ),
        ),
      ),
      child: Scaffold(

        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const ReusableText(
            title: "Log in",
            size: 24,
            weight: FontWeight.bold,
            color: whiteColor,
          ),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Logo
                  Center(
                    child: SizedBox(
                      height: 150,
                      width: 150,
                      child: Image.asset(
                        "assets/images/logo.png",
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Email
                  const ReusableText(
                    title: "Email",
                    size: 16,
                    color: whiteColor,
                  ),
                  const SizedBox(height: 8),
                  ReusableTextForm(
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    hintText: "Enter your email",
                    validator: (v) {
                      if (v == null || v.isEmpty) {
                        return 'This field is required';
                      }
                      if (!v.contains('@') || !v.contains('.')) {
                        return 'Invalid email';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),

                  // Password
                  const ReusableText(
                    title: "Password",
                    size: 16,
                    color: whiteColor,
                  ),
                  const SizedBox(height: 8),
                  ReusableTextForm(
                    controller: passwordController,
                    hintText: "Enter your password",
                    obscureText: _obscure,
                    suffixIcon: InkWell(
                      onTap: () => setState(() => _obscure = !_obscure),
                      child: Icon(
                        _obscure ? Icons.visibility : Icons.visibility_off,
                        color: whiteColor,
                      ),
                    ),
                    validator: (v) => (v == null || v.isEmpty) ? 'Password is required' : null,
                  ),

                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () => Get.to(() => const ForgotPasswordScreen()),
                      child: const Text("Forgot Password?"),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Login button
                  RoundButton(
                    title: _isLoading ? "Signing in..." : "Log in",
                    onTap: _logIn,
                  ),
                  const SizedBox(height: 24),

                  // Sign up link
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const ReusableText(
                        title: "Don't have an account?",
                        size: 16,
                        color: whiteColor,
                      ),
                      TextButton(
                        onPressed: () => Get.to(() => const SignupScreen()),
                        child: const ReusableText(
                          title: "Sign Up",
                          size: 16,
                          weight: FontWeight.bold,
                          color: whiteColor,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
