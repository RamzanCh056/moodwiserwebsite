// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
//
// class PeopleScreen extends StatelessWidget {
//   PeopleScreen({Key? key}) : super(key: key);
//
//   final _auth = FirebaseAuth.instance;
//   final _firestore = FirebaseFirestore.instance;
//
//   @override
//   Widget build(BuildContext context) {
//     final currentUser = _auth.currentUser;
//     if (currentUser == null) {
//       return const Scaffold(
//         body: Center(child: Text('You must be signed in')),
//       );
//     }
//
//     final myDocRef = _firestore.collection('usersData').doc(currentUser.uid);
//
//     return DefaultTabController(
//       length: 3,
//       child: Scaffold(
//         appBar: AppBar(
//           title: const Text('People'),
//           backgroundColor: Colors.white,
//           foregroundColor: Colors.black,
//           elevation: 0,
//         ),
//         body: StreamBuilder<DocumentSnapshot>(
//           stream: myDocRef.snapshots(),
//           builder: (ctx, meSnap) {
//             if (meSnap.connectionState == ConnectionState.waiting) {
//               return const Center(child: CircularProgressIndicator());
//             }
//
//             final meData = meSnap.data?.data() as Map<String, dynamic>? ?? {};
//             final followers = List<String>.from(meData['followers'] ?? []);
//             final following = List<String>.from(meData['following'] ?? []);
//
//             return Column(
//               children: [
//                 // --- Counts Row ---
//                 Padding(
//                   padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                     children: [
//                       _buildCountColumn(followers.length, 'Followers'),
//                       _buildCountColumn(following.length, 'Following'),
//                     ],
//                   ),
//                 ),
//
//                 // --- Tab Bar ---
//                 TabBar(
//                   labelColor: Colors.purple,
//                   unselectedLabelColor: Colors.grey,
//                   indicatorColor: Colors.purple,
//                   tabs: [
//                     const Tab(text: 'All'),
//                     Tab(text: 'Followers (${followers.length})'),
//                     Tab(text: 'Following (${following.length})'),
//                   ],
//                 ),
//
//                 // --- Tab Views ---
//                 Expanded(
//                   child: TabBarView(
//                     children: [
//                       _buildAllUsersTab(currentUser.uid, following),
//                       ConnectionsList(uids: followers),
//                       ConnectionsList(uids: following),
//                     ],
//                   ),
//                 ),
//               ],
//             );
//           },
//         ),
//       ),
//     );
//   }
//
//   Widget _buildCountColumn(int count, String label) {
//     return Column(
//       children: [
//         Text(
//           '$count',
//           style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//         ),
//         Text(label),
//       ],
//     );
//   }
//
//   Widget _buildAllUsersTab(String myUid, List<String> following) {
//     return StreamBuilder<QuerySnapshot>(
//       stream: _firestore.collection('usersData').snapshots(),
//       builder: (ctx2, allSnap) {
//         if (allSnap.connectionState == ConnectionState.waiting) {
//           return const Center(child: CircularProgressIndicator());
//         }
//         final docs = allSnap.data?.docs ?? [];
//         final others = docs.where((d) => d.id != myUid).toList();
//         if (others.isEmpty) {
//           return const Center(child: Text('No other users found'));
//         }
//
//         return ListView.builder(
//           itemCount: others.length,
//           itemBuilder: (context, i) {
//             final doc = others[i];
//             final data = doc.data()! as Map<String, dynamic>;
//             final name = '${data['firstName'] ?? ''} ${data['secondName'] ?? ''}'.trim();
//             final email = data['email'] ?? '';
//             final followersList = List<String>.from(data['followers'] ?? []);
//             final isFollowing = following.contains(doc.id);
//
//             return ListTile(
//               title: Text(name.isEmpty ? email : name),
//               subtitle: Text(
//                 '$email • ${followersList.length} follower${followersList.length == 1 ? '' : 's'}',
//               ),
//               trailing: ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: isFollowing ? Colors.grey : Colors.purple,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(20),
//                   ),
//                 ),
//                 child: Text(isFollowing ? 'Following' : 'Follow'),
//                 onPressed: () async {
//                   final batch = _firestore.batch();
//
//                   // toggle following for me
//                   batch.update(
//                     _firestore.collection('usersData').doc(myUid),
//                     {
//                       'following': isFollowing ? FieldValue.arrayRemove([doc.id]) : FieldValue.arrayUnion([doc.id]),
//                     },
//                   );
//                   // toggle followers for them
//                   batch.update(
//                     doc.reference,
//                     {
//                       'followers': isFollowing ? FieldValue.arrayRemove([myUid]) : FieldValue.arrayUnion([myUid]),
//                     },
//                   );
//
//                   await batch.commit();
//                 },
//               ),
//             );
//           },
//         );
//       },
//     );
//   }
// }
//
// /// Shows a simple list of user profiles for a given list of UIDs.
// class ConnectionsList extends StatelessWidget {
//   final List<String> uids;
//   const ConnectionsList({Key? key, required this.uids}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     if (uids.isEmpty) {
//       return const Center(child: Text('No connections to show'));
//     }
//
//     // Firestore only allows up to 10 in whereIn
//     final queryUids = uids.length > 10 ? uids.sublist(0, 10) : uids;
//
//     return FutureBuilder<QuerySnapshot>(
//       future: FirebaseFirestore.instance.collection('usersData').where(FieldPath.documentId, whereIn: queryUids).get(),
//       builder: (ctx, snap) {
//         if (snap.connectionState == ConnectionState.waiting) {
//           return const Center(child: CircularProgressIndicator());
//         }
//         final docs = snap.data?.docs ?? [];
//         if (docs.isEmpty) {
//           return const Center(child: Text('No users found'));
//         }
//         return ListView.builder(
//           itemCount: docs.length,
//           itemBuilder: (context, i) {
//             final data = docs[i].data()! as Map<String, dynamic>;
//             final name = '${data['firstName'] ?? ''} ${data['secondName'] ?? ''}'.trim();
//             final email = data['email'] ?? '';
//             return ListTile(
//               leading: const CircleAvatar(child: Icon(Icons.person)),
//               title: Text(name.isEmpty ? email : name),
//               subtitle: Text(email),
//             );
//           },
//         );
//       },
//     );
//   }
// }

// people_chat_screens.dart
// people_chat_screens.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Main screen showing all users, followers, and following lists
class PeopleScreen extends StatelessWidget {
  const PeopleScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) {
      return const Scaffold(
        backgroundColor: Color(0xFF121212),
        body: Center(
          child: Text(
            'You must be signed in',
            style: TextStyle(color: Colors.white),
          ),
        ),
      );
    }

    final myDocRef = FirebaseFirestore.instance.collection('usersData').doc(currentUser.uid);

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        appBar: AppBar(
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          ),
          backgroundColor: const Color(0xFF1F1F1F),
          elevation: 0,
          title: const Text(
            'People',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          centerTitle: true,
          bottom: const TabBar(
            indicatorColor: Color(0xFFBB86FC),
            labelColor: Color(0xFFBB86FC),
            unselectedLabelColor: Colors.white54,
            tabs: [
              Tab(text: 'All'),
              Tab(text: 'Followers'),
              Tab(text: 'Following'),
            ],
          ),
        ),
        body: StreamBuilder<DocumentSnapshot>(
          stream: myDocRef.snapshots(),
          builder: (context, meSnap) {
            if (meSnap.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(color: Color(0xFFBB86FC)),
              );
            }
            final meData = meSnap.data?.data() as Map<String, dynamic>? ?? {};
            final followers = List<String>.from(meData['followers'] ?? []);
            final following = List<String>.from(meData['following'] ?? []);

            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildCountColumn(followers.length, 'Followers'),
                      _buildCountColumn(following.length, 'Following'),
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    children: [
                      _UsersListTab(myUid: currentUser.uid, following: following),
                      ConnectionsList(uids: followers),
                      ConnectionsList(uids: following),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildCountColumn(int count, String label) {
    return Column(
      children: [
        Text(
          '$count',
          style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: Colors.white70)),
      ],
    );
  }
}

/// Tab showing all users except current user, with follow/chat actions
class _UsersListTab extends StatelessWidget {
  final String myUid;
  final List<String> following;
  const _UsersListTab({Key? key, required this.myUid, required this.following}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('usersData').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: Color(0xFFBB86FC)),
          );
        }
        final docs = snapshot.data?.docs.where((d) => d.id != myUid).toList() ?? [];
        if (docs.isEmpty) {
          return const Center(
            child: Text('No other users found', style: TextStyle(color: Colors.white70)),
          );
        }
        return ListView.builder(
          itemCount: docs.length,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          itemBuilder: (context, index) {
            final doc = docs[index];
            final data = doc.data()! as Map<String, dynamic>;
            final name = '${data['firstName'] ?? ''} ${data['secondName'] ?? ''}'.trim();
            final email = data['email'] ?? '';
            final followersList = List<String>.from(data['followers'] ?? []);
            final isFollowing = following.contains(doc.id);

            return Card(
              color: const Color(0xFF1F1F1F),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              margin: const EdgeInsets.symmetric(vertical: 6,),
              child:
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15,vertical: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      backgroundColor: const Color(0xFFBB86FC),
                      child: Text(
                        (name.isNotEmpty ? name[0] : email[0]).toUpperCase(),
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                    SizedBox(width: 10,),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(name.isEmpty ? email : name, style: const TextStyle(color: Colors.white)),
                          Text(
                            '$email • ${followersList.length} follower${followersList.length == 1 ? '' : 's'}',
                            style: const TextStyle(color: Colors.white60, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 10,),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GestureDetector(
                          onTap: () async {
                            final batch = FirebaseFirestore.instance.batch();
                            batch.update(
                              FirebaseFirestore.instance.collection('usersData').doc(myUid),
                              {
                                'following': isFollowing ? FieldValue.arrayRemove([doc.id]) : FieldValue.arrayUnion([doc.id]),
                              },
                            );
                            batch.update(
                              doc.reference,
                              {
                                'followers': isFollowing ? FieldValue.arrayRemove([myUid]) : FieldValue.arrayUnion([myUid]),
                              },
                            );
                            await batch.commit();
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 10,vertical: 6),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: isFollowing ? Colors.white38 : const Color(0xFFBB86FC))
                            ),
                            child: Text(
                              isFollowing ? 'Following' : 'Follow',
                              style: TextStyle(
                                color: isFollowing ? Colors.white54 : const Color(0xFFBB86FC),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        isFollowing
                            ? SizedBox()
                            :
                        GestureDetector(
                          onTap: () {
                            print("is called");
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChatScreen(peerUid: doc.id, peerName: name.isEmpty ? email : name),
                              ),
                            );
                          },
                          child: Icon(Icons.chat, color: Colors.white),),
                      ],
                    ),

                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

/// Widget displaying a list of given UIDs (followers/following)
class ConnectionsList extends StatelessWidget {
  final List<String> uids;
  const ConnectionsList({Key? key, required this.uids}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (uids.isEmpty) {
      return const Center(child: Text('No connections to show', style: TextStyle(color: Colors.white70)));
    }

    final queryUids = uids.length > 10 ? uids.sublist(0, 10) : uids;
    return FutureBuilder<QuerySnapshot>(
      future: FirebaseFirestore.instance.collection('usersData').where(FieldPath.documentId, whereIn: queryUids).get(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: Color(0xFFBB86FC)),
          );
        }
        final docs = snap.data?.docs ?? [];
        if (docs.isEmpty) {
          return const Center(
            child: Text('No users found', style: TextStyle(color: Colors.white70)),
          );
        }
        return ListView.builder(
          itemCount: docs.length,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          itemBuilder: (context, index) {
            final data = docs[index].data()! as Map<String, dynamic>;
            final name = '${data['firstName'] ?? ''} ${data['secondName'] ?? ''}'.trim();
            final email = data['email'] ?? '';
            return Card(
              color: const Color(0xFF1F1F1F),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              margin: const EdgeInsets.symmetric(vertical: 6),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFFBB86FC),
                  child: Icon(Icons.person, color: Colors.white),
                ),
                title: Text(name.isEmpty ? email : name, style: const TextStyle(color: Colors.white)),
                subtitle: Text(email, style: const TextStyle(color: Colors.white60)),
                // trailing: Icon(Icons.chat, color: Colors.white),
              ),
            );
          },
        );
      },
    );
  }
}

/// Chat screen with real-time messaging between two users
class ChatScreen extends StatefulWidget {
  final String peerUid;
  final String peerName;
  const ChatScreen({Key? key, required this.peerUid, required this.peerName}) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final currentUser = FirebaseAuth.instance.currentUser!;
  late String chatId;
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    final uids = [currentUser.uid, widget.peerUid]..sort();
    chatId = '${uids[0]}_${uids[1]}';
  }

  void sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;
    final msgRef = FirebaseFirestore.instance.collection('chats').doc(chatId).collection('messages').doc();
    await msgRef.set({
      'text': text,
      'senderId': currentUser.uid,
      'receiverId': widget.peerUid,
      'timestamp': FieldValue.serverTimestamp(),
    });
    _messageController.clear();
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent + 60,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        leading: GestureDetector(
            onTap: (){
              Navigator.pop(context);
            },
            child: Icon(Icons.keyboard_arrow_left_rounded,color: Colors.white,)),
        title: Text(widget.peerName,style: TextStyle(color: Colors.white),),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('chats')
                  .doc(chatId)
                  .collection('messages')
                  .orderBy('timestamp', descending: false)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: Color(0xFFBB86FC)),
                  );
                }
                final docs = snapshot.data!.docs;
                return ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index].data()! as Map<String, dynamic>;
                    final isMe = data['senderId'] == currentUser.uid;
                    return Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: isMe ? const Color(0xFFBB86FC) : const Color(0xFF2C2C2E),
                          borderRadius: BorderRadius.only(
                            topLeft: const Radius.circular(12),
                            topRight: const Radius.circular(12),
                            bottomLeft: Radius.circular(isMe ? 12 : 0),
                            bottomRight: Radius.circular(isMe ? 0 : 12),
                          ),
                        ),
                        child: Text(
                          data['text'] ?? '',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          const Divider(height: 1),
          Container(
            color: const Color(0xFF1F1F1F),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      hintText: 'Type a message...',
                      hintStyle: TextStyle(color: Colors.white54),
                      border: InputBorder.none,
                    ),
                    onSubmitted: (_) => sendMessage(),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Color(0xFFBB86FC)),
                  onPressed: sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
