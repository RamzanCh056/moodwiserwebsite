import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

import '../../../consolePrintWithColor.dart';
import '../../../model/api_models/feed_models/single_feed_comments_model.dart';
import '../../../providers/feeds_provider/feed_comments_provider.dart';
import '../../../providers/stores_provider/store_feed_provider.dart';
import '../../../providers/stores_provider/store_provider.dart';
import '../../../providers/users_provider/current_user_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../services/api_services/feed_services/feed_comment_services.dart';
import '../../../services/api_services/feed_services/feed_like_services.dart';
import '../../../services/api_services/feed_services/feed_services.dart';
import '../../../services/api_services/store_services/get_store_feeds.dart';
import '../../../utils/color.dart';
import '../../../widget/reusable_text.dart';
import '../../../widget/reusable_textformfield.dart';


class TimelineTab extends StatefulWidget {
  const TimelineTab({
    required this.storeId,
    Key? key}) : super(key: key);
  final int storeId;

  @override
  State<TimelineTab> createState() => _TimelineTabState();
}

class _TimelineTabState extends State<TimelineTab> {

  getFeeds(int storeId)async{
    await StoreFeedServices().getStoreFeeds(context,storeId );
  }


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Provider
          .of<StoreFeedsProvider>(context, listen: false)
          .storeFeeds
          .isNotEmpty ?
      ListView.builder(
          itemCount: Provider
              .of<StoreFeedsProvider>(context, listen: false)
              .storeFeeds
              .length,
          itemBuilder: (context, index) {
            return Consumer<StoreFeedsProvider>(
              builder: (context, feed, _) {
                printLog("<<<<<<<<${feed.storeFeeds[index].videoId}>>>>>>>>");
                printLog("<<<<<<<<${feed.storeFeeds[index].feedLikes.length}>>>>>>>>");
                bool isLiked=false;
                for(int i=0;i<feed.storeFeeds[index].feedLikes.length;i++){
                  printLog(">>>>>>>>>>>>>");
                  if(feed.storeFeeds[index].feedLikes[i]["userId"]==Provider.of<CurrentUserProvider>(context,listen: false).user!.userId){
                    isLiked=true;
                    printLog("<<<<<<<<<<<<<<<<<<<<TRue>>>>>>>>>>>>>>>>>>>>");
                  }
                }
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      width: Get.width,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CachedNetworkImage(
                            imageUrl: Provider
                                .of<StoreProvider>(context, listen: false)
                                .store!
                                .storeImage
                                .replaceAll("public", ApiConstants.baseUrl,

                            ),
                            width: Get.width * .2,
                            placeholder: (context, url) =>
                            const Shimmer(
                              gradient: LinearGradient(
                                  colors: [Colors.white, Colors.black54]),
                              child: CircleAvatar(
                                  radius: 10,
                                  child: ClipOval()),),
                            errorWidget: (context, url, error) =>
                                Icon(Icons.error),
                          ),
                          const SizedBox(
                            width: 15,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ReusableText(
                                    title: Provider
                                        .of<StoreProvider>(
                                        context, listen: false)
                                        .store!
                                        .storeName,
                                    color: Color(0xffFFFFFF),
                                    size: 14,
                                    weight: FontWeight.w700,
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  const Image(
                                    image: AssetImage(
                                        "assets/shop_feed/icons/Subtract.png"),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              const ReusableText(
                                title: 'Sponsored',
                                color: Color(0xf50FFFFFF),
                                size: 11,
                                weight: FontWeight.w500,
                              ),
                            ],
                          ),
                          const Spacer(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: const [
                              // Container(
                              //   height: 31,
                              //   width: 78,
                              //   decoration: BoxDecoration(
                              //       color: indigoColor,
                              //       borderRadius: BorderRadius.circular(8)),
                              //   child: const Center(
                              //       child: ReusableText(
                              //         title: 'Follow',
                              //         color: Color(0xffFFFFFF),
                              //         size: 13,
                              //         weight: FontWeight.w500,
                              //         textAlign: TextAlign.center,
                              //       )
                              //   ),
                              // ),
                              SizedBox(
                                width: 10,
                              ),
                              Icon(
                                Icons.more_vert,
                                color: Color(0xffFFFFFF),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    ReusableText(
                      title: feed.storeFeeds[index].description,
                      color: Color(0xffFFFFFF),
                      size: 14,
                      weight: FontWeight.w500,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xf30FFFFFF),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xffFFFFFF)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: MediaQuery
                                .of(context)
                                .size
                                .width * 1,
                            child: Image(
                                fit: BoxFit.fitWidth,
                                image: NetworkImage(
                                    feed.storeFeeds[index].imageUrl.replaceAll(
                                        "public", ApiConstants.baseUrl))),
                          ),
                          const SizedBox(height: 10,),
                          // Padding(
                          //   padding: const EdgeInsets.all(10.0),
                          //   child: Row(
                          //     crossAxisAlignment: CrossAxisAlignment.start,
                          //     children: [
                          //       const ReusableText(
                          //         title: '\$ 29.99',
                          //         color: Color(0xffFFFFFF),
                          //         size: 17,
                          //         weight: FontWeight.w700,
                          //       ),
                          //       const Spacer(),
                          //       InkWell(
                          //         child: Container(
                          //           height: 31,
                          //           width: 82,
                          //           decoration: BoxDecoration(
                          //               color: indigoColor,
                          //               border: Border.all(
                          //                   color: const Color(0xf30C8D1E5)),
                          //               borderRadius: BorderRadius.circular(8)),
                          //           child: const Center(
                          //               child: ReusableText(
                          //                 title: 'Shop Now',
                          //                 color: Color(0xffFFFFFF),
                          //                 size: 13,
                          //                 weight: FontWeight.w500,
                          //
                          //               )
                          //           ),
                          //         ),
                          //       ),
                          //     ],
                          //   ),
                          // ),
                          // const SizedBox(height: 10,),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10,),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        InkWell(
                          onTap: ()async{

                            var userId=Provider.of<CurrentUserProvider>(context,listen: false).user!.userId!;
                            if(isLiked){
                              await FeedLikeServices().dislikeFeedLike(
                                  userId,
                                  feed.storeFeeds[index].videoId,
                                  index,

                                  context);
                              await getFeeds(widget.storeId);
                              setState(() {});
                            }else{

                              bool like=await FeedLikeServices().likeFeed(
                                  userId,
                                  feed.storeFeeds[index].videoId,
                                  index,
                                  context);
                            }

                          },
                          child: Row(
                            children: [
                              Icon(isLiked?Icons.favorite:Icons.favorite_border,color: isLiked?redColor:whiteColor,),
                              // Image(
                              //     color: Colors.white,
                              //     image: AssetImage(
                              //         "assets/shop_feed/icons/Heart-4.png")),
                              SizedBox(width: 10,),
                              ReusableText(
                                title: isLiked?'${feed.storeFeeds[index].feedLikes.length} React':"React",
                                color: Color(0xffFFFFFF),
                                size: 13,
                                weight: FontWeight.w500,
                              ),
                            ],
                          ),
                        ),
                        Spacer(),
                        InkWell(
                          onTap: ()async{
                            _showComments(context: context, feedId: feed.storeFeeds[index].videoId);
                          },
                          child: Row(
                            children: [
                              Image(
                                  color: Colors.white,
                                  image: AssetImage(
                                      "assets/shop_feed/icons/Iconly Light Chat.png")),
                              SizedBox(width: 10,),
                              ReusableText(
                                title: 'Comment',
                                color: Color(0xffFFFFFF),
                                size: 13,
                                weight: FontWeight.w500,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20,)
                  ],
                );
              },
            );
          }
      ) :
      const Center(child: Text("No feeds available"),),
    );
  }

  updateAllFeeds()async{
    await FeedServices().getAllFeeds(context);
    setState(() {

    });
  }
  TextEditingController commentController=TextEditingController();
  void _showComments({required BuildContext context,required int feedId}) {

    showModalBottomSheet(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(20),

            topLeft: Radius.circular(20),
          )
      ),
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Container(
            decoration: const BoxDecoration(


            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: SizedBox(
                height: Get.height*.6,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const ReusableText(
                            title: "Comments",
                            size: 16,
                          ),
                          ReusableText(
                            title: "${Provider.of<CommentsProvider>(context).feedComments.length} Comments",
                            size: 14,
                            color: Colors.grey,
                          ),
                        ],
                      ),
                    ),

                    const Divider(),
                    const SizedBox(height: 10,),
                    SizedBox(
                      height: Get.height*.45,
                      child:ListView.builder(
                          itemCount: Provider.of<CommentsProvider>(context).feedComments.length,
                          itemBuilder: (context,commentIndex){
                            List<SingleFeedCommentModel> feedComments=Provider.of<CommentsProvider>(context).feedComments;
                            String imageUrl=feedComments[commentIndex].user!.profileImg.replaceAll('public', ApiConstants.baseUrl);
                            return Provider.of<CommentsProvider>(context).feedComments.isNotEmpty?Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Column(
                                        children: [
                                          SizedBox(height: 20,),
                                          CircleAvatar(
                                            backgroundColor: indigoColor,
                                            // backgroundImage: NetworkImage(imageUrl),
                                            radius: 25,
                                            child: Padding(
                                              padding: const EdgeInsets.all(2.0),
                                              child: Image.network(imageUrl),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(width: 10,),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          // SizedBox(height: 15,),
                                          SizedBox(
                                            width: Get.width*.73,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(height: 20,),
                                                    ReusableText(
                                                      title: "${feedComments[commentIndex].user!.firstName} ${feedComments[commentIndex].user!.lastName}",
                                                      size: 16,
                                                      weight: FontWeight.w700,
                                                      color: whiteColor,
                                                    ),
                                                    ReusableText(
                                                      title: DateFormat("dd-MMM-yyyy ").add_jm().format(DateTime.parse(feedComments[commentIndex].createdAt)),
                                                      size: 10,
                                                      color: Colors.grey,
                                                    ),
                                                  ],
                                                ),
                                                Spacer(),
                                                PopupMenuButton(

                                                    position: PopupMenuPosition.over,
                                                    offset: const Offset(-20,30),
                                                    padding: EdgeInsets.zero,
                                                    icon: const Icon(Icons.more_horiz_rounded,size: 40,color: greyColor,),
                                                    itemBuilder: (context)=>[
                                                      PopupMenuItem(
                                                          child: feedComments[commentIndex].userId==Provider.of<CurrentUserProvider>(context,listen: false).user!.userId?TextButton(
                                                            onPressed: () async{
                                                              EasyLoading.show(status: 'Deleting');

                                                              bool isDeleted=await FeedCommentServices().deleteFeedComment(Provider.of<CurrentUserProvider>(context,listen: false).user!.userId!, feedId, feedComments[commentIndex].commentId, context);
                                                              if(isDeleted){
                                                                Get.showSnackbar(const GetSnackBar(message: "Deleted successfully",duration: Duration(seconds: 2),));
                                                              }
                                                              await updateAllFeeds();
                                                              await FeedCommentServices().getAllComments(feedId, context);
                                                              setState(() {

                                                              });
                                                              Navigator.pop(context);
                                                              EasyLoading.dismiss();
                                                            },
                                                            child: const Text("Delete"),
                                                          ):TextButton(
                                                            onPressed: () {
                                                              // FeedServices().deleteFeed(feedProvider.feedsList[index].feedId, context);
                                                            },
                                                            child: const Text("About"),
                                                          )
                                                      )
                                                    ]),
                                              ],
                                            ),
                                          ),
                                          const SizedBox(height: 5,),

                                          const SizedBox(height: 10,),
                                          SizedBox(
                                            width: Get.width*.7,
                                            child: ReusableText(title: feedComments[commentIndex].comment,),
                                          )
                                        ],
                                      ),



                                    ],
                                  ),


                                ],
                              ),
                            ):
                            const Center(child: ReusableText(title: "No comments available",color: Colors.white,),);
                          }),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          height: 50,
                          width: Get.width*.78,

                          child: ReusableTextForm(

                            hintText: "Write comment here...",
                            filledColor: Colors.white,
                            textColor: Colors.black,
                            controller: commentController,
                            // maxLine: 3,
                            borderRadius: 25,
                          ),
                        ),

                        InkWell(
                            onTap: ()async{
                              if(commentController.text.isEmpty){
                                Get.showSnackbar(const GetSnackBar(message: "Can't post empty comment",duration: Duration(seconds: 2),),);
                              }else{
                                EasyLoading.show(status: 'Posting...');
                                await FeedCommentServices().commentFeed(
                                    Provider.of<CurrentUserProvider>(context,listen: false).user!.userId!,
                                    feedId, commentController.text, context);
                                commentController.clear();
                                await updateAllFeeds();
                                await FeedCommentServices().getAllComments(feedId, context);

                                setState(() {

                                });
                                EasyLoading.dismiss();
                              }
                            },
                            child: Container(

                              padding: EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  color: whiteColor,
                                  borderRadius: BorderRadius.circular(50)
                              ),
                              child: Transform.rotate(
                                  angle: -.78,
                                  child: const Icon(Icons.send,color: indigoColor,size: 30,)),
                            ))
                      ],
                    ),



                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
