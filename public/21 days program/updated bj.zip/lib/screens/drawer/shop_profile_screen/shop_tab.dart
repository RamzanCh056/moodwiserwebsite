import 'dart:math';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';


import '../../../providers/stores_provider/product_provider.dart';
import '../../../repo/api_consts.dart';
import '../../../widget/reusable_text.dart';
import '../../shop/product_description.dart';

class ShopTab extends StatefulWidget {
  const ShopTab({required this.storeName,Key? key}) : super(key: key);
  final String storeName;

  @override
  State<ShopTab> createState() => _ShopTabState();
}

class _ShopTabState extends State<ShopTab> {
  List<ShopModel> ImageList1 = [
    ShopModel(
        Title1: "Nike Shoes",
        Title2: "\$299.99",
        Image: "assets/shop_feed/images/Rectangle 24074.png"),
    ShopModel(
        Title1: "Nike Shoes",
        Title2: "\$299.99",
        Image: "assets/shop_feed/images/Rectangle 24074 (1).png"),
    ShopModel(
        Title1: "Nike Shoes",
        Title2: "\$299.99",
        Image: "assets/shop_feed/images/Rectangle 24074 (2).png"),
    ShopModel(
        Title1: "Nike Shoes",
        Title2: "\$299.99",
        Image: "assets/shop_feed/images/Rectangle 24074 (3).png"),
    ShopModel(
        Title1: "Nike Shoes",
        Title2: "\$299.99",
        Image: "assets/shop_feed/images/Rectangle 24074 (4).png"),
    ShopModel(
        Title1: "Nike Shoes",
        Title2: "\$299.99",
        Image: "assets/shop_feed/images/Rectangle 24074 (5).png"),
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
              child: Provider
                  .of<ProductProvider>(context, listen: false)
                  .productList
                  .isNotEmpty ?
              GridView.builder(
                itemCount: Provider
                    .of<ProductProvider>(context, listen: false)
                    .productList
                    .length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    mainAxisSpacing: 10,
                    crossAxisCount: 2,
                    childAspectRatio: 0.72,
                    crossAxisSpacing: 10),
                itemBuilder: (BuildContext context, int index) {
                  return Consumer<ProductProvider>(
                    builder: (BuildContext context, product, Widget? _) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            // height: 260,
                            decoration: BoxDecoration(
                              color: const Color(0xf30FFFFFF),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CachedNetworkImage(
                                  alignment: Alignment.center,
                                  height: 120,
                                  fit: BoxFit.cover,
                                  imageUrl: product.productList[index]
                                      .productImg1.replaceAll(
                                    "public", ApiConstants.baseUrl,
                                  ),
                                  placeholder: (context, url) =>
                                  const Shimmer(
                                    gradient: LinearGradient(
                                        colors: [Colors.white, Colors.black54]),
                                    child: SizedBox(
                                      width: 250,
                                      // height: 260,
                                    ),),
                                  errorWidget: (context, url, error) =>
                                  const Icon(Icons.error, size: 100,),
                                ),
                                // Image(
                                //     width: 250,
                                //     fit: BoxFit.cover,
                                //     image:
                                //     AssetImage(product.productList[index].productImg1.replaceAll("public", ApiConstants.baseUrl))),
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    children: [
                                      Text(
                                        product.productList[index].productName,
                                        style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                            color: Color(0xffFFFFFF)),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        product.productList[index].productPrice
                                            .toString(),
                                        style: const TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w700,
                                            color: Color(0xffFFFFFF)),
                                      ),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      InkWell(
                                        onTap: () async {
                                          List<String> images=[
                                            product.productList[index].productImg1,
                                            product.productList[index].productImg2,
                                            product.productList[index].productImg3,
                                            product.productList[index].productImg4,
                                          ];
                                          Get.to(()=>ProductDescription(
                                            product: product.productList[index],
                                            images: images,
                                            storeName: widget.storeName,
                                          ));
                                          // var productValue=product.productList[index];
                                          // var user=Provider.of<CurrentUserProvider>(context,listen: false).user!;
                                          // Checkout.checkOut(
                                          //     context,
                                          //     productValue.productName,
                                          //     productValue.id,
                                          //     widget.storeName,
                                          //     productValue.storeId,
                                          //     user.userId!,
                                          //     "${user.firstName} ${user.lastName}",
                                          //     productValue.productPrice,
                                          //     productValue.productDiscount,
                                          //     Random().nextInt(1000),
                                          //     "Pending");
                                        },
                                        child: Container(
                                          height: 28,
                                          padding: const EdgeInsets.all(5),
                                          decoration: BoxDecoration(
                                              borderRadius: BorderRadius
                                                  .circular(6),
                                              color: Color(0xFFB717DB)),
                                          child: const Center(
                                            child: ReusableText(
                                              title: 'Add to Cart',
                                              color: Color(0xffFFFFFF),
                                              size: 12,
                                              weight: FontWeight.w700,
                                              textAlign: TextAlign.center,
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    },

                  );
                },
              ) :
              const Center(child: Text("No products available"),)
          )
        ],
      ),
    );
  }
}

class ShopModel {
  String? Title1;
  String? Title2;
  String? Image;

  ShopModel({this.Title1, this.Image, this.Title2});
}
