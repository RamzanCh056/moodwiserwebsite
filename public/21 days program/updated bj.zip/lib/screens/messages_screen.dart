import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  List<Map<String, dynamic>> users = [];
  List<Map<String, dynamic>> filteredUsers = [];
  final currentUser = FirebaseAuth.instance.currentUser;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchUsers();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> fetchUsers() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('usersData')
          .get();

      setState(() {
        users = snapshot.docs
            .map((doc) => {
                  'id': doc.id,
                  ...doc.data(),
                })
            .where((user) => user['id'] != currentUser?.uid) // Exclude current user
            .toList();
        filteredUsers = List.from(users); // Initialize filtered users
      });
    } catch (e) {
      print('Error fetching users: $e');
    }
  }

  void _filterUsers(String query) {
    setState(() {
      if (query.isEmpty) {
        filteredUsers = List.from(users);
      } else {
        filteredUsers = users.where((user) {
          final displayName = _getDisplayName(user).toLowerCase();
          final email = (user['email'] ?? '').toLowerCase();
          final searchLower = query.toLowerCase();
          return displayName.contains(searchLower) || email.contains(searchLower);
        }).toList();
      }
    });
  }

  String _getDisplayName(Map<String, dynamic> user) {
    // Debug: Print available fields
    print('User data fields: ${user.keys.toList()}');
    
    // Try multiple possible field combinations
    if (user['name'] != null && user['name'].toString().trim().isNotEmpty) {
      print('Found name: ${user['name']}');
      return user['name'].toString().trim();
    } 
    
    if (user['userFirstName'] != null && user['userSecondName'] != null) {
      final firstName = user['userFirstName'].toString().trim();
      final lastName = user['userSecondName'].toString().trim();
      if (firstName.isNotEmpty || lastName.isNotEmpty) {
        final fullName = '$firstName $lastName'.trim();
        print('Found userFirstName + userSecondName: $fullName');
        return fullName;
      }
    }
    
    if (user['firstName'] != null && user['lastName'] != null) {
      final firstName = user['firstName'].toString().trim();
      final lastName = user['lastName'].toString().trim();
      if (firstName.isNotEmpty || lastName.isNotEmpty) {
        final fullName = '$firstName $lastName'.trim();
        print('Found firstName + lastName: $fullName');
        return fullName;
      }
    }
    
    // Try individual fields
    if (user['userFirstName'] != null && user['userFirstName'].toString().trim().isNotEmpty) {
      print('Found only userFirstName: ${user['userFirstName']}');
      return user['userFirstName'].toString().trim();
    }
    
    if (user['firstName'] != null && user['firstName'].toString().trim().isNotEmpty) {
      print('Found only firstName: ${user['firstName']}');
      return user['firstName'].toString().trim();
    }
    
    print('No name found for user, returning email');
    return user['email'] ?? 'Unknown User';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text(
          'Messages',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A2A),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFBB86FC).withOpacity(0.3)),
              ),
              child: TextField(
                controller: _searchController,
                style: const TextStyle(color: Colors.white),
                                  decoration: InputDecoration(
                    icon: const Icon(Icons.search, color: Color(0xFFBB86FC)),
                    hintText: 'Search users...',
                    hintStyle: const TextStyle(color: Colors.white54),
                    border: InputBorder.none,
                    suffixIcon: _searchController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear, color: Colors.white54),
                            onPressed: () {
                              _searchController.clear();
                              _filterUsers('');
                            },
                          )
                        : null,
                  ),
                onChanged: _filterUsers,
                onSubmitted: (_) => _filterUsers(_searchController.text),
              ),
            ),
          ),
          // Users List
          Expanded(
            child: filteredUsers.isEmpty
                ? Center(
                    child: Text(
                      _searchController.text.isEmpty ? 'No users found' : 'No users match your search',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  )
                : ListView.builder(
                    itemCount: filteredUsers.length,
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                              itemBuilder: (context, index) {
                  final user = filteredUsers[index];
                final displayName = _getDisplayName(user);
                final email = user['email'] ?? '';
                final followersList = List<String>.from(user['followers'] ?? []);

                return Card(
                  color: const Color(0xFF1F1F1F),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundColor: const Color(0xFFBB86FC),
                          child: Text(
                            (displayName.isNotEmpty ? displayName[0] : email[0]).toUpperCase(),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                displayName.isEmpty ? email : displayName,
                                style: const TextStyle(color: Colors.white),
                              ),
                              Text(
                                '$email • ${followersList.length} follower${followersList.length == 1 ? '' : 's'}',
                                style: const TextStyle(color: Colors.white60, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ChatScreen(
                                  peerUid: user['id'],
                                  peerName: displayName.isEmpty ? email : displayName,
                                ),
                              ),
                            );
                          },
                          child: const Icon(Icons.chat, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    )]));
  }
}

/// Chat screen with real-time messaging between two users
class ChatScreen extends StatefulWidget {
  final String peerUid;
  final String peerName;
  const ChatScreen({Key? key, required this.peerUid, required this.peerName}) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final currentUser = FirebaseAuth.instance.currentUser!;
  late String chatId;
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    final uids = [currentUser.uid, widget.peerUid]..sort();
    chatId = '${uids[0]}_${uids[1]}';
  }

  void sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;
    final msgRef = FirebaseFirestore.instance.collection('chats').doc(chatId).collection('messages').doc();
    await msgRef.set({
      'text': text,
      'senderId': currentUser.uid,
      'receiverId': widget.peerUid,
      'timestamp': FieldValue.serverTimestamp(),
    });
    _messageController.clear();
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent + 60,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: const Icon(Icons.keyboard_arrow_left_rounded, color: Colors.white),
        ),
        title: Text(widget.peerName, style: const TextStyle(color: Colors.white)),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('chats')
                  .doc(chatId)
                  .collection('messages')
                  .orderBy('timestamp', descending: false)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: Color(0xFFBB86FC)),
                  );
                }
                final docs = snapshot.data!.docs;
                return ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final data = docs[index].data()! as Map<String, dynamic>;
                    final isMe = data['senderId'] == currentUser.uid;
                    return Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: isMe ? const Color(0xFFBB86FC) : const Color(0xFF2C2C2E),
                          borderRadius: BorderRadius.only(
                            topLeft: const Radius.circular(12),
                            topRight: const Radius.circular(12),
                            bottomLeft: Radius.circular(isMe ? 12 : 0),
                            bottomRight: Radius.circular(isMe ? 0 : 12),
                          ),
                        ),
                        child: Text(
                          data['text'] ?? '',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          const Divider(height: 1),
          Container(
            color: const Color(0xFF1F1F1F),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      hintText: 'Type a message...',
                      hintStyle: TextStyle(color: Colors.white54),
                      border: InputBorder.none,
                    ),
                    onSubmitted: (_) => sendMessage(),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Color(0xFFBB86FC)),
                  onPressed: sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
