import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../model/api_models/all_categories/all_category_song_model.dart';
import '../../model/recently_music.dart';
import '../../providers/music_style_provider/music_style_provider.dart';
import '../../services/api_services/music_style_services/music_style_services.dart';
import '../../services/api_services/user_song_services/user_song_services.dart';
import '../../shimmer_effect/recently_music_screen_skeleton.dart';
import '../../utils/color.dart';
import '../../widget/reusable_text.dart';
import '../../widget/reusable_textformfield.dart';
import '../preacher_podcast.dart' show AudioPlay;

class MyCategorySongsScreen extends StatefulWidget {
  const MyCategorySongsScreen({required this.id,required this.title,Key? key}) : super(key: key);
  final String title;
  final int id;
  @override
  State<MyCategorySongsScreen> createState() => _MyCategorySongsScreenState();
}

class _MyCategorySongsScreenState extends State<MyCategorySongsScreen> {

  bool isLoading=true;
  getMusicById()async{
    await MusicStyleServices().getMusicStylesById(widget.id, context);
    songsList=Provider.of<MusicStyleProvider>(context,listen: false).songsInCategoryList;
    setState(() {
      isLoading=false;
    });

  }

  List<CategoriesSongModel> songsList=[];

  @override
  void initState() {
    getMusicById();
    // TODO: implement initState
    super.initState();
  }

  TextEditingController songTitleController=TextEditingController();
  TextEditingController singerNameController=TextEditingController();
  TextEditingController songDescriptionController=TextEditingController();

  FilePickerResult? musicFile;
  String selectedCategory="";
  int selectedYear = 2024;

  pickSong() async {
    musicFile = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3', 'wmv'],
    );
  }



  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: blackColor,
          title:  ReusableText(
            title: widget.title,
          ),
          actions: [
            IconButton(onPressed: (){
              setState(() {
                selectedCategory=widget.id.toString();
              });
              buildShowModalBottomSheet(context, screenHeight);


            }, icon: Icon(Icons.add_circle_outline,color: Colors.white,))
          ],
        ),
        body: isLoading?const RecentlyMusicScreenSkeleton():ListView.builder(
          padding: const EdgeInsets.all(14),
          shrinkWrap: true,
          itemCount: songsList.length,
          itemBuilder: (BuildContext context, int index) {
            return InkWell(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) {
                  // return PreacherPodcast(song: song,);
                  return AudioPlay(song: songsList[index],);
                }),);
              },
              child: Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Row(
                  children: [
                    ReusableText(
                      title: index.toString(),
                      size: 18,
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Container(
                      height: 60,
                      width: 80,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        image: songsList[index].coverImageURL!=null?DecorationImage(
                          fit: BoxFit.cover,
                          image: NetworkImage(songsList[index].coverImageURL!),
                        ):const DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage('assets/images/logo.png'),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ReusableText(
                          title: songsList[index].title,
                          color: whiteColor,
                          size: 16,
                          weight: FontWeight.bold,
                        ),
                        ReusableText(
                          title: songsList[index].descriptionOfSong.length>10?"${songsList[index].descriptionOfSong.substring(0,11)}...":songsList[index].descriptionOfSong,
                          color: greyColor,
                          weight: FontWeight.bold,
                        ),
                      ],
                    ),
                    const Spacer(),
                    const Icon(Icons.more_vert,color: whiteColor,),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Future<dynamic> buildShowModalBottomSheet(
      BuildContext context,
      double screenHeight,
      ) {
    return showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(15), topLeft: Radius.circular(15))),
      builder: (BuildContext context) {
        return Padding(
          padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: StatefulBuilder(
            builder: (BuildContext context,
                StateSetter songState) {
              return SizedBox(
                // height: screenHeight * 0.55,
                child: SingleChildScrollView(
                  child: Column(
                    //  clipBehavior: Clip.antiAlias,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(right: 5, top: 5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.red.shade400,
                                  ),
                                  height: 30,
                                  width: 30,
                                  child: const Center(
                                      child: Icon(
                                        Icons.close,
                                        color: Colors.white,
                                      ))),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20)),
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Container(
                                padding:
                                const EdgeInsets.symmetric(vertical: 30),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: indigoColor,
                                ),
                                child: musicFile == null
                                    ? Center(
                                  child: InkWell(
                                    onTap: () {
                                      pickSong();
                                    },
                                    child: const Text(
                                      'Choose MP3 Song',
                                      style: TextStyle(),
                                    ),
                                  ),
                                )
                                    : Text(musicFile!.names.first!)),
                            const SizedBox(
                              height: 15,
                            ),
                            ReusableTextForm(
                              // enabled: false,
                              borderRadius: 10,
                              controller: singerNameController,
                              hintText: "Enter Singer name",
                              onChanged: (value) {
                                //searchProduct(value);
                                songState(() {});
                              },
                              filledColor: Colors.white24,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            ReusableTextForm(
                              // enabled: false,
                              borderRadius: 10,
                              controller: songTitleController,
                              hintText: "Enter Song Title",
                              onChanged: (value) {
                                //searchProduct(value);
                                songState(() {});
                              },
                              filledColor: Colors.white24,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            ReusableTextForm(
                              borderRadius: 10,
                              controller: songDescriptionController,
                              hintText: "Enter Song Description",
                              onChanged: (value) {
                                //searchProduct(value);
                                songState(() {});
                              },
                              filledColor: Colors.white24,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            Row(
                              children: [
                                const Text(
                                  "Year Of Song: ",
                                  style: TextStyle(color: Colors.white),
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                DropdownButtonHideUnderline(
                                    child: SizedBox(
                                      height: 50,
                                      child: DropdownButton(
                                          value: selectedYear,
                                          items: List.generate(50, (index) {
                                            return DropdownMenuItem<int>(
                                                value: 2024 - index,
                                                child: Text(
                                                    (2024 - index).toString()));
                                          }),
                                          onChanged: (value) {
                                            selectedYear = value!;
                                            songState(() {});
                                          }),
                                    ))
                              ],
                            ),
                            const SizedBox(
                              height: 25,
                            ),
                            isLoading?
                            Center(child: CircularProgressIndicator(),):InkWell(
                              onTap: () async {
                                songState((){
                                  isLoading=true;
                                });
                                if (musicFile != null) {
                                  bool response =
                                  await UserSongServices().addSong(
                                    context,
                                    songTitle: songTitleController.text,
                                    songDescription:
                                    songDescriptionController.text,
                                    singer: singerNameController.text,
                                    musicPath: musicFile!.paths.first!,
                                    categoryId: selectedCategory,
                                    year: selectedYear.toString(),
                                  );
                                  if (response && context.mounted) {
                                    songState((){
                                      isLoading=false;
                                    });
                                    await getMusicById();
                                    // Get.showSnackbar(const GetSnackBar(
                                    //   message: "Song Added Successfully",
                                    //   duration: Duration(seconds: 2),
                                    // ));
                                    Navigator.pop(context);
                                  } else {
                                    songState((){
                                      isLoading=false;
                                    });
                                    Navigator.pop(context);
                                    Get.showSnackbar(const GetSnackBar(
                                      message: "Error occurred",
                                      duration: Duration(seconds: 2),
                                    ));
                                  }
                                } else {
                                  songState((){
                                    isLoading=false;
                                  });
                                  Get.showSnackbar(const GetSnackBar(
                                    message: "Song is required",
                                    duration: Duration(seconds: 2),
                                  ));
                                }
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: indigoColor,
                                ),
                                height: 50,
                                width: 150,
                                child: const Center(
                                  child: Text("Upload Song"),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

}
