import 'package:flutter/material.dart';

import '../../utils/color.dart';
import 'my_songs_categories.dart';
import 'my_songs.dart';
class ArtistScreen extends StatefulWidget {
  const ArtistScreen({Key? key}) : super(key: key);

  @override
  State<ArtistScreen> createState() => _ArtistScreenState();
}

class _ArtistScreenState extends State<ArtistScreen> {
 int curentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text("Artists"),
        actions: const [

          Padding(
            padding: EdgeInsets.all(10.0),
            child: Icon(Icons.search, size: 27,),
          ),
        ],
        centerTitle: true,
        elevation: 0,

      ),
      body: Column(children: [

        Padding(
          padding:  const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Column(

            children: [
             // SizedBox(height: 25,),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GestureDetector(
                    onTap: (){
                      setState(() {
                        curentIndex =0;
                      });
                    },
                    child: Container(
                      width: 80,
                      height: 40,
                      decoration:  curentIndex ==0?
                      BoxDecoration(
                        color:indigoColor,

                        borderRadius: BorderRadius.circular(30),
                      ):
                      BoxDecoration(
                        border: Border.all(

                          color:curentIndex ==0?indigoColor:artistSlowColor ,
                        ),

                        borderRadius: BorderRadius.circular(30),
                      ),
                      child:  Center(
                        child: Text(
                          "All Artist",
                          style: TextStyle(color: curentIndex ==0?Colors.white: Colors.grey.shade600),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: (){
                      setState(() {
                        curentIndex =1;
                      });
                    },
                    child: Container(
                      width: 80,
                      height: 40,
                      decoration:  curentIndex ==1?
                      BoxDecoration(
                        color:indigoColor,

                        borderRadius: BorderRadius.circular(30),
                      ):
                      BoxDecoration(
                        border: Border.all(

                          color: curentIndex ==1?indigoColor:artistSlowColor ,
                        ),

                        borderRadius: BorderRadius.circular(30),
                      ),
                      child:  Center(
                        child: Text(
                          "My Artist",
                          style: TextStyle(color:curentIndex ==1?Colors.white: Colors.grey.shade600),
                        ),
                      ),
                    ),
                  ),
                ],
              ),


            ],
          ),
        ),
        curentIndex ==0?const Expanded(
            child: MySongCategories()) : Container(),
        curentIndex ==1?const Expanded(child: MySongs()) : Container(),


      ],)
    );
  }
}
