import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../providers/artist_provider/artist_provider.dart';
import '../../repo/api_consts.dart';
import '../../services/api_services/artist_services/artist_services.dart';
import '../../utils/color.dart';
import '../../widget/reusable_text.dart';
import '../../widget/reusable_textformfield.dart';

// import 'my_category_songs.dart';
class MySongs extends StatefulWidget {
  const MySongs({Key? key}) : super(key: key);

  @override
  State<MySongs> createState() => _MySongsState();
}

class _MySongsState extends State<MySongs> {
  List<String> artistImages = [
    'https://media.istockphoto.com/id/1160768128/photo/rap-musician-in-studio.jpg?s=612x612&w=0&k=20&c=8LzuLliur66CaZnXywhBZzcTRellYlRF3gRCTlSG3XE=',
    'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8Nnx8fGVufDB8fHx8fA%3D%3D',
    'https://www.rollingstone.com/wp-content/uploads/2022/02/5-Tips-for-Any-Artist-Looking-to-Release-New-Music.png',
    'https://bestlifeonline.com/wp-content/uploads/sites/3/2020/04/Prince-performing-in-1985-e1619625440537.jpg?quality=82&strip=all',
    'https://disctopia.com/wp-content/uploads/2023/03/Disctopia-Blog-Banners-2023-2.jpg',
    'https://www.conor-maynard.com/wp-content/uploads/2022/07/Screen-Shot-2022-07-19-at-10.24.48-PM.png',
    'https://blog.sonicbids.com/hs-fs/hubfs/shutterstock_739053811.jpg?width=630&name=shutterstock_739053811.jpg',
    'https://i.pinimg.com/736x/fb/8d/21/fb8d21861a98f99cbf8417413b721333.jpg',
    'https://img.freepik.com/premium-photo/electric-guitar-hd-8k-wallpaper-background-stock-photographic-image_915071-21859.jpg',
    'https://brisketandbagels.com/wp-content/uploads/2021/09/Shakey-Graves.jpg',
  ];
  List<String> names = [
    'Alex',
    'Khakis',
    'Chris',
    'Dodo',
    'Network',
    'Jerkin',
    'Maxi',
    'Shelbi',
    'Json',
    'Jordon',
  ];
  XFile? _selectedImage;

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      _selectedImage = image;
      setState(() {});
    }
  }

  getMyArtists() async {
    Provider.of<ArtistProvider>(context, listen: false).getMyArtists(context);
  }

  @override
  void initState() {
    getMyArtists();
    // TODO: implement initState
    super.initState();
  }

  TextEditingController searchController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController bandNameController = TextEditingController();
  TextEditingController aboutController = TextEditingController();

  late TextEditingController songTitleController;
  late TextEditingController singerNameController;
  late TextEditingController songDescriptionController;

  FilePickerResult? musicFile;
  int selectedYear = 2024;

  pickSong() async {
    musicFile = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3', 'wmv'],
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      child: Consumer<ArtistProvider>(builder: (context, myArtists, _) {
        return Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 8,
          ),
          child: Column(
            children: [
              const SizedBox(height: 15),
              Row(
                children: [
                  Flexible(
                    child: ReusableTextForm(
                      borderRadius: 30,
                      controller: searchController,
                      hintText: "Search artist name",
                      onChanged: (value) {
                        //searchProduct(value);
                        setState(() {});
                      },
                      filledColor: Colors.white24,
                      prefixIcon: const Icon(
                        Icons.search,
                        color: greyColor,
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  GestureDetector(
                    onTap: () {
                      buildShowModalBottomSheet(context, screenHeight);
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: indigoColor,
                        borderRadius: BorderRadius.circular(30),
                      ),
                      height: 50,
                      width: 50,
                      child: const Center(
                        child: Icon(
                          Icons.add,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  )
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: const [
                  Text("My Artists"),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              myArtists.isLoading
                  ? const CircularProgressIndicator()
                  : myArtists.myArtists.isEmpty
                      ? const Text("No Artist Found")
                      : GridView.builder(
                          physics: const ScrollPhysics(),
                          shrinkWrap: true,
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            mainAxisExtent: 190,
                            crossAxisSpacing: 10,
                            mainAxisSpacing: 10,
                            crossAxisCount: 2,
                          ),
                          itemCount: myArtists.myArtists.length,
                          itemBuilder: (BuildContext context, int index) {
                            return GestureDetector(
                              onTap: () {
                                buildShowModalBottomSheet(context, screenHeight);
                                // Navigator.push(context, MaterialPageRoute(builder: (context)=>MyCategorySongs(artist: myArtists.myArtists[index], isMyArtist: true,)));
                              },
                              child: Container(
                                //height: 190,

                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: indigoColor,
                                ),
                                child: Stack(
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          height: 170,
                                          width: double.infinity,
                                          child: ClipRRect(
                                            borderRadius: const BorderRadius.only(
                                              topLeft: Radius.circular(10),
                                              topRight: Radius.circular(10),
                                            ),
                                            child: Image(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(
                                                  myArtists.myArtists[index].picture.replaceAll("public", ApiConstants.baseUrl)),
                                            ),
                                          ),
                                        ),
                                        const Expanded(
                                            child: SizedBox(
                                          height: 1,
                                        )),
                                        ReusableText(
                                          title: myArtists.myArtists[index].artistName,
                                          size: 13,
                                          weight: FontWeight.w600,
                                          color: const Color(0xffFFFFFF),
                                        ),
                                        const Expanded(
                                            child: SizedBox(
                                          height: 1,
                                        )),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
            ],
          ),
        );
      }),
    );
  }

  Future<dynamic> buildShowModalBottomSheet(
    BuildContext context,
    double screenHeight,
  ) {
    return showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(topRight: Radius.circular(15), topLeft: Radius.circular(15))),
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: StatefulBuilder(
            builder: (BuildContext context, void Function(void Function()) setState) {
              return SizedBox(
                // height: screenHeight * 0.55,
                child: SingleChildScrollView(
                  child: Column(
                    //  clipBehavior: Clip.antiAlias,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(right: 5, top: 5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.red.shade400,
                                  ),
                                  height: 30,
                                  width: 30,
                                  child: const Center(
                                      child: Icon(
                                    Icons.close,
                                    color: Colors.white,
                                  ))),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Container(
                                padding: const EdgeInsets.symmetric(vertical: 30),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: indigoColor,
                                ),
                                child: musicFile == null
                                    ? Center(
                                        child: InkWell(
                                          onTap: () {
                                            pickSong();
                                          },
                                          child: const Text(
                                            'Choose MP3 Song',
                                            style: TextStyle(),
                                          ),
                                        ),
                                      )
                                    : Text(musicFile!.names.first!)),
                            const SizedBox(
                              height: 15,
                            ),
                            ReusableTextForm(
                              // enabled: false,
                              borderRadius: 10,
                              controller: singerNameController,
                              hintText: "Enter Singer name",
                              onChanged: (value) {
                                //searchProduct(value);
                                setState(() {});
                              },
                              filledColor: Colors.white24,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            ReusableTextForm(
                              // enabled: false,
                              borderRadius: 10,
                              controller: songTitleController,
                              hintText: "Enter Song Title",
                              onChanged: (value) {
                                //searchProduct(value);
                                setState(() {});
                              },
                              filledColor: Colors.white24,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            ReusableTextForm(
                              borderRadius: 10,
                              controller: songDescriptionController,
                              hintText: "Enter Song Description",
                              onChanged: (value) {
                                //searchProduct(value);
                                setState(() {});
                              },
                              filledColor: Colors.white24,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            Row(
                              children: [
                                const Text(
                                  "Year Of Song: ",
                                  style: TextStyle(color: Colors.white),
                                ),
                                const SizedBox(
                                  width: 30,
                                ),
                                DropdownButtonHideUnderline(
                                    child: SizedBox(
                                  height: 50,
                                  child: DropdownButton(
                                      value: selectedYear,
                                      items: List.generate(50, (index) {
                                        return DropdownMenuItem<int>(value: 2024 - index, child: Text((2024 - index).toString()));
                                      }),
                                      onChanged: (value) {
                                        selectedYear = value!;
                                        setState(() {});
                                      }),
                                ))
                              ],
                            ),
                            const SizedBox(
                              height: 25,
                            ),
                            InkWell(
                              // onTap: () async {
                              //   if (musicFile != null) {
                              //     bool response =
                              //     await AdminSongServices().addSong(
                              //       context,
                              //       songTitle: songTitleController.text,
                              //       songDescription:
                              //       songDescriptionController.text,
                              //       singer: singerNameController.text,
                              //       musicPath: musicFile!.paths.first!,
                              //       categoryId: "2",
                              //       year: selectedYear.toString(),
                              //     );
                              //     if (response && context.mounted) {
                              //       Get.showSnackbar(const GetSnackBar(
                              //         message: "Song Added Successfully",
                              //         duration: Duration(seconds: 2),
                              //       ));
                              //       Navigator.pop(context);
                              //     } else {
                              //       Navigator.pop(context);
                              //       Get.showSnackbar(const GetSnackBar(
                              //         message: "Error occurred",
                              //         duration: Duration(seconds: 2),
                              //       ));
                              //     }
                              //   } else {
                              //     Get.showSnackbar(const GetSnackBar(
                              //       message: "Song is required",
                              //       duration: Duration(seconds: 2),
                              //     ));
                              //   }
                              // },
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: indigoColor,
                                ),
                                height: 50,
                                width: 150,
                                child: const Center(
                                  child: Text("Upload Song"),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
