import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../providers/user_songs_categories_provider/user_songs_categories_provider.dart';
import '../../repo/api_consts.dart';
import '../../utils/color.dart';
import '../../widget/reusable_text.dart';
import '../../widget/reusable_textformfield.dart';
import 'my_category_songs_screen.dart';
class MySongCategories extends StatefulWidget {

  const MySongCategories({Key? key}) : super(key: key);

  @override
  State<MySongCategories> createState() => _MySongCategoriesState();
}

class _MySongCategoriesState extends State<MySongCategories> {
  List<String> artistImages = [
    'https://media.istockphoto.com/id/1160768128/photo/rap-musician-in-studio.jpg?s=612x612&w=0&k=20&c=8LzuLliur66CaZnXywhBZzcTRellYlRF3gRCTlSG3XE=',
    'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8Nnx8fGVufDB8fHx8fA%3D%3D',
    'https://www.rollingstone.com/wp-content/uploads/2022/02/5-Tips-for-Any-Artist-Looking-to-Release-New-Music.png',
    'https://bestlifeonline.com/wp-content/uploads/sites/3/2020/04/Prince-performing-in-1985-e1619625440537.jpg?quality=82&strip=all',
    'https://disctopia.com/wp-content/uploads/2023/03/Disctopia-Blog-Banners-2023-2.jpg',
    'https://www.conor-maynard.com/wp-content/uploads/2022/07/Screen-Shot-2022-07-19-at-10.24.48-PM.png',
    'https://blog.sonicbids.com/hs-fs/hubfs/shutterstock_739053811.jpg?width=630&name=shutterstock_739053811.jpg',
    'https://i.pinimg.com/736x/fb/8d/21/fb8d21861a98f99cbf8417413b721333.jpg',
    'https://img.freepik.com/premium-photo/electric-guitar-hd-8k-wallpaper-background-stock-photographic-image_915071-21859.jpg',
    'https://brisketandbagels.com/wp-content/uploads/2021/09/Shakey-Graves.jpg',
  ];
  List <String> names = [
    'Alex',
    'Khakis',
    'Chris',
    'Dodo',
    'Network',
    'Jerkin',
    'Maxi',
    'Shelbi',
    'Json',
    'Jordon',
  ];
  List <Color> containerColor = [
    indigoColor,
    greenColor,
    eventsColor,
    peopleColor,
    storeColor,
    indigoColor,
    recntsColor,
    eventsColor,
    peopleColor,
    storeColor,

  ];

  bool isLoading=false;

  @override
  void initState() {
    Provider.of<UserSongsCategoriesProvider>(context,listen: false).getCategories(context);
    // TODO: implement initState
    super.initState();
  }


  TextEditingController songTitleController=TextEditingController();
   TextEditingController singerNameController=TextEditingController();
   TextEditingController songDescriptionController=TextEditingController();

  FilePickerResult? musicFile;
  String selectedCategory="";
  int selectedYear = 2024;

  pickSong() async {
    musicFile = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3', 'wmv'],
    );
  }


  @override
  Widget build(BuildContext context) {

    return SingleChildScrollView(

      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8,),
        child: Column(
          children: [
            Row(
              children: const [
                Text("Categories"),
              ],
            ),
            const SizedBox(height: 10,),
            Consumer<UserSongsCategoriesProvider>(
              builder: (context,category,_) {
                return GridView.builder(
                  physics: const ScrollPhysics(),
                      shrinkWrap: true,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    mainAxisExtent: 190,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    crossAxisCount: 2,

                  ),
                  itemCount: category.allCategories.length,
                  itemBuilder: (BuildContext context, int index) {

                    return GestureDetector(
                      onTap: (){
                        Get.to(()=>MyCategorySongsScreen(id: category.allCategories[index].id, title: "My Songs"));
                       },
                      child: Container(
                        //height: 190,

                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color:indigoColor,
                        ),
                        child: Stack(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children:  [
                                SizedBox(
                                  height: 170,

                                  width: double.infinity,
                                  child: ClipRRect(
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(10),
                                      topRight: Radius.circular(10),
                                    ),
                                    child: Image(
                                      fit: BoxFit.cover,
                                      image: AssetImage('assets/images/app_icon.jpeg'),
                                    ),
                                  ),
                                ),
                                const Expanded(child: SizedBox(height: 1,)),



                                ReusableText(
                                  title: category.allCategories[index].categoryName,
                                  size: 13,
                                  weight: FontWeight.w600,
                                  color: const Color(0xffFFFFFF),
                                ),
                                const Expanded(child: SizedBox(height: 1,)),

                              ],
                            ),

                          ],
                        ),
                      ),
                    );

                  },
                );
              }
            ),
          ],
        ),
      ),
    );
  }


}
