import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/api_models/user_model/user_model.dart';
import '../model/gamification_models.dart';
import '../services/achievement_service.dart';
import '../utils/name_utils.dart';
import '../widget/confetti_widget.dart';
import 'auth_screen/login_screen.dart';
import 'edit_profile.dart';
import 'new_reels.dart';


class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  /// Variables to hold the user's profile data
  String _firstName = '';
  String _lastName = '';
  String? _email;
  String? _profileImage;
  bool _isPaid = false;

  bool _isLoading = false;

  // Gamification variables
  int _dailyStreak = 0;
  int _totalPoints = 0;
  int _level = 1;
  List<Achievement> _achievements = [];
  String? _currentBadge;

  // Image picker instance
  final ImagePicker _picker = ImagePicker();

  // Method to pick and upload profile image
  Future<void> _pickAndUploadImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );

      if (image != null) {
        EasyLoading.show(status: 'Uploading image...');
        
        // Upload to Firebase Storage
        final user = FirebaseAuth.instance.currentUser;
        if (user == null) return;

        final storageRef = FirebaseStorage.instance
            .ref()
            .child('profile_images')
            .child('${user.uid}.jpg');

        final file = File(image.path);
        await storageRef.putFile(file);
        
        // Get download URL
        final downloadURL = await storageRef.getDownloadURL();
        
        // Update Firestore
        await FirebaseFirestore.instance
            .collection('usersData')
            .doc(user.uid)
            .update({'profileImage': downloadURL});
        
        // Update local state
        setState(() {
          _profileImage = downloadURL;
        });
        
        EasyLoading.showSuccess('Profile image updated!');
      }
    } catch (e) {
      EasyLoading.showError('Failed to upload image: $e');
      debugPrint('Error uploading image: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this, initialIndex: 0);

    _loadProfileData();
    _loadGamificationData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  /// Load gamification data
  Future<void> _loadGamificationData() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      // Load user's gamification data
      final doc = await FirebaseFirestore.instance
          .collection('userRewards')
          .doc(user.uid)
          .get();

      if (doc.exists) {
        final data = doc.data()!;
        setState(() {
          _dailyStreak = data['dailyStreak'] ?? 0;
          _totalPoints = data['totalPoints'] ?? 0;
          _level = data['level'] ?? 1;
        });
      }

      // Load achievements
      await _loadAchievements();
      
      // Check daily login
      await _checkDailyLogin();
      
      // Check and unlock achievements
      await AchievementService.checkAndUnlockAchievements(user.uid);
      
      // Check for newly unlocked achievements and show notifications
      await _checkForNewAchievements();
    } catch (e) {
      debugPrint('Error loading gamification data: $e');
    }
  }

  /// Load user achievements
  Future<void> _loadAchievements() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      // Initialize achievements if they don't exist
      await AchievementService.initializeUserAchievements(user.uid);
      
      // Load achievements using the service
      final achievements = await AchievementService.getUserAchievements(user.uid);
      
      setState(() {
        _achievements = achievements;
      });
      
      // Get current badge
      _getCurrentBadge();
    } catch (e) {
      debugPrint('Error loading achievements: $e');
    }
  }

  /// Get current achievement badge
  void _getCurrentBadge() {
    if (_achievements.isNotEmpty) {
      // Get the most recent unlocked achievement
      final unlockedAchievements = _achievements.where((a) => a.isUnlocked).toList();
      if (unlockedAchievements.isNotEmpty) {
        // Sort by points to get the highest achievement
        unlockedAchievements.sort((a, b) => b.points.compareTo(a.points));
        setState(() {
          _currentBadge = unlockedAchievements.first.title;
        });
      }
    }
  }



  /// Check daily login and update streak
  Future<void> _checkDailyLogin() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      
      final doc = await FirebaseFirestore.instance
          .collection('userRewards')
          .doc(user.uid)
          .get();

      if (doc.exists) {
        final data = doc.data()!;
        final lastLogin = data['lastLogin'];
        
        if (lastLogin != null) {
          final lastLoginDate = (lastLogin as Timestamp).toDate();
          final lastLoginDay = DateTime(lastLoginDate.year, lastLoginDate.month, lastLoginDate.day);
          
          if (today.difference(lastLoginDay).inDays == 1) {
            // Consecutive day
            final newStreak = (data['dailyStreak'] ?? 0) + 1;
            final newPoints = (data['totalPoints'] ?? 0) + 10;
            
            await FirebaseFirestore.instance
                .collection('userRewards')
                .doc(user.uid)
                .update({
              'dailyStreak': newStreak,
              'totalPoints': newPoints,
              'lastLogin': Timestamp.now(),
            });
            
            setState(() {
              _dailyStreak = newStreak;
              _totalPoints = newPoints;
            });
            
            _showStreakReward(newStreak);
          } else if (today.difference(lastLoginDay).inDays > 1) {
            // Streak broken
            await FirebaseFirestore.instance
                .collection('userRewards')
                .doc(user.uid)
                .update({
              'dailyStreak': 1,
              'totalPoints': (data['totalPoints'] ?? 0) + 10,
              'lastLogin': Timestamp.now(),
            });
            
            setState(() {
              _dailyStreak = 1;
              _totalPoints = (data['totalPoints'] ?? 0) + 10;
            });
          }
        } else {
          // First time login
          await FirebaseFirestore.instance
              .collection('userRewards')
              .doc(user.uid)
              .set({
            'dailyStreak': 1,
            'totalPoints': 10,
            'lastLogin': Timestamp.now(),
            'level': 1,
          });
          
          setState(() {
            _dailyStreak = 1;
            _totalPoints = 10;
          });
        }
      } else {
        // Create new user rewards document
        await FirebaseFirestore.instance
            .collection('userRewards')
            .doc(user.uid)
            .set({
          'dailyStreak': 1,
          'totalPoints': 10,
          'lastLogin': Timestamp.now(),
          'level': 1,
        });
        
        setState(() {
          _dailyStreak = 1;
          _totalPoints = 10;
        });
      }
    } catch (e) {
      debugPrint('Error checking daily login: $e');
    }
  }

  /// Show streak reward
  void _showStreakReward(int streak) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.local_fire_department, color: Colors.orange, size: 30),
            SizedBox(width: 10),
            Text(
              'Daily Streak!',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Text(
          'Amazing! You\'ve logged in for $streak consecutive days!\n\n+10 points earned! 🔥',
          style: TextStyle(color: Colors.white, fontSize: 16),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Awesome!',
              style: TextStyle(color: Colors.purple, fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  /// Check for newly unlocked achievements and show notifications
  Future<void> _checkForNewAchievements() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      // Get current achievements
      final currentAchievements = await AchievementService.getUserAchievements(user.uid);
      
      // Find newly unlocked achievements
      for (final achievement in currentAchievements) {
        if (achievement.isUnlocked && 
            achievement.unlockedAt != null &&
            achievement.unlockedAt!.toDate().isAfter(DateTime.now().subtract(Duration(minutes: 5)))) {
          // Show notification for recently unlocked achievement
          _showAchievementUnlocked(achievement);
        }
      }
      
      // Update local achievements
      setState(() {
        _achievements = currentAchievements;
      });
      
      // Update current badge
      _getCurrentBadge();
    } catch (e) {
      debugPrint('Error checking for new achievements: $e');
    }
  }





  /// Show achievement unlocked notification
  void _showAchievementUnlocked(Achievement achievement) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Stack(
        children: [
          // Confetti background
          ConfettiWidget(isActive: true),
          
          // Achievement dialog
          Center(
            child: Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                padding: EdgeInsets.all(30),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.amber.shade600, Colors.orange.shade600],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.amber.withOpacity(0.5),
                      blurRadius: 30,
                      offset: const Offset(0, 15),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Celebration animation
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 800),
                      builder: (context, value, child) {
                        return Transform.scale(
                          scale: value,
                          child: Container(
                            padding: EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              achievement.icon,
                              color: Colors.amber.shade800,
                              size: 80,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 25),
                    
                    // Achievement title with animation
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 600),
                      builder: (context, value, child) {
                        return Transform.translate(
                          offset: Offset(0, 20 * (1 - value)),
                          child: Opacity(
                            opacity: value,
                            child: Text(
                              'Achievement Unlocked!',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 15),
                    
                    // Achievement name
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 800),
                      builder: (context, value, child) {
                        return Transform.translate(
                          offset: Offset(0, 20 * (1 - value)),
                          child: Opacity(
                            opacity: value,
                            child: Text(
                              achievement.title,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 10),
                    
                    // Achievement description
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 1000),
                      builder: (context, value, child) {
                        return Transform.translate(
                          offset: Offset(0, 20 * (1 - value)),
                          child: Opacity(
                            opacity: value,
                            child: Text(
                              achievement.description,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 25),
                    
                    // Points earned with animation
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0.0, end: 1.0),
                      duration: Duration(milliseconds: 1200),
                      builder: (context, value, child) {
                        return Transform.scale(
                          scale: value,
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(25),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 10,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.star, color: Colors.amber.shade800, size: 24),
                                SizedBox(width: 10),
                                Text(
                                  '+${achievement.points} Points!',
                                  style: TextStyle(
                                    color: Colors.amber.shade800,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
    
    // Auto-close after 3 seconds
    Future.delayed(Duration(seconds: 3), () {
      if (Navigator.canPop(context)) {
        Navigator.pop(context);
      }
    });
  }

  /// Fetch the user's profile data from Firestore and store it locally
  Future<void> _loadProfileData() async {
    setState(() => _isLoading = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        setState(() => _isLoading = false);
        return;
      }

      // Read from Firestore
      final doc = await FirebaseFirestore.instance.collection('usersData').doc(user.uid).get();

      if (doc.exists) {
        final data = doc.data()!;
        setState(() {
          _firstName = data['firstName'] ?? '';
          _lastName = data['secondName'] ?? '';
          _email = user.email;
          _profileImage = data['profileImage'];
          _isPaid = (data['isPaid'] ?? false) as bool;
        });
      }
    } catch (e) {
      debugPrint('Error loading user data: $e');
    }

    setState(() => _isLoading = false);
  }

  Future<void> _logoutUser() async {
    try {
      await FirebaseAuth.instance.signOut();
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(UserModelFields.email);
      await prefs.remove(UserModelFields.userId);
      await prefs.remove(UserModelFields.deviceId);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );
    } catch (e) {
      EasyLoading.showError("Logout failed");
      debugPrint("Logout Error: $e");
    }
  }

  void _editProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const EditProfileScreen()),
    ).then((_) {
      _loadProfileData();
    });
  }

  @override
  Widget build(BuildContext context) {
    final myDocRef = FirebaseFirestore.instance.collection('usersData').doc(FirebaseAuth.instance.currentUser!.uid);
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Profile",
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Colors.white),
            )
          : Column(
              children: [
                // User Info Section
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          GestureDetector(
                            onTap: _pickAndUploadImage,
                            child: Stack(
                              children: [
                                CircleAvatar(
                                  radius: 32,
                                  backgroundImage: _profileImage != null && _profileImage!.isNotEmpty
                                      ? NetworkImage(_profileImage!)
                                      : null,
                                  backgroundColor: Colors.grey[700],
                                  child: _profileImage == null || _profileImage!.isEmpty
                                      ? const Icon(
                                          Icons.person,
                                          color: Colors.white,
                                          size: 32,
                                        )
                                      : null,
                                ),
                                // Blue Tick Badge for verified users
                                if (_isPaid)
                                  Positioned(
                                    bottom: 2,
                                    right: 2,
                                    child: Container(
                                      padding: EdgeInsets.all(3),
                                      decoration: BoxDecoration(
                                        color: Colors.blue,
                                        shape: BoxShape.circle,
                                        border: Border.all(color: Colors.white, width: 2),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.blue.withOpacity(0.5),
                                            blurRadius: 4,
                                            offset: const Offset(0, 2),
                                          ),
                                        ],
                                      ),
                                      child: Icon(Icons.verified, color: Colors.white, size: 10),
                                    ),
                                  ),
                                // Achievement Badge
                                if (_currentBadge != null)
                                  Positioned(
                                    top: 2,
                                    right: 2,
                                    child: Container(
                                      padding: EdgeInsets.all(3),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [Colors.amber.shade600, Colors.orange.shade600],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                        shape: BoxShape.circle,
                                        border: Border.all(color: Colors.white, width: 2),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.amber.withOpacity(0.5),
                                            blurRadius: 4,
                                            offset: const Offset(0, 2),
                                          ),
                                        ],
                                      ),
                                      child: Icon(Icons.emoji_events, color: Colors.white, size: 10),
                                    ),
                                  ),
                                // Camera icon for editing
                                Positioned(
                                  bottom: 0,
                                  left: 0,
                                  child: Container(
                                    padding: const EdgeInsets.all(4),
                                    decoration: BoxDecoration(
                                      color: Colors.purple,
                                      shape: BoxShape.circle,
                                      border: Border.all(color: Colors.white, width: 2),
                                    ),
                                    child: const Icon(
                                      Icons.camera_alt,
                                      color: Colors.white,
                                      size: 16,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 16),
                          // Name, handle, verified
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  NameUtils.getDisplayName(_firstName, _lastName),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    Text(
                                      _email != null ? '@${_email!.split('@').first}' : '',
                                      style: const TextStyle(
                                        color: Colors.grey,
                                        fontSize: 14,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    if (_isPaid)
                                      const Icon(
                                        Icons.check_circle,
                                        color: Colors.blue,
                                        size: 16,
                                      ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      
                      // Stats Row
                      StreamBuilder<DocumentSnapshot>(
                        stream: myDocRef.snapshots(),
                        builder: (context, meSnap) {
                          if (meSnap.connectionState == ConnectionState.waiting) {
                            return const Center(
                              child: CircularProgressIndicator(color: Colors.white),
                            );
                          }
                          final meData = meSnap.data?.data() as Map<String, dynamic>? ?? {};
                          final followers = List<String>.from(meData['followers'] ?? []);
                          final following = List<String>.from(meData['following'] ?? []);

                          return StreamBuilder<QuerySnapshot>(
                            stream: FirebaseFirestore.instance
                                .collection('songs')
                                .where('userId', isEqualTo: FirebaseAuth.instance.currentUser?.uid)
                                .snapshots(),
                            builder: (context, songsSnap) {
                              if (songsSnap.connectionState == ConnectionState.waiting) {
                                return const Center(
                                  child: CircularProgressIndicator(color: Colors.white),
                                );
                              }
                              final songCount = (songsSnap.data?.docs.length ?? 0).toInt();

                              return StreamBuilder<QuerySnapshot>(
                                stream: FirebaseFirestore.instance
                                    .collection('reels')
                                    .where('userId', isEqualTo: FirebaseAuth.instance.currentUser?.uid)
                                    .snapshots(),
                                builder: (context, videosSnap) {
                                  if (videosSnap.connectionState == ConnectionState.waiting) {
                                    return const Center(
                                      child: CircularProgressIndicator(color: Colors.white),
                                    );
                                  }
                                  final videoCount = (videosSnap.data?.docs.length ?? 0).toInt();

                                  return Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                    children: [
                                      _buildStatItem(videoCount.toString(), 'Videos'),
                                      _buildStatItem(followers.length.toString(), 'Followers'),
                                      _buildStatItem(following.length.toString(), 'Followings'),
                                    ],
                                  );
                                },
                              );
                            },
                          );
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Tab Bar
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey[900],
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: TabBar(
                    controller: _tabController,
                    indicator: BoxDecoration(
                      color: Colors.purple,
                      borderRadius: BorderRadius.circular(25),
                    ),
                    labelColor: Colors.white,
                    unselectedLabelColor: Colors.grey,
                    indicatorSize: TabBarIndicatorSize.tab,
                    dividerColor: Colors.transparent,
                    tabs: const [
                      Tab(
                        icon: Icon(Icons.photo),
                        text: 'Photos',
                      ),
                      Tab(
                        icon: Icon(Icons.video_library),
                        text: 'Videos',
                      ),
                      Tab(
                        icon: Icon(Icons.music_note),
                        text: 'Songs',
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Tab Bar View
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      // Photos Tab
                      _buildPhotosTab(),
                      // Videos Tab
                      _buildVideosTab(),
                      // Songs Tab
                      _buildSongsTab(),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildPhotosTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('posts')
          .where('userId', isEqualTo: FirebaseAuth.instance.currentUser?.uid)
          .where('type', isEqualTo: 'image')
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Colors.white));
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(
            child: Text(
              'No photos uploaded yet',
              style: TextStyle(color: Colors.grey),
            ),
          );
        }

        return GridView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            final doc = snapshot.data!.docs[index];
            final data = doc.data() as Map<String, dynamic>;
            final imageUrl = data['fileUrl'] ?? '';
            
            return ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                imageUrl,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: Colors.grey[800],
                    child: const Icon(Icons.error, color: Colors.white),
                  );
                },
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildVideosTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('reels')
          .where('userId', isEqualTo: FirebaseAuth.instance.currentUser?.uid)
          .snapshots(),
      builder: (context, snapshot) {


        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Colors.white));
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(
            child: Text(
              'No videos uploaded yet',
              style: TextStyle(color: Colors.grey),
            ),
          );
        }

        return GridView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            final doc = snapshot.data!.docs[index];
            final data = doc.data() as Map<String, dynamic>;
            final videoUrl = data['videoUrl'] ?? '';
            final description = data['description'] ?? '';
            

            
            return ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // Video thumbnail or placeholder
                  Container(
                    color: Colors.grey[800],
                    child: const Icon(Icons.play_circle_outline, color: Colors.white, size: 50),
                  ),
                  // Play button overlay
                  Positioned(
                    top: 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.play_arrow,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                  // Clickable video item
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        // Navigate to reels page and play this specific video
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ReelsScreen(showBackButton: true),
                          ),
                        );
                      },
                      borderRadius: BorderRadius.circular(8),
                      splashColor: Colors.purple.withOpacity( 0.3),
                      highlightColor: Colors.purple.withOpacity( 0.1),
                      child: Container(
                        color: Colors.transparent,
                      ),
                    ),
                  ),
                  // Description overlay if available
                  if (description.isNotEmpty)
                    Positioned(
                      bottom: 8,
                      left: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          description,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  // Tap to play indicator
                  Positioned(
                    bottom: description.isNotEmpty ? 40 : 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.black87,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Text(
                        'Tap to play',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                  // Video icon
                  Positioned(
                    top: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Icon(Icons.videocam, color: Colors.white, size: 16),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildSongsTab() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('songs')
          .where('userId', isEqualTo: FirebaseAuth.instance.currentUser?.uid)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Colors.white));
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(
            child: Text(
              'No songs uploaded yet',
              style: TextStyle(color: Colors.grey),
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            final doc = snapshot.data!.docs[index];
            final data = doc.data() as Map<String, dynamic>;
            final songName = data['songName'] ?? 'Unknown Song';
            final artistName = data['artistName'] ?? 'Unknown Artist';
            
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[900],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.purple,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.music_note, color: Colors.white, size: 24),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          songName,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          artistName,
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.play_arrow, color: Colors.white),
                    onPressed: () {
                      // TODO: Implement song playback
                    },
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildStatItem(String count, String label) {
    return Column(
      children: [
        Text(
          count,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 14,
          ),
        ),
      ],
    );
  }
}
