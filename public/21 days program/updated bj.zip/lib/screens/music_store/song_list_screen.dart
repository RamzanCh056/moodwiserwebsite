import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../providers/song_provider/song_provider.dart';
import 'audio_player_screen.dart';
import 'create_song_screen.dart';
import 'music_store_model.dart';

class SongListScreen extends StatefulWidget {
  final MusicStoreModel store;
  const SongListScreen({required this.store, Key? key}) : super(key: key);

  @override
  State<SongListScreen> createState() => _SongListScreenState();
}

class _SongListScreenState extends State<SongListScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SongProvider>().fetchSongs(widget.store.id);
    });
  }

  void _deleteSong(BuildContext context, String songId) async {
    final currentUserId = FirebaseAuth.instance.currentUser?.uid;
    
    // Server-side ownership verification
    if (widget.store.userId != currentUserId) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You can only delete songs from your own store'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[850],
        title: const Text('Delete Song', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Are you sure you want to delete this song? This action cannot be undone.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel', style: TextStyle(color: Colors.blue)),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      try {
        await context.read<SongProvider>().deleteSong(songId);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Song deleted successfully'),
            backgroundColor: Colors.green,
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to delete song: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final songs = context.watch<SongProvider>().songs;
    final currentUserId = FirebaseAuth.instance.currentUser?.uid;
    final isStoreOwner = widget.store.userId == currentUserId;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          color: Colors.white,
          onPressed: () => Navigator.of(context).pop(),
        ),
        backgroundColor: Colors.black,
        elevation: 0,
        title: Text(
          widget.store.name,
          style: const TextStyle(color: Colors.white),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        itemCount: songs.length,
        itemBuilder: (_, i) {
          final s = songs[i];
          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(8),
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              tileColor: Colors.transparent,
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: s.coverImageUrl.isNotEmpty
                    ? Image.network(s.coverImageUrl, width: 48, height: 48, fit: BoxFit.cover)
                    : Container(
                        width: 48,
                        height: 48,
                        color: Colors.grey[800],
                        child: const Icon(Icons.music_note, color: Colors.white24),
                      ),
              ),
              title: Text(
                s.title,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
              ),
              subtitle: Text(
                s.singer,
                style: TextStyle(color: Colors.grey.shade400),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (isStoreOwner) ...[
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CreateSongScreen(
                            storeId: widget.store.id,
                            song: s, // Pass the song for editing
                          ),
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deleteSong(context, s.id),
                    ),
                  ],
                  const Icon(Icons.play_arrow, color: Colors.white70),
                ],
              ),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AudioPlayerScreen(song: s)),
              ),
            ),
          );
        },
      ),
      floatingActionButton: isStoreOwner
          ? FloatingActionButton(
              backgroundColor: Colors.grey[800],
              elevation: 2,
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CreateSongScreen(storeId: widget.store.id),
                ),
              ),
              child: const Icon(Icons.add, color: Colors.white),
            )
          : null,
    );
  }
}
