
import 'package:beatjerky/screens/music_store/song_model.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import '../../utils/color.dart';

class AudioPlayerScreen extends StatefulWidget {
  final SongModel song;
  const AudioPlayerScreen({required this.song, Key? key}) : super(key: key);
  @override
  State<AudioPlayerScreen> createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<AudioPlayerScreen> {
  late AudioPlayer _player;
  @override
  void initState() {
    super.initState();
    _player = AudioPlayer()..setUrl(widget.song.fileUrl);
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      backgroundColor: blackColor,
      appBar: AppBar(title: Text(widget.song.title)),
      body: Column(children: [
        const SizedBox(height: 20),
        CircleAvatar(
            radius: 100,
            backgroundImage: widget.song.coverImageUrl.isNotEmpty ? NetworkImage(widget.song.coverImageUrl) : null,
            backgroundColor: Colors.grey[800]),
        Text(widget.song.title, style: const TextStyle(color: whiteColor, fontSize: 24)),
        Text(widget.song.singer, style: const TextStyle(color: greyColor)),
        StreamBuilder<Duration>(
            stream: _player.positionStream,
            builder: (_, snap) {
              final pos = snap.data ?? Duration.zero;
              return Slider(
                  value: pos.inSeconds.toDouble(),
                  max: (_player.duration?.inSeconds.toDouble() ?? 0),
                  onChanged: (v) => _player.seek(Duration(seconds: v.toInt())));
            }),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton(
              icon: const Icon(Icons.replay_10),
              color: whiteColor,
              onPressed: () => _player.seek(_player.position - const Duration(seconds: 10))),
          StreamBuilder<bool>(
              stream: _player.playingStream,
              builder: (_, s) {
                final playing = s.data ?? false;
                return IconButton(
                    icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                    color: whiteColor,
                    onPressed: () => playing ? _player.pause() : _player.play());
              }),
          IconButton(
              icon: const Icon(Icons.forward_10),
              color: whiteColor,
              onPressed: () => _player.seek(_player.position + const Duration(seconds: 10)))
        ])
      ]));
}
