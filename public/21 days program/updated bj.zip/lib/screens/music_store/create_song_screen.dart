import 'dart:io';

import 'package:beatjerky/screens/music_store/song_model.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../providers/song_provider/song_provider.dart';
import '../../utils/color.dart';

class CreateSongScreen extends StatefulWidget {
  final String storeId;
  final SongModel? song;
  const CreateSongScreen({
    required this.storeId,
    this.song,
    Key? key,
  }) : super(key: key);

  @override
  State<CreateSongScreen> createState() => _CreateSongScreenState();
}

class _CreateSongScreenState extends State<CreateSongScreen> {
  final _form = GlobalKey<FormState>();
  final _titleC = TextEditingController();
  final _singerC = TextEditingController();
  final _descC = TextEditingController();
  final _priceC = TextEditingController();
  int _year = DateTime.now().year;
  File? _file, _cover;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.song != null) {
      _titleC.text = widget.song!.title;
      _singerC.text = widget.song!.singer;
      _descC.text = widget.song!.description;
      _priceC.text = widget.song!.price.toString();
      _year = widget.song!.year;
    }
  }

  @override
  void dispose() {
    _titleC.dispose();
    _singerC.dispose();
    _descC.dispose();
    _priceC.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp3'],
    );
    if (res != null) setState(() => _file = File(res.files.first.path!));
  }

  Future<void> _pickCover() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (x != null) setState(() => _cover = File(x.path));
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    if (widget.song == null && _file == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select an MP3 file')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      if (widget.song == null) {
        // Create new song
        await context.read<SongProvider>().addSong(
              storeId: widget.storeId,
              title: _titleC.text,
              singer: _singerC.text,
              description: _descC.text,
              price: double.parse(_priceC.text),
              year: _year,
              file: _file,
              coverImage: _cover,
            );
      } else {
        // Update existing song
        await context.read<SongProvider>().updateSong(
              songId: widget.song!.id,
              title: _titleC.text,
              singer: _singerC.text,
              description: _descC.text,
              price: double.parse(_priceC.text),
              year: _year,
              file: _file,
              coverImage: _cover,
            );
      }
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(widget.song == null ? 'Song added successfully' : 'Song updated successfully'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to ${widget.song == null ? 'add' : 'update'} song: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          color: Colors.white,
          onPressed: () => Navigator.of(context).pop(),
        ),
        backgroundColor: Colors.black,
        elevation: 0,
        title: Text(
          widget.song == null ? 'Add Song' : 'Edit Song',
          style: const TextStyle(color: Colors.white),
        ),
      ),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _form,
              child: ListView(
                children: [
                  _buildDarkTextField(
                    controller: _titleC,
                    labelText: 'Title',
                    validator: (v) => v!.isEmpty ? 'Enter title' : null,
                  ),
                  const SizedBox(height: 7),
                  _buildDarkTextField(
                    controller: _singerC,
                    labelText: 'Singer',
                    validator: (v) => v!.isEmpty ? 'Enter singer' : null,
                  ),
                  const SizedBox(height: 7),
                  _buildDarkTextField(
                    controller: _descC,
                    labelText: 'Description',
                    validator: (v) => v!.isEmpty ? 'Enter description' : null,
                  ),
                  const SizedBox(height: 7),
                  _buildDarkTextField(
                    controller: _priceC,
                    labelText: 'Price',
                    keyboardType: TextInputType.number,
                    validator: (v) => double.tryParse(v!) == null ? 'Enter valid price' : null,
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[800],
                    ),
                    onPressed: _isLoading ? null : _pickFile,
                    child: Text(
                      _file == null ? 'Pick MP3' : 'MP3 Selected',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[800],
                    ),
                    onPressed: _isLoading ? null : _pickCover,
                    child: Text(
                      _cover == null ? 'Pick Cover Image' : 'Cover Selected',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<int>(
                    value: _year,
                    dropdownColor: Colors.grey[900],
                    style: const TextStyle(color: Colors.white),
                    decoration: _buildDropdownDecoration('Year'),
                    items: List.generate(
                      20,
                      (i) => DropdownMenuItem(
                        value: DateTime.now().year - i,
                        child: Text('${DateTime.now().year - i}'),
                      ),
                    ),
                    onChanged: _isLoading ? null : (v) => setState(() => _year = v!),
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: indigoColor,
                    ),
                    onPressed: _isLoading ? null : _save,
                    child: _isLoading
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: Colors.black,
                              strokeWidth: 2,
                            ),
                          )
                        : Text(
                            widget.song == null ? 'Add Song' : 'Update Song',
                            style: const TextStyle(color: Colors.black),
                          ),
                  ),
                ],
              ),
            ),
          ),
          if (_isLoading)
            Container(
              color: Colors.black45,
              child: const Center(child: CircularProgressIndicator()),
            ),
        ],
      ),
    );
  }

  Widget _buildDarkTextField({
    required TextEditingController controller,
    required String labelText,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      style: const TextStyle(color: Colors.white),
      keyboardType: keyboardType,
      validator: validator,
      decoration: InputDecoration(
        labelText: labelText,
        labelStyle: const TextStyle(color: Colors.grey),
        filled: true,
        fillColor: Colors.grey[900],
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey.shade700),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: indigoColor),
        ),
      ),
    );
  }

  InputDecoration _buildDropdownDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.grey),
      filled: true,
      fillColor: Colors.grey[900],
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.grey.shade700),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: indigoColor),
      ),
    );
  }
}
