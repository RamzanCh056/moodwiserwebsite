import 'dart:async';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'notification_model.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  List<NotificationViewModel> newNotifications = [];
  List<NotificationViewModel> pastNotifications = [];
  StreamSubscription? _subscription;
  String? userId;

  @override
  void initState() {
    super.initState();
    userId = _auth.currentUser?.uid;
    log("User ID: $userId");
    if (userId != null) {
      _startListeningToNotifications();
    }
  }

  void _startListeningToNotifications() {
    _subscription = FirebaseFirestore.instance
        .collection('notifications')
        .doc(userId)
        .collection('userNotifications')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .listen((snapshot) {
      List<NotificationViewModel> all = snapshot.docs
          .map((doc) => NotificationViewModel.fromFirestore(
                doc.id,
                doc.data() as Map<String, dynamic>,
              ))
          .toList();

      setState(() {
        newNotifications = all.where((n) => !n.isRead).toList();
        pastNotifications = all.where((n) => n.isRead).toList();
      });
    });
  }

  Future<void> _markAsRead(String notificationId) async {
    if (userId == null) return;
    try {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(userId)
          .collection('userNotifications')
          .doc(notificationId)
          .update({'isRead': true});
    } catch (e) {
      print('Failed to mark notification as read: $e');
    }
  }

  Future<void> _markAllAsRead() async {
    if (userId == null || newNotifications.isEmpty) return;
    try {
      final batch = FirebaseFirestore.instance.batch();
      for (var n in newNotifications) {
        final docRef = FirebaseFirestore.instance
            .collection('notifications')
            .doc(userId)
            .collection('userNotifications')
            .doc(n.id);
        batch.update(docRef, {'isRead': true});
      }
      await batch.commit();
    } catch (e) {
      print('Error marking all notifications as read: $e');
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212), // or any background color you're using
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        elevation: 0,
        title: const Text(
          'Notifications',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Lexend Deca',
            fontWeight: FontWeight.w400,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert, color: Colors.white),
          color: Colors.white,
          onSelected: (value) {
            if (value == 'read_all') {
              _markAllAsRead();
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem<String>(
              value: 'read_all',
              child: Text('Mark all as read'),
            ),
          ],
        ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 16),
          children: [
            if (newNotifications.isNotEmpty)...[
              _buildSectionTitle('New Notification'),
            const SizedBox(height: 10),
            ...newNotifications
                .map((n) => _buildNotificationItem(n, true))
                .toList(),
            const SizedBox(height: 30),
            ],
            _buildSectionTitle('Past Notification'),
            const SizedBox(height: 10),
            if (pastNotifications.isEmpty)
              _buildEmptyState('No past notifications.'),
            ...pastNotifications
                .map((n) => _buildNotificationItem(n, false))
                .toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
        title,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 15,
          fontFamily: 'Lexend Deca',
          fontWeight: FontWeight.w400,
        ),
    );
  }

  Widget _buildEmptyState(String message) {
    return Text(
        message,
        style: const TextStyle(
          color: Colors.grey,
          fontSize: 13,
          fontFamily: 'Lexend Deca',
        ),
    );
  }

  Widget _buildNotificationItem(
      NotificationViewModel notification, bool isNew) {
    return Column(
      children: [
        const SizedBox(height: 10),
        GestureDetector(
          onTap: () {
            if (isNew) _markAsRead(notification.id);
          },
          child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                  decoration: ShapeDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Color(0xFFB917DC), Color(0xFFDB05C6)],
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(7)),
                    ),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x2B000000),
                        blurRadius: 4,
                        offset: Offset(0, 0),
                        spreadRadius: 0,
                      ),
                    ],
                  ),
                  child: Text(
                    '${notification.message[0]}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        notification.type,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontFamily: 'Lexend Deca',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        notification.message,
                        style: const TextStyle(
                          color: Color(0xFFAAAAAA),
                          fontSize: 12,
                          fontFamily: 'Lexend Deca',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Text(
                        DateFormat.yMMMd().add_jm().format(
                              DateTime.parse(notification.createdAt),
                            ),
                        style: const TextStyle(
                          color: Color(0xFF666666),
                          fontSize: 12,
                          fontFamily: 'Lexend Deca',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
        ),
        const SizedBox(height: 7),
        const Divider(
          thickness: 1,
          height: 1,
          color: Color(0xf80FFFFFF),
        ),
        const SizedBox(height: 7),
      ],
    );
  }
}
