// import 'dart:ui';
// import 'package:beatjerky/screens/preacher_podcast.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter_easyloading/flutter_easyloading.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:provider/provider.dart';
//
// import '../model/api_models/all_categories/all_category_model.dart';
// import '../model/api_models/all_categories/all_category_song_model.dart';
// import '../providers/all_categories_provider/all_categories_provider.dart';
// import '../providers/stores_provider/followed_stores_provider.dart';
// import '../providers/users_provider/current_user_provider.dart';
// import '../repo/api_consts.dart';
// import '../services/api_services/admin_services/get_admin_services.dart';
// import '../services/api_services/admin_song_services/admin_song_services.dart';
// import '../services/api_services/all_categories_services/all_categories_services.dart';
// import '../utils/color.dart';
// import '../widget/reusable_text.dart';
// import '../widget/reusable_textformfield.dart';
// import 'artists/artist_screen.dart';
// import 'chat_screens/message_screen.dart';
// import 'event_screens/event_screen.dart';
//
// class HomeScreen extends StatefulWidget {
//   const HomeScreen({Key? key}) : super(key: key);
//
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   int _currentIndex = 0;
//   bool initialized = false;
//
//   // Stories data
//   List<StoryModel> _stories = [
//     StoryModel(
//       id: '1',
//       username: 'Ramzan',
//       content: 'Just finished recording! 🎵',
//       isImage: false,
//       isLive: false,
//       timestamp: DateTime.now().subtract(const Duration(hours: 2)),
//       ownerId: 'user1',
//     ),
//     StoryModel(
//       id: '2',
//       username: 'BeatJerky',
//       content: 'https://via.placeholder.com/300x300/BB86FC/FFFFFF?text=Music',
//       isImage: true,
//       isLive: true,
//       timestamp: DateTime.now().subtract(const Duration(hours: 1)),
//       ownerId: 'user2',
//     ),
//     StoryModel(
//       id: '3',
//       username: 'MusicLover',
//       content: 'New beats dropping soon! 🎧',
//       isImage: false,
//       isLive: false,
//       timestamp: DateTime.now().subtract(const Duration(minutes: 30)),
//       ownerId: 'user3',
//     ),
//   ];
//
//   List<Color> containerColor = [
//     indigoColor,
//     greenColor,
//     eventsColor,
//     peopleColor,
//     storeColor,
//   ];
//   List<String> name = [
//     'Artists',
//
//     /// 'Music Style',
//     'Events', 'People',
//     'Add Song',
//     // 'My songs'
//
//     ///,'Stores'
//   ];
//   List<IconData> icons = [
//     Icons.mic,
//     // Icons.music_note,
//     Icons.event,
//     Icons.person_rounded,
//     Icons.library_music,
//     // Icons.music_note_outlined
//     // Icons.store,
//   ];
//
//   getAllCategories() async {
//     await AllCategoriesServices().getAllCategoriesWithSongs(context);
//     allCategories = Provider.of<AllCategoriesProvider>(context, listen: false).allCategories;
//     for (int i = 0; i < allCategories.length; i++) {
//       for (int j = 0; j < allCategories[i].songs.length; j++) {
//         songsList.add(CategoriesSongModel.fromJson(allCategories[i].songs[j]));
//       }
//     }
//     setState(() {
//       initialized = true;
//     });
//   }
//
//   final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
//   List<AllCategoriesModel> allCategories = [];
//
//   late TextEditingController songTitleController;
//   late TextEditingController singerNameController;
//   late TextEditingController songDescriptionController;
//
//   FilePickerResult? musicFile;
//   int selectedYear = 2024;
//
//   pickSong() async {
//     musicFile = await FilePicker.platform.pickFiles(
//       type: FileType.custom,
//       allowedExtensions: ['mp3', 'wmv'],
//     );
//   }
//
//   @override
//   void initState() {
//     singerNameController = TextEditingController();
//     songTitleController = TextEditingController();
//     songDescriptionController = TextEditingController();
//     getAllCategories();
//     Provider.of<FollowedStoresProvider>(context, listen: false).getFollowedStores(context);
//     EasyLoading.dismiss();
//     // TODO: implement initState
//     super.initState();
//   }
//
//   void controlMenu() {
//     if (!scaffoldKey.currentState!.isDrawerOpen) {
//       scaffoldKey.currentState!.openDrawer();
//       if (!scaffoldKey.currentState!.isDrawerOpen) {
//         scaffoldKey.currentState!.openDrawer();
//       }
//     }
//   }
//
//   TextEditingController searchController = TextEditingController();
//
//   List<CategoriesSongModel> songsList = [];
//   List<CategoriesSongModel> searchList = [];
//   searchPodCost(String value) {
//     searchList.clear();
//     for (int i = 0; i < songsList.length; i++) {
//       if (songsList[i].title.contains(value)) {
//         searchList.add(songsList[i]);
//       }
//     }
//     setState(() {});
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       key: scaffoldKey,
//       //  drawer: const Drawer(
//
//       //    child: DrawerScreen(),
//       //  ),
//
//       body: SingleChildScrollView(
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Padding(
//               padding: const EdgeInsets.all(20.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       // GestureDetector(
//                       //   onTap:(){
//                       //   //  Scaffold.of(context).openDrawer();
//                       //     scaffoldKey.currentState!.openDrawer();
//                       //   },
//                       //     child: const Icon(Icons.menu, size: 26,)),
//                       const Spacer(),
//                       ReusableText(
//                         title:
//                             "Hello ${Provider.of<CurrentUserProvider>(context).user!.firstName} ${Provider.of<CurrentUserProvider>(context).user!.lastName},",
//                         size: 18,
//                         weight: FontWeight.w700,
//                         color: whiteColor,
//                       ),
//                       const Spacer(),
//                       InkWell(
//                           onTap: () {
//                             Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) {
//                               return const MessageScreen();
//                             }));
//                           },
//                           child: const Icon(
//                             FontAwesomeIcons.solidCommentDots,
//                             color: whiteColor,
//                             size: 26,
//                           )),
//                     ],
//                   ),
//                   const SizedBox(
//                     height: 20,
//                   ),
//                   SizedBox(
//                     height: 100,
//                     width: double.infinity,
//                     child: ListView.builder(
//                         itemCount: name.length,
//                         shrinkWrap: true,
//                         scrollDirection: Axis.horizontal,
//                         itemBuilder: (context, index) {
//                           return Padding(
//                             padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
//                             child: GestureDetector(
//                               onTap: () {
//                                 if (index == 0) {
//                                   Navigator.push(context, MaterialPageRoute(builder: (context) => const ArtistScreen()));
//                                 }
//                                 if (index == 1) {
//                                   Navigator.push(context, MaterialPageRoute(builder: (context) => const EventsScreen()));
//                                 }
//                                 if (index == 3) {
//                                   buildShowModalBottomSheet(context, MediaQuery.of(context).size.height);
//                                 }
//                                 // if(index==4){
//                                 //   Get.to(()=>MySongCategories());
//                                 // }
//                               },
//                               child: Column(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 crossAxisAlignment: CrossAxisAlignment.center,
//                                 children: [
//                                   Container(
//                                     height: 50,
//                                     width: 50,
//                                     decoration: BoxDecoration(
//                                       shape: BoxShape.circle,
//                                       color: containerColor[index],
//                                     ),
//                                     child: Center(
//                                       child: Icon(
//                                         icons[index],
//                                         color: Colors.white,
//                                       ),
//                                     ),
//                                   ),
//                                   const SizedBox(
//                                     height: 5,
//                                   ),
//                                   Text(
//                                     name[index],
//                                     style: const TextStyle(fontSize: 13),
//                                   ),
//                                   const SizedBox(
//                                     height: 5,
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           );
//                         }),
//                   ),
//                   const SizedBox(
//                     height: 10,
//                   ),
//                   ReusableTextForm(
//                     controller: searchController,
//                     hintText: "Search Podcast",
//                     prefixIcon: const Icon(
//                       Icons.search,
//                       color: greyColor,
//                     ),
//                     suffixIcon: const Icon(
//                       Icons.filter_list_outlined,
//                       color: greyColor,
//                     ),
//                     onChanged: (value) {
//                       searchPodCost(value);
//                       setState(() {});
//                     },
//                   ),
//                   const SizedBox(
//                     height: 20,
//                   ),
//
//                   // Stories Section
//                   _buildStoriesSection(),
//
//                   const SizedBox(
//                     height: 20,
//                   ),
//                   SizedBox(
//                     width: Get.width * .9,
//                     height: 40,
//                     child: ListView.builder(
//                         scrollDirection: Axis.horizontal,
//                         itemCount: allCategories.length,
//                         itemBuilder: (context, index) {
//                           return Padding(
//                             padding: const EdgeInsets.only(right: 8.0),
//                             child: InkWell(
//                               onTap: () {
//                                 setState(() {
//                                   _currentIndex = index;
//                                 });
//                               },
//                               child: Column(
//                                 children: [
//                                   ReusableText(
//                                     title: allCategories[index].categoryName,
//                                     size: 16,
//                                     color: whiteColor,
//                                   ),
//                                   const SizedBox(
//                                     height: 10,
//                                   ),
//                                   Container(
//                                     height: 3,
//                                     width: 30,
//                                     decoration: BoxDecoration(
//                                       gradient: _currentIndex == index
//                                           ? const LinearGradient(
//                                               colors: [
//                                                 indigoColor,
//                                                 pinkColor,
//                                               ],
//                                             )
//                                           : const LinearGradient(
//                                               colors: [
//                                                 transparentColor,
//                                                 transparentColor,
//                                               ],
//                                             ),
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             ),
//                           );
//                         }),
//                   ),
//                 ],
//               ),
//             ),
//             const SizedBox(
//               height: 5,
//             ),
//             initialized && searchController.text.isEmpty
//                 ? SizedBox(
//                     height: Get.height * .578,
//                     child: ListView.builder(
//                         itemCount: allCategories[_currentIndex].songs.length,
//                         itemBuilder: (context, index) {
//                           CategoriesSongModel song = CategoriesSongModel.fromJson(allCategories[_currentIndex].songs[index]);
//
//                           return Container(
//                             padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
//                             margin: const EdgeInsets.only(bottom: 10),
//                             decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(10),
//                               color: lightBlackColor,
//                             ),
//                             child: Row(
//                               children: [
//                                 SizedBox(
//                                   height: 100,
//                                   width: 90,
//                                   child: ClipRRect(
//                                     borderRadius: BorderRadius.circular(20),
//                                     child: song.coverImageURL != null
//                                         ? Image.network(
//                                             song.coverImageURL!.replaceAll('public', ApiConstants.baseUrl),
//                                             fit: BoxFit.cover,
//                                           )
//                                         : Image.asset('assets/images/logo.png'),
//                                   ),
//                                 ),
//                                 const SizedBox(
//                                   width: 10,
//                                 ),
//                                 Expanded(
//                                   child: Column(
//                                     crossAxisAlignment: CrossAxisAlignment.start,
//                                     children: [
//                                       ReusableText(
//                                         title: song.title.length > 20 ? song.title.substring(0, 20) : song.title,
//                                         weight: FontWeight.w700,
//                                         color: whiteColor,
//                                       ),
//                                       const SizedBox(
//                                         height: 5,
//                                       ),
//                                       ReusableText(
//                                         title: song.singer,
//                                         size: 15,
//                                         weight: FontWeight.w400,
//                                         color: greyColor,
//                                       ),
//                                       const SizedBox(
//                                         height: 10,
//                                       ),
//                                       Row(
//                                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                         children: [
//                                           ReusableText(
//                                             title: song.createdAt.substring(0, 10),
//                                             size: 15,
//                                             weight: FontWeight.w400,
//                                             color: greyColor,
//                                           ),
//                                           InkWell(
//                                             onTap: () async {
//                                               Navigator.push(
//                                                 context,
//                                                 MaterialPageRoute(builder: (BuildContext context) {
//                                                   // return PreacherPodcast(song: song,);
//                                                   return AudioPlay(
//                                                     song: song,
//                                                   );
//                                                 }),
//                                               );
//                                               // await player.play(source)
//                                             },
//                                             child: Container(
//                                               height: 40,
//                                               width: 40,
//                                               alignment: Alignment.center,
//                                               decoration: BoxDecoration(
//                                                 shape: BoxShape.circle,
//                                                 gradient: buttonGradient,
//                                               ),
//                                               child: const Icon(
//                                                 Icons.play_arrow,
//                                                 color: whiteColor,
//                                               ),
//                                             ),
//                                           )
//                                         ],
//                                       )
//                                     ],
//                                   ),
//                                 )
//                               ],
//                             ),
//                           );
//                         }),
//                   )
//                 : initialized && searchController.text.isNotEmpty
//                     ? SizedBox(
//                         height: Get.height * .578,
//                         child: ListView.builder(
//                             itemCount: searchList.length,
//                             itemBuilder: (context, index) {
//                               CategoriesSongModel song = songsList[index];
//
//                               return Container(
//                                 padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
//                                 margin: const EdgeInsets.only(bottom: 10),
//                                 decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(10),
//                                   color: lightBlackColor,
//                                 ),
//                                 child: Row(
//                                   children: [
//                                     SizedBox(
//                                       height: 100,
//                                       width: 90,
//                                       child: ClipRRect(
//                                         borderRadius: BorderRadius.circular(20),
//                                         child: song.coverImageURL != null
//                                             ? Image.network(
//                                                 song.coverImageURL!.replaceAll('public', ApiConstants.baseUrl),
//                                                 fit: BoxFit.cover,
//                                               )
//                                             : Image.asset('assets/images/logo.png'),
//                                       ),
//                                     ),
//                                     const SizedBox(
//                                       width: 10,
//                                     ),
//                                     Expanded(
//                                       child: Column(
//                                         crossAxisAlignment: CrossAxisAlignment.start,
//                                         children: [
//                                           ReusableText(
//                                             title: song.title.length > 20 ? song.title.substring(0, 20) : song.title,
//                                             weight: FontWeight.w700,
//                                             color: whiteColor,
//                                           ),
//                                           const SizedBox(
//                                             height: 5,
//                                           ),
//                                           ReusableText(
//                                             title: song.singer,
//                                             size: 15,
//                                             weight: FontWeight.w400,
//                                             color: greyColor,
//                                           ),
//                                           const SizedBox(
//                                             height: 10,
//                                           ),
//                                           Row(
//                                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                             children: [
//                                               ReusableText(
//                                                 title: song.createdAt.substring(0, 10),
//                                                 size: 15,
//                                                 weight: FontWeight.w400,
//                                                 color: greyColor,
//                                               ),
//                                               InkWell(
//                                                 onTap: () async {
//                                                   Navigator.push(
//                                                     context,
//                                                     MaterialPageRoute(builder: (BuildContext context) {
//                                                       // return PreacherPodcast(song: song,);
//                                                       return AudioPlay(
//                                                         song: song,
//                                                       );
//                                                     }),
//                                                   );
//                                                   // await player.play(source)
//                                                 },
//                                                 child: Container(
//                                                   height: 40,
//                                                   width: 40,
//                                                   alignment: Alignment.center,
//                                                   decoration: BoxDecoration(
//                                                     shape: BoxShape.circle,
//                                                     gradient: buttonGradient,
//                                                   ),
//                                                   child: const Icon(
//                                                     Icons.play_arrow,
//                                                     color: whiteColor,
//                                                   ),
//                                                 ),
//                                               )
//                                             ],
//                                           )
//                                         ],
//                                       ),
//                                     )
//                                   ],
//                                 ),
//                               );
//                             }),
//                       )
//                     : const Center(child: CircularProgressIndicator()),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Future<dynamic> buildShowModalBottomSheet(
//     BuildContext context,
//     double screenHeight,
//   ) {
//     return showModalBottomSheet(
//       isScrollControlled: true,
//       context: context,
//       shape: const RoundedRectangleBorder(
//           borderRadius: BorderRadius.only(topRight: Radius.circular(15), topLeft: Radius.circular(15))),
//       builder: (BuildContext context) {
//         return Padding(
//           padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
//           child: StatefulBuilder(
//             builder: (BuildContext context, void Function(void Function()) setState) {
//               return SizedBox(
//                 // height: screenHeight * 0.55,
//                 child: SingleChildScrollView(
//                   child: Column(
//                     //  clipBehavior: Clip.antiAlias,
//                     children: [
//                       GestureDetector(
//                         onTap: () {
//                           Navigator.pop(context);
//                         },
//                         child: Padding(
//                           padding: const EdgeInsets.only(right: 5, top: 5),
//                           child: Row(
//                             mainAxisAlignment: MainAxisAlignment.end,
//                             children: [
//                               Container(
//                                   decoration: BoxDecoration(
//                                     shape: BoxShape.circle,
//                                     color: Colors.red.shade400,
//                                   ),
//                                   height: 30,
//                                   width: 30,
//                                   child: const Center(
//                                       child: Icon(
//                                     Icons.close,
//                                     color: Colors.white,
//                                   ))),
//                             ],
//                           ),
//                         ),
//                       ),
//                       Container(
//                         decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
//                         padding: const EdgeInsets.all(16.0),
//                         child: Column(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: <Widget>[
//                             Container(
//                                 padding: const EdgeInsets.symmetric(vertical: 30),
//                                 width: double.infinity,
//                                 decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(10),
//                                   color: indigoColor,
//                                 ),
//                                 child: musicFile == null
//                                     ? Center(
//                                         child: InkWell(
//                                           onTap: () {
//                                             pickSong();
//                                           },
//                                           child: const Text(
//                                             'Choose MP3 Song',
//                                             style: TextStyle(),
//                                           ),
//                                         ),
//                                       )
//                                     : Text(musicFile!.names.first!)),
//                             const SizedBox(
//                               height: 15,
//                             ),
//                             ReusableTextForm(
//                               // enabled: false,
//                               borderRadius: 10,
//                               controller: singerNameController,
//                               hintText: "Enter Singer name",
//                               onChanged: (value) {
//                                 //searchProduct(value);
//                                 setState(() {});
//                               },
//                               filledColor: Colors.white24,
//                             ),
//                             const SizedBox(
//                               height: 15,
//                             ),
//                             ReusableTextForm(
//                               // enabled: false,
//                               borderRadius: 10,
//                               controller: songTitleController,
//                               hintText: "Enter Song Title",
//                               onChanged: (value) {
//                                 //searchProduct(value);
//                                 setState(() {});
//                               },
//                               filledColor: Colors.white24,
//                             ),
//                             const SizedBox(
//                               height: 15,
//                             ),
//                             ReusableTextForm(
//                               borderRadius: 10,
//                               controller: songDescriptionController,
//                               hintText: "Enter Song Description",
//                               onChanged: (value) {
//                                 //searchProduct(value);
//                                 setState(() {});
//                               },
//                               filledColor: Colors.white24,
//                             ),
//                             const SizedBox(
//                               height: 15,
//                             ),
//                             Row(
//                               children: [
//                                 const Text(
//                                   "Year Of Song: ",
//                                   style: TextStyle(color: Colors.white),
//                                 ),
//                                 const SizedBox(
//                                   width: 30,
//                                 ),
//                                 DropdownButtonHideUnderline(
//                                     child: SizedBox(
//                                   height: 50,
//                                   child: DropdownButton(
//                                       value: selectedYear,
//                                       items: List.generate(50, (index) {
//                                         return DropdownMenuItem<int>(value: 2024 - index, child: Text((2024 - index).toString()));
//                                       }),
//                                       onChanged: (value) {
//                                         selectedYear = value!;
//                                         setState(() {});
//                                       }),
//                                 ))
//                               ],
//                             ),
//                             const SizedBox(
//                               height: 25,
//                             ),
//                             InkWell(
//                               onTap: () async {
//                                 if (musicFile != null) {
//                                   bool response = await AdminSongServices().addSong(
//                                     context,
//                                     songTitle: songTitleController.text,
//                                     songDescription: songDescriptionController.text,
//                                     singer: singerNameController.text,
//                                     musicPath: musicFile!.paths.first!,
//                                     categoryId: "2",
//                                     year: selectedYear.toString(),
//                                   );
//                                   if (response && context.mounted) {
//                                     Get.showSnackbar(const GetSnackBar(
//                                       message: "Song Added Successfully",
//                                       duration: Duration(seconds: 2),
//                                     ));
//                                     Navigator.pop(context);
//                                   } else {
//                                     Navigator.pop(context);
//                                     Get.showSnackbar(const GetSnackBar(
//                                       message: "Error occurred",
//                                       duration: Duration(seconds: 2),
//                                     ));
//                                   }
//                                 } else {
//                                   Get.showSnackbar(const GetSnackBar(
//                                     message: "Song is required",
//                                     duration: Duration(seconds: 2),
//                                   ));
//                                 }
//                               },
//                               child: Container(
//                                 decoration: BoxDecoration(
//                                   borderRadius: BorderRadius.circular(20),
//                                   color: indigoColor,
//                                 ),
//                                 height: 50,
//                                 width: 150,
//                                 child: const Center(
//                                   child: Text("Upload Song"),
//                                 ),
//                               ),
//                             )
//                           ],
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               );
//             },
//           ),
//         );
//       },
//     );
//   }
//
//   // Stories Section Widget
//   Widget _buildStoriesSection() {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             const Text(
//               'Stories',
//               style: TextStyle(
//                 fontSize: 18,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.white,
//               ),
//             ),
//             TextButton(
//               onPressed: () {
//                 // TODO: Implement watch all stories
//               },
//               child: const Text(
//                 '► Watch all',
//                 style: TextStyle(
//                   color: Color(0xFFBB86FC),
//                   fontSize: 14,
//                 ),
//               ),
//             ),
//           ],
//         ),
//         const SizedBox(height: 15),
//         SizedBox(
//           height: 100,
//           child: ListView.builder(
//             scrollDirection: Axis.horizontal,
//             itemCount: _stories.length + 1, // +1 for "Your Story"
//             itemBuilder: (context, index) {
//               if (index == 0) {
//                 // Your Story - Create Story
//                 return _buildCreateStoryItem();
//               } else {
//                 // Other Stories
//                 return _buildStoryItem(_stories[index - 1]);
//               }
//             },
//           ),
//         ),
//       ],
//     );
//   }
//
//   // Create Story Item
//   Widget _buildCreateStoryItem() {
//     return Container(
//       margin: const EdgeInsets.only(right: 15),
//       child: Column(
//         children: [
//           GestureDetector(
//             onTap: () {
//               _showCreateStoryDialog();
//             },
//             child: Container(
//               width: 70,
//               height: 70,
//               decoration: BoxDecoration(
//                 shape: BoxShape.circle,
//                 gradient: const LinearGradient(
//                   colors: [Color(0xFFBB86FC), Color(0xFF6200EE)],
//                   begin: Alignment.topLeft,
//                   end: Alignment.bottomRight,
//                 ),
//                 border: Border.all(
//                   color: Colors.white,
//                   width: 2,
//                 ),
//               ),
//               child: const Center(
//                 child: Icon(
//                   Icons.add,
//                   color: Colors.white,
//                   size: 30,
//                 ),
//               ),
//             ),
//           ),
//           const SizedBox(height: 8),
//           const Text(
//             'Your Story',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 12,
//               fontWeight: FontWeight.w500,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   // Story Item
//   Widget _buildStoryItem(StoryModel story) {
//     return Container(
//       margin: const EdgeInsets.only(right: 15),
//       child: Column(
//         children: [
//           GestureDetector(
//             onTap: () {
//               _showStoryViewer(story);
//             },
//             child: Container(
//               width: 70,
//               height: 70,
//               decoration: BoxDecoration(
//                 shape: BoxShape.circle,
//                 border: Border.all(
//                   color: story.isLive
//                       ? const Color(0xFFE91E63)
//                       : const LinearGradient(
//                           colors: [Color(0xFFBB86FC), Color(0xFF6200EE)],
//                           begin: Alignment.topLeft,
//                           end: Alignment.bottomRight,
//                         ).colors.first,
//                   width: 3,
//                 ),
//               ),
//               child: ClipRRect(
//                 borderRadius: BorderRadius.circular(35),
//                 child: story.isImage
//                     ? Image.network(
//                         story.content,
//                         fit: BoxFit.cover,
//                         errorBuilder: (context, error, stackTrace) {
//                           return Container(
//                             color: const Color(0xFF2A2A2A),
//                             child: const Icon(
//                               Icons.image,
//                               color: Color(0xFFBB86FC),
//                             ),
//                           );
//                         },
//                       )
//                     : Container(
//                         color: const Color(0xFF2A2A2A),
//                         child: Center(
//                           child: Text(
//                             story.content,
//                             style: const TextStyle(
//                               color: Colors.white,
//                               fontSize: 16,
//                               fontWeight: FontWeight.bold,
//                             ),
//                             textAlign: TextAlign.center,
//                           ),
//                         ),
//                       ),
//               ),
//             ),
//           ),
//           const SizedBox(height: 8),
//           Row(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Text(
//                 story.username,
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 12,
//                   fontWeight: FontWeight.w500,
//                 ),
//               ),
//               if (story.isLive) ...[
//                 const SizedBox(width: 4),
//                 Container(
//                   padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
//                   decoration: BoxDecoration(
//                     color: const Color(0xFFE91E63),
//                     borderRadius: BorderRadius.circular(8),
//                   ),
//                   child: const Text(
//                     'LIVE',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 8,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   ),
//                 ],
//             ],
//           ),
//         ],
//       ),
//     );
//   }
//
//   // Show Create Story Dialog
//   void _showCreateStoryDialog() {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: const Color(0xFF1F1F1F),
//         title: const Text(
//           'Create Story',
//           style: TextStyle(color: Colors.white),
//         ),
//         content: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             ListTile(
//               leading: const Icon(Icons.image, color: Color(0xFFBB86FC)),
//               title: const Text(
//                 'Image Story',
//                 style: TextStyle(color: Colors.white),
//               ),
//               onTap: () {
//                 Navigator.pop(context);
//                 _pickImageForStory();
//               },
//             ),
//             ListTile(
//               leading: const Icon(Icons.text_fields, color: Color(0xFFBB86FC)),
//               title: const Text(
//                 'Text Story',
//                 style: TextStyle(color: Colors.white),
//               ),
//               onTap: () {
//                 Navigator.pop(context);
//                 _showTextStoryDialog();
//               },
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   // Show Text Story Dialog
//   void _showTextStoryDialog() {
//     final TextEditingController textController = TextEditingController();
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: const Color(0xFF1F1F1F),
//         title: const Text(
//           'Create Text Story',
//           style: TextStyle(color: Colors.white),
//         ),
//         content: TextField(
//           controller: textController,
//           style: const TextStyle(color: Colors.white),
//           decoration: const InputDecoration(
//             hintText: 'Enter your story text...',
//             hintStyle: TextStyle(color: Colors.white54),
//             border: OutlineInputBorder(),
//             focusedBorder: OutlineInputBorder(
//               borderSide: BorderSide(color: Color(0xFFBB86FC)),
//             ),
//           ),
//           maxLines: 3,
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('Cancel'),
//           ),
//           ElevatedButton(
//             onPressed: () {
//               if (textController.text.isNotEmpty) {
//                 _createTextStory(textController.text);
//                 Navigator.pop(context);
//               }
//             },
//             style: ElevatedButton.styleFrom(
//               backgroundColor: const Color(0xFFBB86FC),
//             ),
//             child: const Text('Create'),
//           ),
//         ],
//       ),
//     );
//   }
//
//   // Pick Image for Story
//   void _pickImageForStory() async {
//     try {
//       final result = await FilePicker.platform.pickFiles(
//         type: FileType.image,
//         allowMultiple: false,
//       );
//
//       if (result != null && result.files.isNotEmpty) {
//         final file = result.files.first;
//         if (file.path != null) {
//           // For now, we'll use a placeholder URL
//           // In a real app, you'd upload this to Firebase Storage
//           final imageUrl = 'https://via.placeholder.com/300x300/BB86FC/FFFFFF?text=Story+Image';
//
//           final newStory = StoryModel(
//             id: DateTime.now().millisecondsSinceEpoch.toString(),
//             username: 'You',
//             content: imageUrl,
//             isImage: true,
//             isLive: false,
//             timestamp: DateTime.now(),
//             ownerId: 'current_user_id', // TODO: Get actual user ID
//           );
//
//           setState(() {
//             _stories.insert(0, newStory);
//           });
//
//           Get.showSnackbar(const GetSnackBar(
//             message: "Image story created successfully!",
//             duration: Duration(seconds: 2),
//           ));
//         }
//       }
//     } catch (e) {
//       Get.showSnackbar(GetSnackBar(
//         message: "Error picking image: $e",
//         duration: const Duration(seconds: 2),
//       ));
//     }
//   }
//
//   // Create Text Story
//   void _createTextStory(String text) {
//     final newStory = StoryModel(
//       id: DateTime.now().millisecondsSinceEpoch.toString(),
//       username: 'You',
//       content: text,
//       isImage: false,
//       isLive: false,
//       timestamp: DateTime.now(),
//       ownerId: 'current_user_id', // TODO: Get actual user ID
//     );
//
//     setState(() {
//       _stories.insert(0, newStory);
//     });
//
//     Get.showSnackbar(const GetSnackBar(
//       message: "Story created successfully!",
//       duration: Duration(seconds: 2),
//     ));
//   }
//
//   // Show Story Viewer
//   void _showStoryViewer(StoryModel story) {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         backgroundColor: const Color(0xFF1F1F1F),
//         title: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             Text(
//               story.username,
//               style: const TextStyle(color: Colors.white),
//             ),
//             if (story.ownerId == 'current_user_id') // TODO: Get actual user ID
//               PopupMenuButton<String>(
//                 icon: const Icon(Icons.more_vert, color: Colors.white),
//                 color: const Color(0xFF1F1F1F),
//                 itemBuilder: (context) => [
//                   const PopupMenuItem(
//                     value: 'delete',
//                     child: Text(
//                       'Delete Story',
//                       style: TextStyle(color: Colors.white),
//                     ),
//                   ),
//                 ],
//                 onSelected: (value) {
//                   if (value == 'delete') {
//                     Navigator.pop(context);
//                     _deleteStory(story.id);
//                   }
//                 },
//               ),
//           ],
//         ),
//         content: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Container(
//               width: double.maxFinite,
//               height: 250,
//               child: story.isImage
//                   ? Image.network(
//                       story.content,
//                       fit: BoxFit.cover,
//                       errorBuilder: (context, error, stackTrace) {
//                         return const Center(
//                           child: Icon(
//                             Icons.image,
//                             color: Color(0xFFBB86FC),
//                             size: 50,
//                           ),
//                         );
//                       },
//                     )
//                   : Container(
//                       color: const Color(0xFF2A2A2A),
//                       child: Center(
//                         child: Padding(
//                           padding: const EdgeInsets.all(20),
//                           child: Text(
//                             story.content,
//                             style: const TextStyle(
//                               color: Colors.white,
//                               fontSize: 24,
//                               fontWeight: FontWeight.bold,
//                             ),
//                             textAlign: TextAlign.center,
//                           ),
//                         ),
//                       ),
//                     ),
//             ),
//             const SizedBox(height: 10),
//             Container(
//               padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//               decoration: BoxDecoration(
//                 color: const Color(0xFF2A2A2A),
//                 borderRadius: BorderRadius.circular(15),
//               ),
//               child: Text(
//                 story.timeAgo,
//                 style: const TextStyle(
//                   color: Colors.white70,
//                   fontSize: 12,
//                 ),
//               ),
//             ),
//           ],
//         ),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text(
//               'Close',
//               style: TextStyle(color: Color(0xFFBB86FC)),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   // Delete Story
//   void _deleteStory(String storyId) {
//     setState(() {
//       _stories.removeWhere((story) => story.id == storyId);
//     });
//
//     Get.showSnackbar(const GetSnackBar(
//       message: "Story deleted successfully!",
//       duration: Duration(seconds: 2),
//     ));
//   }
// }
//
// // Story Model Class
// class StoryModel {
//   final String id;
//   final String username;
//   final String content;
//   final bool isImage;
//   final bool isLive;
//   final DateTime timestamp;
//   final String ownerId;
//
//   StoryModel({
//     required this.id,
//     required this.username,
//     required this.content,
//     required this.isImage,
//     required this.isLive,
//     required this.timestamp,
//     required this.ownerId,
//   });
//
//   String get timeAgo {
//     final now = DateTime.now();
//     final difference = now.difference(timestamp);
//
//     if (difference.inDays > 0) {
//       return '${difference.inDays}d ago';
//     } else if (difference.inHours > 0) {
//       return '${difference.inHours}h ago';
//     } else if (difference.inMinutes > 0) {
//       return '${difference.inMinutes}m ago';
//     } else {
//       return 'Just now';
//     }
//   }
// }
