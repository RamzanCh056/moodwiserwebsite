import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:image_picker/image_picker.dart';
import '../utils/name_utils.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  // Controllers for text fields
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _oldPasswordController = TextEditingController();
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  // For toggling password visibility
  bool _showOldPassword = false;
  bool _showNewPassword = false;
  bool _showConfirmPassword = false;

  // For loading and saving states
  bool _isLoading = false;

  // Profile image
  String? _profileImage;
  File? _selectedImageFile;

  // Image picker instance
  final ImagePicker _picker = ImagePicker();



  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  // Method to pick profile image
  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );

      if (image != null) {
        setState(() {
          _selectedImageFile = File(image.path);
        });
      }
    } catch (e) {
      debugPrint('Error picking image: $e');
    }
  }

  /// Loads current user data from Firestore
  Future<void> _loadUserData() async {
    setState(() => _isLoading = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        // Not logged in, handle accordingly
        setState(() => _isLoading = false);
        return;
      }

      // Load from Firestore
      final doc = await FirebaseFirestore.instance.collection('usersData').doc(user.uid).get();

      if (doc.exists) {
        final data = doc.data()!;
        _firstNameController.text = data['firstName'] ?? '';
        _lastNameController.text = data['secondName'] ?? '';
        _profileImage = data['profileImage'];
      }

      // Also load email from FirebaseAuth
      _emailController.text = user.email ?? '';
    } catch (e) {
      debugPrint('Error loading user data: $e');
      // Show some error to user, if needed
    }

    setState(() => _isLoading = false);
  }

  /// Saves the updated profile data
  Future<void> _saveProfile() async {
    final oldPassword = _oldPasswordController.text.trim();
    final newPassword = _newPasswordController.text.trim();
    final confirmPassword = _confirmPasswordController.text.trim();

    if (newPassword != confirmPassword) {
      _showMessage('New passwords do not match');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        _showMessage('No user found');
        return;
      }

      // 1) Re-authenticate with old password if user is updating email or password
      if (oldPassword.isNotEmpty && (newPassword.isNotEmpty || _emailController.text.trim() != user.email)) {
        final cred = EmailAuthProvider.credential(
          email: user.email!,
          password: oldPassword,
        );
        await user.reauthenticateWithCredential(cred);
      }

      // 2) Update email (if changed)
      final newEmail = _emailController.text.trim();
      if (newEmail.isNotEmpty && newEmail != user.email) {
        await user.updateEmail(newEmail);
      }

      // 3) Upload profile image if selected
      String? newProfileImageUrl = _profileImage;
      if (_selectedImageFile != null) {
        EasyLoading.show(status: 'Uploading image...');
        
        final storageRef = FirebaseStorage.instance
            .ref()
            .child('profile_images')
            .child('${user.uid}.jpg');

        await storageRef.putFile(_selectedImageFile!);
        newProfileImageUrl = await storageRef.getDownloadURL();
      }

      // 3) Update password (if provided)
      if (newPassword.isNotEmpty) {
        await user.updatePassword(newPassword);
      }

      // 4) Update Firestore data (firstName, lastName)
      await FirebaseFirestore.instance.collection('usersData').doc(user.uid).update({
        'firstName': _firstNameController.text.trim(),
        'secondName': _lastNameController.text.trim(),
        if (newProfileImageUrl != null) 'profileImage': newProfileImageUrl,
      });

      _showMessage('Profile updated successfully!');
      Navigator.pop(context); // Return to previous screen (optional)
    } on FirebaseAuthException catch (e) {
      debugPrint('FirebaseAuth Error: $e');
      _showMessage(e.message ?? 'Error updating profile');
    } catch (e) {
      debugPrint('General Error: $e');
      _showMessage('Something went wrong');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  /// Helper method to show a snackbar or dialog
  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text(
          'Edit Profile',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.black,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Profile Image - MOVED TO TOP
                  _buildLabel('Profile Image'),
                  GestureDetector(
                    onTap: _pickImage,
                    child: Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        color: Colors.grey[800],
                        borderRadius: BorderRadius.circular(50),
                        border: Border.all(color: Colors.purple, width: 2),
                      ),
                      child: Stack(
                        children: [
                          if (_selectedImageFile != null)
                            ClipRRect(
                              borderRadius: BorderRadius.circular(48),
                              child: Image.file(
                                _selectedImageFile!,
                                width: 96,
                                height: 96,
                                fit: BoxFit.cover,
                              ),
                            )
                          else if (_profileImage != null && _profileImage!.isNotEmpty)
                            ClipRRect(
                              borderRadius: BorderRadius.circular(48),
                              child: Image.network(
                                _profileImage!,
                                width: 96,
                                height: 96,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) => const Icon(
                                  Icons.person,
                                  color: Colors.white,
                                  size: 48,
                                ),
                              ),
                            )
                          else
                            const Center(
                              child: Icon(
                                Icons.person,
                                color: Colors.white,
                                size: 48,
                              ),
                            ),
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.purple,
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 2),
                              ),
                              child: const Icon(
                                Icons.camera_alt,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 32), // Increased spacing for visual separation

                  // First Name
                  _buildLabel('First Name'),
                  _buildTextField(
                    controller: _firstNameController,
                    hintText: 'First Name',
                  ),
                  const SizedBox(height: 16),

                  // Last Name
                  _buildLabel('Last Name'),
                  _buildTextField(
                    controller: _lastNameController,
                    hintText: 'Last Name',
                  ),
                  const SizedBox(height: 16),

                  // Email
                  _buildLabel('Email'),
                  _buildTextField(
                    controller: _emailController,
                    hintText: 'Email',
                    keyboardType: TextInputType.emailAddress,
                  ),
                  const SizedBox(height: 16),

                  _buildLabel('Old Password'),
                  _buildPasswordField(
                    controller: _oldPasswordController,
                    hintText: 'Old Password',
                    isVisible: _showOldPassword,
                    onVisibilityToggle: () {
                      setState(() => _showOldPassword = !_showOldPassword);
                    },
                  ),
                  const SizedBox(height: 16),

                  // New Password
                  _buildLabel('New Password'),
                  _buildPasswordField(
                    controller: _newPasswordController,
                    hintText: 'New Password',
                    isVisible: _showNewPassword,
                    onVisibilityToggle: () {
                      setState(() => _showNewPassword = !_showNewPassword);
                    },
                  ),
                  const SizedBox(height: 16),

                  // Confirm Password
                  _buildLabel('Confirm Password'),
                  _buildPasswordField(
                    controller: _confirmPasswordController,
                    hintText: 'Confirm Password',
                    isVisible: _showConfirmPassword,
                    onVisibilityToggle: () {
                      setState(() => _showConfirmPassword = !_showConfirmPassword);
                    },
                  ),
                  const SizedBox(height: 32),

                  // Save Button
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purple,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      onPressed: _saveProfile,
                      child: const Text(
                        'Save',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  /// A small helper to build labels
  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          text,
          style: const TextStyle(color: Colors.white, fontSize: 14),
        ),
      ),
    );
  }

  /// A generic text field for first name, last name, email, etc.
  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: const TextStyle(color: Colors.grey),
        filled: true,
        fillColor: const Color(0xFF1E1E1E),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.transparent),
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.purple),
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  /// A specialized text field for passwords with an eye icon
  Widget _buildPasswordField({
    required TextEditingController controller,
    required String hintText,
    required bool isVisible,
    required VoidCallback onVisibilityToggle,
  }) {
    return TextField(
      controller: controller,
      obscureText: !isVisible,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: const TextStyle(color: Colors.grey),
        filled: true,
        fillColor: const Color(0xFF1E1E1E),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.transparent),
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.purple),
          borderRadius: BorderRadius.circular(8),
        ),
        suffixIcon: IconButton(
          icon: Icon(
            isVisible ? Icons.visibility : Icons.visibility_off,
            color: Colors.grey,
          ),
          onPressed: onVisibilityToggle,
        ),
      ),
    );
  }
}
