import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class BJAI extends StatefulWidget {
  const BJAI({Key? key}) : super(key: key);

  @override
  State<BJAI> createState() => _BJAIState();
}

class _BJAIState extends State<BJAI> {
  final TextEditingController _messageController = TextEditingController();
  final TextEditingController _searchBarController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;
  bool _isTyping = false;
  final currentUser = FirebaseAuth.instance.currentUser;
  bool _showQuickStart = true;
  
  // OpenAI API configuration
  static const String _apiKey = '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';
  static const String _baseUrl = 'https://api.openai.com/v1/chat/completions';

  @override
  void initState() {
    super.initState();
    _loadChatHistory();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _searchBarController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadChatHistory() async {
    if (currentUser == null) return;
    
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser!.uid)
          .collection('bjai_chats')
          .orderBy('timestamp', descending: false)
          .get();

      setState(() {
        _messages.clear();
        for (var doc in snapshot.docs) {
          _messages.add(ChatMessage.fromFirestore(doc));
        }
        if (_messages.isNotEmpty) {
          _showQuickStart = false;
        }
      });
      
      if (_messages.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _scrollToBottom();
        });
      }
    } catch (e) {
      print('Error loading chat history: $e');
    }
  }

  Future<void> _saveMessage(ChatMessage message) async {
    if (currentUser == null) return;
    
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser!.uid)
          .collection('bjai_chats')
          .add(message.toFirestore());
    } catch (e) {
      print('Error saving message: $e');
    }
  }

  Future<void> _deleteChat() async {
    if (currentUser == null) return;
    
    try {
      final batch = FirebaseFirestore.instance.batch();
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser!.uid)
          .collection('bjai_chats')
          .get();
      
      for (var doc in snapshot.docs) {
        batch.delete(doc.reference);
      }
      
      await batch.commit();
      setState(() {
        _messages.clear();
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Chat history cleared'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error clearing chat: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _sendMessage() async {
    if (_messageController.text.trim().isEmpty) return;
    
    final userMessage = ChatMessage(
      text: _messageController.text.trim(),
      isUser: true,
      timestamp: DateTime.now(),
    );
    
    setState(() {
      _messages.add(userMessage);
      _isTyping = true;
      _showQuickStart = false;
    });
    
    _messageController.clear();
    _scrollToBottom();
    await _saveMessage(userMessage);
    
    try {
      final aiResponse = await _getAIResponse('Answer as BeatJerky AI (BJAI). Keep tone friendly. ${userMessage.text}');
      
      final aiMessage = ChatMessage(
        text: aiResponse,
        isUser: false,
        timestamp: DateTime.now(),
      );
      
      setState(() {
        _messages.add(aiMessage);
        _isTyping = false;
      });
      
      _scrollToBottom();
      await _saveMessage(aiMessage);
    } catch (e) {
      setState(() {
        _isTyping = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<String> _getAIResponse(String userMessage) async {
         // Check for common music queries and provide enhanced responses
     final lowerMessage = userMessage.toLowerCase();
     
     // Enhanced system prompt for better music responses
     final systemPrompt = '''You are BJAI, a music expert AI assistant with deep knowledge of music history, theory, and industry. 

When responding to music queries, always provide:
- **Artist Name** (if applicable)
- **Song Title** (if applicable) 
- **Year Released** (if applicable)
- **Album Name** (if applicable)
- **Genre** (if applicable)
- **Interesting Facts** or background information
- **Musical Analysis** when relevant

For business/music store queries, provide:
- Creative business concepts
- Marketing strategies
- Target audience insights
- Revenue streams
- Competitive advantages

Keep responses conversational, engaging, and informative. Use emojis occasionally to make responses more friendly. Always aim to be helpful and accurate with music information.''';

    try {
      final response = await http.post(
        Uri.parse(_baseUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_apiKey',
        },
        body: jsonEncode({
          'model': 'gpt-3.5-turbo',
          'messages': [
            {'role': 'system', 'content': 'You are BJAI (BeatJerky AI). Be concise, friendly, and music-focused.'},
            {'role': 'user', 'content': userMessage}
          ],
          'max_tokens': 600,
          'temperature': 0.8,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['choices'][0]['message']['content'];
      } else {
        // Fallback responses for common queries if API fails
        return _getFallbackResponse(userMessage);
      }
    } catch (e) {
      // Return fallback response if API call fails
      return _getFallbackResponse(userMessage);
    }
  }

  String _getFallbackResponse(String userMessage) {
    final lowerMessage = userMessage.toLowerCase();
    
    // Song information fallbacks
    if (lowerMessage.contains('bohemian rhapsody') || lowerMessage.contains('queen')) {
      return '''🎵 **Bohemian Rhapsody** by Queen

**Artist:** Queen  
**Song:** Bohemian Rhapsody  
**Year:** 1975  
**Album:** A Night at the Opera  
**Genre:** Rock, Progressive Rock, Opera  

**Interesting Facts:**
• This 6-minute masterpiece was considered too long for radio play
• Freddie Mercury wrote the entire song himself
• The song has no chorus and is divided into distinct sections
• It was recorded in multiple studios over 3 weeks
• The "Galileo" part was inspired by Mercury's love of opera

**Musical Analysis:**
The song features complex harmonies, multiple key changes, and combines rock with classical opera elements. It's considered one of the greatest rock songs ever recorded! 🎸✨''';
    }
    
    if (lowerMessage.contains('business') || lowerMessage.contains('store') || lowerMessage.contains('idea')) {
      return '''💡 **Creative Music Store Business Ideas**

**1. Vinyl Revival + Coffee Shop** ☕
- Combine vintage vinyl records with specialty coffee
- Host live acoustic sessions
- Create a cozy, retro atmosphere

**2. Music Production Studio + Learning Center** 🎧
- Offer recording sessions and music lessons
- Sell production equipment and software
- Host workshops and masterclasses

**3. Instrument Rental + Repair Shop** 🎸
- Rent instruments for schools and events
- Provide professional repair services
- Offer maintenance workshops

**4. Music-Themed Merchandise Store** 🎵
- Band t-shirts, posters, and collectibles
- Custom instrument accessories
- Music-inspired fashion items

**5. Digital Music Distribution Service** 📱
- Help independent artists distribute music
- Provide marketing and promotion services
- Create custom merchandise packages

**Marketing Strategies:**
• Social media presence with music content
• Partnerships with local musicians
• Community events and workshops
• Loyalty programs for regular customers

**Target Audience:**
• Music enthusiasts aged 16-45
• Local musicians and bands
• Students and music teachers
• Collectors and vinyl lovers

Would you like me to elaborate on any of these ideas? 🚀''';
    }
    
    if (lowerMessage.contains('guitar') || lowerMessage.contains('chord') || lowerMessage.contains('beginner')) {
      return '''🎸 **Basic Guitar Chords for Beginners**

**Essential Open Chords:**

**C Major (C)** - The foundation chord
- Place fingers: 1st fret B string, 2nd fret D string, 3rd fret A string
- Strum from A string down

**G Major (G)** - Great for folk and rock
- Place fingers: 2nd fret A string, 3rd fret low E string, 3rd fret high E string
- Strum all strings

**D Major (D)** - Perfect for country and pop
- Place fingers: 2nd fret G string, 2nd fret E string, 3rd fret B string
- Strum from D string down

**A Minor (Am)** - Melancholic sound
- Place fingers: 1st fret B string, 2nd fret D string, 2nd fret G string
- Strum from A string down

**E Major (E)** - Powerful and bright
- Place fingers: 1st fret G string, 2nd fret A string, 2nd fret D string
- Strum all strings

**Practice Tips:**
• Start slow and focus on clean sound
• Practice chord transitions
• Use a metronome for timing
• Don't press too hard on strings

**Easy Song to Start:**
Try "Wonderwall" by Oasis - it uses C, G, Am, and F chords! 🎵

Keep practicing, and soon you'll be playing your favorite songs! 🚀''';
    }
    
    if (lowerMessage.contains('weeknd') || lowerMessage.contains('similar') || lowerMessage.contains('recommend')) {
      return '''🎼 **Artists Similar to The Weeknd**

**R&B/Pop Artists with Similar Vibes:**

**1. Frank Ocean** 🎤
- Similar atmospheric, moody sound
- Albums: "Blonde", "Channel Orange"
- Known for: Emotional depth, unique production

**2. Daft Punk** 🤖
- The Weeknd collaborated with them on "Starboy"
- Similar electronic influences
- Albums: "Random Access Memories", "Discovery"

**3. Miguel** 🌙
- Smooth R&B vocals with alternative edge
- Albums: "Wildheart", "Kaleidoscope Dream"
- Known for: Soulful voice, genre-blending

**4. PARTYNEXTDOOR** 🎉
- Similar dark, atmospheric R&B
- Albums: "PARTYNEXTDOOR", "PARTYNEXTDOOR 2"
- Known for: Mood-setting tracks

**5. Future** 🚀
- Trap-influenced R&B
- Albums: "DS2", "HNDRXX"
- Known for: Auto-tune style, dark themes

**6. Tame Impala** 🎸
- Psychedelic rock with electronic elements
- Albums: "Currents", "The Slow Rush"
- Known for: Dreamy, atmospheric sound

**7. Lana Del Rey** 🌹
- Similar melancholic, cinematic style
- Albums: "Born to Die", "Norman Fucking Rockwell!"
- Known for: Vintage aesthetic, emotional depth

**8. Post Malone** 🍺
- Blends hip-hop with melodic singing
- Albums: "Stoney", "Hollywood's Bleeding"
- Known for: Genre versatility

**Why These Artists:**
They all share The Weeknd's signature dark, atmospheric sound, emotional depth, and ability to blend multiple genres seamlessly! 🎵✨''';
    }
    
         // Additional fallback responses for new quick actions
     if (lowerMessage.contains('producer') || lowerMessage.contains('production') || lowerMessage.contains('tip')) {
       return '''🎤 **5 Essential Tips for Beginner Music Producers**

**1. Start Simple** 🎯
- Begin with basic drum patterns and simple melodies
- Don't overwhelm yourself with complex arrangements
- Focus on one element at a time

**2. Learn Your DAW** 💻
- Choose one Digital Audio Workstation and master it
- Popular options: FL Studio, Ableton Live, Logic Pro
- Watch tutorials and practice daily

**3. Study Reference Tracks** 🎧
- Analyze songs you love in your genre
- Pay attention to structure, arrangement, and mixing
- Use them as templates for your own music

**4. Focus on Sound Selection** 🎵
- Quality samples and sounds make a huge difference
- Build a good sample library
- Learn basic sound design techniques

**5. Finish Your Songs** ✅
- Don't get stuck in the loop of endless tweaking
- Set deadlines and complete projects
- Quantity leads to quality over time

**Bonus Tips:**
• Learn basic music theory (scales, chords, rhythm)
• Practice mixing and arrangement
• Collaborate with other producers
• Get feedback from listeners

Remember: Every producer started as a beginner. Keep creating! 🚀''';
     }
     
     if (lowerMessage.contains('piano') || lowerMessage.contains('chord')) {
       return '''🎹 **Basic Piano Chords for Beginners**

**Essential Chords to Start With:**

**C Major (C)** - The foundation chord
- Notes: C, E, G
- Fingers: 1, 3, 5 (thumb, middle, pinky)

**G Major (G)** - Great for many songs
- Notes: G, B, D
- Fingers: 1, 3, 5

**F Major (F)** - Common in pop music
- Notes: F, A, C
- Fingers: 1, 2, 5

**A Minor (Am)** - Melancholic sound
- Notes: A, C, E
- Fingers: 1, 3, 5

**D Minor (Dm)** - Dark and emotional
- Notes: D, F, A
- Fingers: 1, 3, 5

**Practice Tips:**
• Start with your right hand only
• Practice chord transitions slowly
• Use a metronome for timing
• Keep your fingers curved and relaxed

**Easy Song to Start:**
Try "Let It Be" by The Beatles - it uses C, G, Am, and F chords! 🎵

**Progression to Practice:**
C → G → Am → F (I → V → vi → IV)

Keep practicing, and you'll be playing beautiful music in no time! 🚀''';
     }
     
     if (lowerMessage.contains('genre') || lowerMessage.contains('rock') || lowerMessage.contains('jazz') || lowerMessage.contains('classical')) {
       return '''🎧 **Music Genres Explained**

**Rock Music** 🎸
- **Characteristics:** Electric guitars, strong rhythms, powerful vocals
- **Origins:** 1950s, evolved from blues and country
- **Subgenres:** Classic rock, hard rock, alternative, indie
- **Famous Artists:** The Beatles, Led Zeppelin, Queen, Nirvana
- **Instruments:** Electric guitar, bass, drums, vocals

**Jazz Music** 🎷
- **Characteristics:** Complex harmonies, improvisation, swing rhythm
- **Origins:** Early 1900s in New Orleans
- **Subgenres:** Bebop, smooth jazz, fusion, Latin jazz
- **Famous Artists:** Miles Davis, John Coltrane, Louis Armstrong
- **Instruments:** Saxophone, trumpet, piano, double bass, drums

**Classical Music** 🎻
- **Characteristics:** Orchestral arrangements, complex compositions, formal structure
- **Origins:** Medieval period through present day
- **Periods:** Baroque, Classical, Romantic, Modern
- **Famous Composers:** Bach, Mozart, Beethoven, Tchaikovsky
- **Instruments:** Full orchestra, piano, chamber ensembles

**Key Differences:**
• **Rock:** Focus on rhythm and energy
• **Jazz:** Emphasis on improvisation and harmony
• **Classical:** Complex arrangements and formal structure

**Modern Blending:**
Many contemporary artists blend these genres to create unique sounds! 🎵✨''';
     }
     
     if (lowerMessage.contains('promote') || lowerMessage.contains('marketing') || lowerMessage.contains('independent')) {
       return '''📱 **How Independent Musicians Can Promote Their Music**

**Digital Marketing Strategies:**

**1. Social Media Presence** 📱
- **Instagram:** Share behind-the-scenes, live performances
- **TikTok:** Create viral content with your music
- **YouTube:** Music videos, covers, tutorials
- **Twitter:** Engage with fans and industry professionals

**2. Streaming Platform Optimization** 🎧
- **Spotify:** Create playlists, use Spotify for Artists
- **Apple Music:** Optimize metadata and artwork
- **YouTube Music:** Upload high-quality audio and videos
- **SoundCloud:** Connect with other independent artists

**3. Content Creation** 🎬
- **Music Videos:** Professional or creative DIY videos
- **Behind-the-Scenes:** Show your creative process
- **Live Streams:** Perform live on social platforms
- **Podcasts:** Share your story and music journey

**4. Live Performances** 🎤
- **Local Venues:** Start with small local shows
- **Open Mics:** Build confidence and network
- **House Concerts:** Intimate performances for fans
- **Festivals:** Apply to local and regional festivals

**5. Networking & Collaboration** 🤝
- **Local Scene:** Connect with other musicians
- **Online Communities:** Join music forums and groups
- **Collaborations:** Work with other artists
- **Industry Events:** Attend music conferences

**6. Email Marketing** 📧
- **Newsletter:** Keep fans updated on new releases
- **Exclusive Content:** Offer early access to new music
- **Personal Connection:** Share your story and journey

**7. Merchandise & Branding** 🎨
- **Custom Merch:** T-shirts, posters, stickers
- **Brand Identity:** Consistent visual style
- **Fan Engagement:** Involve fans in design decisions

**Success Tips:**
• Be consistent with your content
• Engage genuinely with your audience
• Focus on quality over quantity
• Build relationships, not just followers
• Stay true to your artistic vision

**Remember:** Building a fanbase takes time. Focus on creating great music and connecting with people who love it! 🚀🎵''';
     }
     
     // Default fallback response
     return '''🎵 **BJAI Music Assistant**

I'm here to help you with all things music! I can provide:

• **Song Information** - Artist, year, album, genre, facts
• **Business Ideas** - Music store concepts and strategies  
• **Music Theory** - Chords, scales, production tips
• **Artist Recommendations** - Similar artists and genres
• **Creative Inspiration** - Songwriting and production help

Ask me anything about music, and I'll do my best to help! 🚀

Note: I'm currently using fallback responses. For the best experience, please check your internet connection.''';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A1A1A),
        elevation: 0,
        foregroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.white),
        automaticallyImplyLeading: false,
        centerTitle: true,
        leading: null,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFFBB86FC),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.smart_toy, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 8),
            const Text('BJAI',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 22,
                  letterSpacing: 0.3,
                )),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(64),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              controller: _searchBarController,
              style: const TextStyle(color: Colors.white, fontSize: 16),
              cursorColor: const Color(0xFFBB86FC),
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF242424),
                hintText: 'Search for songs, artists, or music topics...',
                hintStyle: const TextStyle(color: Colors.white60),
                prefixIcon: const Icon(Icons.search, color: Color(0xFFBB86FC)),
                suffixIcon: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (_searchBarController.text.isNotEmpty)
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.white54),
                        onPressed: () {
                          setState(() => _searchBarController.clear());
                        },
                      ),
                    IconButton(
                      icon: const Icon(Icons.send, color: Color(0xFFBB86FC)),
                      onPressed: () {
                        final q = _searchBarController.text.trim();
                        if (q.isNotEmpty) {
                          _sendQuickMessage('Tell me about $q');
                        }
                      },
                      tooltip: 'Search',
                    ),
                  ],
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide(color: const Color(0xFFBB86FC).withOpacity(0.25)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: Color(0xFFBB86FC), width: 1),
                ),
              ),
              onChanged: (_) => setState(() {}),
              textInputAction: TextInputAction.search,
              onSubmitted: (query) {
                if (query.trim().isNotEmpty) {
                  _sendQuickMessage('Tell me about $query');
                }
              },
            ),
          ),
        ),
        actions: [
          if (_messages.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep, color: Colors.red),
              onPressed: () => _showDeleteDialog(),
              tooltip: 'Clear chat history',
            ),
        ],
      ),
      body: Column(
        children: [
          // Scrollable content area
          Expanded(
            child: _showQuickStart && _messages.isEmpty
                ? SingleChildScrollView(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: Container(
                      padding: const EdgeInsets.all(24),
                      margin: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            const Color(0xFFBB86FC).withOpacity(0.1),
                            const Color(0xFF03DAC6).withOpacity(0.1),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: const Color(0xFFBB86FC).withOpacity(0.3),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: const [
                              Icon(Icons.auto_awesome, color: Color(0xFFBB86FC), size: 22),
                              SizedBox(width: 8),
                              Text(
                                'Quick Start',
                                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Ask BJAI about songs, artists and ideas',
                            style: TextStyle(color: Colors.white70, fontSize: 14),
                          ),
                          const SizedBox(height: 16),
                          // Beautiful full-width buttons
                          Column(
                            children: [
                              _buildCTAButton(
                                icon: Icons.library_music,
                                title: 'Song Info',
                                subtitle: 'Tell me about Bohemian Rhapsody',
                                onTap: () => _sendQuickMessage('Tell me about the song Bohemian Rhapsody by Queen'),
                              ),
                              const SizedBox(height: 12),
                              _buildCTAButton(
                                icon: Icons.lightbulb,
                                title: 'Business Ideas',
                                subtitle: 'Music store concepts',
                                onTap: () => _sendQuickMessage('Give me 5 creative music store business ideas'),
                              ),
                              const SizedBox(height: 12),
                              _buildCTAButton(
                                icon: Icons.music_note,
                                title: 'Music Theory',
                                subtitle: 'Learn guitar basics',
                                onTap: () => _sendQuickMessage('Explain basic guitar chords for beginners'),
                              ),
                              const SizedBox(height: 12),
                              _buildCTAButton(
                                icon: Icons.recommend,
                                title: 'Recommendations',
                                subtitle: 'Similar artists',
                                onTap: () => _sendQuickMessage('Recommend artists similar to The Weeknd'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: _messages.length + (_isTyping ? 1 : 0),
                    itemBuilder: (context, index) {
                      if (index == _messages.length && _isTyping) {
                        return _buildTypingIndicator();
                      }
                      return _buildMessage(_messages[index]);
                    },
                  ),
          ),

          // Input area
          SafeArea(
            top: false,
            child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1F1F1F),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF2A2A2A),
                      borderRadius: BorderRadius.circular(25),
                      border: Border.all(
                        color: const Color(0xFFBB86FC).withOpacity(0.3),
                      ),
                    ),
                    child: TextField(
                      controller: _messageController,
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                        hintText: 'Ask about music, songs, or business ideas...',
                        hintStyle: TextStyle(color: Colors.white54),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 15,
                        ),
                      ),
                      maxLines: null,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFBB86FC), Color(0xFF03DAC6)],
                    ),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: IconButton(
                    onPressed: _isLoading ? null : _sendMessage,
                    icon: _isLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          )
                        : const Icon(
                            Icons.send,
                            color: Colors.white,
                          ),
                  ),
                ),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildMessage(ChatMessage message) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!message.isUser) ...[
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFFBB86FC),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.smart_toy,
                color: Colors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: message.isUser
                    ? const Color(0xFFBB86FC).withOpacity(0.2)
                    : const Color(0xFF2A2A2A),
                borderRadius: BorderRadius.circular(20).copyWith(
                  bottomLeft: message.isUser ? const Radius.circular(20) : const Radius.circular(5),
                  bottomRight: message.isUser ? const Radius.circular(5) : const Radius.circular(20),
                ),
                border: Border.all(
                  color: message.isUser
                      ? const Color(0xFFBB86FC).withOpacity(0.3)
                      : Colors.transparent,
                ),
              ),
              child: Text(
                message.text,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  height: 1.4,
                ),
              ),
            ),
          ),
          if (message.isUser) ...[
            const SizedBox(width: 12),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFF03DAC6),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(
                Icons.person,
                color: Colors.white,
                size: 20,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFFBB86FC),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(
              Icons.smart_toy,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xFF2A2A2A),
              borderRadius: BorderRadius.circular(20).copyWith(
                bottomLeft: const Radius.circular(5),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Text(
                  'BJAI is thinking…',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDot(int index) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 600 + (index * 200)),
      builder: (context, value, child) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 2),
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            color: const Color(0xFFBB86FC).withOpacity(value),
            shape: BoxShape.circle,
          ),
        );
      },
      child: null,
    );
  }

  void _sendQuickMessage(String message) {
    _messageController.text = message;
    _sendMessage();
  }

  Widget _buildQuickActionButton(String emoji, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF2A2A2A),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: const Color(0xFFBB86FC).withOpacity(0.3),
          ),
        ),
        child: Column(
          children: [
            Text(
              emoji,
              style: const TextStyle(fontSize: 24),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 86),
        child: Ink(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color(0xFF2A2A2A),
              const Color(0xFF2F2F2F),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFBB86FC).withOpacity(0.25)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),

          
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFBB86FC).withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: const Color(0xFFBB86FC)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.chevron_right, color: Colors.white54),
          ],
          ),
        ),
      ),
    );
  }

  Widget _buildCTAButton({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Ink(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF2A2A2A), Color(0xFF2F2F2F)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFBB86FC).withOpacity(0.25)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFBB86FC).withOpacity(0.18),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: const Color(0xFFBB86FC)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: const Color(0xFFBB86FC).withOpacity(0.18),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.chevron_right, color: Colors.white70),
            )
          ],
        ),
      ),
    );
  }

  void _showDeleteDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF2A2A2A),
        title: const Text(
          'Clear Chat History',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Are you sure you want to delete all chat messages? This action cannot be undone.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'Cancel',
              style: TextStyle(color: Colors.grey),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteChat();
            },
            child: const Text(
              'Delete',
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;

  ChatMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
  });

  Map<String, dynamic> toFirestore() {
    return {
      'text': text,
      'isUser': isUser,
      'timestamp': timestamp,
    };
  }

  factory ChatMessage.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ChatMessage(
      text: data['text'] ?? '',
      isUser: data['isUser'] ?? false,
      timestamp: (data['timestamp'] as Timestamp).toDate(),
    );
  }
}
