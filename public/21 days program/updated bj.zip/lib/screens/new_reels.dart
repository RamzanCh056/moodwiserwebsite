import 'package:beatjerky/screens/create_video_screen_1.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:preload_page_view/preload_page_view.dart';
import 'package:video_player/video_player.dart';
import 'dart:io';
import 'dart:developer';
import '../services/music_service.dart';
import '../widget/video_editor.dart';
import '../notification_services/trigger_notification_services.dart';
import 'create_video_screen.dart';

class ReelsScreen extends StatefulWidget {
  final bool showBackButton;

  const ReelsScreen({Key? key, this.showBackButton = false}) : super(key: key);

  @override
  _ReelsScreenState createState() => _ReelsScreenState();
}

class _ReelsScreenState extends State<ReelsScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final ImagePicker _picker = ImagePicker();
  final TextEditingController _commentController = TextEditingController();
  Map<String, bool> _likedVideos = {};
  Map<String, int> _likeCounts = {};
  late PreloadPageController _pageController;
  int _currentIndex = 0;
  Map<int, GlobalKey<_VideoPlayerWidgetState>> _videoKeys = {};

  @override
  void initState() {
    super.initState();
    _pageController = PreloadPageController();
    _loadLikedVideos();
  }

  Future<void> _loadLikedVideos() async {
    String userId = _auth.currentUser?.uid ?? "unknown";
    final likedVideos = await _firestore
        .collection('reels')
        .where('likedBy', arrayContains: userId)
        .get();

    setState(() {
      for (var doc in likedVideos.docs) {
        _likedVideos[doc.id] = true;
      }
    });
  }

  Future<void> _toggleLike(String videoId) async {
    String userId = _auth.currentUser?.uid ?? "unknown";
    bool isLiked = _likedVideos[videoId] ?? false;

    try {
      final reelRef = _firestore.collection('reels').doc(videoId);
      final reelSnapshot = await reelRef.get();

      if (!reelSnapshot.exists) return;

      final reelData = reelSnapshot.data()!;
      final ownerId = reelData['userId'];
      if (isLiked) {
        // Unlike
        await _firestore.collection('reels').doc(videoId).update({
          'likedBy': FieldValue.arrayRemove([userId]),
          'likes': FieldValue.increment(-1),
        });
        setState(() {
          _likedVideos[videoId] = false;
          _likeCounts[videoId] = (_likeCounts[videoId] ?? 1) - 1;
        });

        await _deleteReelLikeNotification(
          fromUserId: userId,
          toUserId: ownerId,
          reelId: videoId,
        );
      } else {
        // Like
        await _firestore.collection('reels').doc(videoId).update({
          'likedBy': FieldValue.arrayUnion([userId]),
          'likes': FieldValue.increment(1),
        });
        setState(() {
          _likedVideos[videoId] = true;
          _likeCounts[videoId] = (_likeCounts[videoId] ?? 0) + 1;
        });

        // Send notification to reel owner
        await _sendReelLikeNotification(videoId);
      }
    } catch (e) {
      print("Error toggling like: $e");
    }
  }

  Future<void> _deleteReelLikeNotification({
    required String fromUserId,
    required String toUserId,
    required String reelId,
  }) async {
    try {
      final querySnapshot = await _firestore
          .collection('notifications')
          .doc(toUserId)
          .collection('userNotifications')
          .where('fromUserId', isEqualTo: fromUserId)
          .where('reelId', isEqualTo: reelId)
          .where('type', isEqualTo: 'reel_like')
          .get();

      for (var doc in querySnapshot.docs) {
        await doc.reference.delete();
      }

      log(
        'Deleted reel like notification from $fromUserId to $toUserId on reel $reelId',
      );
    } catch (e) {
      log('Error deleting reel like notification: $e');
    }
  }

  void _showComments(String videoId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.black87,
      isScrollControlled: true,
      builder: (context) {
        return StreamBuilder<QuerySnapshot>(
          stream: _firestore
              .collection('reels')
              .doc(videoId)
              .collection('comments')
              .orderBy('timestamp', descending: true)
              .snapshots(),
          builder: (context, snapshot) {
            bool hasComments =
                snapshot.hasData && snapshot.data!.docs.isNotEmpty;
            // calculate dynamic height
            final screenHeight = MediaQuery.of(context).size.height;
            final sheetHeight = hasComments
                ? screenHeight *
                      0.7 // up to 70% if there are comments
                : screenHeight * 0.3; // only 30% if no comments

            return AnimatedContainer(
              duration: Duration(milliseconds: 200),
              height: sheetHeight + MediaQuery.of(context).viewInsets.bottom,
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
              ),
              child: Column(
                children: [
                  // header
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Comments',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.close, color: Colors.white),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ),

                  // comments list or empty message
                  Expanded(
                    child: !snapshot.hasData
                        ? Center(child: CircularProgressIndicator())
                        : hasComments
                        ? ListView.builder(
                            padding: EdgeInsets.zero,
                            itemCount: snapshot.data!.docs.length,
                            itemBuilder: (context, index) {
                              var comment = snapshot.data!.docs[index];
                              String commentUserId = comment['userId'] ?? '';
                              String currentUserId =
                                  _auth.currentUser?.uid ?? '';
                              bool isOwner = commentUserId == currentUserId;

                              return FutureBuilder<Map<String, dynamic>?>(
                                future: _fetchUserData(comment['userId']),
                                builder: (context, userSnap) {
                                  if (!userSnap.hasData) return SizedBox();
                                  final user = userSnap.data!;
                                  return ListTile(
                                    leading: CircleAvatar(
                                      backgroundImage: _buildProfileImage(
                                        user['profileImage'],
                                      ),
                                      backgroundColor: Colors.grey[700],
                                      child:
                                          _shouldShowProfileIcon(
                                            user['profileImage'],
                                          )
                                          ? Text(
                                              (user['firstName'] ?? 'U')
                                                  .substring(0, 1)
                                                  .toUpperCase(),
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14,
                                              ),
                                            )
                                          : null,
                                    ),
                                    title: Text(
                                      user['firstName'] ?? 'Unknown',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                    subtitle: Text(
                                      comment['text'],
                                      style: TextStyle(color: Colors.white70),
                                    ),
                                    trailing: isOwner
                                        ? IconButton(
                                            icon: Icon(
                                              Icons.delete,
                                              color: Colors.red,
                                            ),
                                            onPressed: () => _deleteComment(
                                              videoId,
                                              comment.id,
                                              commentUserId,
                                            ),
                                          )
                                        : null,
                                  );
                                },
                              );
                            },
                          )
                        : Center(
                            child: Text(
                              'No comments yet',
                              style: TextStyle(color: Colors.white70),
                            ),
                          ),
                  ),

                  // input field
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _commentController,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              hintText: 'Add a comment...',
                              hintStyle: TextStyle(color: Colors.white54),
                              filled: true,
                              fillColor: Colors.white12,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(25),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.send, color: Colors.white),
                          onPressed: () async {
                            final text = _commentController.text.trim();
                            if (text.isNotEmpty) {
                              await _addComment(videoId, text);
                              _commentController.clear();
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _deleteComment(
    String videoId,
    String commentId,
    String commentUserId,
  ) async {
    final currentUserId = _auth.currentUser?.uid ?? '';

    // Security check - verify the comment belongs to current user
    if (commentUserId != currentUserId) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You don\'t have permission to delete this comment'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    // Show confirmation dialog
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'Delete Comment',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Are you sure you want to delete this comment?',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (shouldDelete == true) {
      try {
        // Double-check ownership on server side
        final commentDoc = await _firestore
            .collection('reels')
            .doc(videoId)
            .collection('comments')
            .doc(commentId)
            .get();

        if (!commentDoc.exists ||
            commentDoc.data()?['userId'] != currentUserId) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'You don\'t have permission to delete this comment',
              ),
              backgroundColor: Colors.red,
            ),
          );
          return;
        }

        await _firestore
            .collection('reels')
            .doc(videoId)
            .collection('comments')
            .doc(commentId)
            .delete();

        // Now delete the related notification (if any)
        final reelDoc = await _firestore.collection('reels').doc(videoId).get();
        final reelOwnerId = reelDoc.data()?['userId'];

        if (reelOwnerId != null && reelOwnerId != currentUserId) {
          await _deleteReelCommentNotification(
            fromUserId: currentUserId,
            toUserId: reelOwnerId,
            reelId: videoId,
          );
        }

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Comment deleted successfully'),
            backgroundColor: Colors.green,
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error deleting comment: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _deleteReelCommentNotification({
    required String fromUserId,
    required String toUserId,
    required String reelId,
  }) async {
    try {
      final querySnapshot = await _firestore
          .collection('notifications')
          .doc(toUserId)
          .collection('userNotifications')
          .where('fromUserId', isEqualTo: fromUserId)
          .where('reelId', isEqualTo: reelId)
          .where('type', isEqualTo: 'reel_comment')
          .get();

      for (var doc in querySnapshot.docs) {
        await doc.reference.delete();
      }

      log(
        'Deleted comment notification from $fromUserId to $toUserId on reel $reelId',
      );
    } catch (e) {
      log('Error deleting comment notification: $e');
    }
  }

  Future<void> _addComment(String videoId, String text) async {
    String userId = _auth.currentUser?.uid ?? "unknown";
    try {
      await _firestore
          .collection('reels')
          .doc(videoId)
          .collection('comments')
          .add({
            'userId': userId,
            'text': text,
            'timestamp': FieldValue.serverTimestamp(),
          });

      // Send notification to reel owner
      await _sendReelCommentNotification(videoId);
    } catch (e) {
      print("Error adding comment: $e");
    }
  }

  Future<void> _sendReelLikeNotification(String videoId) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) return;

      // Get reel data to find the reel owner
      final reelDoc = await _firestore.collection('reels').doc(videoId).get();

      if (!reelDoc.exists) return;

      final reelData = reelDoc.data();
      final reelOwnerId = reelData?['userId'] as String?;

      if (reelOwnerId == null) return;

      // Don't send notification if user is liking their own reel
      if (currentUser.uid == reelOwnerId) return;

      log("reelownerid $reelOwnerId");

      // Get current user's name for the notification
      final currentUserDoc = await _firestore
          .collection('usersData')
          .doc(currentUser.uid)
          .get();

      final currentUserName = currentUserDoc['firstName'] ?? 'Someone';

      // Get reel owner's FCM token
      final userSnapshot = await FirebaseFirestore.instance
          .collection('usersData')
          .doc(reelOwnerId)
          .get();

      final userData = userSnapshot.data();
      final targetToken = userData?['fcmToken'] as String?;

      if (targetToken != null && targetToken.isNotEmpty) {
        // Send push notification
        final trigger = TriggerNotificationService();
        await trigger.sendPushNotification(
          token: targetToken,
          title: 'New Like on Reel! ❤️',
          body: '$currentUserName liked your reel',
        );
      } else {
        log('No FCM token found for user $reelOwnerId');
      }

      // Save notification to Firestore
      final notificationData = {
        'type': 'reel_like',
        'fromUserId': currentUser.uid,
        'fromUserName': currentUserName,
        'reelId': videoId,
        'timestamp': FieldValue.serverTimestamp(),
        'message': '$currentUserName liked your reel',
        'isRead': false,
      };

      await _firestore
          .collection('notifications')
          .doc(reelOwnerId)
          .collection('userNotifications')
          .add(notificationData);

      log('Reel like notification sent and saved for $reelOwnerId');
    } catch (e) {
      log('Error sending reel like notification: $e');
    }
  }

  Future<void> _sendReelCommentNotification(String videoId) async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) return;

      // Get reel data to find the reel owner
      final reelDoc = await _firestore.collection('reels').doc(videoId).get();

      if (!reelDoc.exists) return;

      final reelData = reelDoc.data();
      final reelOwnerId = reelData?['userId'] as String?;

      if (reelOwnerId == null) return;

      // Don't send notification if user is commenting on their own reel
      if (currentUser.uid == reelOwnerId) return;

      log("reelownerid $reelOwnerId");

      // Get current user's name for the notification
      final currentUserDoc = await _firestore
          .collection('usersData')
          .doc(currentUser.uid)
          .get();

      final currentUserName = currentUserDoc['firstName'] ?? 'Someone';

      // Get reel owner's FCM token
      final userSnapshot = await FirebaseFirestore.instance
          .collection('usersData')
          .doc(reelOwnerId)
          .get();

      final userData = userSnapshot.data();
      final targetToken = userData?['fcmToken'] as String?;

      if (targetToken != null && targetToken.isNotEmpty) {
        // Send push notification
        final trigger = TriggerNotificationService();
        await trigger.sendPushNotification(
          token: targetToken,
          title: 'New Comment on Reel! 💬',
          body: '$currentUserName commented on your reel',
        );
      } else {
        log('No FCM token found for user $reelOwnerId');
      }
      // Save notification to Firestore
      final notificationData = {
        'type': 'reel_comment',
        'fromUserId': currentUser.uid,
        'fromUserName': currentUserName,
        'reelId': videoId,
        'timestamp': FieldValue.serverTimestamp(),
        'message': '$currentUserName commented on your reel',
        'isRead': false,
      };

      // await _firestore
      //   .collection('usersData')
      //   .doc(reelOwnerId)
      //   .collection('notifications')
      //   .add(notificationData);

      await _firestore
          .collection('notifications')
          .doc(reelOwnerId)
          .collection('userNotifications')
          .add(notificationData);

      log('Reel comment notification sent and saved for $reelOwnerId');
    } catch (e) {
      log('Error sending reel comment notification: $e');
    }
  }

  Future<void> _sendNewReelNotificationToAllUsers() async {
    try {
      final currentUser = _auth.currentUser;
      if (currentUser == null) return;

      // Get current user's name for the notification
      final currentUserDoc = await _firestore
          .collection('usersData')
          .doc(currentUser.uid)
          .get();

      final currentUserName = currentUserDoc['firstName'] ?? 'Someone';

      // Get all users from usersData collection
      final usersSnapshot = await _firestore.collection('usersData').get();

      final trigger = TriggerNotificationService();
      int notificationCount = 0;

      // Send notification to each user (except current user)
      for (var userDoc in usersSnapshot.docs) {
        final userId = userDoc.id;

        // Skip current user
        if (userId == currentUser.uid) continue;

        final userData = userDoc.data();
        final fcmToken = userData['fcmToken'] as String?;

        if (fcmToken != null && fcmToken.isNotEmpty) {
          try {
            // Send push notification
            await trigger.sendPushNotification(
              token: fcmToken,
              title: 'New Reel Available! 🎬',
              body: '$currentUserName just uploaded a new reel',
            );
          } catch (e) {
            log('Error sending notification to user $userId: $e');
          }
        }
        // Save notification to Firestore
        final notificationData = {
          'type': 'new_reel',
          'fromUserId': currentUser.uid,
          'fromUserName': currentUserName,
          'timestamp': FieldValue.serverTimestamp(),
          'message': '$currentUserName just uploaded a new reel',
          'isRead': false,
        };

        await _firestore
            .collection('notifications')
            .doc(userId)
            .collection('userNotifications')
            .add(notificationData);

        notificationCount++;
      }

      log('New reel notification sent to $notificationCount users');
    } catch (e) {
      log('Error sending new reel notifications: $e');
    }
  }

  Future<void> _uploadVideo(bool fromCamera) async {
    try {
      final XFile? pickedFile = await _picker.pickVideo(
        source: fromCamera ? ImageSource.camera : ImageSource.gallery,
        maxDuration: const Duration(minutes: 10),
      );

      if (pickedFile == null) {
        print("No video selected");
        return;
      }

      File videoFile = File(pickedFile.path);

      // Ensure file exists before uploading
      if (!videoFile.existsSync()) {
        print("Video file does not exist: ${pickedFile.path}");
        return;
      }

      // Show video editor for advanced editing options
      _showVideoEditor(videoFile);
    } catch (e) {
      print("Error picking video: $e");
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error picking video: $e')));
    }
  }

  void _showVideoEditor(File videoFile) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => VideoEditorScreen(
          videoFile: videoFile,
          onVideoEdited: (editedFile, editData) {
            Navigator.pop(context);
            _showVideoCreationUI(editedFile, editData: editData);
          },
        ),
      ),
    );
  }

  void _showVideoCreationUI(File videoFile, {Map<String, dynamic>? editData}) {
    final TextEditingController descriptionController = TextEditingController();
    bool isUploading = false;
    double uploadProgress = 0.0;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          return Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Handle bar
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 20),

                // Title
                const Text(
                  "Create New Video",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),

                // Description field
                TextField(
                  controller: descriptionController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Add description (Optional)',
                    hintStyle: TextStyle(color: Colors.grey[400]),
                    filled: true,
                    fillColor: Colors.grey[800],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                  maxLines: 2,
                ),
                const SizedBox(height: 20),

                // Video preview
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey[850],
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      color: Colors.purple.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.video_camera_back,
                        size: 40,
                        color: Colors.purple[300],
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Video Selected",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Duration: ${_getVideoDuration(videoFile)}",
                              style: TextStyle(
                                color: Colors.grey[400],
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(Icons.close, color: Colors.red),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Upload button
                Container(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: isUploading
                        ? null
                        : () async {
                            setModalState(() {
                              isUploading = true;
                              uploadProgress = 0.0;
                            });

                            try {
                              // Simulate upload progress
                              for (int i = 0; i <= 100; i += 10) {
                                await Future.delayed(
                                  const Duration(milliseconds: 200),
                                );
                                setModalState(() {
                                  uploadProgress = i / 100;
                                });
                              }

                              // Actual upload
                              String fileName =
                                  "videos/${DateTime.now().millisecondsSinceEpoch}.mp4";
                              Reference storageRef = _storage.ref(fileName);
                              UploadTask uploadTask = storageRef.putFile(
                                videoFile,
                              );

                              TaskSnapshot snapshot = await uploadTask;
                              String downloadUrl = await snapshot.ref
                                  .getDownloadURL();

                              // Save to Firestore with edit data
                              await _saveVideoToFirestore(
                                downloadUrl,
                                descriptionController.text.trim(),
                                editData: editData,
                              );

                              setModalState(() {
                                isUploading = false;
                                uploadProgress = 0.0;
                              });

                              Navigator.pop(context);
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Video uploaded successfully!'),
                                  backgroundColor: Colors.green,
                                ),
                              );
                            } catch (e) {
                              setModalState(() {
                                isUploading = false;
                                uploadProgress = 0.0;
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Error uploading video: $e'),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purple,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      elevation: 8,
                      shadowColor: Colors.purple.withOpacity(0.5),
                    ),
                    child: isUploading
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(width: 10),
                              const Text(
                                "Uploading...",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          )
                        : const Text(
                            "Upload Video",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),

                // Progress indicator
                if (isUploading) ...[
                  const SizedBox(height: 20),
                  Container(
                    height: 8,
                    decoration: BoxDecoration(
                      color: Colors.grey[800],
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: LinearProgressIndicator(
                      value: uploadProgress,
                      backgroundColor: Colors.grey[800],
                      valueColor: const AlwaysStoppedAnimation<Color>(
                        Colors.purple,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "${(uploadProgress * 100).toInt()}%",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
                const SizedBox(height: 10),
              ],
            ),
          );
        },
      ),
    );
  }

  String _getVideoDuration(File videoFile) {
    try {
      // This is a simple estimation - in a real app you'd use video_metadata package
      final fileSize = videoFile.lengthSync();
      // Rough estimation: 1MB ≈ 1 second for compressed video
      final estimatedSeconds = (fileSize / (1024 * 1024)).round();
      if (estimatedSeconds < 60) {
        return "${estimatedSeconds}s";
      } else {
        final minutes = estimatedSeconds ~/ 60;
        final seconds = estimatedSeconds % 60;
        return "${minutes}m ${seconds}s";
      }
    } catch (e) {
      return "Unknown";
    }
  }

  void _handleVideoMenuSelection(
    String value,
    Map<String, dynamic> videoData,
    String videoId,
  ) {
    switch (value) {
      case 'edit':
        _showEditVideoDialog(videoData, videoId);
        break;
      case 'delete':
        _showDeleteConfirmation(videoData, videoId);
        break;
      case 'report':
        _showReportOptions(videoData, videoId);
        break;
    }
  }

  void _showEditVideoDialog(Map<String, dynamic> videoData, String videoId) {
    final TextEditingController descriptionController = TextEditingController(
      text: _getVideoDescriptionFromMap(videoData),
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text('Edit Video', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: descriptionController,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Update video description...',
            hintStyle: TextStyle(color: Colors.grey[400]),
            filled: true,
            fillColor: Colors.grey[800],
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
          ),
          maxLines: 3,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                await _firestore.collection('reels').doc(videoId).update({
                  'description': descriptionController.text.trim(),
                });
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Video updated successfully!'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error updating video: $e'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.purple,
              foregroundColor: Colors.white,
            ),
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(Map<String, dynamic> videoData, String videoId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'Delete Video',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Are you sure you want to delete this video? This action cannot be undone.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                // Delete from Firestore
                await _firestore.collection('reels').doc(videoId).delete();

                // Delete from Storage (optional - you might want to keep the file)
                // await _storage.refFromURL(videoData['videoUrl']).delete();

                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Video deleted successfully!'),
                    backgroundColor: Colors.green,
                  ),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Error deleting video: $e'),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showReportOptions(Map<String, dynamic> videoData, String videoId) {
    String selectedReason = '';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            backgroundColor: Colors.grey[900],
            title: const Text(
              'Report Video',
              style: TextStyle(color: Colors.white),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Please select a reason for reporting:',
                  style: TextStyle(color: Colors.white70),
                ),
                const SizedBox(height: 16),
                RadioListTile<String>(
                  title: const Text(
                    'Inappropriate content',
                    style: TextStyle(color: Colors.white),
                  ),
                  value: 'inappropriate',
                  groupValue: selectedReason,
                  onChanged: (value) =>
                      setDialogState(() => selectedReason = value!),
                  activeColor: Colors.purple,
                ),
                RadioListTile<String>(
                  title: const Text(
                    'Violence',
                    style: TextStyle(color: Colors.white),
                  ),
                  value: 'violence',
                  groupValue: selectedReason,
                  onChanged: (value) =>
                      setDialogState(() => selectedReason = value!),
                  activeColor: Colors.purple,
                ),
                RadioListTile<String>(
                  title: const Text(
                    'Spam',
                    style: TextStyle(color: Colors.white),
                  ),
                  value: 'spam',
                  groupValue: selectedReason,
                  onChanged: (value) =>
                      setDialogState(() => selectedReason = value!),
                  activeColor: Colors.purple,
                ),
                RadioListTile<String>(
                  title: const Text(
                    'Other',
                    style: TextStyle(color: Colors.white),
                  ),
                  value: 'other',
                  groupValue: selectedReason,
                  onChanged: (value) =>
                      setDialogState(() => selectedReason = value!),
                  activeColor: Colors.purple,
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text(
                  'Cancel',
                  style: TextStyle(color: Colors.grey),
                ),
              ),
              ElevatedButton(
                onPressed: selectedReason.isEmpty
                    ? null
                    : () async {
                        try {
                          // Save report to Firestore
                          await _firestore.collection('reports').add({
                            'videoId': videoId,
                            'reportedBy': _auth.currentUser?.uid,
                            'reason': selectedReason,
                            'timestamp': FieldValue.serverTimestamp(),
                          });

                          Navigator.pop(context);
                          _showReportConfirmation();
                        } catch (e) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Error reporting video: $e'),
                              backgroundColor: Colors.red,
                            ),
                          );
                        }
                      },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Report'),
              ),
            ],
          );
        },
      ),
    );
  }

  void _showReportConfirmation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'Report Submitted',
          style: TextStyle(color: Colors.white),
        ),
        content: const Text(
          'Thank you for your report. We will review it and take appropriate action.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.purple,
              foregroundColor: Colors.white,
            ),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _saveVideoToFirestore(
    String videoUrl,
    String description, {
    Map<String, dynamic>? editData,
  }) async {
    String userId = _auth.currentUser?.uid ?? "unknown";

    Map<String, dynamic> videoData = {
      'userId': userId,
      'videoUrl': videoUrl,
      'description': description.isNotEmpty ? description : null,
      'likes': 0,
      'public': true,
      'timestamp': FieldValue.serverTimestamp(),
    };

    // Add edit data if available
    if (editData != null) {
      if (editData['music'] != null) {
        videoData['music'] = editData['music'];
        videoData['musicVolume'] = editData['musicVolume'];
        videoData['videoVolume'] = editData['videoVolume'];

        // Increment music use count
        final musicData = editData['music'] as Map<String, dynamic>?;
        if (musicData != null && musicData['id'] != null) {
          await MusicService.incrementUseCount(musicData['id']);
        }
      }

      if (editData['filter'] != null && editData['filter'] != 'None') {
        videoData['filter'] = editData['filter'];
      }

      if (editData['caption'] != null &&
          editData['caption']['text'] != null &&
          editData['caption']['text'].isNotEmpty) {
        videoData['caption'] = editData['caption'];
      }
    }

    await _firestore
        .collection('reels')
        .add(videoData)
        .then((value) {
          print("Video successfully saved!");

          // Send notification to all users about new reel
          _sendNewReelNotificationToAllUsers();
        })
        .catchError((error) {
          print("Error saving video: $error");
        });
  }

  Future<Map<String, dynamic>?> _fetchUserData(String userId) async {
    DocumentSnapshot userDoc = await _firestore
        .collection('usersData')
        .doc(userId)
        .get();
    if (userDoc.exists) {
      return userDoc.data() as Map<String, dynamic>?;
    }
    return null;
  }

  // Helper method to build profile image with proper validation
  ImageProvider<Object>? _buildProfileImage(String? profileImg) {
    if (profileImg == null ||
        profileImg.isEmpty ||
        !profileImg.startsWith('http') ||
        profileImg.contains('file:///')) {
      return null;
    }

    try {
      return NetworkImage(profileImg);
    } catch (e) {
      print("Error loading profile image: $e");
      return null;
    }
  }

  // Helper method to determine if profile icon should be shown
  bool _shouldShowProfileIcon(String? profileImg) {
    return profileImg == null ||
        profileImg.isEmpty ||
        !profileImg.startsWith('http') ||
        profileImg.contains('file:///');
  }

  // Helper method to safely get video description
  String _getVideoDescription(dynamic data) {
    try {
      final description = data['description'];
      if (description == null) return '';
      return description.toString().trim();
    } catch (e) {
      print("Error getting video description: $e");
      return '';
    }
  }

  // Helper method to safely get video description from Map
  String _getVideoDescriptionFromMap(Map<String, dynamic> videoData) {
    try {
      final description = videoData['description'];
      if (description == null) return '';
      return description.toString().trim();
    } catch (e) {
      print("Error getting video description from map: $e");
      return '';
    }
  }

  // Helper method to safely check if document has music data
  bool _hasMusicData(dynamic data) {
    try {
      if (data is! Map<String, dynamic>) return false;
      final musicData = data['music'];
      if (musicData == null) return false;
      if (musicData is! Map<String, dynamic>) return false;
      return musicData['title'] != null &&
          musicData['title'].toString().isNotEmpty;
    } catch (e) {
      print("Error checking music data: $e");
      return false;
    }
  }

  // Helper method to safely get music title
  String _getMusicTitle(dynamic data) {
    try {
      if (data is! Map<String, dynamic>) return 'Music';
      final musicData = data['music'];
      if (musicData == null || musicData is! Map<String, dynamic>)
        return 'Music';
      return musicData['title']?.toString() ?? 'Music';
    } catch (e) {
      print("Error getting music title: $e");
      return 'Music';
    }
  }

  void _handlePageChanged(int index) {
    print("📱 Page changed to index: $index");

    // Pause previous video
    if (_videoKeys.containsKey(_currentIndex)) {
      final previousVideoKey = _videoKeys[_currentIndex];
      previousVideoKey?.currentState?.pauseVideo();
    }

    // Update current index
    setState(() {
      _currentIndex = index;
    });

    // Play current video
    if (_videoKeys.containsKey(index)) {
      final currentVideoKey = _videoKeys[index];
      currentVideoKey?.currentState?.playVideo();
    }
  }

  void _showUploadOptions() {

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CreateVideoScreen()),
    );

    // Navigator.push(
    //   context,
    //   MaterialPageRoute(builder: (context) => ProVideoWithPicker()),
    // );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.showBackButton
          ? AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              flexibleSpace: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.9),
                      Colors.black.withOpacity(0.7),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
              title: const Text(
                'Videos',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            )
          : null,
      body: StreamBuilder(
        stream: _firestore
            .collection('reels')
            .where('public', isEqualTo: true)
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("No videos found. Upload a video to get started!"),
                  SizedBox(height: 20),
                  IconButton(
                    icon: Icon(
                      Icons.add_circle_outline_rounded,
                      size: 50,
                      color: Colors.purple,
                    ),
                    onPressed: _showUploadOptions,
                  ),
                ],
              ),
            );
          }
          // Ensure first video starts playing when screen loads
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (_currentIndex == 0 && _videoKeys.containsKey(0)) {
              Future.delayed(Duration(milliseconds: 500), () {
                _videoKeys[0]?.currentState?.playVideo();
              });
            }
          });

          return PreloadPageView.builder(
            controller: _pageController,
            scrollDirection: Axis.vertical,
            itemCount: snapshot.data!.docs.length,
            onPageChanged: (index) {
              _handlePageChanged(index);
            },
            itemBuilder: (context, index) {
              // Create unique key for each video
              if (!_videoKeys.containsKey(index)) {
                _videoKeys[index] = GlobalKey<_VideoPlayerWidgetState>();
              }
              var data = snapshot.data!.docs[index];
              return FutureBuilder(
                future: _fetchUserData(data['userId']),
                builder:
                    (
                      context,
                      AsyncSnapshot<Map<String, dynamic>?> userSnapshot,
                    ) {
                      return Stack(
                        children: [
                          GestureDetector(
                            onTap: () {},
                            child: VideoPlayerWidget(
                              key: _videoKeys[index]!,
                              videoUrl: data['videoUrl'],
                              isVisible: index == _currentIndex,
                              isFirstVideo: index == 0,
                            ),
                          ),
                          if (userSnapshot.hasData)
                            Positioned(
                              left: 10,
                              bottom: 50,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // User info
                                  Row(
                                    children: [
                                      Stack(
                                        children: [
                                          CircleAvatar(
                                            backgroundImage: _buildProfileImage(
                                              userSnapshot
                                                  .data!['profileImage'],
                                            ),
                                            backgroundColor: Colors.grey[700],
                                            radius: 20,
                                            child:
                                                _shouldShowProfileIcon(
                                                  userSnapshot
                                                      .data!['profileImage'],
                                                )
                                                ? Text(
                                                    (userSnapshot
                                                                .data!['firstName'] ??
                                                            'U')
                                                        .substring(0, 1)
                                                        .toUpperCase(),
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 16,
                                                    ),
                                                  )
                                                : null,
                                          ),
                                          // Blue tick badge for verified users
                                          if ((userSnapshot.data!['isPaid'] ??
                                                  false) ==
                                              true)
                                            Positioned(
                                              bottom: 0,
                                              right: 0,
                                              child: Container(
                                                padding: EdgeInsets.all(2),
                                                decoration: BoxDecoration(
                                                  color: Colors.blue,
                                                  shape: BoxShape.circle,
                                                  border: Border.all(
                                                    color: Colors.white,
                                                    width: 1.5,
                                                  ),
                                                ),
                                                child: Icon(
                                                  Icons.verified,
                                                  color: Colors.white,
                                                  size: 8,
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                                      const SizedBox(width: 10),
                                      Text(
                                        userSnapshot.data!['firstName'] ??
                                            'Unknown',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      if ((userSnapshot.data!['isPaid'] ??
                                              false) ==
                                          true)
                                        const Icon(
                                          Icons.check_circle,
                                          color: Colors.blue,
                                          size: 16,
                                        ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  // Description
                                  if (_getVideoDescription(data).isNotEmpty)
                                    Container(
                                      constraints: BoxConstraints(
                                        maxWidth:
                                            MediaQuery.of(context).size.width *
                                            0.6,
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 8,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.black.withOpacity(0.7),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Text(
                                        _getVideoDescription(data),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                        ),
                                        maxLines: 3,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),

                                  // Music info if available
                                  if (_hasMusicData(data)) ...[
                                    const SizedBox(height: 8),
                                    Container(
                                      constraints: BoxConstraints(
                                        maxWidth:
                                            MediaQuery.of(context).size.width *
                                            0.6,
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 8,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.black.withOpacity(0.8),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                          color: Colors.purple.withOpacity(0.5),
                                          width: 1,
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Container(
                                            width: 20,
                                            height: 20,
                                            decoration: BoxDecoration(
                                              color: Colors.purple,
                                              shape: BoxShape.circle,
                                            ),
                                            child: Icon(
                                              Icons.music_note,
                                              color: Colors.white,
                                              size: 12,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Flexible(
                                            child: Text(
                                              _getMusicTitle(data),
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 12,
                                                fontWeight: FontWeight.bold,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          Positioned(
                            right: 10,
                            bottom: 50,
                            child: Column(
                              children: [
                                StreamBuilder(
                                  stream: _firestore
                                      .collection('reels')
                                      .doc(data.id)
                                      .snapshots(),
                                  builder:
                                      (
                                        context,
                                        AsyncSnapshot<DocumentSnapshot>
                                        snapshot,
                                      ) {
                                        if (!snapshot.hasData) {
                                          return IconButton(
                                            icon: Icon(
                                              Icons.favorite_border,
                                              color: Colors.purple,
                                            ),
                                            onPressed: () =>
                                                _toggleLike(data.id),
                                          );
                                        }
                                        final likes =
                                            (snapshot.data!.data()
                                                as Map<
                                                  String,
                                                  dynamic
                                                >?)?['likes'] ??
                                            0;
                                        return Column(
                                          children: [
                                            IconButton(
                                              icon: Icon(
                                                _likedVideos[data.id] ?? false
                                                    ? Icons.favorite
                                                    : Icons.favorite_border,
                                                color:
                                                    _likedVideos[data.id] ??
                                                        false
                                                    ? Colors.red
                                                    : Colors.purple,
                                              ),
                                              onPressed: () =>
                                                  _toggleLike(data.id),
                                            ),
                                            Text(
                                              '$likes',
                                              style: TextStyle(
                                                color: Colors.purple,
                                              ),
                                            ),
                                          ],
                                        );
                                      },
                                ),
                                StreamBuilder(
                                  stream: _firestore
                                      .collection('reels')
                                      .doc(data.id)
                                      .collection('comments')
                                      .snapshots(),
                                  builder:
                                      (
                                        context,
                                        AsyncSnapshot<QuerySnapshot> snapshot,
                                      ) {
                                        final commentCount =
                                            snapshot.data?.docs.length ?? 0;
                                        return Column(
                                          children: [
                                            IconButton(
                                              icon: Icon(
                                                Icons.comment,
                                                color: Colors.purple,
                                              ),
                                              onPressed: () =>
                                                  _showComments(data.id),
                                            ),
                                            Text(
                                              '$commentCount',
                                              style: TextStyle(
                                                color: Colors.purple,
                                              ),
                                            ),
                                          ],
                                        );
                                      },
                                ),
                                IconButton(
                                  icon: Icon(
                                    Icons.add_circle_outline_rounded,
                                    color: Colors.purple,
                                    size: 35,
                                  ),
                                  onPressed: _showUploadOptions,
                                ),
                                const SizedBox(height: 8),
                                // 3-dots menu
                                PopupMenuButton<String>(
                                  icon: const Icon(
                                    Icons.more_vert,
                                    color: Colors.purple,
                                    size: 24,
                                  ),
                                  color: Colors.grey[900],
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                  onSelected: (value) =>
                                      _handleVideoMenuSelection(
                                        value,
                                        data.data() as Map<String, dynamic>,
                                        data.id,
                                      ),
                                  itemBuilder: (context) => [
                                    if (data['userId'] ==
                                        _auth.currentUser?.uid) ...[
                                      // Own video options
                                      PopupMenuItem(
                                        value: 'edit',
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.edit,
                                              color: Colors.blue,
                                              size: 20,
                                            ),
                                            const SizedBox(width: 8),
                                            const Text(
                                              'Edit Video',
                                              style: TextStyle(
                                                color: Colors.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: 'delete',
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.delete,
                                              color: Colors.red,
                                              size: 20,
                                            ),
                                            const SizedBox(width: 8),
                                            const Text(
                                              'Delete Video',
                                              style: TextStyle(
                                                color: Colors.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ] else ...[
                                      // Other user's video options
                                      PopupMenuItem(
                                        value: 'report',
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.report,
                                              color: Colors.orange,
                                              size: 20,
                                            ),
                                            const SizedBox(width: 8),
                                            const Text(
                                              'Report',
                                              style: TextStyle(
                                                color: Colors.white,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    },
              );
            },
          );
        },
      ),
    );
  }
}

class VideoPlayerWidget extends StatefulWidget {
  final String videoUrl;
  final bool isVisible;
  final bool isFirstVideo;

  const VideoPlayerWidget({
    Key? key,
    required this.videoUrl,
    this.isVisible = true,
    this.isFirstVideo = false,
  }) : super(key: key);

  @override
  _VideoPlayerWidgetState createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  late VideoPlayerController _controller;
  bool _isPaused = false;
  bool _isInitialized = false;
  bool _hasError = false;
  bool _showLikeAnimationOverlay = false;
  late AnimationController _likeAnimationController;
  bool _isVisible = true;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _likeAnimationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _initializeVideo();
  }

  Future<void> _initializeVideo() async {
    try {
      print("🎬 Starting video initialization: ${widget.videoUrl}");

      // Basic URL validation
      if (widget.videoUrl.isEmpty || !widget.videoUrl.startsWith('http')) {
        throw Exception('Invalid video URL: ${widget.videoUrl}');
      }

      // Log the complete URL for debugging
      print("📋 Full video URL: ${widget.videoUrl}");
      print("📋 URL length: ${widget.videoUrl.length} characters");

      // Create controller with minimal configuration
      _controller = VideoPlayerController.networkUrl(
        Uri.parse(widget.videoUrl),
      );

      print("🔄 Attempting video initialization...");

      // Simple initialization with reasonable timeout
      await _controller.initialize().timeout(
        const Duration(seconds: 20), // Single longer timeout
        onTimeout: () {
          throw Exception(
            'Video failed to load within 20 seconds - this may be due to slow network or large file size',
          );
        },
      );

      print("✅ Video initialization successful!");

      // Optimize for smooth playback
      _controller.setPlaybackSpeed(1.0);
      _controller.setLooping(true);
      _controller.setVolume(1.0);

      // Add error listener with mounted check
      _controller.addListener(_videoStateListener);

      // Auto-play if this video is visible OR if it's the first video
      if (widget.isVisible || widget.isFirstVideo) {
        await _controller.play();
        print(
          "▶️ Auto-playing video (visible: ${widget.isVisible}, first: ${widget.isFirstVideo})",
        );
      } else {
        print("⏸️ Video initialized but not auto-playing");
      }

      if (mounted) {
        setState(() {
          _isInitialized = true;
        });
      }

      print("✅ Video initialization successful!");
    } catch (e) {
      print("Error initializing video: $e");
      if (mounted) {
        setState(() {
          _hasError = true;
        });
      }
    }
  }

  void _togglePlayPause() {
    if (!_isInitialized || !mounted) return;

    setState(() {
      if (_controller.value.isPlaying) {
        _controller.pause();
        _isPaused = true;
      } else {
        _controller.play();
        _isPaused = false;
      }
    });
  }

  void _seekForward() {
    if (!_isInitialized || !mounted) return;

    final currentPosition = _controller.value.position;
    final duration = _controller.value.duration;
    final newPosition = currentPosition + const Duration(seconds: 10);

    if (newPosition < duration) {
      _controller.seekTo(newPosition);
    } else {
      _controller.seekTo(duration);
    }
  }

  void _seekBackward() {
    if (!_isInitialized || !mounted) return;

    final currentPosition = _controller.value.position;
    final newPosition = currentPosition - const Duration(seconds: 10);

    if (newPosition > Duration.zero) {
      _controller.seekTo(newPosition);
    } else {
      _controller.seekTo(Duration.zero);
    }
  }

  void _videoStateListener() {
    if (!mounted) return;

    if (_controller.value.hasError) {
      print("Video playback error: ${_controller.value.errorDescription}");
      setState(() {
        _hasError = true;
      });
    }
  }

  void playVideo() {
    if (!mounted || !_isInitialized) return;

    print("▶️ Playing video: ${widget.videoUrl}");
    _controller.play();
    setState(() {
      _isPaused = false;
    });
  }

  void pauseVideo() {
    if (!mounted || !_isInitialized) return;

    print("⏸️ Pausing video: ${widget.videoUrl}");
    _controller.pause();
    setState(() {
      _isPaused = true;
    });
  }

  void _showLikeAnimation() {
    if (!mounted) return;

    setState(() {
      _showLikeAnimationOverlay = true;
    });

    _likeAnimationController.forward().then((_) {
      if (mounted) {
        _likeAnimationController.reset();
        setState(() {
          _showLikeAnimationOverlay = false;
        });
      }
    });
  }

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    // Remove listener before disposing to prevent memory leaks
    _controller.removeListener(_videoStateListener);
    _controller.dispose();
    _likeAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin

    if (_hasError) {
      return Container(
        color: Colors.black,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, color: Colors.red, size: 60),
              const SizedBox(height: 20),
              const Text(
                "Failed to load video",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "Check your internet connection\nor try again later",
                style: TextStyle(color: Colors.grey, fontSize: 14),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: () {
                  setState(() {
                    _hasError = false;
                    _isInitialized = false;
                  });
                  _initializeVideo();
                },
                icon: const Icon(Icons.refresh, color: Colors.white),
                label: const Text(
                  'Retry',
                  style: TextStyle(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: _togglePlayPause,
      onDoubleTap: () {
        // Double tap to like
        if (_isInitialized) {
          _showLikeAnimation();
        }
      },
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (_isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _controller.value.size.width,
                  height: _controller.value.size.height,
                  child: VideoPlayer(_controller),
                ),
              ),
            )
          else
            Container(
              color: Colors.black,
              child: const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(
                      color: Colors.purple,
                      strokeWidth: 3,
                    ),
                    SizedBox(height: 16),
                    Text(
                      "Loading video...",
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ],
                ),
              ),
            ),

          // Video controls overlay
          if (_isPaused && _isInitialized)
            Container(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.7),
                borderRadius: BorderRadius.circular(25),
                border: Border.all(
                  color: Colors.purple.withOpacity(0.5),
                  width: 2,
                ),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Backward button
                  GestureDetector(
                    onTap: _seekBackward,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.purple.withOpacity(0.2),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.purple.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: const Icon(
                        Icons.replay_10,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),

                  // Play/Pause button
                  GestureDetector(
                    onTap: _togglePlayPause,
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.purple,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.purple.withOpacity(0.5),
                            blurRadius: 8,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Icon(
                        _controller.value.isPlaying
                            ? Icons.pause
                            : Icons.play_arrow,
                        color: Colors.white,
                        size: 28,
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),

                  // Forward button
                  GestureDetector(
                    onTap: _seekForward,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.purple.withOpacity(0.2),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.purple.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: const Icon(
                        Icons.forward_10,
                        color: Colors.white,
                        size: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          // Like animation overlay
          if (_showLikeAnimationOverlay)
            Positioned.fill(
              child: Center(
                child: ScaleTransition(
                  scale: Tween<double>(begin: 0.5, end: 1.2).animate(
                    CurvedAnimation(
                      parent: _likeAnimationController,
                      curve: Curves.elasticOut,
                    ),
                  ),
                  child: FadeTransition(
                    opacity: Tween<double>(begin: 1.0, end: 0.0).animate(
                      CurvedAnimation(
                        parent: _likeAnimationController,
                        curve: const Interval(0.5, 1.0),
                      ),
                    ),
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.3),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.red.withOpacity(0.5),
                            blurRadius: 20,
                            spreadRadius: 10,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.favorite,
                        color: Colors.red,
                        size: 60,
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
