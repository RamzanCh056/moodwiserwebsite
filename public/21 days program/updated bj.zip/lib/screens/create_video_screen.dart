import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:just_audio/just_audio.dart';
import 'package:file_picker/file_picker.dart';

import '../model/music_track_model.dart';
import '../services/music_service.dart';
import '../widget/music_browser.dart';

class CreateVideoScreen extends StatefulWidget {
  @override
  _CreateVideoScreenState createState() => _CreateVideoScreenState();
}

class _CreateVideoScreenState extends State<CreateVideoScreen>
    with TickerProviderStateMixin {
  final TextEditingController _descriptionController = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final AudioPlayer _previewPlayer = AudioPlayer();

  // Video state
  File? _selectedVideo;
  VideoPlayerController? _videoController;
  bool _isVideoInitialized = false;
  
  // Music state
  MusicTrack? _selectedMusic;
  bool _isMusicPlaying = false;
  double _musicVolume = 0.5;
  double _videoVolume = 1.0;
  
  // UI state
  bool _isUploading = false;
  double _uploadProgress = 0.0;
  late TabController _tabController;
  String _selectedFilter = 'None';
  
  // Available filters
  final List<String> _filters = [
    'None',
    'Vintage',
    'Black & White',
    'Sepia',
    'Cool',
    'Warm',
    'Bright',
    'Dark',
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    _videoController?.dispose();
    _previewPlayer.dispose();
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _pickVideo(ImageSource source) async {
    try {
      print('Starting video picker from source: $source');
      
      final XFile? pickedFile = await _picker.pickVideo(
        source: source,
        maxDuration: const Duration(minutes: 10),
      );

      if (pickedFile != null) {
        print('Video picked: ${pickedFile.path}');
        final videoFile = File(pickedFile.path);
        
        // Basic validation before initialization
        if (!await videoFile.exists()) {
          throw Exception('Selected video file does not exist');
        }
        
        final fileStat = await videoFile.stat();
        print('Selected video size: ${fileStat.size} bytes');
        
        if (fileStat.size == 0) {
          throw Exception('Selected video file is empty');
        }
        
        if (fileStat.size > 500 * 1024 * 1024) { // 500MB limit
          throw Exception('Video file is too large (max 500MB)');
        }
        
        // Check file extension
        final fileName = pickedFile.name ?? pickedFile.path.split('/').last;
        final extension = fileName.toLowerCase().split('.').last;
        final validExtensions = ['mp4', 'mov', 'avi', 'mkv', 'm4v', '3gp'];
        
        if (!validExtensions.contains(extension)) {
          _showSnackBar('Warning: $extension may not be a supported video format', isError: false);
        }
        
        await _initializeVideo(videoFile);
      } else {
        print('No video selected');
      }
    } catch (e) {
      print('Error picking video: $e');
      _showSnackBar('Error selecting video: ${e.toString()}', isError: true);
    }
  }

  Future<void> _initializeVideo(File videoFile) async {
    try {
      _videoController?.dispose();
      
      setState(() {
        _selectedVideo = videoFile;
        _isVideoInitialized = false;
      });

      // Check if file exists and is valid
      if (!await videoFile.exists()) {
        throw Exception('Video file does not exist');
      }

      final fileStat = await videoFile.stat();
      print('Video file size: ${fileStat.size} bytes');
      
      if (fileStat.size == 0) {
        throw Exception('Video file is empty');
      }

      if (fileStat.size > 500 * 1024 * 1024) { // 500MB limit
        throw Exception('Video file is too large (max 500MB)');
      }

      _videoController = VideoPlayerController.file(videoFile);
      
      // Set a timeout for initialization
      await _videoController!.initialize().timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          throw Exception('Video initialization timeout - file may be corrupted or too large');
        },
      );
      
      // Add listener for video state changes
      _videoController!.addListener(() {
        if (mounted) {
          setState(() {});
        }
      });
      
      setState(() {
        _isVideoInitialized = true;
      });
      
      _videoController!.setLooping(true);
      _videoController!.play();
    } catch (e) {
      print('Error initializing video: $e');
      setState(() {
        _selectedVideo = null;
        _isVideoInitialized = false;
      });
      _showSnackBar('Error loading video: ${e.toString()}', isError: true);
    }
  }

  Future<void> _selectMusic() async {
    // Show direct music options
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        // height: 300,
        decoration: const BoxDecoration(
          color: Color(0xFF1E1E1E),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Add Music to Video',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 30),
            
            // Upload from device
            ListTile(
              leading: const Icon(Icons.upload_file, color: Colors.purple, size: 28),
              title: const Text('Upload from Device', style: TextStyle(color: Colors.white, fontSize: 16)),
              subtitle: const Text('Add your own music file', style: TextStyle(color: Colors.grey)),
              onTap: () {
                Navigator.pop(context);
                _uploadMusicDirectly();
              },
            ),
            
            const SizedBox(height: 10),
            
            // Browse existing music
            ListTile(
              leading: const Icon(Icons.library_music, color: Colors.blue, size: 28),
              title: const Text('Browse Music Library', style: TextStyle(color: Colors.white, fontSize: 16)),
              subtitle: const Text('Choose from uploaded songs', style: TextStyle(color: Colors.grey)),
              onTap: () {
                Navigator.pop(context);
                _browseExistingMusic();
              },
            ),
            
            const SizedBox(height: 10),
            
            // No music
            ListTile(
              leading: const Icon(Icons.music_off, color: Colors.grey, size: 28),
              title: const Text('No Music', style: TextStyle(color: Colors.white, fontSize: 16)),
              subtitle: const Text('Create video without music', style: TextStyle(color: Colors.grey)),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  _selectedMusic = null;
                  _isMusicPlaying = false;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _uploadMusicDirectly() async {
    try {
      print('Starting direct music upload...');
      
      // Use the safe file picker from music browser
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['mp3', 'wav', 'aac', 'm4a', 'flac', 'ogg'],
        allowMultiple: false,
        allowCompression: false,
        withData: false,
        withReadStream: false,
      );

      if (result != null && result.files.isNotEmpty) {
        final filePath = result.files.first.path;
        final fileName = result.files.first.name;
        
        if (filePath != null) {
          final file = File(filePath);
          
          if (await file.exists()) {
            // Create a temporary music track for preview
            final tempTrack = MusicTrack(
              id: 'temp_${DateTime.now().millisecondsSinceEpoch}',
              title: fileName.split('.').first,
              artist: 'Local File',
              audioUrl: filePath,
              coverImageUrl: '', // No cover image for local files
              duration: 0, // Duration will be detected when playing
              genre: 'Local',
              uploadedBy: FirebaseAuth.instance.currentUser?.uid ?? 'unknown',
              uploadedAt: DateTime.now(), // Use DateTime instead of Timestamp
              useCount: 0,
            );
            
            setState(() {
              _selectedMusic = tempTrack;
            });
            
            _showSnackBar('Music selected: $fileName', isError: false);
            _playMusicPreview();
          } else {
            _showSnackBar('Selected file does not exist', isError: true);
          }
        } else {
          _showSnackBar('File path is invalid', isError: true);
        }
      }
    } catch (e) {
      print('Error uploading music directly: $e');
      _showSnackBar('Error selecting music: $e', isError: true);
    }
  }

  Future<void> _browseExistingMusic() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MusicBrowserScreen(
          onMusicSelected: (track) {
            setState(() {
              _selectedMusic = track;
            });
            if (track != null) {
              _playMusicPreview();
            }
          },
        ),
      ),
    );
  }

  Future<void> _playMusicPreview() async {
    if (_selectedMusic == null) return;
    
    try {
      if (_isMusicPlaying) {
        await _previewPlayer.stop();
        setState(() {
          _isMusicPlaying = false;
        });
      } else {
        print('Attempting to play music: ${_selectedMusic!.audioUrl}');
        
        // Handle local files differently
        if (_selectedMusic!.id.startsWith('temp_')) {
          // For local files, use setFilePath instead of setUrl
          final audioFile = File(_selectedMusic!.audioUrl);
          
          if (!await audioFile.exists()) {
            throw Exception('Audio file does not exist: ${_selectedMusic!.audioUrl}');
          }
          
          final fileStat = await audioFile.stat();
          print('Audio file size: ${fileStat.size} bytes');
          
          if (fileStat.size == 0) {
            throw Exception('Audio file is empty');
          }
          
          print('Playing local file: ${audioFile.path}');
          await _previewPlayer.setFilePath(audioFile.path);
        } else {
          // For remote URLs, use setUrl
          print('Playing remote URL: ${_selectedMusic!.audioUrl}');
          await _previewPlayer.setUrl(_selectedMusic!.audioUrl);
        }
        
        await _previewPlayer.setVolume(_musicVolume);
        await _previewPlayer.play();
        setState(() {
          _isMusicPlaying = true;
        });

        // Auto-stop after 30 seconds
        Future.delayed(const Duration(seconds: 30), () async {
          if (_isMusicPlaying) {
            await _previewPlayer.stop();
            if (mounted) {
              setState(() {
                _isMusicPlaying = false;
              });
            }
          }
        });
      }
    } catch (e) {
      print('Error playing music preview: $e');
      setState(() {
        _isMusicPlaying = false;
      });
      _showSnackBar('Cannot preview this audio file', isError: true);
    }
  }

  Future<void> _uploadVideo() async {
    if (_selectedVideo == null) {
      _showSnackBar('Please select a video first', isError: true);
      return;
    }

    setState(() {
      _isUploading = true;
      _uploadProgress = 0.0;
    });

    try {
      // Simulate upload progress
      for (int i = 0; i <= 50; i += 10) {
        await Future.delayed(const Duration(milliseconds: 100));
        setState(() {
          _uploadProgress = i / 100;
        });
      }

      // Upload video to Firebase Storage
      String fileName = "videos/${DateTime.now().millisecondsSinceEpoch}.mp4";
      Reference storageRef = _storage.ref(fileName);
      UploadTask uploadTask = storageRef.putFile(_selectedVideo!);

      // Monitor upload progress
      uploadTask.snapshotEvents.listen((TaskSnapshot snapshot) {
        double progress = (snapshot.bytesTransferred / snapshot.totalBytes);
        setState(() {
          _uploadProgress = 0.5 + (progress * 0.5); // Second half of progress
        });
      });

      TaskSnapshot snapshot = await uploadTask;
      String videoUrl = await snapshot.ref.getDownloadURL();

      // Prepare video data
      Map<String, dynamic> videoData = {
        'userId': _auth.currentUser?.uid ?? 'unknown',
        'videoUrl': videoUrl,
        'description': _descriptionController.text.trim(),
        'likes': 0,
        'public': true,
        'timestamp': FieldValue.serverTimestamp(),
      };

      // Add music data if selected
      if (_selectedMusic != null) {
        String finalAudioUrl = _selectedMusic!.audioUrl;
        String finalMusicId = _selectedMusic!.id;
        
        // If it's a temporary local file, upload it to Firebase first
        if (_selectedMusic!.id.startsWith('temp_')) {
          print('Uploading local music file to Firebase...');
          
          // Upload music file to Firebase Storage
          final musicFile = File(_selectedMusic!.audioUrl);
          if (await musicFile.exists()) {
            String musicFileName = "music/${DateTime.now().millisecondsSinceEpoch}_${_selectedMusic!.title}.mp3";
            Reference musicStorageRef = _storage.ref(musicFileName);
            UploadTask musicUploadTask = musicStorageRef.putFile(musicFile);
            
            TaskSnapshot musicSnapshot = await musicUploadTask;
            finalAudioUrl = await musicSnapshot.ref.getDownloadURL();
            finalMusicId = 'uploaded_${DateTime.now().millisecondsSinceEpoch}';
            
            // Save to music collection for future use
            final musicData = {
              'id': finalMusicId,
              'title': _selectedMusic!.title,
              'artist': _selectedMusic!.artist,
              'genre': _selectedMusic!.genre,
              'audioUrl': finalAudioUrl,
              'coverImageUrl': '', // No cover image for uploaded files
              'uploadedBy': _auth.currentUser?.uid ?? 'unknown',
              'uploadedAt': FieldValue.serverTimestamp(),
              'useCount': 1,
              'duration': _selectedMusic!.duration,
              'isTrending': false,
            };
            
            await FirebaseFirestore.instance
                .collection('musicTracks')
                .doc(finalMusicId)
                .set(musicData);
                
            print('Local music uploaded successfully: $finalAudioUrl');
          }
        }
        
        videoData['music'] = {
          'musicId': finalMusicId,
          'title': _selectedMusic!.title,
          'artist': _selectedMusic!.artist,
          'genre': _selectedMusic!.genre,
          'audioUrl': finalAudioUrl,
          'duration': _selectedMusic!.duration,
        };
        videoData['musicVolume'] = _musicVolume;
        videoData['videoVolume'] = _videoVolume;
        
        // Increment music use count (only if not a temp file that was just uploaded)
        if (!_selectedMusic!.id.startsWith('temp_')) {
          await MusicService.incrementUseCount(_selectedMusic!.id);
        }
      }

      // Add filter if selected
      if (_selectedFilter != 'None') {
        videoData['filter'] = _selectedFilter;
      }

      // Save to Firestore
      await _firestore.collection('reels').add(videoData);

      setState(() {
        _isUploading = false;
        _uploadProgress = 0.0;
      });

      _showSnackBar('Video uploaded successfully!', isError: false);
      Navigator.pop(context);
    } catch (e) {
      setState(() {
        _isUploading = false;
        _uploadProgress = 0.0;
      });
      _showSnackBar('Error uploading video: $e', isError: true);
    }
  }

  void _showSnackBar(String message, {required bool isError}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1E1E1E),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E1E1E),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Create Video',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Video preview and editing section
            _buildVideoEditingSection(),
            
            // Music section moved to video preview area
            if(_selectedVideo !=null)
            _buildMusicSection(),
            
            // Filters and effects section
            _buildFiltersSection(),
            
            // Description section
            _buildDescriptionSection(),
            
            // Upload button
            Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  if (_isUploading) ...[
                    Container(
                      height: 8,
                      decoration: BoxDecoration(
                        color: Colors.grey[800],
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: LinearProgressIndicator(
                        value: _uploadProgress,
                        backgroundColor: Colors.grey[800],
                        valueColor: const AlwaysStoppedAnimation<Color>(Colors.purple),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Uploading... ${(_uploadProgress * 100).toInt()}%",
                      style: const TextStyle(color: Colors.white),
                    ),
                    const SizedBox(height: 16),
                  ],
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isUploading ? null : _uploadVideo,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.purple,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        elevation: 8,
                        shadowColor: Colors.purple.withOpacity(0.5),
                      ),
                      child: _isUploading
                          ? const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                ),
                                SizedBox(width: 10),
                                Text(
                                  "Uploading...",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            )
                          : const Text(
                              "Post Video",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoEditingSection() {
    return Container(
      margin: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Video preview section with integrated music controls
          Container(
            width: double.infinity,
            height: _selectedVideo != null ? 450 : 200,
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _selectedVideo != null ? Colors.purple : Colors.grey[600]!,
                width: 2,
              ),
            ),
            child: _selectedVideo != null && _isVideoInitialized
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        AspectRatio(
                          aspectRatio: _videoController!.value.aspectRatio,
                          child: _applyVideoFilter(VideoPlayer(_videoController!)),
                        ),
                        // Play/pause overlay
                        GestureDetector(
                          onTap: () {
                            if (_videoController!.value.isPlaying) {
                              _videoController!.pause();
                            } else {
                              _videoController!.play();
                            }
                          },
                          child: Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.5),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              _videoController!.value.isPlaying
                                  ? Icons.pause
                                  : Icons.play_arrow,
                              color: Colors.white,
                              size: 30,
                            ),
                          ),
                        ),
                        // Change video button
                        Positioned(
                          top: 10,
                          right: 10,
                          child: IconButton(
                            onPressed: () => _showVideoSourceDialog(),
                            icon: const Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 24,
                            ),
                            style: IconButton.styleFrom(
                              backgroundColor: Colors.black.withOpacity(0.5),
                              shape: const CircleBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.video_camera_back,
                        size: 60,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Select Video',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildVideoButton(
                            'Camera',
                            Icons.camera_alt,
                            () => _pickVideo(ImageSource.camera),
                          ),
                          _buildVideoButton(
                            'Gallery',
                            Icons.photo_library,
                            () => _pickVideo(ImageSource.gallery),
                          ),
                        ],
                      ),
                    ],
                  ),
          ),
          
          // Video editing tools (if video is selected)
          if (_selectedVideo != null) ...[
            const SizedBox(height: 20),
            const Text(
              'Video Tools',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[850],
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.grey[600]!, width: 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildEditButton(
                    'Trim',
                    Icons.content_cut,
                    () => _showVideoTrimmer(),
                  ),
                  _buildEditButton(
                    'Crop',
                    Icons.crop,
                    () => _showVideoCropper(),
                  ),
                  _buildEditButton(
                    'Speed',
                    Icons.speed,
                    () => _showSpeedControl(),
                  ),
                  _buildEditButton(
                    'Rotate',
                    Icons.rotate_right,
                    () => _rotateVideo(),
                  ),
                ],
              ),
            ),
            
            // Volume control
            if(_selectedMusic == null)...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[850],
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.grey[600]!, width: 1),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      const Icon(Icons.videocam, color: Colors.blue, size: 20),
                      const SizedBox(width: 8),
                      const Text('Video Volume', style: TextStyle(color: Colors.white)),
                      const Spacer(),
                      Text(
                        '${(_videoVolume * 100).round()}%',
                        style: TextStyle(color: Colors.grey[400]),
                      ),
                    ],
                  ),
                  Slider(
                    value: _videoVolume,
                    onChanged: (value) {
                      setState(() {
                        _videoVolume = value;
                      });
                      _videoController?.setVolume(value);
                    },
                    activeColor: Colors.blue,
                    inactiveColor: Colors.grey[600],
                  ),
                ],
              ),
            ),
            ]
          ],
        ],
      ),
    );
  }

  Widget _buildMusicSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Simple Music Addition - ONE TAP PROCESS
          if (_selectedMusic == null) 
            // No music selected - show big add music button
            GestureDetector(
              onTap: _selectMusic,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.purple.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.purple.withOpacity(0.3), width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.purple.withOpacity(0.2),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        color: Colors.purple,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.library_music,
                        color: Colors.white,
                        size: 32,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Tap to Add Background Music',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Choose from your device or our library',
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            )
          else
            // Music selected - show selected music with easy controls
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.7),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.purple.withOpacity(0.5), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.purple.withOpacity(0.3),
                    blurRadius: 15,
                    spreadRadius: 3,
                  ),
                ],
              ),
              child: Column(
                children: [
                  // Music info
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: const BoxDecoration(
                          color: Colors.purple,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.music_note,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _selectedMusic!.title,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _selectedMusic!.artist,
                              style: TextStyle(
                                color: Colors.grey[400],
                                fontSize: 14,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      // Play/Stop button
                      GestureDetector(
                        onTap: _playMusicPreview,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _isMusicPlaying ? Colors.red : Colors.green,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            _isMusicPlaying ? Icons.stop : Icons.play_arrow,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      // Change music button
                      GestureDetector(
                        onTap: _selectMusic,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.purple.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.purple.withOpacity(0.3)),
                          ),
                          child: const Text(
                            'Change',
                            style: TextStyle(
                              color: Colors.purple,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  
                  // Volume controls
                  Row(
                    children: [
                      const Icon(Icons.volume_down, color: Colors.purple, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Slider(
                          value: _musicVolume,
                          onChanged: (value) {
                            setState(() {
                              _musicVolume = value;
                            });
                            if (_isMusicPlaying) {
                              _previewPlayer.setVolume(value);
                            }
                          },
                          activeColor: Colors.purple,
                          inactiveColor: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(Icons.volume_up, color: Colors.purple, size: 20),
                    ],
                  ),
                  Row(
                    children: [
                      const Icon(Icons.video_collection_outlined, color: Colors.purple, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Slider(
                          value: _videoVolume,
                          onChanged: (value) {
                            setState(() {
                              _videoVolume = value;
                            });
                            if (_isMusicPlaying) {
                              _videoController?.setVolume(value);
                            }
                          },
                          activeColor: Colors.purple,
                          inactiveColor: Colors.grey[600],
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(Icons.video_collection, color: Colors.purple, size: 20),
                    ],
                  ),
                ],
              ),
            ),
          // Music info will be shown in video preview area instead
        ],
      ),
    );
  }


  Widget _buildFiltersSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.filter_vintage, color: Colors.orange, size: 24),
              const SizedBox(width: 8),
              const Text(
                'Filters & Effects',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          
          // Filter selection
          Container(
            height: 80,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _filters.length,
              itemBuilder: (context, index) {
                final filter = _filters[index];
                final isSelected = _selectedFilter == filter;
                
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedFilter = filter;
                    });
                  },
                  child: Container(
                    width: 60,
                    margin: const EdgeInsets.only(right: 12),
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.purple : Colors.grey[800],
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? Colors.purple : Colors.grey[600]!,
                        width: 2,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _getFilterIcon(filter),
                          color: isSelected ? Colors.white : Colors.grey[400],
                          size: 20,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          filter,
                          style: TextStyle(
                            color: isSelected ? Colors.white : Colors.grey[400],
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDescriptionSection() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.edit, color: Colors.green, size: 24),
              const SizedBox(width: 8),
              const Text(
                'Description',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _descriptionController,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Write a caption...',
              hintStyle: TextStyle(color: Colors.grey[400]),
              filled: true,
              fillColor: Colors.grey[850],
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.all(16),
            ),
            maxLines: 3,
          ),
        ],
      ),
    );
  }

  Widget _buildEditButton(String label, IconData icon, VoidCallback onPressed) {
    return Column(
      children: [
        IconButton(
          onPressed: onPressed,
          icon: Icon(icon, color: Colors.purple, size: 24),
          style: IconButton.styleFrom(
            backgroundColor: Colors.purple.withOpacity(0.1),
            shape: const CircleBorder(),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  void _showVideoTrimmer() {
    if (_videoController == null || !_isVideoInitialized) {
      _showSnackBar('Please select a video first', isError: true);
      return;
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: 300,
        decoration: const BoxDecoration(
          color: Color(0xFF1E1E1E),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Trim Video',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Video Duration: ${_formatDuration(_videoController!.value.duration)}',
              style: TextStyle(color: Colors.grey[400]),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey[850],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  const Text(
                    'Trim Start Position',
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),
                  const SizedBox(height: 8),
                  Slider(
                    value: 0,
                    max: _videoController!.value.duration.inSeconds.toDouble(),
                    onChanged: (value) {
                      _videoController!.seekTo(Duration(seconds: value.toInt()));
                    },
                    activeColor: Colors.purple,
                    inactiveColor: Colors.grey[600],
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Trim End Position',
                    style: TextStyle(color: Colors.white, fontSize: 14),
                  ),
                  const SizedBox(height: 8),
                  Slider(
                    value: _videoController!.value.duration.inSeconds.toDouble(),
                    max: _videoController!.value.duration.inSeconds.toDouble(),
                    onChanged: (value) {
                      // Handle end position
                    },
                    activeColor: Colors.purple,
                    inactiveColor: Colors.grey[600],
                  ),
                ],
              ),
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
                  ),
                ),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _showSnackBar('Video trimmed successfully!', isError: false);
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                    child: const Text('Apply', style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showVideoCropper() {
    if (_videoController == null || !_isVideoInitialized) {
      _showSnackBar('Please select a video first', isError: true);
      return;
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: 350,
        decoration: const BoxDecoration(
          color: Color(0xFF1E1E1E),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[600],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Crop Video',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                children: [
                  _buildCropOption('Square', '1:1', Icons.crop_square),
                  _buildCropOption('Portrait', '9:16', Icons.crop_portrait),
                  _buildCropOption('Landscape', '16:9', Icons.crop_landscape),
                  _buildCropOption('Original', 'Original', Icons.crop_original),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
                  ),
                ),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _showSnackBar('Video cropped successfully!', isError: false);
                    },
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                    child: const Text('Apply', style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCropOption(String title, String ratio, IconData icon) {
    return GestureDetector(
      onTap: () {
        // Handle crop selection
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[850],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey[600]!, width: 1),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.purple, size: 30),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              ratio,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSpeedControl() {
    if (_videoController == null || !_isVideoInitialized) {
      _showSnackBar('Please select a video first', isError: true);
      return;
    }

    double currentSpeed = 1.0;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => Container(
          height: 300,
          decoration: const BoxDecoration(
            color: Color(0xFF1E1E1E),
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[600],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Video Speed',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Speed: ${currentSpeed.toStringAsFixed(1)}x',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 20),
              Slider(
                value: currentSpeed,
                min: 0.25,
                max: 4.0,
                divisions: 15,
                onChanged: (value) {
                  setModalState(() {
                    currentSpeed = value;
                  });
                },
                activeColor: Colors.purple,
                inactiveColor: Colors.grey[600],
              ),
              const SizedBox(height: 20),
              Wrap(
                spacing: 12,
                children: [0.25, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0].map((speed) {
                  return GestureDetector(
                    onTap: () {
                      setModalState(() {
                        currentSpeed = speed;
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: currentSpeed == speed ? Colors.purple : Colors.grey[800],
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Text(
                        '${speed}x',
                        style: TextStyle(
                          color: currentSpeed == speed ? Colors.white : Colors.grey[400],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const Spacer(),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
                    ),
                  ),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _showSnackBar('Video speed changed to ${currentSpeed}x!', isError: false);
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                      child: const Text('Apply', style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _rotateVideo() {
    if (_videoController == null || !_isVideoInitialized) {
      _showSnackBar('Please select a video first', isError: true);
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E1E),
        title: const Text(
          'Rotate Video',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Choose rotation angle:',
              style: TextStyle(color: Colors.white),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildRotateButton('90°', Icons.rotate_right),
                _buildRotateButton('180°', Icons.refresh),
                _buildRotateButton('270°', Icons.rotate_left),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
        ],
      ),
    );
  }

  Widget _buildRotateButton(String angle, IconData icon) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        _showSnackBar('Video rotated $angle!', isError: false);
      },
      child: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: Colors.purple.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.purple, width: 1),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.purple, size: 20),
            const SizedBox(height: 4),
            Text(
              angle,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  Widget _applyVideoFilter(Widget videoWidget) {
    if (_selectedFilter == 'None') {
      return videoWidget;
    }

    return ColorFiltered(
      colorFilter: _getColorFilter(_selectedFilter),
      child: videoWidget,
    );
  }

  ColorFilter _getColorFilter(String filter) {
    switch (filter) {
      case 'Black & White':
        return const ColorFilter.matrix([
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0.2126, 0.7152, 0.0722, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case 'Sepia':
        return const ColorFilter.matrix([
          0.393, 0.769, 0.189, 0, 0,
          0.349, 0.686, 0.168, 0, 0,
          0.272, 0.534, 0.131, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case 'Vintage':
        return const ColorFilter.matrix([
          1.0, 0.0, 0.0, 0, 20,
          0.0, 1.0, 0.0, 0, 10,
          0.0, 0.0, 0.8, 0, 30,
          0, 0, 0, 1, 0,
        ]);
      case 'Cool':
        return const ColorFilter.matrix([
          0.8, 0.0, 0.2, 0, 0,
          0.0, 0.9, 0.1, 0, 0,
          0.0, 0.0, 1.2, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case 'Warm':
        return const ColorFilter.matrix([
          1.2, 0.0, 0.0, 0, 20,
          0.0, 1.1, 0.0, 0, 10,
          0.0, 0.0, 0.8, 0, 0,
          0, 0, 0, 1, 0,
        ]);
      case 'Bright':
        return const ColorFilter.matrix([
          1.2, 0.0, 0.0, 0, 30,
          0.0, 1.2, 0.0, 0, 30,
          0.0, 0.0, 1.2, 0, 30,
          0, 0, 0, 1, 0,
        ]);
      case 'Dark':
        return const ColorFilter.matrix([
          0.8, 0.0, 0.0, 0, -20,
          0.0, 0.8, 0.0, 0, -20,
          0.0, 0.0, 0.8, 0, -20,
          0, 0, 0, 1, 0,
        ]);
      default:
        return const ColorFilter.matrix([
          1, 0, 0, 0, 0,
          0, 1, 0, 0, 0,
          0, 0, 1, 0, 0,
          0, 0, 0, 1, 0,
        ]);
    }
  }

  Widget _buildVideoTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Video picker section
          Container(
            width: double.infinity,
            height: _selectedVideo != null ? 300 : 200,
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _selectedVideo != null ? Colors.purple : Colors.grey[600]!,
                width: 2,
              ),
            ),
            child: _selectedVideo != null && _isVideoInitialized
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        AspectRatio(
                          aspectRatio: _videoController!.value.aspectRatio,
                          child: _applyVideoFilter(VideoPlayer(_videoController!)),
                        ),
                        // Play/pause overlay
                        GestureDetector(
                          onTap: () {
                            if (_videoController!.value.isPlaying) {
                              _videoController!.pause();
                            } else {
                              _videoController!.play();
                            }
                          },
                          child: Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.5),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              _videoController!.value.isPlaying
                                  ? Icons.pause
                                  : Icons.play_arrow,
                              color: Colors.white,
                              size: 30,
                            ),
                          ),
                        ),
                        // Change video button
                        Positioned(
                          top: 10,
                          right: 10,
                          child: IconButton(
                            onPressed: () => _showVideoSourceDialog(),
                            icon: const Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 24,
                            ),
                            style: IconButton.styleFrom(
                              backgroundColor: Colors.black.withOpacity(0.5),
                              shape: const CircleBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.video_camera_back,
                        size: 60,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'Select Video',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildVideoButton(
                            'Camera',
                            Icons.camera_alt,
                            () => _pickVideo(ImageSource.camera),
                          ),
                          _buildVideoButton(
                            'Gallery',
                            Icons.photo_library,
                            () => _pickVideo(ImageSource.gallery),
                          ),
                        ],
                      ),
                    ],
                  ),
          ),
          
          const SizedBox(height: 20),
          
          // Description field
          const Text(
            'Description',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _descriptionController,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Write a caption...',
              hintStyle: TextStyle(color: Colors.grey[400]),
              filled: true,
              fillColor: Colors.grey[800],
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.all(16),
            ),
            maxLines: 3,
          ),
        ],
      ),
    );
  }

  Widget _buildMusicTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Music selection
          const Text(
            'Background Music',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _selectedMusic != null ? Colors.purple : Colors.grey[600]!,
                width: 2,
              ),
            ),
            child: _selectedMusic != null
                ? Column(
                    children: [
                      Row(
                        children: [
                          // Music artwork or icon
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.purple.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: Colors.purple, width: 1),
                            ),
                            child: const Icon(
                              Icons.music_note,
                              color: Colors.purple,
                              size: 30,
                            ),
                          ),
                          const SizedBox(width: 16),
                          // Music info
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _selectedMusic!.title,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  _selectedMusic!.artist,
                                  style: TextStyle(
                                    color: Colors.grey[400],
                                    fontSize: 14,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                          // Play/pause button
                          IconButton(
                            onPressed: _playMusicPreview,
                            icon: Icon(
                              _isMusicPlaying ? Icons.pause : Icons.play_arrow,
                              color: Colors.purple,
                              size: 30,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      // Volume controls
                      Column(
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.music_note, color: Colors.purple, size: 20),
                              const SizedBox(width: 8),
                              const Text('Music Volume', style: TextStyle(color: Colors.white)),
                              const Spacer(),
                              Text(
                                '${(_musicVolume * 100).round()}%',
                                style: TextStyle(color: Colors.grey[400]),
                              ),
                            ],
                          ),
                          Slider(
                            value: _musicVolume,
                            onChanged: (value) {
                              setState(() {
                                _musicVolume = value;
                              });
                              if (_isMusicPlaying) {
                                _previewPlayer.setVolume(value);
                              }
                            },
                            activeColor: Colors.purple,
                            inactiveColor: Colors.grey[600],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              const Icon(Icons.videocam, color: Colors.blue, size: 20),
                              const SizedBox(width: 8),
                              const Text('Video Volume', style: TextStyle(color: Colors.white)),
                              const Spacer(),
                              Text(
                                '${(_videoVolume * 100).round()}%',
                                style: TextStyle(color: Colors.grey[400]),
                              ),
                            ],
                          ),
                          Slider(
                            value: _videoVolume,
                            onChanged: (value) {
                              setState(() {
                                _videoVolume = value;
                              });
                              _videoController?.setVolume(value);
                            },
                            activeColor: Colors.blue,
                            inactiveColor: Colors.grey[600],
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      // Remove music button
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            setState(() {
                              _selectedMusic = null;
                              _isMusicPlaying = false;
                            });
                            _previewPlayer.stop();
                          },
                          icon: const Icon(Icons.clear, color: Colors.red),
                          label: const Text(
                            'Remove Music',
                            style: TextStyle(color: Colors.red),
                          ),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.red),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ],
                  )
                : Column(
                    children: [
                      Icon(
                        Icons.music_note_outlined,
                        size: 60,
                        color: Colors.grey[400],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No music selected',
                        style: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _selectMusic,
                          icon: const Icon(Icons.library_music, color: Colors.white),
                          label: const Text(
                            'Add Music',
                            style: TextStyle(color: Colors.white, fontSize: 16),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.purple,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 15),
                          ),
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildEffectsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Filters',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          // Filter selection
          Container(
            height: 120,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _filters.length,
              itemBuilder: (context, index) {
                final filter = _filters[index];
                final isSelected = _selectedFilter == filter;
                
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedFilter = filter;
                    });
                  },
                  child: Container(
                    width: 80,
                    margin: const EdgeInsets.only(right: 12),
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.purple : Colors.grey[800],
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                        color: isSelected ? Colors.purple : Colors.grey[600]!,
                        width: 2,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _getFilterIcon(filter),
                          color: isSelected ? Colors.white : Colors.grey[400],
                          size: 30,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          filter,
                          style: TextStyle(
                            color: isSelected ? Colors.white : Colors.grey[400],
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          
          const SizedBox(height: 30),
          
          // Coming soon section
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.grey[600]!, width: 1),
            ),
            child: Column(
              children: [
                Icon(
                  Icons.auto_awesome,
                  size: 40,
                  color: Colors.purple[300],
                ),
                const SizedBox(height: 16),
                const Text(
                  'More Effects Coming Soon!',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'We\'re working on amazing new effects, transitions, and text options for your videos.',
                  style: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoButton(String label, IconData icon, VoidCallback onPressed) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, color: Colors.white),
      label: Text(label, style: const TextStyle(color: Colors.white)),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.purple,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      ),
    );
  }

  void _showVideoSourceDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'Select Video Source',
          style: TextStyle(color: Colors.white),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt, color: Colors.purple),
              title: const Text('Camera', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _pickVideo(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Colors.purple),
              title: const Text('Gallery', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _pickVideo(ImageSource.gallery);
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
        ],
      ),
    );
  }

  IconData _getFilterIcon(String filter) {
    switch (filter) {
      case 'None':
        return Icons.filter_none;
      case 'Vintage':
        return Icons.camera_outlined;
      case 'Black & White':
        return Icons.monochrome_photos;
      case 'Sepia':
        return Icons.gradient;
      case 'Cool':
        return Icons.ac_unit;
      case 'Warm':
        return Icons.wb_sunny;
      case 'Bright':
        return Icons.brightness_high;
      case 'Dark':
        return Icons.brightness_low;
      default:
        return Icons.filter_vintage;
    }
  }
}
