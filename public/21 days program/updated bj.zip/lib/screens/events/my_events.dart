
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:google_maps_place_picker_mb/google_maps_place_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/main.dart';


import '../../providers/events_provider/events_provider.dart';
import '../../repo/api_consts.dart';
import '../../services/api_services/event_services/event_services.dart' show EventServices;
import '../../utils/color.dart';
import '../../widget/reusable_textformfield.dart';
import 'container.dart';
import 'event_map_screen.dart';
class MyEvents extends StatefulWidget {
  const MyEvents({Key? key}) : super(key: key);

  @override
  State<MyEvents> createState() => _MyEventsState();
}

class _MyEventsState extends State<MyEvents> {

  final List<String> eventName = ['Music Event',
    'Canada Event',
    "shaggy music festival",
    'Music training festival',
    'Los angles festival',
    'portugol music festival',
  ];

  bool isLoading=false;
  XFile? _selectedImage;

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      setState(() {
        _selectedImage = image;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Provider.of<EventsProvider>(context,listen: false).getMyEvents(context);
  }

  // Navigate to event map screen
  void _navigateToEventMap(double latitude, double longitude, String eventName, String? eventAddress) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EventMapScreen(
          latitude: latitude,
          longitude: longitude,
          eventName: eventName,
          eventAddress: eventAddress,
        ),
      ),
    );
  }


  DateTime? eventDate=DateTime.now();
  DateTime? eventStartTime=DateTime.now();
  DateTime? eventEndTime=DateTime.now();
  TextEditingController eventStartController=TextEditingController();
  TextEditingController eventEndController=TextEditingController();
  TextEditingController eventDateController=TextEditingController();
  TextEditingController artistNameController=TextEditingController();
  TextEditingController eventNameController=TextEditingController();
  TextEditingController placeNameController=TextEditingController();
  String latitude="";
  String longitude="";

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;

    return Consumer<EventsProvider>(
      builder: (context,myEvent,_) {
        return Column(children: [
          const SizedBox(height: 15),
          Row(
            children: [
              Flexible(
                child: ReusableTextForm(
                  borderRadius: 30,
                 /// controller: searchController,
                  hintText: "Search event",
                  onChanged: (value){
                    //searchProduct(value);
                    setState(() {

                    });
                  },
                  filledColor: Colors.white24,
                  prefixIcon: const Icon(
                    Icons.search,
                    color: greyColor,
                  ),

                ),
              ),
              const SizedBox(width: 10,),
              GestureDetector(
                onTap: (){
                  setState(() {

                    showModalBottomSheet(
                      isScrollControlled: true,
                      context: context,
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                              topRight: Radius.circular(15),
                              topLeft: Radius.circular(15))),
                      builder: (BuildContext context) {
                        return StatefulBuilder(
                          builder: (BuildContext context,
                              void Function(void Function()) setState) {
                            return SizedBox(
                              height: screenHeight * 0.85,
                              child: SingleChildScrollView(

                                child: Column(
                                  //  clipBehavior: Clip.antiAlias,
                                  children: [
                                    GestureDetector(
                                      onTap:(){
                                        Navigator.pop(context);
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(right: 5, top: 5),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.end,
                                          children: [
                                            Container(
                                                decoration:  BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: Colors.red.shade400,


                                                ),

                                                height: 30,
                                                width: 30,

                                                child: const Center(child: Icon(Icons.close, color: Colors.white,))),
                                          ],),
                                      ),
                                    ),
                                    Container(
                                      height: screenHeight * 0.80,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(
                                              20)),
                                      padding: const EdgeInsets.all(16.0),
                                      child: SingleChildScrollView(
                                        scrollDirection: Axis.vertical,
                                        physics: const ScrollPhysics(),
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment
                                              .center,
                                          children: <Widget>[
                                            GestureDetector(
                                              onTap:() async {
                                                await _pickImage();
                                              },
                                              child: Container(
                                                height: 140,
                                                width: double.infinity,
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(10),
                                                  color:  indigoColor,
                                                ),
                                                child: _selectedImage == null
                                                    ? const Center(
                                                  child:
                                                  Text(
                                                    'Click to Add Event Photo',
                                                    style: TextStyle(
                                                    ),
                                                  ),
                                                )
                                                    : Image.file(
                                                  File(_selectedImage!.path),
                                                  width: 200,
                                                  height: 200,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                            const SizedBox(height: 15,),
                                            ReusableTextForm(
                                              borderRadius: 10,
                                              controller: artistNameController,
                                              hintText: "Enter artist name",
                                              onChanged: (value){
                                                //searchProduct(value);
                                                setState(() {

                                                });
                                              },
                                              filledColor: Colors.white24,

                                            ),
                                            const SizedBox(height: 15,),
                                            ReusableTextForm(
                                              borderRadius: 10,
                                              controller: eventNameController,
                                              hintText: "Enter event name",
                                              onChanged: (value){
                                                //searchProduct(value);
                                                setState(() {

                                                });
                                              },
                                              filledColor: Colors.white24,

                                            ),
                                            const SizedBox(height: 15,),
                                            ReusableTextForm(
                                              suffixIcon: const Icon(Icons.arrow_drop_down_outlined),
                                              borderRadius: 10,
                                              controller: placeNameController,
                                              hintText: "Select Event place",
                                              onTap: (){
                                                pickLocation();
                                              },
                                              onChanged: (value){
                                                //searchProduct(value);
                                                setState(() {

                                                });
                                              },
                                              filledColor: Colors.white24,

                                            ),
                                            const SizedBox(height: 15,),
                                            ReusableTextForm(
                                              suffixIcon: const Icon(Icons.arrow_drop_down_outlined),
                                              borderRadius: 10,
                                              controller: eventStartController,
                                              hintText: "Select Start time",
                                              onTap: ()async{
                                                showDatePicker(
                                                  context: context,
                                                  initialDate: DateTime.now(),
                                                  firstDate: DateTime(2000),
                                                  lastDate: DateTime(2101),
                                                ).then((selectedDate) {

                                                  // After selecting the date, display the time picker.
                                                  if (selectedDate != null) {
                                                    showTimePicker(
                                                      context: context,
                                                      initialTime: TimeOfDay.now(),
                                                    ).then((selectedTime) {
                                                      // Handle the selected date and time here.
                                                      if (selectedTime != null) {
                                                        DateTime selectedDateTime = DateTime(
                                                          selectedDate.year,
                                                          selectedDate.month,
                                                          selectedDate.day,
                                                          selectedTime.hour,
                                                          selectedTime.minute,

                                                        );
                                                        print(selectedDateTime);// You can use the selectedDateTime as needed.
                                                        eventStartTime=selectedDateTime;
                                                        eventStartController.text=DateFormat.yMd().add_jm().format(eventStartTime!);
                                                        setState((){});

                                                      }else{
                                                        eventStartTime=DateTime.now();
                                                        eventStartController.text=DateFormat.yMd().add_jm().format(eventStartTime!);
                                                        setState((){});
                                                      }
                                                    });
                                                  }
                                                });
                                              },
                                              onChanged: (value){
                                                //searchProduct(value);
                                                setState(() {

                                                });
                                              },
                                              filledColor: Colors.white24,

                                            ),
                                            const SizedBox(height: 15,),
                                            ReusableTextForm(

                                              borderRadius: 10,  suffixIcon: const Icon(Icons.arrow_drop_down_outlined),
                                              controller: eventEndController,
                                              hintText: "Select end time",
                                              onTap: ()async{

                                                showDatePicker(
                                                  context: context,
                                                  initialDate: DateTime.now(),
                                                  firstDate: DateTime(2000),
                                                  lastDate: DateTime(2101),
                                                ).then((selectedDate) {

                                                  // After selecting the date, display the time picker.
                                                  if (selectedDate != null) {
                                                    showTimePicker(
                                                      context: context,
                                                      initialTime: TimeOfDay.now(),
                                                    ).then((selectedTime) {
                                                      // Handle the selected date and time here.
                                                      if (selectedTime != null) {
                                                        DateTime selectedDateTime = DateTime(
                                                          selectedDate.year,
                                                          selectedDate.month,
                                                          selectedDate.day,
                                                          selectedTime.hour,
                                                          selectedTime.minute,

                                                        );
                                                        print(selectedDateTime);// You can use the selectedDateTime as needed.
                                                        eventEndTime=selectedDateTime;

                                                        eventEndController.text=DateFormat.yMd().add_jm().format(eventEndTime!);
                                                        setState((){});

                                                      }else{
                                                       eventEndTime=DateTime.now();
                                                       eventEndController.text=DateFormat.yMd().add_jm().format(eventEndTime!);
                                                       setState((){});
                                                      }
                                                    });
                                                  }
                                                });


                                                // eventEndTime=await showTimePicker(
                                                //     context: context,
                                                //     initialTime: TimeOfDay.now());
                                                // eventEndTime ?? (eventEndTime=TimeOfDay.now());
                                                // eventEndController.text=eventEndTime!.format(context);
                                                // setState((){});



                                              },
                                              onChanged: (value){
                                                //searchProduct(value);
                                                setState(() {

                                                });
                                              },
                                              filledColor: Colors.white24,

                                            ),
                                            const SizedBox(height: 15,),
                                            ReusableTextForm(
                                              suffixIcon: const Icon(Icons.arrow_drop_down_outlined),
                                              borderRadius: 10,
                                              readOnly: true,
                                              controller: eventDateController,
                                              hintText: "Select date",
                                              onTap: ()async{


                                                eventDate=await showDatePicker(
                                                    context: context,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime.now(),
                                                    lastDate: DateTime(2050,01,01));

                                              },
                                              onChanged: (value){
                                                //searchProduct(value);
                                                setState(() {

                                                });
                                              },
                                              filledColor: Colors.white24,

                                            ),
                                            const SizedBox(height: 25,),


                                            InkWell(
                                              onTap: ()async{
                                                bool response=await EventServices().createEvent(context,
                                                    artistName: artistNameController.text,
                                                    artistId: "1",
                                                    eventName: eventNameController.text,
                                                    locationName: placeNameController.text,
                                                    latitude: latitude,
                                                    longitude: longitude,
                                                    eventStartTime: eventStartTime.toString(),
                                                    eventEndTime: eventEndTime.toString(),
                                                    eventDate: "",
                                                    imagePath: _selectedImage!.path
                                                );
                                                if(response){
                                                  if(context.mounted){
                                                    await Provider.of<EventsProvider>(context,listen: false).getMyEvents(context);
                                                    Navigator.pop(context);
                                                  }
                                                }
                                              },
                                              child: Container(

                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(20),
                                                  color: indigoColor,
                                                ),
                                                height: 50,width: 150,
                                                child: const Center(
                                                  child: Text("Event upload"),
                                                ),

                                              ),
                                            )

                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                    );
                  });
                },
                child: Container(
                  decoration:  BoxDecoration(
                    color: indigoColor,

                    borderRadius: BorderRadius.circular(30),
                  ),
                  height: 50,
                  width: 50,
                  child: const Center(
                    child: Icon(
                      Icons.add,
                      color: Colors.white,
                    ),
                  ),

                ),
              )
            ],
          ),
          const SizedBox(height: 15,),
          Expanded(
            child: myEvent.isLoading?const SizedBox(
                height: 30,
                width: 30,
                child: Center(child: CircularProgressIndicator())):
            myEvent.myEvents.isEmpty?const Text("No Events Available"):
            ListView.builder(
              physics: const ScrollPhysics(),
              shrinkWrap: true,
              itemCount: myEvent.myEvents.length,
              itemBuilder: (BuildContext context, int index) {
                                return Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(10),
                                         onTap: () {
                       // Get coordinates from the event
                       double lat = double.tryParse(myEvent.myEvents[index].latitude) ?? 0.0;
                       double lng = double.tryParse(myEvent.myEvents[index].longitude) ?? 0.0;
                       
                       // Navigate to event map screen
                       _navigateToEventMap(lat, lng, myEvent.myEvents[index].eventName, myEvent.myEvents[index].address);
                     },
                    child: CustomContainerForEvent(
                        requiredEventName: myEvent.myEvents[index].eventName,
                        requiredEventPlace: myEvent.myEvents[index].address ?? myEvent.myEvents[index].eventPlace, // Use address if available, fallback to eventPlace
                        requiredEventTime: DateFormat("dd-MM-yyyy ").add_jm().format(DateTime.parse(myEvent.myEvents[index].eventStartTime)),
                        requiredImage: myEvent.myEvents[index].picturePath.replaceAll("public", ApiConstants.baseUrl),
                        requiredEventEndTime: DateFormat("dd-MM-yyyy ").add_jm().format(DateTime.parse(myEvent.myEvents[index].eventEndTime)),
                        requiredEventArtist: myEvent.myEvents[index].artistName,
                        isMyEvent: true,
                                                 eventId: myEvent.myEvents[index].id.toString(),
                      )),
                );
              },),
          ),
        ],);
      }
    );
  }

  // void showPlacePicker() async {
  //   LocationResult? result = await Navigator.of(context).push(
  //       MaterialPageRoute(builder: (context) => PlacePicker(
  //           "AIzaSyDoXNJ61DgfBXVBIANYkUZJfhai6vtelhY",
  //
  //       )));
  //
  //   // Handle the result in your way
  //   printLog("${result}");
  // }

  pickLocation()async{


    // Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //     builder: (context) => PlacePicker(
    //         apiKey: Platform.isAndroid
    //             ? "AIzaSyAlWLuEzszKgldMmuo9JjtKLxe9MGk75_k"
    //             : "YOUR IOS API KEY",
    //         onPlacePicked: (result) {
    //   print(result.adrAddress);
    //   latitude=result.geometry!.location.lat.toString();
    //   longitude=result.geometry!.location.lng.toString();
    //   placeNameController.text=result.formattedAddress!;
    //   setState(() {
    //
    //   });
    //
    //   Navigator.of(context).pop();
    //   },
    //     // initialPosition: HomePage.kInitialPosition,
    //     useCurrentLocation: true,
    //     resizeToAvoidBottomInset: false,
    //       initialPosition:  const LatLng(37.42796133580664, -122.085749655962) , // only works in page mode, less flickery, remove if wrong offsets
    //   ),
    // ),
    // );
}


}
