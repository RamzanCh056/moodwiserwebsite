import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
class MapScreen extends StatefulWidget {

   MapScreen(this.currentIndex, this.long, this.lat,this.longLat,this.eventName, this.eventLocation,  {Key? key}) : super(key: key);
  int currentIndex;
  double  long ;
  double  lat ;
   List<double> longLat;
   String eventName;
   String eventLocation;
  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {

  static const _initialCameraPosition = CameraPosition(
    target: LatLng(30.3753, 69.3451),
    zoom: 11.5,
  );
  PageController controller = PageController();
  @override
  void dispose() {
    _googleMapController.dispose();

    super.dispose();
  }

  @override
  void initState() {
    Future.delayed(const Duration(milliseconds: 100), () {
      controller.jumpToPage(widget.currentIndex);
    });
    super.initState();
  }

  late GoogleMapController _googleMapController;

  final Set<Marker> markers = Set(); //markers for google map


  TextEditingController search = TextEditingController();
  // void launchMapsUrl(index) async {
  //   final url = 'https://www.google.com/maps/search/?api=1&query=${widget.users[index].lat!},${widget.users[index].lng!}';
  //   if (await canLaunch(url)) {
  //     await launch(url);
  //   } else {
  //     throw 'Could not launch $url';
  //   }
  // }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.eventName),
        elevation: 0,
        backgroundColor: Colors.transparent,
        centerTitle: true,
      ),
      body: Stack(
          children: [
            Container(
              height: MediaQuery.of(context).size.height,
              width: double.infinity,
              alignment: Alignment.center,
              child: GoogleMap(
                zoomGesturesEnabled: true,
                initialCameraPosition: CameraPosition(
                  target: LatLng(widget.lat,
                      widget.long),
                   zoom: 5,
                ),
                markers: getmarkers(),
                onMapCreated: (controller) => _googleMapController = controller,
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Positioned.fill(
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    color: Colors.transparent,
                    height: 120,
                    child: PageView.builder(
                      itemBuilder: buildListItem,
                      controller: controller,
                      itemCount: widget.longLat.length,
                      onPageChanged: (val) {
                        moveToLocation(val);
                        print(val);
                      },
                    ),
                  ),
                ))
          ],
        ),
      );

  }
  Set<Marker> getmarkers() {

    for (int i = 0; i < widget.longLat.length; i++) {
      markers.add(Marker(
        //add second marker
        markerId: MarkerId('$i'),
        position: LatLng(widget.lat, widget.long),
        icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueViolet
        ),
      ));
    }
    setState(() {});

    return markers;
  }

  moveToLocation(int index) {
    _googleMapController.animateCamera(CameraUpdate.newCameraPosition(
      CameraPosition(
          target: LatLng(widget.lat, widget.long),
          zoom: 15.151926040649414),
    ));
  }

  Widget buildListItem(BuildContext context, int index) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: InkWell(
        onTap: (){
        //  launchMapsUrl(index);
        },
        child: Container(
          width: MediaQuery.of(context).size.width,
          margin: const EdgeInsets.only(bottom: 15),
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: const [
                BoxShadow(color: Colors.black12, blurRadius: 6 )
              ]
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Row(

                  children: [
                    const Text(
                      'Name: ',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15,color: Colors.grey),
                    ),
                    Text(
                     widget.eventName,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 15, color: Colors.grey ),
                    ),
                  ],
                ),
                const SizedBox(height: 5,),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children:  [
                    const Icon(
                      Icons.fmd_good_outlined,
                      color: Colors.purple,
                      size: 16,
                    ),
                    Expanded(
                      child: Text(
                        widget.eventLocation,
                        style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey),
                      ),
                    ),
                  ],
                )

              ],
            ),
          ),

        ),
      ),
    );
  }
}
