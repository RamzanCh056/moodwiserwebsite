import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart'as http;

import '../../services/api_services/event_services/event_services.dart';
import '../../utils/color.dart';

class CustomContainerForEvent extends StatelessWidget {
  final String? requiredImage;
  final String? requiredEventName;
  final String? requiredEventPlace;
  final String? requiredEventTime;
  final String? requiredEventEndTime;
  final String? requiredEventArtist;
  final bool isMyEvent;
  final String eventId;

  const CustomContainerForEvent(
      {super.key, this.requiredImage, this.requiredEventName, this.requiredEventPlace, this.requiredEventTime, this.requiredEventEndTime,this. requiredEventArtist, this.isMyEvent = false,required this.eventId});

  // Get display place text with fallback
  String _getDisplayPlace() {
    if (requiredEventPlace == null || requiredEventPlace!.isEmpty) {
      return 'Location not set';
    }
    
    // Check if it's an error message
    if (requiredEventPlace!.contains('Error getting address')) {
      return '📍 Tap to view location';
    }
    
    // Truncate if too long
    if (requiredEventPlace!.length > 40) {
      return requiredEventPlace!.substring(0, 39) + '...';
    }
    
    return requiredEventPlace!;
  }

    @override
  Widget build(BuildContext context) {
    print('Building CustomContainerForEvent for: ${requiredEventName}');
    return Container(
       margin: const EdgeInsets.only(bottom: 15),
       width: double.infinity,
       padding: const EdgeInsets.all(16),
       decoration: BoxDecoration(
         borderRadius: BorderRadius.circular(16),
         color: const Color(0xFF1F1F1F),
         border: Border.all(
           color: const Color(0xFFBB86FC).withOpacity(0.2),
           width: 1,
         ),
         boxShadow: [
           BoxShadow(
             color: Colors.black.withOpacity(0.3),
             blurRadius: 10,
             offset: const Offset(0, 4),
           ),
         ],
       ),
      child: Stack(

        children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                         ClipRRect(
               borderRadius: BorderRadius.circular(12),
               child: Container(
                 width: 120,
                 height: 120,
                 decoration: BoxDecoration(
                   borderRadius: BorderRadius.circular(12),
                   boxShadow: [
                     BoxShadow(
                       color: Colors.black.withOpacity(0.3),
                       blurRadius: 8,
                       offset: const Offset(0, 4),
                     ),
                   ],
                 ),
                 child: Image.network(
                   requiredImage!,
                   width: 120,
                   height: 120,
                   fit: BoxFit.cover,
                                        errorBuilder: (context, error, stackTrace) {
                       return Container(
                         width: 120,
                         height: 120,
                         decoration: BoxDecoration(
                           color: const Color(0xFF2A2A2A),
                           borderRadius: BorderRadius.circular(12),
                         ),
                         child: const Icon(
                           Icons.image,
                           color: Color(0xFFBB86FC),
                           size: 50,
                         ),
                       );
                     },
                                        loadingBuilder: (context, child, loadingProgress) {
                       if (loadingProgress == null) return child;
                       return Container(
                         width: 120,
                         height: 120,
                         decoration: BoxDecoration(
                           color: const Color(0xFF2A2A2A),
                           borderRadius: BorderRadius.circular(12),
                         ),
                         child: Center(
                           child: CircularProgressIndicator(
                             value: loadingProgress.expectedTotalBytes != null
                                 ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                 : null,
                             color: const Color(0xFFBB86FC),
                           ),
                         ),
                       );
                     },
                 ),
               ),
             ),
            const SizedBox(width: 10,),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start, children: [
                                 const SizedBox(height: 12),
               Text(
                 requiredEventName.toString(),
                 style: const TextStyle(
                   fontWeight: FontWeight.bold,
                   fontSize: 18,
                   color: const Color(0xFFBB86FC),
                 ),
               ),
                const SizedBox(height: 8),
              RichText(text: TextSpan(
                  text: 'Artist: ',
                  style: const TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 12,
                      color: Color(0xff7D8CAC)),
                  children: [
                    TextSpan(
                      text: requiredEventArtist,
                      style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 10,
                          color: Colors.white),
                    )
                  ]

              )               ),
               const SizedBox(height: 8,),
               Row(
                children: [
                  const Icon(
                    Icons.location_on,
                    size: 12,
                    color: Color(0xFFBB86FC),
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: RichText(
                        softWrap: true,
                        overflow: TextOverflow.visible,
                        text: TextSpan(
                        text: 'Place: ',
                        style: const TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 12,
                            color: Color(0xff7D8CAC)),
                        children: [
                          TextSpan(
                            text: _getDisplayPlace(),
                            style: const TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 10,
                                color: Colors.white),
                          )
                        ]

                    )),
                  ),
                                 ],
               ),
               const SizedBox(height: 8,),
               RichText(text: TextSpan(
                  text: 'Time: ',
                  style: const TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 12,
                      color: Color(0xff7D8CAC)),
                  children: [

                    TextSpan(
                      text: "${requiredEventTime.toString()} to ${requiredEventEndTime.toString()}",
                      style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 10,
                          color: Colors.white),
                    )
                  ]

              )),

              // Text('      |',  style: const TextStyle(
              //   fontWeight: FontWeight.w500,
              //   fontSize: 12,
              //
              //   color: Color(0xff99A7C7),
              //
              // ),),
              // Text(requiredEventTime.toString(),
              //   style: const TextStyle(
              //     fontWeight: FontWeight.w500,
              //     fontSize: 12,
              //
              //     color: Color(0xff99A7C7),
              //
              //   ),
              //   // textAlign: TextAlign.end,
              // ),
            ],
            )
          ],),
          
          // Click hint for map navigation
          Positioned(
            right: 5,
            bottom: 5,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFFBB86FC).withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: const Color(0xFFBB86FC).withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.map,
                    size: 10,
                    color: Color(0xFFBB86FC),
                  ),
                  const SizedBox(width: 2),
                  Text(
                    'Tap for map',
                    style: TextStyle(
                      color: const Color(0xFFBB86FC).withOpacity(0.8),
                      fontSize: 8,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
          isMyEvent?
          Positioned(
            right: 5,
            top: 5,
            child: InkWell(
              onTap: ()async{
               http.Response response= await EventServices().deleteEvent(context, eventId: eventId);
               if(response.statusCode==200){
                 Get.showSnackbar(const GetSnackBar(message: "Successfully deleted",duration: Duration(seconds: 2),));
                 await EventServices().getMyEvents(context);

               }else{
                 Get.showSnackbar(const GetSnackBar(message: "Something went wrong",duration: Duration(seconds: 2),));

               }
               },
              child: Container(
                decoration:  BoxDecoration(
                  color: Colors.red.shade400,

                  borderRadius: BorderRadius.circular(30),
                ),

                height: 25,
                width: 25,
                child: const Center(
                  child: Icon(
                    Icons.delete,size: 18,
                    color: Colors.white,
                  ),
                ),

              ),
            ),
          ) :SizedBox()
        ],
      ),

    );
  }
}
