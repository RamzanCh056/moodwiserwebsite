import 'dart:async';
import 'package:flutter/material.dart';

import 'package:intl/intl.dart';
import 'package:provider/provider.dart';


import '../../providers/events_provider/events_provider.dart';
import '../../repo/api_consts.dart';
import '../../utils/color.dart';
import '../../widget/reusable_textformfield.dart';
import 'container.dart';
import 'event_map_screen.dart';
class AllEvents extends StatefulWidget {
  const AllEvents({Key? key}) : super(key: key);

  @override
  State<AllEvents> createState() => _AllEventsState();
}

class _AllEventsState extends State<AllEvents> {

  final List<String> eventName = ['Music Event',
    'Canada Event',
    "shaggy music festival",
    'Music training festival',
    'Los angles festival',
    'portugol music festival',
  ];
  final List<String> eventTime = [
    'October 20, Tuesday, 9 AM',
    'October 25, Tuesday, 9 AM',
    'October 30, Tuesday, 9 AM',
    'October 10, Tuesday, 9 AM',
    'October 15, Tuesday, 9 AM',
    'October 5, Tuesday, 9 AM',
    'October 22, Tuesday, 9 AM',

  ];
  final List<String> eventEndTime = [
    '11:00 AM',
    '10:00 AM',
    '11:00 AM',
    '12:00 PM',
    '10:00 AM',
    '10:00 pm',
    '11:00 pm',
    '10:00 pm',
    '11:00 pm',

  ];
  final List<String> eventPlace = [
    'London city',
    'New York Music',
    'Candida Music',
    'Pakistan',
    'Candida city',
    'India',

  ];
  final List<String> artistName = [
    'John band',
    'Bts boys',
    'Canadian hero',
    'aima baig',
    'Nusrat',
    'Arman jog',

  ];
  final List<String> eventImages = ['https://media.istockphoto.com/id/1478375497/photo/friends-dancing-at-the-festival.webp?b=1&s=170667a&w=0&k=20&c=EbYC1LAUa6gIhUSrOJiW7M6SYatTSxVOPeIUXJDnbJI=',
    'https://themusicessentials.com/wp-content/uploads/2021/08/how-to-organise-music-festival-450x300.jpg',
    'https://i.pinimg.com/474x/ff/98/47/ff9847cae8f3eae7ecfce681bd80e316.jpg',
    'https://sandwichevents.org.uk/wp-content/uploads/2016/02/many-people-music-event-concert-awesome.jpg',
    'https://media.istockphoto.com/id/1289481257/photo/a-crowded-concert-hall-with-scene-stage-lights-rock-show-performance-with-people-silhouette.jpg?b=1&s=612x612&w=0&k=20&c=i04jVo_GHeV4JdYwKoV8YFwE4TeuXs58sjKGNX56gbM=',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1dCWcifABNHEG9fEJeDcNsrt9Zo9Sqw-oxDsje_cIcLnq6EbH5X71YzCOshennXJ1G64&usqp=CAU',
  ];

  final List<double> latitude = <double>[
    30.3753,
    33.6844,
    24.8607,
    35.3247,
    56.1304,
    37.0902,
    51.5072,
  ];
  final List<double> longitude = <double>[
    69.3451,
    73.0479,
    67.0011,
    75.5510,
    106.3468,
    95.7129,
    0.1276,
  ];


  @override
  void initState() {
    Provider.of<EventsProvider>(context,listen:false).getEvents(context);
    // TODO: implement initState
    super.initState();
  }

  // Navigate to event map screen
  void _navigateToEventMap(double latitude, double longitude, String eventName, String? eventAddress) {
    print('Navigating to map with: $latitude, $longitude, $eventName, $eventAddress');
    
    try {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => EventMapScreen(
            latitude: latitude,
            longitude: longitude,
            eventName: eventName,
            eventAddress: eventAddress,
          ),
        ),
      ).then((_) {
        print('Returned from map screen');
      }).catchError((error) {
        print('Error navigating to map: $error');
        // Fallback: show error message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error opening map: $error'),
            backgroundColor: Colors.red,
          ),
        );
      });
    } catch (e) {
      print('Exception during navigation: $e');
      // Fallback: show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error opening map: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<EventsProvider>(
      builder: (context,event,_) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Column(
            children: [
              ReusableTextForm(
                borderRadius: 10,
                // controller: searchController,
                hintText: "Search event",
                onChanged: (value){
                  //searchProduct(value);
                  setState(() {

                  });
                },
                filledColor: Colors.white24,
                prefixIcon: const Icon(
                  Icons.search,
                  color: greyColor,
                ),

              ),
                             const SizedBox(height: 15,),
               
               // Test button for map navigation
               ElevatedButton(
                 onPressed: () {
                   print('Test button pressed');
                   try {
                     Navigator.push(
                       context,
                       MaterialPageRoute(
                         builder: (context) => EventMapScreen(
                           latitude: 37.7749,
                           longitude: -122.4194,
                           eventName: 'Test Event',
                           eventAddress: 'San Francisco, CA',
                         ),
                       ),
                     );
                   } catch (e) {
                     print('Test navigation error: $e');
                     ScaffoldMessenger.of(context).showSnackBar(
                       SnackBar(
                         content: Text('Test Error: $e'),
                         backgroundColor: Colors.red,
                       ),
                     );
                   }
                 },
                 child: const Text('Test Map Navigation'),
                 style: ElevatedButton.styleFrom(
                   backgroundColor: const Color(0xFFBB86FC),
                   foregroundColor: Colors.white,
                 ),
               ),
               
               const SizedBox(height: 15,),
               Expanded(

                child: event.isLoading?const SizedBox(
                    height: 30,
                    width: 30,
                    child: Center(child: CircularProgressIndicator())):
                event.events.isEmpty? const Text("No Events Found"):
                ListView.builder(
                  physics: const ScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: event.events.length,
                  itemBuilder: (BuildContext context, int index) {
                    final eventData = event.events[index];
                    return Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(10),
                                                 onTap: () {
                           print('=== EVENT TAPPED ===');
                           print('Event tapped: ${eventData.eventName}');
                           print('Event coordinates: ${eventData.latitude}, ${eventData.longitude}');
                           
                           // Check if event has coordinates, if not use default
                           double lat = double.tryParse(eventData.latitude) ?? latitude[index % latitude.length];
                           double lng = double.tryParse(eventData.longitude) ?? longitude[index % longitude.length];
                           
                           print('Using coordinates: $lat, $lng');
                           
                           // Test navigation first
                           ScaffoldMessenger.of(context).showSnackBar(
                             SnackBar(
                               content: Text('Navigating to map for ${eventData.eventName}'),
                               backgroundColor: const Color(0xFFBB86FC),
                             ),
                           );
                           
                           // Try to navigate to map screen
                           try {
                             print('Creating EventMapScreen...');
                             final mapScreen = EventMapScreen(
                               latitude: lat,
                               longitude: lng,
                               eventName: eventData.eventName,
                               eventAddress: eventData.address,
                             );
                             print('EventMapScreen created successfully');
                             
                             Navigator.push(
                               context,
                               MaterialPageRoute(
                                 builder: (context) => mapScreen,
                               ),
                             );
                           } catch (e) {
                             print('Navigation error: $e');
                             ScaffoldMessenger.of(context).showSnackBar(
                               SnackBar(
                                 content: Text('Error: $e'),
                                 backgroundColor: Colors.red,
                               ),
                             );
                           }
                         },
                        child: CustomContainerForEvent(
                        requiredEventName: eventData.eventName,
                        requiredEventPlace: eventData.address ?? eventData.eventPlace, // Use address if available, fallback to eventPlace
                        requiredEventTime: DateFormat("dd-MM-yyyy ").add_jm().format(DateTime.parse(eventData.eventStartTime)),
                        requiredImage: eventData.picturePath.replaceAll("public", ApiConstants.baseUrl),
                        requiredEventEndTime: DateFormat("dd-MM-yyyy ").add_jm().format(DateTime.parse(eventData.eventEndTime)),
                        requiredEventArtist: eventData.artistName,
                        isMyEvent: false,
                        eventId: eventData.id.toString(),
                      ),
                    ));
                  },),
              ),
            ],
          ),
        );
      }
    );
  }

}
