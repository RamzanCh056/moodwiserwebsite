import 'package:beatjerky/notification_services/trigger_notification_services.dart';
import 'package:beatjerky/screens/store/store_screen.dart';
import 'package:flutter/material.dart';

import '../utils/color.dart';
import 'New Feed/new_feed.dart';
import 'home1/home1.dart';
import 'leaderboard_screen.dart';
import 'new_reels.dart';
import 'bjai_screen.dart';

class BottomNavBar extends StatefulWidget {
  const BottomNavBar({Key? key}) : super(key: key);

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  String? fcmToken;

  void initState() {
    //getFCMToken();
    // TODO: implement initState
    super.initState();
  }

  int _currentIndex = 0;
  final List _pages = [
    // const EntryPoint(),
    // const HomeScreen(),
    const Home1(),
    StoreScreen(),
    // const StoresScreen(),
    // const MusicStyle(),
    //StoreListScreen(),
    const BJAI(),
    NewFeedScreen(),
    // const FeedScreen(),
    // const PreloadPage(),
    const ReelsScreen(),
    const LeaderboardScreen(),
    // NotificationScreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: blackColor,
          type: BottomNavigationBarType.fixed,
          selectedFontSize: 12,
          unselectedFontSize: 10,
          currentIndex: _currentIndex,
          selectedItemColor: indigoColor,
          unselectedItemColor: Colors.grey,
          onTap: (v) {
            setState(() {
              _currentIndex = v;
            });
          },
          items: [
            // BottomNavigationBarItem(
            //   icon: Icon(Icons.home),
            //   label: "Home",
            // ),
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: "Home",
            ),
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/images/store.png",
                  color: _currentIndex == 1 ? indigoColor : Colors.grey,
                ),
                label: "Store"),
            //BottomNavigationBarItem(icon: Icon(Icons.people),label: "People"),
            BottomNavigationBarItem(icon: Icon(Icons.smart_toy), label: "BJAI"),
            BottomNavigationBarItem(icon: Icon(Icons.feed), label: "Feed"),
            BottomNavigationBarItem(icon: Icon(Icons.play_circle), label: "Video"),
            BottomNavigationBarItem(icon: Icon(Icons.emoji_events), label: "Leaderboard"),
            // BottomNavigationBarItem(
            //     icon: Image.asset(
            //         height: 25,
            //         width: 25,
            //         color: _currentIndex! == 6 ? indigoColor : Colors.grey,
            //         'assets/images/shop/Group 3.png'),
            //     label: "Notify"),
          ],
        ),
        body: _pages[_currentIndex],
      );
  }
}

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter/material.dart';
//
// class BottomNavBar extends StatefulWidget {
//   const BottomNavBar({Key? key}) : super(key: key);
//
//   @override
//   State<BottomNavBar> createState() => _BottomNavBarState();
// }
//
// class _BottomNavBarState extends State<BottomNavBar> {
//   String? fcmToken;
//
//   // Function to get the FCM Token and store it in Firestore
//   Future<void> getFCMToken() async {
//     FirebaseMessaging messaging = FirebaseMessaging.instance;
//     String? token = await messaging.getToken();
//
//     if (token != null) {
//       // Print the FCM token
//       print('FCM Token: $token');
//
//       // Store the FCM token in Firestore under the 'users' collection
//       saveFCMTokenToFirestore(token);
//
//       setState(() {
//         fcmToken = token;
//       });
//     }
//   }
//
//   // Function to save the FCM token to Firestore
//   Future<void> saveFCMTokenToFirestore(String token) async {
//     // Get the current user's UID
//     String? userUid = FirebaseAuth.instance.currentUser?.uid;
//
//     if (userUid != null) {
//       try {
//         // Get the Firestore instance and reference to the 'users' collection
//         FirebaseFirestore firestore = FirebaseFirestore.instance;
//
//         // Store the token in the Firestore document using UID as the document ID
//         await firestore.collection('users').doc(userUid).set({
//           'fcmToken': token,
//           'lastUpdated': FieldValue.serverTimestamp(), // Optional: Track the last update time
//         }, SetOptions(merge: true)); // Merge to avoid overwriting other user data
//
//         print('FCM token saved successfully');
//       } catch (e) {
//         print('Error saving FCM token to Firestore: $e');
//       }
//     }
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     // Get the FCM token when the screen is initialized
//     getFCMToken();
//   }
//
//   int _currentIndex = 0;
//   final List _pages = [
//     // Your pages here...
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         bottomNavigationBar: BottomNavigationBar(
//           backgroundColor: Colors.black,
//           selectedFontSize: 12,
//           unselectedFontSize: 10,
//           currentIndex: _currentIndex,
//           selectedItemColor: Colors.indigo,
//           unselectedItemColor: Colors.grey,
//           onTap: (v) {
//             setState(() {
//               _currentIndex = v;
//             });
//           },
//           items: [
//             BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
//             BottomNavigationBarItem(
//                 icon: Image.asset(
//                   "assets/images/store.png",
//                   color: _currentIndex == 1 ? Colors.indigo : Colors.grey,
//                 ),
//                 label: "Store"),
//             BottomNavigationBarItem(icon: Icon(Icons.music_note), label: "Music"),
//             BottomNavigationBarItem(icon: Icon(Icons.feed), label: "Feed"),
//             BottomNavigationBarItem(icon: Icon(Icons.play_circle), label: "Video"),
//             BottomNavigationBarItem(icon: Icon(Icons.person_pin), label: "Profile"),
//             BottomNavigationBarItem(
//                 icon: Image.asset(
//                     height: 25,
//                     width: 25,
//                     color: _currentIndex == 6 ? Colors.indigo : Colors.grey,
//                     'assets/images/shop/Group 3.png'),
//                 label: "Notify"),
//           ],
//         ),
//         body: _pages[_currentIndex],
//       ),
//     );
//   }
// }
