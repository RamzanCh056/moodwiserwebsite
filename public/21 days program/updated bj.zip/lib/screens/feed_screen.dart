import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:beatjerky/screens/user_profile_view.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:http/http.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../consolePrintWithColor.dart';
import '../model/api_models/feed_models/feed_model.dart';
import '../model/api_models/feed_models/single_feed_comments_model.dart';
import '../providers/feeds_provider/feed_comments_provider.dart';
import '../providers/feeds_provider/feeds_provider.dart';
import '../providers/stores_provider/followed_stores_provider.dart';
import '../providers/users_provider/current_user_provider.dart';
import '../repo/api_consts.dart';
import '../services/api_services/feed_services/feed_comment_services.dart';
import '../services/api_services/feed_services/feed_like_services.dart';
import '../services/api_services/feed_services/feed_services.dart';
import '../services/api_services/store_services/get_store_profile.dart';
import '../services/api_services/store_services/store_follow_services.dart';
import '../services/api_services/user_services.dart';
import '../shimmer_effect/feed_skeleton.dart';
import '../utils/app_sizes.dart';
import '../utils/color.dart';
import '../utils/name_utils.dart';
import '../widget/reusable_text.dart';
import '../widget/reusable_textformfield.dart';
import '../widget/round_button.dart';
import 'package:http/http.dart' as http;

class FeedScreen extends StatefulWidget {
  const FeedScreen({Key? key}) : super(key: key);

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  TextEditingController descriptionController = TextEditingController();
  TextEditingController commentController = TextEditingController();

  File? videoFile;
  File? galleryFile;
  final picker = ImagePicker();
  bool isVideo = true;
  bool isPic = false;

  getAllFeeds() async {
    await FeedServices().getAllFeeds(context);
    await _fetchUserBadgesAndImages();
    EasyLoading.dismiss();
    setState(() {
      isLoading = false;
    });
  }

  bool isLoading = true;

  updateAllFeeds() async {
    await FeedServices().getAllFeeds(context);
    await _fetchUserBadgesAndImages();
    setState(() {});
  }
  
  // Cache for profile images and paid badge
  Map<String, String> userProfileImages = {};
  Map<String, bool> userIsPaid = {};
  
  // Fetch profile images and paid status from usersData collection
  Future<void> _fetchUserBadgesAndImages() async {
    try {
      var feedProvider = Provider.of<FeedsProvider>(context, listen: false);
      for (var feed in feedProvider.feedsList) {
        String userId = feed.userId.toString();
        if (userProfileImages.containsKey(userId) && userIsPaid.containsKey(userId)) {
          continue;
        }
        try {
          var userDoc = await FirebaseFirestore.instance.collection('usersData').doc(userId).get();
          if (userDoc.exists && userDoc.data() != null) {
            var userData = userDoc.data()!;
            String? profileImage = userData['profileImage'];
            bool isPaid = userData['isPaid'] ?? false;
            if (profileImage != null && profileImage.isNotEmpty) {
              userProfileImages[userId] = profileImage;
            }
            userIsPaid[userId] = isPaid;
          }
        } catch (e) {
          print('Error fetching user badge/image for $userId: $e');
        }
      }
    } catch (e) {
      print('Error in _fetchUserBadgesAndImages: $e');
    }
  }
  
  // Helper method to get display name
  String _getFeedDisplayName(FeedModel feed) {
    if (feed.user != null) {
      return NameUtils.getDisplayName(feed.user!.firstName, feed.user!.lastName);
    } else {
      return 'Unknown User';
    }
  }
  
  // Helper method to get first letter for placeholder
  String _getFeedFirstLetter(FeedModel feed) {
    if (feed.user != null) {
      return feed.user!.firstName.isNotEmpty ? feed.user!.firstName[0] : 'U';
    } else {
      return 'U';
    }
  }

  @override
  void initState() {
    getAllFeeds();
    super.initState();
  }

  bool hateReport = false;
  bool nudityReport = false;
  bool violentReport = false;
  bool spamReport = false;
  bool childSafety = false;

  List<FeedModel> feedList = [];
  List<int> listOfLikedFeedsIndex = [];
  
  @override
  Widget build(BuildContext context) {
    var feedProvider = Provider.of<FeedsProvider>(context);
    var followed = Provider.of<FollowedStoresProvider>(context, listen: false)
        .followedStores;
    return Scaffold(
        appBar: AppBar(
          backgroundColor: transparentColor,
          automaticallyImplyLeading: false,
          title: const ReusableText(
            title: "Beat Jerky",
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh, color: Colors.white),
              onPressed: () async {
                await updateAllFeeds();
              },
            ),
            IconButton(
              onPressed: () {
                _showPicker(context: context);
              },
              icon: const Icon(
                Icons.add_circle_outline,
                color: whiteColor,
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(
                Icons.favorite_border,
                color: whiteColor,
              ),
            ),
          ],
        ),
        body: isLoading
            ? ListView.builder(
                itemCount: 4,
                itemBuilder: (context, index) {
                  return const FeedSkeleton();
                })
            : feedProvider.feedsList.isNotEmpty
                ? RefreshIndicator(
                    onRefresh: () async {
                      await updateAllFeeds();
                    },
                    child: ListView.builder(
                      itemCount: feedProvider.feedsList.length,
                      itemBuilder: (BuildContext context, int index) {
                        String imageUrl = feedProvider.feedsList[index].imageUrl
                            .replaceAll('public', ApiConstants.baseUrl);
                        String userImage = "";

                        if (feedProvider.feedsList[index].store != null) {
                          // Store image
                          userImage =
                              feedProvider.feedsList[index].store!["storeImage"]
                                  .replaceAll('public', ApiConstants.baseUrl);
                        } else if (feedProvider.feedsList[index].user != null) {
                          // Get profile image from Firebase cache (usersData collection)
                          String uid = feedProvider.feedsList[index].userId.toString();
                          String? firebaseProfileImage = userProfileImages[uid];
                          if (firebaseProfileImage != null &&
                              firebaseProfileImage.isNotEmpty) {
                            userImage = firebaseProfileImage;
                          } else {
                            // Fallback to API data if available
                            if (feedProvider.feedsList[index].user != null &&
                                feedProvider.feedsList[index].user!.profileImg
                                    .isNotEmpty) {
                              String profileImg = feedProvider.feedsList[index]
                                  .user!.profileImg;
                              if (profileImg.startsWith('http')) {
                                userImage = profileImg;
                              } else if (profileImg.startsWith('/')) {
                                userImage =
                                "${ApiConstants.baseUrl}$profileImg";
                              } else {
                                userImage = "$profileImg";
                              }
                            }
                          }

                          // Use placeholder image if no profile image is available
                          if (userImage.isEmpty) {
                            userImage =
                            'https://via.placeholder.com/100x100/6366f1/ffffff?text=${_getFeedFirstLetter(
                                feedProvider.feedsList[index])}';
                          }

                          var user = Provider
                              .of<CurrentUserProvider>(context,
                              listen: false)
                              .user!;
                          bool feedLiked = feedProvider.feedsList[index]
                              .feedLikes
                              .any((element) =>
                          element['userId'] == user.userId);

                          List feedLikes = feedProvider.feedsList[index]
                              .feedLikes;
                          List feedComments =
                              feedProvider.feedsList[index].feedComments;
                          int likeId = 0;
                          if (feedLikes.isNotEmpty && feedLiked) {
                            var likes = feedLikes.where(
                                    (element) =>
                                element['userId'] == user.userId);
                            likeId = feedLikes.elementAt(feedLikes.indexWhere(
                                    (element) =>
                                element['userId'] == user.userId))['id'];
                          }

                          final uidForBadge = feedProvider.feedsList[index].userId.toString();
                          final isPaid = userIsPaid[uidForBadge] ?? false;

                          return Container(
                            margin: const EdgeInsets.only(
                                bottom: 16, left: 16, right: 16),
                            decoration: BoxDecoration(
                              color: Colors.grey[900],
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.3),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                // Header with user info and actions
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: Colors.grey[850],
                                    borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(16),
                                      topRight: Radius.circular(16),
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      // User avatar
                                      GestureDetector(
                                        onTap: feedProvider.feedsList[index]
                                            .user != null
                                            ? () {
                                          Get.to(() =>
                                              OtherUsersProfileView(
                                                userId: feedProvider
                                                    .feedsList[index].userId,
                                                userfirstname: feedProvider
                                                    .feedsList[index]
                                                    .user!
                                                    .firstName,
                                                userlastname: feedProvider
                                                    .feedsList[index]
                                                    .user!
                                                    .lastName,
                                                userImage: feedProvider
                                                    .feedsList[index]
                                                    .user!
                                                    .profileImg,
                                              ));
                                        }
                                            : null,
                                        child: Container(
                                          width: 50,
                                          height: 50,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: Colors.purple,
                                              width: 2,
                                            ),
                                          ),
                                          child: userImage.isNotEmpty &&
                                              userImage !=
                                                  'https://via.placeholder.com/100x100/6366f1/ffffff?text=${_getFeedFirstLetter(
                                                      feedProvider
                                                          .feedsList[index])}'
                                              ? CircleAvatar(
                                            backgroundImage: NetworkImage(
                                                userImage),
                                            backgroundColor: indigoColor,
                                          )
                                              : CircleAvatar(
                                            backgroundColor: indigoColor,
                                            child: userImage.isNotEmpty &&
                                                userImage.startsWith(
                                                    'https://via.placeholder.com')
                                                ? Text(
                                              _getFeedFirstLetter(feedProvider
                                                  .feedsList[index]),
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            )
                                                : const ReusableText(
                                              title: "No\nImage",
                                              textAlign: TextAlign.center,
                                              size: 10,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 12),

                                      // User info
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment
                                              .start,
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Row(
                                                    children: [
                                                      Flexible(
                                                        child: ReusableText(
                                                          title: feedProvider
                                                              .feedsList[index]
                                                              .store !=
                                                              null
                                                              ? feedProvider
                                                              .feedsList[index]
                                                              .store!["storeName"]
                                                              : _getFeedDisplayName(
                                                              feedProvider
                                                                  .feedsList[index]),
                                                          size: 16,
                                                          weight: FontWeight.w700,
                                                          color: whiteColor,
                                                        ),
                                                      ),
                                                      const SizedBox(width: 6),
                                                      if (isPaid)
                                                        const Icon(
                                                          Icons.check_circle,
                                                          color: Colors.blue,
                                                          size: 16,
                                                        ),
                                                    ],
                                                  ),
                                                ),
                                                const SizedBox(width: 8),
                                                feedProvider.feedsList[index]
                                                    .store != null
                                                    ? Container(
                                                  padding: const EdgeInsets
                                                      .symmetric(horizontal: 8,
                                                      vertical: 4),
                                                  decoration: BoxDecoration(
                                                    color: Colors.blue
                                                        .withOpacity(0.2),
                                                    borderRadius: BorderRadius
                                                        .circular(12),
                                                  ),
                                                  child: const Image(
                                                    image: AssetImage(
                                                        "assets/shop_feed/icons/Subtract.png"),
                                                    height: 16,
                                                  ),
                                                )
                                                    : const SizedBox.shrink(),
                                              ],
                                            ),
                                            const SizedBox(height: 4),
                                            Row(
                                              children: [
                                                Text(
                                                  "~1mo",
                                                  style: TextStyle(
                                                    color: Colors.grey[400],
                                                    fontSize: 12,
                                                  ),
                                                ),
                                                const SizedBox(width: 8),
                                                Icon(
                                                  Icons.people,
                                                  color: Colors.grey[400],
                                                  size: 16,
                                                ),
                                              ],
                                            ),
                                            // Description - NOW UNDER TIMESTAMP IN HEADER, LEFT ALIGNED
                                            if (feedProvider.feedsList[index]
                                                .description.isNotEmpty) ...[
                                              const SizedBox(height: 8),
                                              Align(
                                                alignment: Alignment.centerLeft,
                                                child: Text(
                                                  feedProvider.feedsList[index]
                                                      .description,
                                                  style: const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.w400,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ],
                                        ),
                                      ),

                                      // Follow button for stores
                                      if (feedProvider.feedsList[index].store !=
                                          null)
                                        Container(
                                          margin: const EdgeInsets.only(
                                              left: 8),
                                          child: InkWell(
                                            onTap: () async {
                                              var result = followed.where(
                                                      (element) =>
                                                  element.storeId ==
                                                      feedProvider
                                                          .feedsList[index]
                                                          .storeId);
                                              printLog(
                                                  ">>>>>>>>>>>>>>>>>>>>${result
                                                      .length}");
                                              if (result.isNotEmpty) {
                                                await GetStoreProfile
                                                    .unFollowStore(
                                                    feedProvider
                                                        .feedsList[index]
                                                        .storeId!,
                                                    context);
                                                await StoreFollowServices
                                                    .getAllFollowedStores(
                                                    context);
                                                setState(() {});
                                              } else {
                                                await GetStoreProfile
                                                    .followStore(
                                                    feedProvider
                                                        .feedsList[index]
                                                        .storeId!,
                                                    context);
                                                await StoreFollowServices
                                                    .getAllFollowedStores(
                                                    context);
                                                setState(() {});
                                              }
                                            },
                                            child: Container(
                                              padding: const EdgeInsets
                                                  .symmetric(
                                                  horizontal: 16, vertical: 8),
                                              decoration: BoxDecoration(
                                                color: followed.any(
                                                        (element) =>
                                                    element.storeId ==
                                                        feedProvider
                                                            .feedsList[
                                                        index]
                                                            .storeId)
                                                    ? Colors.green
                                                    : indigoColor,
                                                borderRadius: BorderRadius
                                                    .circular(20),
                                                border: Border.all(
                                                  color: const Color(
                                                      0xf30E0E6F3),
                                                ),
                                              ),
                                              child: ReusableText(
                                                title: followed.any(
                                                        (element) =>
                                                    element.storeId ==
                                                        feedProvider
                                                            .feedsList[
                                                        index]
                                                            .storeId)
                                                    ? "Following"
                                                    : "Follow",
                                                size: 12,
                                                weight: FontWeight.w600,
                                                color: whiteColor,
                                              ),
                                            ),
                                          ),
                                        ),

                                      // More options menu
                                      PopupMenuButton<String>(
                                        icon: Icon(Icons.more_vert,
                                            color: Colors.grey[400]),
                                        color: Colors.grey[800],
                                        itemBuilder: (BuildContext context) =>
                                        [
                                          PopupMenuItem<String>(
                                              child: feedProvider
                                                  .feedsList[index].userId ==
                                                  user.userId
                                                  ? TextButton(
                                                onPressed: () async {
                                                  EasyLoading.show(
                                                      status: 'Deleting...');
                                                  bool isDeleted =
                                                  await FeedServices()
                                                      .deleteFeed(
                                                      feedProvider
                                                          .feedsList[
                                                      index]
                                                          .feedId,
                                                      context);
                                                  if (isDeleted) {
                                                    Get.showSnackbar(
                                                        const GetSnackBar(
                                                          message:
                                                          "Deleted successfully",
                                                          duration: Duration(
                                                              seconds: 2),
                                                        ));
                                                    updateAllFeeds();
                                                  }
                                                  Navigator.pop(context);
                                                  EasyLoading.dismiss();
                                                },
                                                child: const Text("Delete"),
                                              )
                                                  : TextButton(
                                                onPressed: () {
                                                  // FeedServices().deleteFeed(feedProvider.feedsList[index].feedId, context);
                                                },
                                                child: const Text("About"),
                                              )),
                                          PopupMenuItem(
                                            child: TextButton(
                                              onPressed: () async {
                                                EasyLoading.show(
                                                    status: 'Loading Please wait...');
                                                // ... existing report logic ...
                                              },
                                              style: TextButton.styleFrom(
                                                foregroundColor: Colors.white,
                                                backgroundColor: Colors
                                                    .transparent,
                                              ),
                                              child: const Text(
                                                "Report",
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),


                                // Image/Video content
                                ClipRRect(
                                  borderRadius: const BorderRadius.only(
                                    bottomLeft: Radius.circular(16),
                                    bottomRight: Radius.circular(16),
                                  ),
                                  child: CachedNetworkImage(
                                    imageUrl: imageUrl,
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                    placeholder: (context, url) =>
                                        Container(
                                          height: 200,
                                          color: Colors.grey[800],
                                          child: const Center(
                                            child: CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 2,
                                            ),
                                          ),
                                        ),
                                    errorWidget: (context, url, error) =>
                                        Container(
                                          height: 200,
                                          color: Colors.grey[800],
                                          child: const Center(
                                            child: Icon(Icons.error,
                                                color: Colors.white, size: 50),
                                          ),
                                        ),
                                    memCacheWidth: 800,
                                    // Optimize memory usage
                                    memCacheHeight: 600,
                                    maxWidthDiskCache: 800,
                                    maxHeightDiskCache: 600,
                                  ),
                                ),

                                // Action buttons only - NO DESCRIPTION HERE
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  child: Row(
                                    children: [
                                      // Like button
                                      InkWell(
                                        onTap: () async {
                                          if (feedLiked) {
                                            await FeedLikeServices()
                                                .dislikeFeedLike(
                                                user.userId!,
                                                feedProvider.feedsList[index]
                                                    .feedId,
                                                likeId,
                                                context);
                                          } else {
                                            await FeedLikeServices().likeFeed(
                                                user.userId!,
                                                feedProvider.feedsList[index]
                                                    .feedId,
                                                index,
                                                context);
                                          }
                                          updateAllFeeds();
                                        },
                                        child: Row(
                                          children: [
                                            Icon(
                                              feedLiked ? Icons.favorite : Icons
                                                  .favorite_border,
                                              color: feedLiked
                                                  ? Colors.red
                                                  : Colors.grey[400],
                                              size: 24,
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              feedLikes.length.toString(),
                                              style: TextStyle(
                                                color: Colors.grey[400],
                                                fontSize: 14,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                      // Comment button
                                      InkWell(
                                        onTap: () {
                                          _showComments(
                                            context: context,
                                            userId: feedProvider
                                                .feedsList[index].userId,
                                            feedId: feedProvider
                                                .feedsList[index].feedId,
                                          );
                                        },
                                        child: Row(
                                          children: [
                                            Icon(
                                              Icons.comment_outlined,
                                              color: Colors.grey[400],
                                              size: 24,
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              feedProvider.feedsList[index]
                                                  .feedComments.length
                                                  .toString(),
                                              style: TextStyle(
                                                color: Colors.grey[400],
                                                fontSize: 14,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                      const Spacer(),

                                      // Bookmark button
                                      Icon(
                                        Icons.bookmark_border,
                                        color: Colors.grey[400],
                                        size: 24,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        }


                      }))
                : const Center(
                    child: ReusableText(
                      title: "No Feeds available",
                      color: whiteColor,
                    )),
    );
  }

  void _showPicker({
    required BuildContext context,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ReusableTextForm(
                    controller: descriptionController,
                    hintText: 'Write description here...',
                    maxLine: 3,
                  ),
                  ListTile(
                    leading: const Icon(Icons.photo_library),
                    title: const Text('Gallery'),
                    onTap: () {
                      getImage(ImageSource.gallery);
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.photo_camera),
                    title: const Text('Camera'),
                    onTap: () {
                      getImage(ImageSource.camera);
                    },
                  ),
                  Center(
                    child: InkWell(
                        onTap: () async {
                          if (galleryFile != null &&
                              descriptionController.text.isNotEmpty) {
                            EasyLoading.show(status: "Posting...");
                            bool status = await FeedServices().uploadFeed(
                                galleryFile!.path,
                                descriptionController.text,
                                context);
                            if (status) {
                              Get.showSnackbar(
                                const GetSnackBar(
                                  message: "Post shared successfully",
                                  duration: Duration(seconds: 2),
                                ),
                              );
                              
                              // Clear the form
                              descriptionController.clear();
                              galleryFile = null;
                              
                              // Close the modal and refresh feeds
                              Navigator.pop(context);
                              await updateAllFeeds();
                              
                              // Navigate to feed tab to show the new post
                              // You can add navigation logic here if needed
                            } else {
                              Get.showSnackbar(
                                const GetSnackBar(
                                  message: "Failed to upload post",
                                  duration: Duration(seconds: 2),
                                ),
                              );
                            }
                            EasyLoading.dismiss();
                          } else {
                            Get.showSnackbar(
                              const GetSnackBar(
                                message: "Please select an image and write a description",
                                duration: Duration(seconds: 2),
                              ),
                            );
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                              alignment: Alignment.center,
                              width: MediaQuery.of(context).size.width * .3,
                              height: 40,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(24)),
                              child: const Text(
                                "Upload",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              )),
                        )),
                  )
                ],
            ),
          ),
        );
      },
    );
  }

  void _showComments({
    required BuildContext context,
    userId,
    required int feedId,
  }) {
    showModalBottomSheet(
      clipBehavior: Clip.antiAliasWithSaveLayer,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(20),
          topLeft: Radius.circular(20),
        ),
      ),
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Consumer<CommentsProvider>(
          builder: (context, comment, _) {
            return Container(
              margin: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              padding: const EdgeInsets.only(
                  left: 8.0, right: 8, top: 8, bottom: 15),
              child: _buildCommentSheet(context, comment, feedId, userId),
            );
          },
        );
      },
    );
  }

  Widget _buildCommentSheet(
      BuildContext context, CommentsProvider comment, int feedId, userId) {
    return SizedBox(
      // height: Get.height * .6,

      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          _buildCommentHeader(context, comment),
          const Divider(),
          // const SizedBox(height: 10,),
          _buildCommentList(context, comment, feedId),
          _buildCommentFooter(context, comment, feedId, userId),
        ],
      ),
    );
  }

  Widget _buildCommentHeader(BuildContext context, CommentsProvider comment) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const ReusableText(
            title: "Comments",
            size: 16,
          ),
          ReusableText(
            title: "${comment.feedComments.length} Comments",
            size: 14,
            color: Colors.grey,
          ),
        ],
      ),
    );
  }

  Widget _buildCommentList(
      BuildContext context, CommentsProvider comment, int feedId) {
    return SizedBox(
      child: SizedBox(
        height: responsiveHeight(Get.height * .35, context),
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: comment.feedComments.length,
          itemBuilder: (context, commentIndex) =>
              _buildCommentItem(context, comment, commentIndex, feedId),
        ),
      ),
    );
  }

  Widget _buildCommentItem(BuildContext context, CommentsProvider comment,
      int commentIndex, int feedId) {
    List<SingleFeedCommentModel> feedComments = comment.feedComments;
    String imageUrl = feedComments[commentIndex]
        .user!
        .profileImg
        .replaceAll('public', ApiConstants.baseUrl);

    if (comment.feedComments.isEmpty) {
      return const Center(
        child: ReusableText(
          title: "No comments available",
          color: Colors.white,
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildAvatar(imageUrl),
              const SizedBox(
                width: 10,
              ),
              _buildCommentDetail(context, feedComments, commentIndex, feedId),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAvatar(String imageUrl) {
    return Column(
      children: [
        const SizedBox(
          height: 20,
        ),
        CircleAvatar(
          backgroundColor: indigoColor,
          // backgroundImage: NetworkImage(imageUrl),
          radius: 25,
                  child: Padding(
          padding: const EdgeInsets.all(2.0),
          child: CachedNetworkImage(
            imageUrl: imageUrl,
            placeholder: (context, url) => const CircularProgressIndicator(
              color: Colors.white,
              strokeWidth: 2,
            ),
            errorWidget: (context, url, error) => const Icon(
              Icons.person,
              color: Colors.white,
              size: 20,
            ),
            memCacheWidth: 100,
            memCacheHeight: 100,
          ),
        ),
        ),
      ],
    );
  }

  Widget _buildCommentDetail(BuildContext context,
      List<SingleFeedCommentModel> feedComments, int commentIndex, int feedId) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        // SizedBox(height: 15,),
        SizedBox(
          // width: Get.width * .73,
          width: responsiveWidth(Get.width * .6, context),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildUserInfo(context, feedComments, commentIndex, feedId),
              const Spacer(),
              _buildMoreOptions(context, feedComments, commentIndex, feedId),
            ],
          ),
        ),
        const SizedBox(
          height: 5,
        ),
        const SizedBox(
          height: 10,
        ),
        SizedBox(
          // width: Get.width * .7,
          width: responsiveWidth(Get.width * .6, context),
          child: ReusableText(
            title: feedComments[commentIndex].comment,
          ),
        )
      ],
    );
  }

  Widget _buildUserInfo(BuildContext context,
      List<SingleFeedCommentModel> feedComments, int commentIndex, int feedId) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(
          height: 18,
        ),
        ReusableText(
          title: NameUtils.getDisplayName(
            feedComments[commentIndex].user!.firstName,
            feedComments[commentIndex].user!.lastName,
          ),
          size: 16,
          weight: FontWeight.w700,
          color: whiteColor,
        ),
        ReusableText(
          title: DateFormat("dd-MMM-yyyy ")
              .add_jm()
              .format(DateTime.parse(feedComments[commentIndex].createdAt)),
          size: 10,
          color: Colors.grey,
        ),
      ],
    );
  }

  Widget _buildMoreOptions(BuildContext context,
      List<SingleFeedCommentModel> feedComments, int commentIndex, int feedId) {
    return PopupMenuButton(
      position: PopupMenuPosition.over,
      offset: const Offset(-20, 30),
      padding: EdgeInsets.zero,
      icon: const Icon(
        Icons.more_horiz_rounded,
        size: 40,
        color: greyColor,
      ),
      itemBuilder: (context) => [
        PopupMenuItem(
          child: feedComments[commentIndex].userId ==
                  Provider.of<CurrentUserProvider>(context, listen: false)
                      .user!
                      .userId
              ? _buildDeleteOption(context, feedComments, commentIndex, feedId)
              : _buildAboutOption(),
        )
      ],
    );
  }

  Widget _buildDeleteOption(BuildContext context,
      List<SingleFeedCommentModel> feedComments, int commentIndex, int feedId) {
    return TextButton(
      onPressed: () async {
        EasyLoading.show(status: 'Deleting');
        bool isDeleted = await FeedCommentServices().deleteFeedComment(
            Provider.of<CurrentUserProvider>(context, listen: false)
                .user!
                .userId!,
            feedId,
            feedComments[commentIndex].commentId,
            context);
        if (isDeleted) {
          Get.showSnackbar(const GetSnackBar(
            message: "Deleted successfully",
            duration: Duration(seconds: 2),
          ));
        }
        await updateAllFeeds();
        await FeedCommentServices().getAllComments(feedId, context);
        setState(() {});
        Navigator.pop(context);
        EasyLoading.dismiss();
      },
      child: const Text("Delete"),
    );
  }

  Widget _buildAboutOption() {
    return TextButton(
      onPressed: () {
        // FeedServices().deleteFeed(feedProvider.feedsList[index].feedId, context);
      },
      child: const Text("About"),
    );
  }

  Widget _buildCommentFooter(
      BuildContext context, CommentsProvider comment, int feedId, userId) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          height: 50,
          // width: Get.width * .78,
          width: responsiveWidth(Get.width * .80, context),
          child: ReusableTextForm(
            hintText: "Write comment here...",
            filledColor: Colors.white,
            textColor: Colors.black,
            controller: commentController,
            borderRadius: 25,
          ),
        ),
        InkWell(
          onTap: () async {
            if (commentController.text.isEmpty) {
              Get.showSnackbar(
                const GetSnackBar(
                  message: "Can't post empty comment",
                  duration: Duration(seconds: 2),
                ),
              );
            } else {
              await _postComment(context, comment, feedId);
              await FeedServices()
                  .saveNotificationToApi(userId, feedId, context);
            }
          },
          child: _buildSendIcon(),
        )
      ],
    );
  }

  Future<void> _postComment(
      BuildContext context, CommentsProvider comment, int feedId) async {
    EasyLoading.show(status: 'Posting...');
    await FeedCommentServices().commentFeed(
        Provider.of<CurrentUserProvider>(context, listen: false).user!.userId!,
        feedId,
        commentController.text,
        context);
    commentController.clear();
    await updateAllFeeds();
    await FeedCommentServices().getAllComments(feedId, context);
    setState(() {});
    EasyLoading.dismiss();
  }

  Widget _buildSendIcon() {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: whiteColor, borderRadius: BorderRadius.circular(50)),
      child: Transform.rotate(
        angle: -.78,
        child: const Icon(
          Icons.send,
          color: indigoColor,
          size: 35,
        ),
      ),
    );
  }

  // void _showComments({required BuildContext context,required int feedId}) {
  //
  //   showModalBottomSheet(
  //     clipBehavior: Clip.antiAliasWithSaveLayer,
  //     shape: const RoundedRectangleBorder(
  //         borderRadius: BorderRadius.only(
  //           topRight: Radius.circular(20),
  //
  //           topLeft: Radius.circular(20),
  //         )
  //     ),
  //     context: context,
  //     isScrollControlled: true,
  //     builder: (BuildContext context) {
  //       return Consumer<CommentsProvider>(
  //         builder: (context,comment,_) {
  //           return Container(
  //             margin: EdgeInsets.only(
  //                 bottom: MediaQuery.of(context).viewInsets.bottom),
  //             padding: const EdgeInsets.all(8.0),
  //             child: SizedBox(
  //               height: Get.height*.6,
  //               child: Column(
  //                 mainAxisSize: MainAxisSize.min,
  //                 children: <Widget>[
  //                   Padding(
  //                     padding: const EdgeInsets.all(8.0),
  //                     child: Row(
  //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                       children: [
  //                         const ReusableText(
  //                           title: "Comments",
  //                           size: 16,
  //                         ),
  //                         ReusableText(
  //                           title: "${comment.feedComments.length} Comments",
  //                           size: 14,
  //                           color: Colors.grey,
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //
  //                   const Divider(),
  //                   const SizedBox(height: 10,),
  //                   SizedBox(
  //                     height: Get.height*.45,
  //                     child:ListView.builder(
  //                       itemCount: comment.feedComments.length,
  //                         itemBuilder: (context,commentIndex){
  //                         List<SingleFeedCommentModel> feedComments=comment.feedComments;
  //                         String imageUrl=feedComments[commentIndex].user!.profileImg.replaceAll('public', ApiConstants.baseUrl);
  //                           return comment.feedComments.isNotEmpty?Padding(
  //                             padding: const EdgeInsets.all(10),
  //                             child: Column(
  //                               crossAxisAlignment: CrossAxisAlignment.start,
  //                               mainAxisSize: MainAxisSize.min,
  //                               children: [
  //                                 Row(
  //                                   mainAxisAlignment: MainAxisAlignment.start,
  //                                   crossAxisAlignment: CrossAxisAlignment.start,
  //                                   children: [
  //                                     Column(
  //                                       children: [
  //                                         const SizedBox(height: 20,),
  //                                         CircleAvatar(
  //                                           backgroundColor: indigoColor,
  //                                           // backgroundImage: NetworkImage(imageUrl),
  //                                           radius: 25,
  //                                           child: Padding(
  //                                             padding: const EdgeInsets.all(2.0),
  //                                             child: Image.network(imageUrl),
  //                                           ),
  //                                         ),
  //                                       ],
  //                                     ),
  //                                     const SizedBox(width: 10,),
  //                                     Column(
  //                                       crossAxisAlignment: CrossAxisAlignment.start,
  //                                       mainAxisAlignment: MainAxisAlignment.start,
  //                                       children: [
  //                                         // SizedBox(height: 15,),
  //                                         SizedBox(
  //                                           width: Get.width*.73,
  //                                           child: Row(
  //                                             crossAxisAlignment: CrossAxisAlignment.start,
  //                                             children: [
  //                                               Column(
  //                                                 crossAxisAlignment: CrossAxisAlignment.start,
  //                                                 children: [
  //                                                   const SizedBox(height: 20,),
  //                                                   ReusableText(
  //                                                     title: "${feedComments[commentIndex].user!.firstName} ${feedComments[commentIndex].user!.lastName}",
  //                                                     size: 16,
  //                                                     weight: FontWeight.w700,
  //                                                     color: whiteColor,
  //                                                   ),
  //                                                   ReusableText(
  //                                                     title: DateFormat("dd-MMM-yyyy ").add_jm().format(DateTime.parse(feedComments[commentIndex].createdAt)),
  //                                                     size: 10,
  //                                                     color: Colors.grey,
  //                                                   ),
  //                                                 ],
  //                                               ),
  //                                               const Spacer(),
  //                                               PopupMenuButton(
  //
  //                                                   position: PopupMenuPosition.over,
  //                                                   offset: const Offset(-20,30),
  //                                                   padding: EdgeInsets.zero,
  //                                                   icon: const Icon(Icons.more_horiz_rounded,size: 40,color: greyColor,),
  //                                                   itemBuilder: (context)=>[
  //                                                     PopupMenuItem(
  //                                                         child: feedComments[commentIndex].userId==Provider.of<CurrentUserProvider>(context,listen: false).user!.userId?TextButton(
  //                                                           onPressed: () async{
  //                                                             EasyLoading.show(status: 'Deleting');
  //
  //                                                             bool isDeleted=await FeedCommentServices().deleteFeedComment(Provider.of<CurrentUserProvider>(context,listen: false).user!.userId!, feedId, feedComments[commentIndex].commentId, context);
  //                                                             if(isDeleted){
  //                                                               Get.showSnackbar(const GetSnackBar(message: "Deleted successfully",duration: Duration(seconds: 2),));
  //                                                             }
  //                                                             await updateAllFeeds();
  //                                                             await FeedCommentServices().getAllComments(feedId, context);
  //                                                             setState(() {
  //
  //                                                             });
  //                                                             Navigator.pop(context);
  //                                                             EasyLoading.dismiss();
  //                                                           },
  //                                                           child: const Text("Delete"),
  //                                                         ):TextButton(
  //                                                           onPressed: () {
  //                                                             // FeedServices().deleteFeed(feedProvider.feedsList[index].feedId, context);
  //                                                           },
  //                                                           child: const Text("About"),
  //                                                         )
  //                                                     )
  //                                                   ]),
  //                                             ],
  //                                           ),
  //                                         ),
  //                                         const SizedBox(height: 5,),
  //
  //                                         const SizedBox(height: 10,),
  //                                         SizedBox(
  //                                           width: Get.width*.7,
  //                                           child: ReusableText(title: feedComments[commentIndex].comment,),
  //                                         )
  //                                       ],
  //                                     ),
  //
  //
  //
  //                                   ],
  //                                 ),
  //
  //
  //                               ],
  //                             ),
  //                           ):
  //                           const Center(child: ReusableText(title: "No comments available",color: Colors.white,),);
  //                         }),
  //                   ),
  //                   Row(
  //                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                     children: [
  //                       SizedBox(
  //                         height: 50,
  //                         width: Get.width*.78,
  //
  //                         child: ReusableTextForm(
  //
  //                           hintText: "Write comment here...",
  //                           filledColor: Colors.white,
  //                           textColor: Colors.black,
  //                           controller: commentController,
  //                           // maxLine: 3,
  //                           borderRadius: 25,
  //                         ),
  //                       ),
  //
  //                       InkWell(
  //                           onTap: ()async{
  //                             if(commentController.text.isEmpty){
  //                               Get.showSnackbar(const GetSnackBar(message: "Can't post empty comment",duration: Duration(seconds: 2),),);
  //                             }else{
  //                               EasyLoading.show(status: 'Posting...');
  //                               await FeedCommentServices().commentFeed(
  //                                   Provider.of<CurrentUserProvider>(context,listen: false).user!.userId!,
  //                                   feedId, commentController.text, context);
  //                               commentController.clear();
  //                               await updateAllFeeds();
  //                               await FeedCommentServices().getAllComments(feedId, context);
  //
  //                               setState(() {
  //
  //                               });
  //                               EasyLoading.dismiss();
  //                             }
  //                           },
  //                           child: Container(
  //
  //                             padding: const EdgeInsets.all(10),
  //                             decoration: BoxDecoration(
  //                               color: whiteColor,
  //                               borderRadius: BorderRadius.circular(50)
  //                             ),
  //                             child: Transform.rotate(
  //                                 angle: -.78,
  //                             child: const Icon(Icons.send,color: indigoColor,size: 30,)),
  //                           ))
  //                     ],
  //                   ),
  //
  //
  //
  //                 ],
  //               ),
  //             ),
  //           );
  //         }
  //       );
  //     },
  //   );
  // }

  Future getVideo(
    ImageSource img,
  ) async {
    final pickedFile = await picker.pickVideo(
        source: img,
        preferredCameraDevice: CameraDevice.front,
        maxDuration: const Duration(minutes: 10));
    XFile? xfilePick = pickedFile;
    setState(
      () {
        if (xfilePick != null) {
          galleryFile = File(pickedFile!.path);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(// is this context <<<
              const SnackBar(content: Text('Nothing is selected')));
        }
      },
    );
  }



  Future getImage(
    ImageSource img,
  ) async {
    final pickedFile = await picker.pickImage(
      source: img,
      preferredCameraDevice: CameraDevice.front,
    );
    XFile? xfilePick = pickedFile;
    setState(
      () {
        if (xfilePick != null) {
          if (pickedFile!.name.endsWith('jpg') ||
              pickedFile.name.endsWith('png') ||
              pickedFile.name.endsWith('jpeg')) {
            galleryFile = File(pickedFile.path);
          } else {
            Get.showSnackbar(
              const GetSnackBar(
                message: "Only jpg,jpeg and png file is supported",
                duration: Duration(seconds: 2),
              ),
            );
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(// is this context <<<
              const SnackBar(content: Text('Nothing is selected')));
        }
      },
    );
  }
}

