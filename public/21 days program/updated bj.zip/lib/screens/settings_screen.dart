import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_stripe/flutter_stripe.dart' as StripePkg;
import 'auth_screen/login_screen.dart';
import 'edit_profile.dart';
import 'profile_screen.dart';
import '../stripe_payment/stripe_payment.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isPaid = false;
  String _paidPlan = '';
  bool _loadingStatus = true;

  @override
  void initState() {
    super.initState();
    _loadPaidStatus();
  }

  Future<void> _loadPaidStatus() async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;
      final doc = await FirebaseFirestore.instance.collection('usersData').doc(uid).get();
      if (doc.exists) {
        final data = doc.data()!;
        setState(() {
          _isPaid = data['isPaid'] ?? false;
          _paidPlan = (data['paidPlan'] ?? '').toString();
          _loadingStatus = false;
        });
      } else {
        setState(() => _loadingStatus = false);
      }
    } catch (_) {
      setState(() => _loadingStatus = false);
    }
  }

  Future<void> _logout(BuildContext context) async {
    try {

      final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      // 🧹 Remove the FCM token from Firestore before logging out
      await FirebaseFirestore.instance
          .collection('usersData') // 👈 change to your actual user collection
          .doc(user.uid)
          .update({'fcmToken': FieldValue.delete()});
    }

      await FirebaseAuth.instance.signOut();
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (route) => false,
        );
      }
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Logout failed')),
      );
    }
  }

  void _goToProfile(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()))
        .then((_) => _loadPaidStatus());
  }

  void _goToEditProfile(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const EditProfileScreen()))
        .then((_) => _loadPaidStatus());
  }

  Future<void> _buyBlueTick(BuildContext context) async {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1F1F1F),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: const [
                  Icon(Icons.verified, color: Colors.blue),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text('Buy Subscription • Get Verified',
                        style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text('Benefits:', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              const Text('• Verified blue check on your profile', style: TextStyle(color: Colors.white70)),
              const Text('• Unlimited access to BJAI', style: TextStyle(color: Colors.white70)),
              const Text('• Priority support and early features', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: () {
                        Navigator.pop(ctx);
                        _startStripeFlow(context, 'monthly');
                      },
                      child: const Text('Monthly • \$9.99'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: () {
                        Navigator.pop(ctx);
                        _startStripeFlow(context, 'yearly');
                      },
                      child: const Text('Yearly • \$99.99'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _startStripeFlow(BuildContext context, String plan) async {
    try {
      final stripeServices = StripeServices();
      final amount = plan == 'monthly' ? '999' : '9999'; // $9.99 or $99.99 in cents
      final planName = plan == 'monthly' ? 'Monthly' : 'Yearly';

      // Create payment intent
      final response = await stripeServices.createPaymentIntent(amount);
      if (response['status'] == 'succeeded') {
        final clientSecret = response['client_secret'];

        // Initialize payment sheet
        await StripePkg.Stripe.instance.initPaymentSheet(
          paymentSheetParameters: StripePkg.SetupPaymentSheetParameters(
            paymentIntentClientSecret: clientSecret,
            merchantDisplayName: 'BeatJerky',
            style: ThemeMode.dark,
          ),
        );

        // Present payment sheet
        await StripePkg.Stripe.instance.presentPaymentSheet();

        // Payment successful
        final uid = FirebaseAuth.instance.currentUser?.uid;
        if (uid != null) {
          await FirebaseFirestore.instance.collection('usersData').doc(uid).update({
            'isPaid': true,
            'paidPlan': planName,
            'paidAt': Timestamp.now(),
          });

          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('$planName subscription activated! 🎉')),
            );
            await _loadPaidStatus();
          }
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Payment failed: ${response['error']?['message'] ?? 'Unknown error'}')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Payment error: $e')),
        );
      }
    }
  }

  void _confirmCancelSubscription(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text('Cancel Subscription', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Are you sure you want to cancel your BeatJerky Blue subscription? You will lose access to verification and BJAI benefits at the end of your current period.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Keep', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () async {
              Navigator.pop(ctx);
              await _cancelSubscription();
            },
            child: const Text('Cancel Subscription'),
                ),
              ],
            ),
    );
  }

  Future<void> _cancelSubscription() async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) return;

      // NOTE: Real Stripe subscription cancellation should be handled on your backend.
      // Here we immediately reflect the change in Firestore for UI purposes.
      await FirebaseFirestore.instance.collection('usersData').doc(uid).update({
        'isPaid': false,
        'paidPlan': null,
        'paidAt': null,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Subscription cancelled')),
        );
      }
      await _loadPaidStatus();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to cancel: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F1F1F),
        title: const Text('Settings', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
      ),
      body: _loadingStatus
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : ListView(
              children: [
                const SizedBox(height: 12),
                ListTile(
                  leading: const Icon(Icons.person, color: Colors.white70),
                  title: const Text('Profile', style: TextStyle(color: Colors.white)),
                  trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 16),
                  onTap: () => _goToProfile(context),
                ),
                const Divider(color: Colors.white12, height: 1),
                ListTile(
                  leading: const Icon(Icons.edit, color: Colors.white70),
                  title: const Text('Edit Profile', style: TextStyle(color: Colors.white)),
                  trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 16),
                  onTap: () => _goToEditProfile(context),
                ),
                const Divider(color: Colors.white12, height: 1),
                _isPaid
                    ? ListTile(
                        leading: const Icon(Icons.verified, color: Colors.blue),
                        title: Text(
                          'Manage Subscription • ${_paidPlan.isNotEmpty ? _paidPlan : 'Active'}',
                          style: const TextStyle(color: Colors.white),
                        ),
                        trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 16),
                        onTap: () => _confirmCancelSubscription(context),
                      )
                    : ListTile(
                        leading: const Icon(Icons.verified, color: Colors.blue),
                        title: const Text('Buy Subscription • Get Verified', style: TextStyle(color: Colors.white)),
                        trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white24, size: 16),
                        onTap: () => _buyBlueTick(context),
                      ),
                const Divider(color: Colors.white12, height: 1),
                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.redAccent),
                  title: const Text('Logout', style: TextStyle(color: Colors.white)),
                  onTap: () => _logout(context),
                ),
              ],
            ),
    );
  }
}
