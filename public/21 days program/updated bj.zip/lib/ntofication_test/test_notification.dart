// import 'dart:async';
// import 'package:flutter/material.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:firebase_auth/firebase_auth.dart';
//
// import '../firebase_options.dart';
// import '../screens/home_screen.dart';
// import 'AuthScreen.dart';
// import 'notification_service.dart';
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
//
//   runZonedGuarded(
//     () => runApp(const MyApp()),
//     (error, stack) {
//       print('❗ Uncaught error: $error');
//       print(stack);
//     },
//   );
// }
//
// class MyApp extends StatefulWidget {
//   const MyApp({Key? key}) : super(key: key);
//   @override
//   State<MyApp> createState() => _MyAppState();
// }
//
// class _MyAppState extends State<MyApp> {
//   @override
//   void initState() {
//     super.initState();
//     PushNotificationService().init();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'FCM Auth Demo',
//       home: AuthGate(),
//     );
//   }
// }
//
// /// Shows either AuthScreen or HomeScreen depending on sign-in state
// class AuthGate extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return StreamBuilder<User?>(
//       stream: FirebaseAuth.instance.authStateChanges(),
//       builder: (context, snap) {
//         if (snap.connectionState == ConnectionState.waiting) {
//           return const Scaffold(body: Center(child: CircularProgressIndicator()));
//         }
//         if (snap.hasData) {
//           return const HomeScreen();
//         }
//         return const AuthScreen();
//       },
//     );
//   }
// }
