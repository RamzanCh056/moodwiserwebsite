// import 'package:firebase_core/firebase_core.dart';
// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
//
// // 1️⃣ Top-level background handler
// Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage msg) async {
//   await Firebase.initializeApp();
//   print('📥 BG message: ${msg.messageId}');
// }
//
// class PushNotificationService {
//   final FirebaseMessaging _fcm = FirebaseMessaging.instance;
//   final FlutterLocalNotificationsPlugin _flutterLocal = FlutterLocalNotificationsPlugin();
//   final FirebaseFirestore _db = FirebaseFirestore.instance;
//
//   Future<void> init() async {
//     // 2️⃣ Firebase init & background handler
//     await Firebase.initializeApp();
//     FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
//
//     // 3️⃣ Ask iOS permissions
//     final settings = await _fcm.requestPermission(
//       alert: true,
//       badge: true,
//       sound: true,
//     );
//     if (settings.authorizationStatus != AuthorizationStatus.authorized) {
//       print('❌ Notification permission denied');
//       return;
//     }
//
//     // 4️⃣ Get & store FCM token
//     final token = await _fcm.getToken();
//     print('🔑 FCM token: $token');
//     if (token != null) {
//       await _db
//           .collection('users')
//           .doc('USER_UID') // ← replace with actual UID
//           .set({'fcmToken': token}, SetOptions(merge: true));
//     }
//
//     // 5️⃣ Android channel for heads-up notifications
//     const channel = AndroidNotificationChannel(
//       'high_importance_channel',
//       'High Importance Notifications',
//       description: 'Used for important notifications',
//       importance: Importance.high,
//     );
//     await _flutterLocal
//         .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
//         ?.createNotificationChannel(channel);
//
//     // 6️⃣ Initialize local notifications (Android + iOS/Darwin)
//     const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
//     const iosSettings = DarwinInitializationSettings();
//     const initSettings = InitializationSettings(
//       android: androidSettings,
//       iOS: iosSettings,
//     );
//     await _flutterLocal.initialize(
//       initSettings,
//       onDidReceiveNotificationResponse: (NotificationResponse resp) {
//         // handle tap
//         print('Notification tapped with payload: ${resp.payload}');
//       },
//     );
//
//     // 7️⃣ Foreground FCM handler
//     FirebaseMessaging.onMessage.listen((RemoteMessage msg) {
//       print('📱 FG message: ${msg.notification?.title}');
//       _showLocalNotification(msg);
//     });
//
//     // 8️⃣ User taps notification (app in background)
//     FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage msg) {
//       print('🖱️ Notification clicked!');
//       // Navigate based on msg.data…
//     });
//   }
//
//   Future<void> _showLocalNotification(RemoteMessage msg) async {
//     final notif = msg.notification;
//     final android = msg.notification?.android;
//     if (notif != null && android != null) {
//       await _flutterLocal.show(
//         notif.hashCode,
//         notif.title,
//         notif.body,
//         NotificationDetails(
//           android: AndroidNotificationDetails(
//             'high_importance_channel',
//             'High Importance Notifications',
//             channelDescription: 'Used for important notifications',
//             icon: android.smallIcon,
//           ),
//           iOS: DarwinNotificationDetails(),
//         ),
//       );
//     }
//   }
// }
