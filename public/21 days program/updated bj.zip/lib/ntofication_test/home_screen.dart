import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  Future<void> _sendNotification() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return print('❌ No signed-in user');

    final uri = Uri.parse('http://10.0.2.2:3000/send');
    final payload = {
      'uid': uid,
      'title': 'Hello $uid!',
      'body': 'You clicked the button 🎉',
      'data': {'via': 'button'},
    };

    print('🚀 HTTP POST → /send payload: $payload');
    try {
      final res = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );
      print('📬 Server responded [${res.statusCode}]: ${res.body}');
    } catch (e) {
      print('❌ HTTP error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Welcome'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => FirebaseAuth.instance.signOut(),
          )
        ],
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: _sendNotification,
          child: const Text('Send Notification to Me'),
        ),
      ),
    );
  }
}
