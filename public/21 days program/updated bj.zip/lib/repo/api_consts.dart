class ApiConstants {
  static const String baseUrl = 'http://beatjerky.com/api';
  static const String signup = '/auth/signup';
  static const String login = '/auth/login';
  static const String forgotPassword = '/auth/forgotPassword';
  static const String deleteAccount = "/users?userId=";
  static const String blockUser = "/users/block-user";
  static const String unBlockUser = "/users/unblock-user";
  static const String resetPassword = "/auth/changePassword";

  /// Get Users
  static const String getCurrentUser = '/users/current?userId=';
  static const String uploadProfileImage = '/users/profileImg';
  static const String getAllUsers = '/users';
  static const String logout = '/auth/logout';
  static const String editProfile = '/users/profile';
  static const String userDeviceId = '/users/deviceId?userId=';

  /// Feeds
  static const String getAllFeeds = '/feed/all';
  static const String deleteFeed = '/feed';
  static const String getCurrentUserAllFeeds = '/feed/?userId=';

  static const String reportFeed =
      '/feed//user-feed-by-client-id?limit=10&offset=0&userId=';

  /// Feed Likes
  static const String likeFeed = '/feedLike';
  static const String allFeedLikes = '/feedLike/all?feedId=';

  /// Feed Comments
  static const String commentFeed = '/feedComment';
  static const String getAllFeedComments = '/feedComment/all?feedId=';

  /// Videos
  static const String postVideo = '/video';
  static const String getUserVideos = '/video/?userId=';
  static const String deleteVideo = '/video?userId=';
  static const String getAllUsersVideos = '/video/all';

  /// Video Likes
  static const String likeVideo = '/videoLike';
  static const String getAllVideoLikes = '/videoLike/all?videoId=';

  /// Video Comments
  static const String videoComment = '/videoComment';
  static const String getAllVideoComments = '/videoComment/all/musicStyleSongs/userId?videoId=';

  /// Video
  static const String video = '/video';

  /// Follow
  static const String follow = '/follower';
  static const String getFollowersAndFollowing = '/follower?userId=';

  /// All categories with songs
  static const String allCategoriesWithSongs =
      '/category/getAllCategoriesWithSongs';

  /// Music style songs category by id
  static const String getMusicStylesById = '/musicStyleSongs/all?categoryId=';
  static const String getAllMusicStyles = '/musicStyle/all';

  static const String songsByUser='/song/userId';
  static const String songCover="/song/addCoverImage/";
  static const String getCategories="/category";
  static const String uploadSongByUser="/musicStyleSongs/userId";

  /// Chat
  static const String startChat = '/message/start';
  static const String message = '/message';
  static const String getConversationById = '/message?conversationId=';
  static const String getChatList = '/message/list?userId=';

  /// Stores
  static const String getStores = "/stores";
  static const String getProducts = "/products/";
  static const String storeProfile = "/storeProfile?storeId=";
  static const String followStore = "/storeFollowers";
  static const String followedStores = "/storeFollowers?userId=";
  static const String adminChat = "/adminChat";
  static const String getStoresChatList =
      "/adminChat/getChatListWithStores?userId=";
  static const String getChatWithStore =
      "/adminChat/fetchChatWithStore?userId=";
  static const String getStoreFeeds = "/feed/storeFeed?storeId=";

  static const String checkOut = "/checkout";

  static const String getAdmin = "/users//getAdminUser";

  /// Artist Endpoints
  static const String getAllArtists = "/artist-profile";
  static const String updateArtistProfile =
      "/artist-profile/update-profile?id=";
  static const String getArtistByUserId = "/artist-profile/byUserId?userId=";
  static const String deleteArtistProfile =
      "/artist-profile/delete-artist-profile?id=";

  /// Artist Songs
  static const String uploadSong = "/artist-songs";
  static const String getAllArtistSongs = "/artist-songs/byArtistId?artistId=";
  static const String updateArtistSong = "/artist-songs/update-song/?id=";
  static const String deleteArtistSong = "/artist-songs/delete-song/?id=";

  /// Events
  static const String createEvent = "/artist-events/create-event";
  static const String getAllEvents = "/artist-events/events";
  static const String getMyEvents = "/artist-events/event/byClientId?clientId=";
  static const String deleteEvent = "/artist-events/delete-event?id=";

  /// Admin Song
  static const String addSong = "/song";

  /// Get Notifications
  static const String getNotifications = "/notification?userId=";
}
