import 'dart:io';
import 'package:beatjerky/notification_services/notification_services.dart';
import 'package:beatjerky/providers/admin_provider/admin_provider.dart';
import 'package:beatjerky/providers/all_categories_provider/all_categories_provider.dart';
import 'package:beatjerky/providers/artist_provider/artist_provider.dart';
import 'package:beatjerky/providers/artist_provider/artist_songs_provider.dart';
import 'package:beatjerky/providers/chat_provider/chat_provider.dart';
import 'package:beatjerky/providers/events_provider/events_provider.dart';
import 'package:beatjerky/providers/feeds_provider/current_user_feeds_provider.dart';
import 'package:beatjerky/providers/feeds_provider/feed_comments_provider.dart';
import 'package:beatjerky/providers/feeds_provider/feeds_provider.dart';
import 'package:beatjerky/providers/follower_provider/followers_and_following_provider.dart';
import 'package:beatjerky/providers/music_store_provider/music_store_provider.dart';
import 'package:beatjerky/providers/music_style_provider/music_style_provider.dart';
import 'package:beatjerky/providers/song_provider/song_provider.dart';
import 'package:beatjerky/providers/stores_provider/followed_stores_provider.dart';
import 'package:beatjerky/providers/stores_provider/product_provider.dart';
import 'package:beatjerky/providers/stores_provider/store_feed_provider.dart';
import 'package:beatjerky/providers/stores_provider/store_provider.dart';
import 'package:beatjerky/providers/user_songs_categories_provider/user_songs_categories_provider.dart';
import 'package:beatjerky/providers/users_provider/all_users_provider.dart';
import 'package:beatjerky/providers/users_provider/current_user_provider.dart';
import 'package:beatjerky/providers/video_provider/current_user_video_provider.dart';
import 'package:beatjerky/providers/video_provider/video_comments_provider.dart';
import 'package:beatjerky/providers/video_provider/video_likes_provider.dart';
import 'package:beatjerky/providers/video_provider/videos_provider.dart';
import 'package:beatjerky/screens/splash_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';

void main() async {
  await WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    NotificationService().initInfo();

    print("✅ Firebase and Notifications Initialized Successfully");
  } catch (e) {
    print("❌ Firebase initialization failed: $e");
  }
  Provider.debugCheckInvalidValueType = null;
  if (Platform.isAndroid) {
    AndroidGoogleMapsFlutter.useAndroidViewSurface = true;
  }

  Stripe.publishableKey = 
      // "pk_test_51NpgNxH2eQXuMczkcp8auJY8HrPZ3DCe2zT1eQPnfJwKFwviBUBeNL1xDA0YtIBerj9MI0ECliWLLRPPrZnxhlS700vliYYT2e";
      "pk_live_51NpgNxH2eQXuMczkKTJVrcF3Czbs57L2bTHCRBFQUhonxp8fgvsDVe7pWM66CkhzMSTvqv023QXizekzK4OgSoNG00kRd31FJv";

  await dotenv.load(fileName: "assets/stripe/.env");
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider(create: (_) => CurrentUserProvider()),
    ChangeNotifierProvider(create: (_) => OtherUserProvider()),
    ChangeNotifierProvider(create: (_) => FeedsProvider()),
    ChangeNotifierProvider(create: (_) => FeedProvider()),
    ChangeNotifierProvider(create: (_) => CommentsProvider()),
    ChangeNotifierProvider(create: (_) => CommentProvider()),
    ChangeNotifierProvider(create: (_) => VideosProvider()),
    ChangeNotifierProvider(create: (_) => VideoCommentsProvider()),
    ChangeNotifierProvider(create: (_) => VideoLikesProvider()),
    ChangeNotifierProvider(create: (_) => CurrentUserVideoProvider()),
    ChangeNotifierProvider(create: (_) => CurrentUserFeedsProvider()),
    ChangeNotifierProvider(create: (_) => AllUsersProvider()),
    ChangeNotifierProvider(create: (_) => FollowAndFollowingProvider()),
    ChangeNotifierProvider(create: (_) => MusicStyleProvider()),
    ChangeNotifierProvider(create: (_) => ChatProvider()),
    ChangeNotifierProvider(create: (_) => AllCategoriesProvider()),
    ChangeNotifierProvider(create: (_) => StoreProvider()),
    ChangeNotifierProvider(create: (_) => ProductProvider()),
    ChangeNotifierProvider(create: (_) => StoreFeedsProvider()),
    ChangeNotifierProvider(create: (_) => FollowedStoresProvider()),
    ChangeNotifierProvider(create: (_) => AdminProvider()),
    ChangeNotifierProvider(create: (_) => ArtistProvider()),
    ChangeNotifierProvider(create: (_) => ArtistSongsProvider()),
    ChangeNotifierProvider(create: (_) => EventsProvider()),
    ChangeNotifierProvider(create: (_) => UserSongsCategoriesProvider()),
    ChangeNotifierProvider(create: (_) => MusicStoreProvider()),
    ChangeNotifierProvider(create: (_) => SongProvider()),
  ], child: const MyApp()));
  configLoading();
}

void configLoading() {
  EasyLoading.instance
    ..displayDuration = const Duration(milliseconds: 2000)
    ..indicatorType = EasyLoadingIndicatorType.fadingCircle
    ..loadingStyle = EasyLoadingStyle.light
    ..indicatorSize = 45.0
    ..radius = 10.0
    ..progressColor = Colors.yellow
    ..backgroundColor = Colors.green
    ..indicatorColor = Colors.yellow
    ..textColor = Colors.yellow
    ..maskColor = Colors.blue.withOpacity(0.5)
    ..userInteractions = true
    ..dismissOnTap = false;
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {

  @override
  void initState() {
    WidgetsBinding.instance.addObserver(
      this,
    );

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          // brightness: Brightness.dark,
          // //   colorScheme: ColorScheme.dark(background: blackColor),
          // scaffoldBackgroundColor: blackColor,
          // primarySwatch: Colors.blue,
          ),
      home: const SplashScreen(),
      builder: EasyLoading.init(),
    );
  }
}
