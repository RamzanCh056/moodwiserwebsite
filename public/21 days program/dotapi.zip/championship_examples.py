"""
OpenDota API Examples - Championship/League and Match Analysis
Demonstrates various use cases for fetching and analyzing Dota 2 tournament data
"""

from opendota_client import OpenDotaClient
import json
from datetime import datetime
from typing import List, Dict
import time


def example_1_fetch_major_leagues():
    """
    Example 1: Fetch information about major Dota 2 leagues and tournaments
    """
    print("=" * 60)
    print("EXAMPLE 1: Fetching Major League Information")
    print("=" * 60)
    
    client = OpenDotaClient()
    
    # Get all leagues
    leagues = client.get_leagues()
    
    # Filter for premium/major leagues (tier 'premium' or 'professional')
    major_leagues = [l for l in leagues if l.get('tier') in ['premium', 'professional']]
    
    print(f"\nFound {len(major_leagues)} major leagues/tournaments")
    print("\nRecent Major Tournaments:")
    print("-" * 40)
    
    # Display recent major leagues
    for league in major_leagues[:10]:
        print(f"ID: {league.get('leagueid', 'N/A')}")
        print(f"Name: {league.get('name', 'Unknown')}")
        print(f"Tier: {league.get('tier', 'N/A')}")
        print("-" * 40)
    
    return major_leagues


def example_2_analyze_specific_tournament(league_id: int = 15728):
    """
    Example 2: Deep dive into a specific tournament
    Default: The International 2023 (league_id = 15728)
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 2: Analyzing Specific Tournament")
    print("=" * 60)
    
    client = OpenDotaClient()
    
    # Get league details
    league = client.get_league_by_id(league_id)
    print(f"\nTournament: {league.get('name', 'Unknown')}")
    print(f"Tier: {league.get('tier', 'N/A')}")
    
    # Get teams in the tournament
    teams = client.get_league_teams(league_id)
    print(f"\nNumber of teams: {len(teams)}")
    
    if teams:
        print("\nTop 5 Teams by Rating:")
        print("-" * 40)
        # Sort teams by rating if available
        sorted_teams = sorted(teams, key=lambda x: x.get('rating', 0), reverse=True)
        for i, team in enumerate(sorted_teams[:5], 1):
            print(f"{i}. {team.get('name', 'Unknown Team')}")
            print(f"   Rating: {team.get('rating', 'N/A')}")
            print(f"   Wins: {team.get('wins', 0)} | Losses: {team.get('losses', 0)}")
    
    # Get match IDs
    match_ids = client.get_league_matches(league_id)
    print(f"\nTotal matches in tournament: {len(match_ids)}")
    
    # Analyze a few recent matches
    if match_ids:
        print("\nAnalyzing 3 recent matches...")
        for match_id in match_ids[:3]:
            time.sleep(1)  # Rate limiting
            try:
                match = client.get_match(match_id)
                print(f"\nMatch ID: {match_id}")
                print(f"Duration: {match.get('duration', 0) // 60} minutes")
                print(f"Radiant Win: {match.get('radiant_win', 'N/A')}")
                
                # Show team names if available
                if 'radiant_team' in match:
                    print(f"Radiant Team: {match['radiant_team'].get('name', 'Unknown')}")
                if 'dire_team' in match:
                    print(f"Dire Team: {match['dire_team'].get('name', 'Unknown')}")
            except Exception as e:
                print(f"Error fetching match {match_id}: {e}")
    
    return league, teams, match_ids


def example_3_live_pro_matches():
    """
    Example 3: Get currently live professional matches
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 3: Live Professional Matches")
    print("=" * 60)
    
    client = OpenDotaClient()
    
    live_matches = client.get_live_matches()
    
    if not live_matches:
        print("\nNo live professional matches at the moment.")
    else:
        print(f"\nFound {len(live_matches)} live professional matches:")
        print("-" * 40)
        
        for match in live_matches[:5]:  # Show first 5
            print(f"\nMatch ID: {match.get('match_id', 'N/A')}")
            print(f"Average MMR: {match.get('average_mmr', 'N/A')}")
            print(f"Game Time: {match.get('game_time', 0) // 60} minutes")
            
            # Show team names if available
            if 'team_name_radiant' in match:
                print(f"Radiant: {match['team_name_radiant']}")
            if 'team_name_dire' in match:
                print(f"Dire: {match['team_name_dire']}")
            
            # Show score
            radiant_score = match.get('radiant_score', 0)
            dire_score = match.get('dire_score', 0)
            print(f"Score: {radiant_score} - {dire_score}")
    
    return live_matches


def example_4_recent_pro_matches():
    """
    Example 4: Fetch and analyze recent professional matches
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 4: Recent Professional Matches")
    print("=" * 60)
    
    client = OpenDotaClient()
    
    # Get recent pro matches
    pro_matches = client.get_pro_matches()
    
    print(f"\nFound {len(pro_matches)} recent professional matches")
    
    # Analyze the first 5 matches
    print("\nRecent Pro Match Results:")
    print("-" * 40)
    
    for match in pro_matches[:5]:
        match_id = match.get('match_id')
        print(f"\nMatch ID: {match_id}")
        print(f"League: {match.get('league_name', 'Unknown')}")
        
        # Convert start time from unix timestamp
        start_time = match.get('start_time', 0)
        if start_time:
            dt = datetime.fromtimestamp(start_time)
            print(f"Played: {dt.strftime('%Y-%m-%d %H:%M')}")
        
        print(f"Duration: {match.get('duration', 0) // 60} minutes")
        
        # Team information
        radiant_name = match.get('radiant_name', 'Radiant')
        dire_name = match.get('dire_name', 'Dire')
        radiant_win = match.get('radiant_win', False)
        
        winner = radiant_name if radiant_win else dire_name
        print(f"Teams: {radiant_name} vs {dire_name}")
        print(f"Winner: {winner}")
    
    return pro_matches


def example_5_match_details_analysis(match_id: int = 7968443666):
    """
    Example 5: Deep analysis of a specific match
    Shows picks, bans, player performance, etc.
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 5: Detailed Match Analysis")
    print("=" * 60)
    
    client = OpenDotaClient()
    
    # Get full match details
    match = client.get_match(match_id)
    
    print(f"\nMatch ID: {match_id}")
    print(f"Duration: {match.get('duration', 0) // 60} minutes")
    print(f"Game Mode: {match.get('game_mode', 'N/A')}")
    print(f"Lobby Type: {match.get('lobby_type', 'N/A')}")
    
    # Team information
    if 'radiant_team' in match:
        print(f"\nRadiant Team: {match['radiant_team'].get('name', 'Unknown')}")
    if 'dire_team' in match:
        print(f"Dire Team: {match['dire_team'].get('name', 'Unknown')}")
    
    print(f"Radiant Win: {match.get('radiant_win', 'N/A')}")
    
    # Picks and Bans
    if 'picks_bans' in match and match['picks_bans']:
        print("\nDraft (First 6 picks/bans):")
        print("-" * 40)
        for i, pb in enumerate(match['picks_bans'][:6]):
            action = "Picked" if pb['is_pick'] else "Banned"
            team = "Radiant" if pb['team'] == 0 else "Dire"
            print(f"{i+1}. {team} {action} Hero ID: {pb['hero_id']}")
    
    # Player performances
    if 'players' in match:
        print("\nPlayer Performances:")
        print("-" * 40)
        
        # Sort players by kills for display
        players = sorted(match['players'], key=lambda x: x.get('kills', 0), reverse=True)
        
        for player in players[:5]:  # Top 5 by kills
            print(f"\nPlayer: {player.get('personaname', 'Unknown')}")
            print(f"Hero ID: {player.get('hero_id', 'N/A')}")
            print(f"K/D/A: {player.get('kills', 0)}/{player.get('deaths', 0)}/{player.get('assists', 0)}")
            print(f"GPM: {player.get('gold_per_min', 0)} | XPM: {player.get('xp_per_min', 0)}")
            print(f"Last Hits: {player.get('last_hits', 0)} | Denies: {player.get('denies', 0)}")
            print(f"Hero Damage: {player.get('hero_damage', 0):,}")
    
    # Objectives
    if 'objectives' in match and match['objectives']:
        print("\nFirst Blood and Objectives:")
        print("-" * 40)
        for obj in match['objectives'][:3]:  # First 3 objectives
            obj_time = obj.get('time', 0)
            obj_type = obj.get('type', 'unknown')
            print(f"Time {obj_time//60}:{obj_time%60:02d} - {obj_type}")
    
    return match


def example_6_team_analysis(team_id: int = 8254400):
    """
    Example 6: Analyze a specific team's performance
    Default: Team Spirit (team_id = 8254400)
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 6: Team Analysis")
    print("=" * 60)
    
    client = OpenDotaClient()
    
    # Get team information
    team = client.get_team(team_id)
    print(f"\nTeam: {team.get('name', 'Unknown')}")
    print(f"Tag: {team.get('tag', 'N/A')}")
    print(f"Rating: {team.get('rating', 'N/A')}")
    print(f"Wins: {team.get('wins', 0)} | Losses: {team.get('losses', 0)}")
    
    # Get team's recent matches
    matches = client.get_team_matches(team_id)
    print(f"\nTotal matches in database: {len(matches)}")
    
    if matches:
        print("\nRecent 5 Matches:")
        print("-" * 40)
        
        for match in matches[:5]:
            match_id = match.get('match_id')
            radiant = match.get('radiant', False)
            radiant_win = match.get('radiant_win', False)
            team_won = (radiant and radiant_win) or (not radiant and not radiant_win)
            
            result = "WON" if team_won else "LOST"
            duration = match.get('duration', 0) // 60
            
            print(f"Match {match_id}: {result} in {duration} minutes")
            
            if 'opposing_team_name' in match:
                print(f"  vs {match['opposing_team_name']}")
    
    # Get current roster
    players = client.get_team_players(team_id)
    print(f"\nCurrent and Former Players ({len(players)} total):")
    print("-" * 40)
    
    # Filter current players (those still active)
    current_players = [p for p in players if p.get('is_current_team_member')]
    
    for player in current_players[:5]:
        print(f"- {player.get('name', 'Unknown')} (Games: {player.get('games_played', 0)})")
    
    return team, matches, players


def example_7_player_in_tournaments(account_id: int = 321580662):
    """
    Example 7: Analyze a player's performance in tournaments
    Default: Yatoro (Team Spirit carry player)
    """
    print("\n" + "=" * 60)
    print("EXAMPLE 7: Player Tournament Performance")
    print("=" * 60)
    
    client = OpenDotaClient()
    
    # Get player info
    player = client.get_player(account_id)
    print(f"\nPlayer: {player.get('profile', {}).get('personaname', 'Unknown')}")
    print(f"Rank Tier: {player.get('rank_tier', 'N/A')}")
    print(f"Estimated MMR: {player.get('mmr_estimate', {}).get('estimate', 'N/A')}")
    
    # Get player's matches filtered by lobby type (tournament = 2)
    tournament_matches = client.get_player_matches(
        account_id=account_id,
        lobby_type=2,  # Tournament lobby
        limit=20
    )
    
    print(f"\nRecent Tournament Matches: {len(tournament_matches)}")
    
    if tournament_matches:
        wins = sum(1 for m in tournament_matches if m.get('player_slot', 0) < 128 and m.get('radiant_win') 
                  or m.get('player_slot', 0) >= 128 and not m.get('radiant_win'))
        
        print(f"Win Rate: {wins}/{len(tournament_matches)} ({100*wins/len(tournament_matches):.1f}%)")
        
        print("\nRecent Tournament Performances:")
        print("-" * 40)
        
        for match in tournament_matches[:5]:
            hero_id = match.get('hero_id')
            kills = match.get('kills', 0)
            deaths = match.get('deaths', 0)
            assists = match.get('assists', 0)
            
            # Determine if won
            is_radiant = match.get('player_slot', 0) < 128
            radiant_win = match.get('radiant_win', False)
            won = (is_radiant and radiant_win) or (not is_radiant and not radiant_win)
            
            result = "WON" if won else "LOST"
            
            print(f"\nMatch {match.get('match_id')}: {result}")
            print(f"  Hero ID: {hero_id}")
            print(f"  K/D/A: {kills}/{deaths}/{assists}")
            print(f"  Duration: {match.get('duration', 0)//60} min")
    
    return player, tournament_matches


def main():
    """
    Run all examples
    """
    print("OpenDota API - Championship and Match Data Examples")
    print("=" * 60)
    print("\nNOTE: Using free tier (no API key) - rate limited to 60 calls/min")
    print("Adding delays between requests to respect rate limits...")
    
    try:
        # Example 1: Fetch major leagues
        major_leagues = example_1_fetch_major_leagues()
        time.sleep(2)
        
        # Example 2: Analyze specific tournament (using first major league found)
        if major_leagues and len(major_leagues) > 0:
            league_id = major_leagues[0].get('leagueid')
            if league_id:
                example_2_analyze_specific_tournament(league_id)
        time.sleep(2)
        
        # Example 3: Live matches
        example_3_live_pro_matches()
        time.sleep(2)
        
        # Example 4: Recent pro matches
        pro_matches = example_4_recent_pro_matches()
        time.sleep(2)
        
        # Example 5: Match details (using a recent pro match if available)
        if pro_matches and len(pro_matches) > 0:
            recent_match_id = pro_matches[0].get('match_id')
            if recent_match_id:
                example_5_match_details_analysis(recent_match_id)
        time.sleep(2)
        
        # Example 6: Team analysis
        example_6_team_analysis()
        time.sleep(2)
        
        # Example 7: Player tournament performance
        example_7_player_in_tournaments()
        
    except Exception as e:
        print(f"\nError occurred: {e}")
        print("Note: Some examples might fail due to rate limiting or data availability")
    
    print("\n" + "=" * 60)
    print("Examples completed!")
    print("=" * 60)


if __name__ == "__main__":
    main()
