"""
OpenDota API Client for League/Championship and Match Data
Supports both authenticated (with API key) and anonymous access
"""

import requests
import time
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
import json


class OpenDotaClient:
    """
    A comprehensive client for OpenDota API with focus on leagues and matches
    """
    
    def __init__(self, api_key: Optional[str] = None, rate_limit_delay: float = 1.0):
        """
        Initialize the OpenDota client
        
        Args:
            api_key: Optional API key for higher rate limits
            rate_limit_delay: Delay between requests in seconds
        """
        self.base_url = "https://api.opendota.com/api"
        self.api_key = api_key
        self.rate_limit_delay = rate_limit_delay
        self.last_request_time = 0
        self.session = requests.Session()
        
    def _rate_limit(self):
        """Enforce rate limiting between requests"""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.rate_limit_delay:
            time.sleep(self.rate_limit_delay - elapsed)
        self.last_request_time = time.time()
    
    def _make_request(self, endpoint: str, params: Optional[Dict] = None) -> Any:
        """
        Make a rate-limited request to the API
        
        Args:
            endpoint: API endpoint (without base URL)
            params: Query parameters
            
        Returns:
            JSON response data
        """
        self._rate_limit()
        
        params = params or {}
        if self.api_key:
            params["api_key"] = self.api_key
        
        url = f"{self.base_url}/{endpoint}"
        
        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error making request to {endpoint}: {e}")
            raise
    
    # ==================== LEAGUE/CHAMPIONSHIP APIS ====================
    
    def get_leagues(self) -> List[Dict]:
        """
        Get list of all leagues
        
        Returns:
            List of league objects with leagueid, ticket, banner, tier, name
        """
        return self._make_request("leagues")
    
    def get_league_by_id(self, league_id: int) -> Dict:
        """
        Get detailed information about a specific league
        
        Args:
            league_id: The league ID
            
        Returns:
            League details including name, tier, region, etc.
        """
        return self._make_request(f"leagues/{league_id}")
    
    def get_league_matches(self, league_id: int) -> List[int]:
        """
        Get list of match IDs for a specific league
        
        Args:
            league_id: The league ID
            
        Returns:
            List of match IDs in the league
        """
        return self._make_request(f"leagues/{league_id}/matches")
    
    def get_league_teams(self, league_id: int) -> List[Dict]:
        """
        Get teams that participated in a league
        
        Args:
            league_id: The league ID
            
        Returns:
            List of team objects with team_id, rating, wins, losses, etc.
        """
        return self._make_request(f"leagues/{league_id}/teams")
    
    def get_pro_matches(self, less_than_match_id: Optional[int] = None) -> List[Dict]:
        """
        Get recent professional matches
        
        Args:
            less_than_match_id: Get matches with ID less than this value (for pagination)
            
        Returns:
            List of professional match objects
        """
        params = {}
        if less_than_match_id:
            params["less_than_match_id"] = less_than_match_id
        return self._make_request("proMatches", params)
    
    def get_live_matches(self) -> List[Dict]:
        """
        Get currently live professional matches
        
        Returns:
            List of live match objects with real-time data
        """
        return self._make_request("live")
    
    # ==================== MATCH APIS ====================
    
    def get_match(self, match_id: int) -> Dict:
        """
        Get detailed data for a specific match
        
        Args:
            match_id: The match ID
            
        Returns:
            Complete match data including players, picks, bans, objectives, etc.
        """
        return self._make_request(f"matches/{match_id}")
    
    def get_public_matches(self, 
                          less_than_match_id: Optional[int] = None,
                          min_rank: Optional[int] = None,
                          max_rank: Optional[int] = None) -> List[Dict]:
        """
        Get recent public matches
        
        Args:
            less_than_match_id: Get matches with ID less than this value
            min_rank: Minimum average rank
            max_rank: Maximum average rank
            
        Returns:
            List of public match objects
        """
        params = {}
        if less_than_match_id:
            params["less_than_match_id"] = less_than_match_id
        if min_rank:
            params["min_rank"] = min_rank
        if max_rank:
            params["max_rank"] = max_rank
        return self._make_request("publicMatches", params)
    
    def get_parsed_matches(self, less_than_match_id: Optional[int] = None) -> List[Dict]:
        """
        Get recently parsed matches (more detailed than public matches)
        
        Args:
            less_than_match_id: Get matches with ID less than this value
            
        Returns:
            List of parsed match objects with detailed statistics
        """
        params = {}
        if less_than_match_id:
            params["less_than_match_id"] = less_than_match_id
        return self._make_request("parsedMatches", params)
    
    # ==================== TEAM APIS ====================
    
    def get_teams(self, page: int = 0) -> List[Dict]:
        """
        Get list of teams
        
        Args:
            page: Page number for pagination
            
        Returns:
            List of team objects
        """
        return self._make_request("teams", {"page": page})
    
    def get_team(self, team_id: int) -> Dict:
        """
        Get detailed information about a specific team
        
        Args:
            team_id: The team ID
            
        Returns:
            Team details including roster, recent matches, etc.
        """
        return self._make_request(f"teams/{team_id}")
    
    def get_team_matches(self, team_id: int) -> List[Dict]:
        """
        Get matches for a specific team
        
        Args:
            team_id: The team ID
            
        Returns:
            List of match objects for the team
        """
        return self._make_request(f"teams/{team_id}/matches")
    
    def get_team_players(self, team_id: int) -> List[Dict]:
        """
        Get current and former players of a team
        
        Args:
            team_id: The team ID
            
        Returns:
            List of player objects with their tenure in the team
        """
        return self._make_request(f"teams/{team_id}/players")
    
    # ==================== HERO APIS ====================
    
    def get_heroes(self) -> List[Dict]:
        """
        Get list of heroes with their IDs and names
        
        Returns:
            List of hero objects
        """
        return self._make_request("heroes")
    
    def get_hero_stats(self) -> List[Dict]:
        """
        Get hero statistics across all matches
        
        Returns:
            List of hero stat objects with win rates, pick rates, etc.
        """
        return self._make_request("heroStats")
    
    # ==================== PLAYER APIS ====================
    
    def get_player(self, account_id: int) -> Dict:
        """
        Get player profile data
        
        Args:
            account_id: The player's account ID (32-bit)
            
        Returns:
            Player profile data
        """
        return self._make_request(f"players/{account_id}")
    
    def get_player_recent_matches(self, account_id: int) -> List[Dict]:
        """
        Get player's recent matches
        
        Args:
            account_id: The player's account ID
            
        Returns:
            List of recent match objects
        """
        return self._make_request(f"players/{account_id}/recentMatches")
    
    def get_player_matches(self, 
                          account_id: int,
                          limit: Optional[int] = None,
                          offset: Optional[int] = None,
                          win: Optional[bool] = None,
                          patch: Optional[int] = None,
                          game_mode: Optional[int] = None,
                          lobby_type: Optional[int] = None,
                          region: Optional[int] = None,
                          date: Optional[int] = None,
                          lane_role: Optional[int] = None,
                          hero_id: Optional[int] = None,
                          is_radiant: Optional[bool] = None,
                          included_account_id: Optional[int] = None,
                          excluded_account_id: Optional[int] = None,
                          with_hero_id: Optional[int] = None,
                          against_hero_id: Optional[int] = None,
                          significant: Optional[bool] = None,
                          having: Optional[int] = None,
                          sort: Optional[str] = None) -> List[Dict]:
        """
        Get filtered matches for a player
        
        Args:
            account_id: The player's account ID
            limit: Number of matches to limit to
            offset: Number of matches to offset start by
            win: Whether the player won
            patch: Patch ID
            game_mode: Game Mode ID
            lobby_type: Lobby type ID
            region: Region ID
            date: Days in the past
            lane_role: Lane Role ID
            hero_id: Hero ID
            is_radiant: Whether the player was on Radiant
            included_account_id: Account ID of a player on the player's team
            excluded_account_id: Account ID of a player not on the player's team
            with_hero_id: Hero ID of a player on the player's team
            against_hero_id: Hero ID of a player against the player's team
            significant: Whether the match was significant for aggregation purposes
            having: The minimum number of matches in the filtered match history
            sort: The field to return matches sorted by in descending order
            
        Returns:
            List of filtered match objects
        """
        params = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if win is not None:
            params["win"] = int(win)
        if patch is not None:
            params["patch"] = patch
        if game_mode is not None:
            params["game_mode"] = game_mode
        if lobby_type is not None:
            params["lobby_type"] = lobby_type
        if region is not None:
            params["region"] = region
        if date is not None:
            params["date"] = date
        if lane_role is not None:
            params["lane_role"] = lane_role
        if hero_id is not None:
            params["hero_id"] = hero_id
        if is_radiant is not None:
            params["is_radiant"] = int(is_radiant)
        if included_account_id is not None:
            params["included_account_id"] = included_account_id
        if excluded_account_id is not None:
            params["excluded_account_id"] = excluded_account_id
        if with_hero_id is not None:
            params["with_hero_id"] = with_hero_id
        if against_hero_id is not None:
            params["against_hero_id"] = against_hero_id
        if significant is not None:
            params["significant"] = int(significant)
        if having is not None:
            params["having"] = having
        if sort is not None:
            params["sort"] = sort
            
        return self._make_request(f"players/{account_id}/matches", params)
    
    # ==================== SEARCH APIS ====================
    
    def search_players(self, q: str) -> List[Dict]:
        """
        Search for players by name
        
        Args:
            q: Search query string
            
        Returns:
            List of player search results
        """
        return self._make_request("search", {"q": q})
    
    def find_matches(self, team_a: Optional[List[int]] = None,
                    team_b: Optional[List[int]] = None) -> List[Dict]:
        """
        Find matches by team composition
        
        Args:
            team_a: List of account IDs for team A
            team_b: List of account IDs for team B
            
        Returns:
            List of matches with specified teams
        """
        params = {}
        if team_a:
            params["teamA"] = ",".join(map(str, team_a))
        if team_b:
            params["teamB"] = ",".join(map(str, team_b))
        return self._make_request("findMatches", params)
    
    # ==================== RANKING/LEADERBOARD APIS ====================
    
    def get_rankings(self, hero_id: int) -> Dict:
        """
        Get hero rankings/leaderboard
        
        Args:
            hero_id: The hero ID
            
        Returns:
            Rankings data for the hero
        """
        return self._make_request(f"rankings", {"hero_id": hero_id})
    
    def get_pro_players(self) -> List[Dict]:
        """
        Get list of professional players
        
        Returns:
            List of pro player objects
        """
        return self._make_request("proPlayers")
    
    # ==================== UTILITY METHODS ====================
    
    def get_match_details_batch(self, match_ids: List[int], delay: float = 1.0) -> List[Dict]:
        """
        Get details for multiple matches with rate limiting
        
        Args:
            match_ids: List of match IDs to fetch
            delay: Delay between requests in seconds
            
        Returns:
            List of match detail objects
        """
        matches = []
        for i, match_id in enumerate(match_ids):
            try:
                print(f"Fetching match {i+1}/{len(match_ids)}: {match_id}")
                match_data = self.get_match(match_id)
                matches.append(match_data)
                if delay > 0 and i < len(match_ids) - 1:
                    time.sleep(delay)
            except Exception as e:
                print(f"Error fetching match {match_id}: {e}")
                continue
        return matches
    
    def get_league_full_data(self, league_id: int) -> Dict:
        """
        Get comprehensive data about a league including matches and teams
        
        Args:
            league_id: The league ID
            
        Returns:
            Dictionary with league info, teams, and recent matches
        """
        result = {
            "league_info": self.get_league_by_id(league_id),
            "teams": self.get_league_teams(league_id),
            "match_ids": self.get_league_matches(league_id)
        }
        
        # Get details for the most recent 10 matches
        if result["match_ids"]:
            recent_match_ids = result["match_ids"][:10]
            result["recent_matches"] = self.get_match_details_batch(recent_match_ids)
        
        return result
