# OpenDota API Client - Championship & Match Data

A comprehensive Python client for fetching Dota 2 championship/league and match data from the OpenDota API.

## 🚀 Quick Start

### No API Key Required!
The OpenDota API offers a generous free tier that doesn't require any API key:
- **2000 calls per month**
- **60 calls per minute**
- Perfect for most projects!

### Installation

```bash
# Install required package
pip install requests

# Run the quick start script
python quick_start.py
```

## 📁 Files Included

1. **`quick_start.py`** - Simple script to get started immediately (no API key needed)
2. **`opendota_client.py`** - Full-featured client with all API endpoints
3. **`championship_examples.py`** - Comprehensive examples for all use cases

## 🎮 Key Features

### Championship/League Data
- Fetch all leagues and tournaments
- Get tournament details (teams, matches, standings)
- Track live professional matches
- Analyze recent pro matches

### Match Data
- Detailed match analysis (picks, bans, player stats)
- Public matches with filters
- Player performance tracking
- Team statistics

## 📊 Example Usage

### Basic Usage (No API Key)

```python
import requests

# Base URL
BASE_URL = "https://api.opendota.com/api"

# Get recent pro matches
response = requests.get(f"{BASE_URL}/proMatches")
matches = response.json()

# Get league info
league_id = 15728  # The International 2023
response = requests.get(f"{BASE_URL}/leagues/{league_id}")
league_info = response.json()
```

### Using the Full Client

```python
from opendota_client import OpenDotaClient

# Initialize client (no API key needed)
client = OpenDotaClient()

# Get major leagues
leagues = client.get_leagues()
major_leagues = [l for l in leagues if l.get('tier') == 'premium']

# Get tournament details
league_id = 15728
teams = client.get_league_teams(league_id)
matches = client.get_league_matches(league_id)

# Get live matches
live_matches = client.get_live_matches()

# Analyze specific match
match = client.get_match(7968443666)
```

## 🔑 API Endpoints

### League/Championship Endpoints
- `GET /leagues` - List all leagues
- `GET /leagues/{id}` - Get league details
- `GET /leagues/{id}/matches` - Get league matches
- `GET /leagues/{id}/teams` - Get league teams
- `GET /proMatches` - Recent professional matches
- `GET /live` - Live matches

### Match Endpoints
- `GET /matches/{id}` - Detailed match data
- `GET /publicMatches` - Recent public matches
- `GET /parsedMatches` - Parsed matches with stats

### Team Endpoints
- `GET /teams` - List teams
- `GET /teams/{id}` - Team details
- `GET /teams/{id}/matches` - Team matches
- `GET /teams/{id}/players` - Team roster

### Player Endpoints
- `GET /players/{id}` - Player profile
- `GET /players/{id}/matches` - Player matches
- `GET /players/{id}/recentMatches` - Recent matches
- `GET /search` - Search players by name

## ⚡ Rate Limiting

### Without API Key
- 60 requests per minute
- 2000 requests per month
- Add 1-second delay between requests

### With API Key (Free Tier)
- 1200 requests per minute
- 50,000 requests per month
- Add 0.5-second delay between requests

### Best Practices
```python
import time

# Always add delays between requests
def fetch_with_delay(url, delay=1.0):
    response = requests.get(url)
    time.sleep(delay)  # Rate limiting
    return response.json()
```

## 🏆 Common Use Cases

### 1. Track Tournament Progress
```python
# Get ongoing tournament
leagues = client.get_leagues()
current_tournament = leagues[0]  # Most recent

# Track matches
matches = client.get_league_matches(current_tournament['leagueid'])
for match_id in matches[:5]:
    match = client.get_match(match_id)
    print(f"Winner: {'Radiant' if match['radiant_win'] else 'Dire'}")
```

### 2. Analyze Team Performance
```python
# Team Spirit analysis
team_id = 8254400
team = client.get_team(team_id)
matches = client.get_team_matches(team_id)

wins = sum(1 for m in matches if 
          (m['radiant'] and m['radiant_win']) or 
          (not m['radiant'] and not m['radiant_win']))

print(f"Win rate: {wins/len(matches)*100:.1f}%")
```

### 3. Player Statistics
```python
# Get player's tournament matches
account_id = 321580662  # Yatoro
matches = client.get_player_matches(
    account_id=account_id,
    lobby_type=2,  # Tournament lobby
    limit=20
)
```

## 🐛 Troubleshooting

### Rate Limit Errors
If you get 429 errors, you're hitting rate limits:
- Add longer delays between requests
- Consider getting a free API key for higher limits

### No Payment Required
The payment form you saw is for Premium tier (>50,000 calls/month). You can:
1. Skip the payment form
2. Use the API without any key
3. Or close the modal to access your free API key

## 📚 Resources

- **API Documentation**: https://docs.opendota.com
- **OpenDota Website**: https://www.opendota.com
- **Create Free Account**: https://www.opendota.com/login

## 💻 Run Examples

```bash
# Quick summary of championships and matches
python quick_start.py

# Full examples with all features
python championship_examples.py

# Import and use in your own code
from opendota_client import OpenDotaClient
client = OpenDotaClient()
```

## 📈 Data Available

- **Leagues**: 1000+ tournaments and leagues
- **Matches**: Millions of parsed matches
- **Players**: Stats for all public players
- **Teams**: Professional team data
- **Heroes**: Pick/ban rates and win rates
- **Live Data**: Real-time match updates

## 🎯 Next Steps

1. Run `quick_start.py` to see it working
2. Explore the examples in `championship_examples.py`
3. Use `opendota_client.py` in your own projects
4. Consider getting a free API key for higher limits (optional)

Happy coding! 🎮
