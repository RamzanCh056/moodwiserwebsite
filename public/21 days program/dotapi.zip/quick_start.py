"""
Quick Start: Fetch Dota 2 Championship and Match Data
No API key required - uses OpenDota's free tier
"""

import requests
import json
import time
from datetime import datetime

# Base URL for OpenDota API
BASE_URL = "https://api.opendota.com/api"


def make_request(endpoint, params=None):
    """Make a request to OpenDota API with basic error handling"""
    url = f"{BASE_URL}/{endpoint}"
    try:
        response = requests.get(url, params=params, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return None


def get_major_tournaments():
    """Get list of major Dota 2 tournaments/leagues"""
    print("\n🏆 FETCHING MAJOR TOURNAMENTS...")
    print("-" * 50)
    
    leagues = make_request("leagues")
    if not leagues:
        return []
    
    # Filter for major tournaments (premium/professional tier)
    major_leagues = [
        l for l in leagues 
        if l.get('tier') in ['premium', 'professional'] 
        and l.get('name')  # Has a name
    ]
    
    # Sort by league ID (newer tournaments have higher IDs)
    major_leagues.sort(key=lambda x: x.get('leagueid', 0), reverse=True)
    
    print(f"Found {len(major_leagues)} major tournaments\n")
    
    # Display top 10 recent major tournaments
    for i, league in enumerate(major_leagues[:10], 1):
        print(f"{i}. {league.get('name')}")
        print(f"   ID: {league.get('leagueid')} | Tier: {league.get('tier')}")
        print()
    
    return major_leagues


def get_tournament_details(league_id):
    """Get detailed information about a specific tournament"""
    print(f"\n📊 TOURNAMENT DETAILS (ID: {league_id})")
    print("-" * 50)
    
    # Get league info
    league = make_request(f"leagues/{league_id}")
    if league:
        print(f"Name: {league.get('name', 'Unknown')}")
        print(f"Tier: {league.get('tier', 'N/A')}")
    
    time.sleep(1)  # Rate limiting
    
    # Get teams
    teams = make_request(f"leagues/{league_id}/teams")
    if teams:
        print(f"\nTeams Participated: {len(teams)}")
        
        # Show top 3 teams by rating
        sorted_teams = sorted(teams, key=lambda x: x.get('rating', 0), reverse=True)[:3]
        print("\nTop Teams:")
        for i, team in enumerate(sorted_teams, 1):
            wins = team.get('wins', 0)
            losses = team.get('losses', 0)
            print(f"{i}. {team.get('name', 'Unknown')}")
            print(f"   W/L: {wins}-{losses} | Rating: {team.get('rating', 'N/A')}")
    
    time.sleep(1)  # Rate limiting
    
    # Get match count
    matches = make_request(f"leagues/{league_id}/matches")
    if matches:
        print(f"\nTotal Matches: {len(matches)}")
        
        # Show sample match IDs
        print(f"Sample Match IDs: {matches[:3]}")
    
    return league, teams, matches


def get_live_matches():
    """Get currently live professional matches"""
    print("\n🔴 LIVE PROFESSIONAL MATCHES")
    print("-" * 50)
    
    live_matches = make_request("live")
    
    if not live_matches:
        print("No live professional matches at the moment")
        return []
    
    print(f"Found {len(live_matches)} live matches\n")
    
    # Display first 5 live matches
    for match in live_matches[:5]:
        match_id = match.get('match_id', 'N/A')
        game_time = match.get('game_time', 0) // 60
        
        print(f"Match ID: {match_id}")
        print(f"Game Time: {game_time} minutes")
        
        # Team names
        radiant = match.get('team_name_radiant', 'Radiant')
        dire = match.get('team_name_dire', 'Dire')
        print(f"Teams: {radiant} vs {dire}")
        
        # Score
        radiant_score = match.get('radiant_score', 0)
        dire_score = match.get('dire_score', 0)
        print(f"Score: {radiant_score} - {dire_score}")
        print()
    
    return live_matches


def get_recent_pro_matches(limit=10):
    """Get recent professional matches"""
    print(f"\n📅 RECENT PROFESSIONAL MATCHES (Last {limit})")
    print("-" * 50)
    
    pro_matches = make_request("proMatches")
    
    if not pro_matches:
        print("Could not fetch pro matches")
        return []
    
    # Display recent matches
    for match in pro_matches[:limit]:
        match_id = match.get('match_id')
        league_name = match.get('league_name', 'Unknown League')
        
        # Teams
        radiant = match.get('radiant_name', 'Radiant')
        dire = match.get('dire_name', 'Dire')
        
        # Winner
        radiant_win = match.get('radiant_win', False)
        winner = radiant if radiant_win else dire
        
        # Time
        start_time = match.get('start_time', 0)
        if start_time:
            dt = datetime.fromtimestamp(start_time)
            time_str = dt.strftime('%Y-%m-%d %H:%M')
        else:
            time_str = 'Unknown'
        
        print(f"\n{match_id}: {radiant} vs {dire}")
        print(f"  League: {league_name}")
        print(f"  Winner: {winner}")
        print(f"  Time: {time_str}")
        print(f"  Duration: {match.get('duration', 0)//60} min")
    
    return pro_matches


def analyze_match(match_id):
    """Get detailed analysis of a specific match"""
    print(f"\n🎮 MATCH ANALYSIS (ID: {match_id})")
    print("-" * 50)
    
    match = make_request(f"matches/{match_id}")
    
    if not match:
        print("Could not fetch match details")
        return None
    
    # Basic info
    print(f"Duration: {match.get('duration', 0)//60} minutes")
    print(f"Winner: {'Radiant' if match.get('radiant_win') else 'Dire'}")
    
    # Teams
    if 'radiant_team' in match:
        print(f"Radiant: {match['radiant_team'].get('name', 'Unknown')}")
    if 'dire_team' in match:
        print(f"Dire: {match['dire_team'].get('name', 'Unknown')}")
    
    # Top performers
    if 'players' in match:
        print("\nTop Performers (by kills):")
        players = sorted(match['players'], key=lambda x: x.get('kills', 0), reverse=True)[:3]
        
        for i, player in enumerate(players, 1):
            name = player.get('personaname', 'Unknown')
            kills = player.get('kills', 0)
            deaths = player.get('deaths', 0)
            assists = player.get('assists', 0)
            print(f"{i}. {name}: {kills}/{deaths}/{assists} K/D/A")
    
    # First blood
    if 'objectives' in match:
        for obj in match['objectives']:
            if obj.get('type') == 'CHAT_MESSAGE_FIRSTBLOOD':
                fb_time = obj.get('time', 0)
                print(f"\nFirst Blood: {fb_time//60}:{fb_time%60:02d}")
                break
    
    return match


def quick_championship_summary():
    """
    Quick summary function that fetches and displays championship and match data
    This is the main function you should run
    """
    print("\n" + "="*60)
    print(" DOTA 2 CHAMPIONSHIP & MATCH DATA - QUICK SUMMARY")
    print("="*60)
    print("\nUsing OpenDota API (Free Tier - No API Key Required)")
    print("Rate Limited: Adding delays between requests...")
    
    try:
        # 1. Get major tournaments
        tournaments = get_major_tournaments()
        time.sleep(1)
        
        # 2. Get details of the most recent major tournament
        if tournaments:
            recent_tournament = tournaments[0]
            league_id = recent_tournament.get('leagueid')
            if league_id:
                get_tournament_details(league_id)
                time.sleep(1)
        
        # 3. Check live matches
        get_live_matches()
        time.sleep(1)
        
        # 4. Get recent pro matches
        pro_matches = get_recent_pro_matches(5)
        time.sleep(1)
        
        # 5. Analyze a recent match
        if pro_matches:
            recent_match_id = pro_matches[0].get('match_id')
            if recent_match_id:
                analyze_match(recent_match_id)
        
        print("\n" + "="*60)
        print(" ✅ SUMMARY COMPLETE!")
        print("="*60)
        
        # Print useful tips
        print("\n💡 TIPS FOR USING THE API:")
        print("1. No API key needed for basic access")
        print("2. Rate limit: 60 requests per minute")
        print("3. Add delays between requests (1 second recommended)")
        print("4. For higher limits, create free account at opendota.com")
        print("5. Full documentation: https://docs.opendota.com")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("This might be due to rate limiting. Try again in a minute.")


# Additional utility functions for specific use cases

def search_player_by_name(player_name):
    """Search for a player by name"""
    print(f"\n🔍 SEARCHING FOR PLAYER: {player_name}")
    print("-" * 50)
    
    results = make_request("search", {"q": player_name})
    
    if not results:
        print("No results found")
        return []
    
    print(f"Found {len(results)} results:\n")
    
    for player in results[:5]:
        print(f"- {player.get('personaname')}")
        print(f"  Account ID: {player.get('account_id')}")
        print()
    
    return results


def get_hero_stats():
    """Get hero statistics"""
    print("\n🦸 HERO STATISTICS")
    print("-" * 50)
    
    stats = make_request("heroStats")
    
    if not stats:
        print("Could not fetch hero stats")
        return []
    
    # Sort by pick rate
    sorted_heroes = sorted(stats, key=lambda x: x.get('pro_pick', 0), reverse=True)[:5]
    
    print("Top 5 Most Picked Heroes in Pro Games:\n")
    
    for i, hero in enumerate(sorted_heroes, 1):
        picks = hero.get('pro_pick', 0)
        wins = hero.get('pro_win', 0)
        win_rate = (wins / picks * 100) if picks > 0 else 0
        
        print(f"{i}. Hero ID: {hero.get('hero_id')}")
        print(f"   Picks: {picks} | Win Rate: {win_rate:.1f}%")
        print()
    
    return stats


if __name__ == "__main__":
    # Run the quick summary
    quick_championship_summary()
    
    # Uncomment below to test specific functions:
    
    # Search for a specific player
    # time.sleep(2)
    # search_player_by_name("Miracle")
    
    # Get hero statistics
    # time.sleep(2)
    # get_hero_stats()
